#include "GraduationPlan.h"

void GraduationPlan::printGradPlan( )
{
   // something...
}
/*
GraduationPlan& GraduationPlan::operator=(const GraduationPlan& rhs)
{
   //if they're not the same object
   if ( this != &rhs )
   {
      m_studentName = rhs.m_studentName;
      m_startingSemester = rhs.m_startingSemester;
      m_major = rhs.m_major;
      m_minor = rhs.m_minor;
      m_plan.clear();
      m_plan = rhs.m_plan;
      m_remainReqs.clear();
      m_remainReqs = rhs.m_remainReqs;
   }
   return *this;
}
*/
void GraduationPlan::viewGradPlan( )
{
   // will make a version that has an input and one that does not.
   // so we can have a range
}

void GraduationPlan::modifyGradPlan( )
{
   // so you make the plan, and then you add it, and you pass this the plan and a number
   // if the number is 1 you add
   // else you delete the one that matches the plan?
   // i don't know?
   // calls, addSemester or deleteSemester.
}

void GraduationPlan::viewRemain( )
{
   for ( unsigned int i = 0; i < m_remainReqs.size( ); ++i )
   {
      cout << m_remainReqs.at(i).getDesg( ) << " "
	   << m_remainReqs.at(i).getNumber( ) << " "
	   << m_remainReqs.at(i).getTitle( ) << endl;
   }
}

void GraduationPlan::listSemesters( )
{
   for ( unsigned int i = 0; i < m_plan.size( ); ++i )
   {
      cout << i << " " << m_plan.at(i).getDesg() << " "
	   << m_plan.at(i).getYear() << endl;
   }
}

int GraduationPlan::numSemesters( )
{
   return static_cast<int>(m_plan.size());
}

Semester GraduationPlan::getSemester( int index )
{
   return m_plan.at(index);
}

string GraduationPlan::getName( )
{
   return m_studentName;
}

string GraduationPlan::getMajor( )
{
   return m_major;
}

string GraduationPlan::getMinor( )
{
   return m_minor;
}

vector<Course> GraduationPlan::getRemainReqs( )
{
   return m_remainReqs;
}
