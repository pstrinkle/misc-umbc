#ifndef _New_h
#define _New_h

#include <iostream>
#include <string>
#include <vector>

#include "Proj.h"
#include "Course.h"
#include "GraduationPlan.h"

const int MJ1 = 0;
const int MJ2 = 1;
const int MJ3 = 2;
const int MJ4 = 3;

using namespace std;

GraduationPlan newPlan( vector<Course> & courseList );

GraduationPlan buildPlan ( vector<Course> & courseList );

vector<Course> getMajorReqs( int major, vector<Course> & courseList );

#endif
