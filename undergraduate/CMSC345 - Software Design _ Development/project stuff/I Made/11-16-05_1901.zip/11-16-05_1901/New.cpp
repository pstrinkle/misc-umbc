#include "New.h"



using namespace std;

GraduationPlan newPlan( vector<Course> & courseList )
{
   system("clear");
   string screenTitle = "New Graduation Plan";
   PrintGreeting( screenTitle );

   string firstName;
   string lastName;
   string major;
   string minor = "None";
   string startingSemesterDesig;
   int startingSemesterYear;
   char validResponse;
   char majorResponse;
   vector<Course> reqCourses;


   vector<char> choices;
   choices.push_back( 'Y' );
   choices.push_back( 'N' );

   vector<char> majorChoices;
   majorChoices.push_back( 'A' );
   majorChoices.push_back( 'B' );
   majorChoices.push_back( 'C' );
   majorChoices.push_back( 'D' );

   do
   {

      cout << "Enter First Name: ";
      cin >> firstName;
      cout << "Enter Last Name: ";
      cin >> lastName;

      cout << "Pick Major: " << endl;
      cout << "\tA - CMSC Major" << endl
	   << "\tB - IS Major" << endl
	   << "\tC - IS Major CMSC Minor" << endl
	   << "\tD - IS CMSC Double Major" << endl;

      majorResponse = GetMenuResponse( majorChoices );

      switch( majorResponse )
      {
	 case 'A':
	    major = "CMSC";
	    reqCourses = getMajorReqs( MJ1, courseList );
	    break;
	 case 'B':
	    major = "IS";
	    reqCourses = getMajorReqs( MJ2, courseList );
	    break;
	 case 'C':
	    major = "IS";
	    minor = "CMSC";
	    reqCourses = getMajorReqs( MJ3, courseList );
	    break;
	 case 'D':
	    major = "CMSC and IS";
	    reqCourses = getMajorReqs( MJ4, courseList );
	    break;
      }

      cout << endl << "Starting Semester Information:" << endl;
      cout << "Enter Starting Semester Designator (i.e. FL, SP): ";
      cin >> startingSemesterDesig;
      cout << "Enter Starting Semester Year (i.e. 2005): ";
      cin >> startingSemesterYear;
      
      firstName += " ";
      firstName += lastName;
      
      cout << "You entered:" << endl
	   << "Name: " << firstName << endl
	   << "Major: " << major << endl
	   << "Minor: " << minor << endl
	   << "Starting Semester: " << startingSemesterDesig << " " 
	   << startingSemesterYear << endl;

      cout << endl << "Is this correct (y/n): ";

      validResponse = GetMenuResponse( choices );
      
   } while ( validResponse == 'N' );

   Semester starting(startingSemesterDesig, startingSemesterYear);
   
   vector<Semester> semesters;
   semesters.push_back(starting);

   return GraduationPlan(firstName, starting, major, minor, semesters, reqCourses);
}


vector<Course> getMajorReqs( int major, vector<Course> & courseList )
{
   string designator;
   int number;

   vector<Course> majorReqs;

   // get GFR's first

   ifstream inStream( "GFR.txt" );
   if ( inStream == NULL )
   {
      cerr << "Invalid GFR File." << endl
	   << "Should be: GFR.txt" << endl;
      exit(-2);
   }

   while ( inStream >> designator )
   {
      inStream >> number;
      Course temp( "General Foundation Requirement", number, designator );
      majorReqs.push_back( temp );
   }
   inStream.close();

   ifstream inStreamCMSC( "CMSC_Maj.txt" );
   if ( inStreamCMSC == NULL )
   {
      cerr << "Invalid CMSC Major File." << endl
	   << "Should be: CMSC_Maj.txt" << endl;
      exit(-2);
   }

   ifstream inStreamIS( "IS_Maj.txt" );
   if ( inStreamIS == NULL )
   {
      cerr << "Invalid IS Major File." << endl
	   << "Should be: IS_Maj.txt" << endl;
      exit(-2);
   }

   ifstream inStreamISMajCMSCMin( "IS_Maj_CMSC_Min.txt" );
   if ( inStreamISMajCMSCMin == NULL )
   {
      cerr << "Invalid IS Major CMSC Minor File." << endl
	   << "Should be: IS_Maj_CMSC_Min.txt" << endl;
      exit(-2);
   }

   ifstream inStreamISCMSC( "IS_CMSC_Dbl_Maj.txt" );
   if ( inStreamISCMSC == NULL )
   {
      cerr << "Invalid IS CMSC Double Major File." << endl
	   << "Should be: IS_CMSC_Dbl_Maj.txt" << endl;
      exit(-2);
   }

   switch( major )
   {
      case MJ1:
	 while ( inStreamCMSC >> designator )
	 {
	    inStreamCMSC >> number;
	    Course temp = retrieveCourseInfo(designator, number, courseList);
	    majorReqs.push_back(temp);
	 }
	 break;
      case MJ2:
	 while ( inStreamIS >> designator )
	 {
	    inStreamIS >> number;
	    Course temp2 = retrieveCourseInfo(designator, number, courseList);
	    majorReqs.push_back(temp2);
	 }
	 break;
      case MJ3:
	 while ( inStreamISMajCMSCMin >> designator )
	 {
	    inStreamISMajCMSCMin >> number;
	    Course temp3 = retrieveCourseInfo(designator, number, courseList);
	    majorReqs.push_back(temp3);
	 }
	 break;
      case MJ4:
	 while ( inStreamISCMSC >> designator )
	 {
	    inStreamISCMSC >> number;
	    Course temp4 = retrieveCourseInfo(designator, number, courseList);
	    majorReqs.push_back(temp4);
	 }
	 break;
   }

   inStreamCMSC.close();
   inStreamIS.close();
   inStreamISMajCMSCMin.close();
   inStreamISCMSC.close();

   return majorReqs;
}

GraduationPlan buildPlan( vector<Course> & courseList )
{

   ifstream inStream( "GraduationPlan.txt" );
   if ( inStream == NULL )
   {
      cerr << "Invalid GraduationPlan File." << endl
	   << "Should be: GraduationPlan.txt" << endl;
      exit(-3);
   }

   string next;
   string name;
   string cmd;
   string comments;
   string designator;
   string semDesignator;
   string major;
   string minor;
   string firstName;
   string lastName;
   char grade;
   int number;
   int numCourses;
   int year;
   vector<Semester> semesters;
   vector<Course> courses;
   vector<Course> remainder;

   while ( inStream >> next )
   {
      if ( next == START )
      {
	 semesters.clear();
	 inStream >> firstName >> lastName;
	 inStream >> major;
	 inStream >> minor;
      }
      
      else if ( next == ADD )
      {
	 inStream >> cmd;
	 if ( cmd == SEM )
	 {
	    inStream >> semDesignator >> year >> numCourses;
	    
	    courses.clear();

	    for ( int i = 0; i < numCourses; ++i )
	    {
	       inStream >> designator >> number >> grade;
	       getline(inStream, comments);
	       Course temp = retrieveCourseInfo(designator, number, courseList);
	       temp.inputComments(comments);
	       temp.inputnewGrade(grade);

	       courses.push_back(temp);
	    }

	    Semester tempSem(semDesignator, year, courses);

	    semesters.push_back(tempSem);
	 }
	 else if ( cmd == REM )
	 {
	    inStream >> numCourses;
	    
	    remainder.clear();
	    
	    for ( int j = 0; j < numCourses; ++j )
	    {
	       inStream >> designator >> number;
	       Course tempRem = retrieveCourseInfo(designator, number, courseList);
	       remainder.push_back(tempRem);
	    }
	 }
	  
      }
   }
   
   Semester startingSemester = semesters.at(0);

   firstName += " ";
   firstName += lastName;

   GraduationPlan gradplan(firstName, startingSemester, major, minor, semesters, remainder);
   
   return gradplan;
}
