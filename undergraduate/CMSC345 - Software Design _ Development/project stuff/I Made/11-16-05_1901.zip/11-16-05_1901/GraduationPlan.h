#ifndef _GraduationPlan_h
#define _GraduationPlan_h

#include "Semester.h"

#include <vector>
#include <string>

using namespace std;

class GraduationPlan
{

  public:
   GraduationPlan( string studentName, Semester startingSemester, string major, string minor )
      :m_studentName(studentName), 
      m_startingSemester(startingSemester), 
      m_major(major), 
      m_minor(minor)
    {
       m_plan.push_back(startingSemester);
    }

   GraduationPlan( string studentName = "default", string major = "None", string minor = "None" )
      :m_studentName(studentName), 
      m_startingSemester("default",6666), 
      m_major(major), 
      m_minor(minor)
      {
      }

   GraduationPlan( string studentName, Semester startingSemester, string major, string minor, vector<Course> reqs )
      :m_studentName(studentName), 
      m_startingSemester(startingSemester), 
      m_major(major), 
      m_minor(minor), 
      m_remainReqs(reqs)
      {
      }

   GraduationPlan( string studentName, Semester startingSemester, string major, string minor, vector<Semester> semesters, vector<Course> reqs )
      :m_studentName(studentName), 
      m_startingSemester(startingSemester), 
      m_major(major), 
      m_minor(minor), 
      m_plan(semesters), 
      m_remainReqs(reqs)
      {
      }

   //GraduationPlan& operator=( const Course& rhs );

   void           printGradPlan( );
   void           viewGradPlan( );
   void           modifyGradPlan( );
   void           viewRemain( );
   void           listSemesters( );
   int            numSemesters( );
   Semester       getSemester( int index );
   string         getName( );
   string         getMajor( );
   string         getMinor( );
   vector<Course> getRemainReqs( );
   

  private:
   string           m_studentName;
   Semester         m_startingSemester;
   string           m_major;
   string           m_minor;
   vector<Semester> m_plan;
   vector<Course>   m_remainReqs; //has major & GFR reqs

   void addSemester( );
   void deleteSemester( );

};

#endif
