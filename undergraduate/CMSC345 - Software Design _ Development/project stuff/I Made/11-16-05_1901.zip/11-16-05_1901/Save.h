#ifndef _Save_h
#define _Save_h

#include <iostream>
#include <string>
#include <vector>

#include "Proj.h"
#include "Course.h"
#include "GraduationPlan.h"

using namespace std;

void save( GraduationPlan & gradplan );

#endif
