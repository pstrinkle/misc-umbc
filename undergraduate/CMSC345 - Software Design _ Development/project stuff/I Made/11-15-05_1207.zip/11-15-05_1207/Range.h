
#ifndef _Range_h
#define _Range_h

#include <string>

using namespace std;

class Range
{
  public:
   Range( int strtyear, string strtdesg, int endyear, string enddesg )
      : m_startyear(strtyear), m_endyear(endyear), m_startdesg(strtdesg), m_enddesg(enddesg)
    {
    }

   int    getStartYear( );
   int    getEndYear( );
   string getStartDesg( );
   string getEndDesg( );

// some accessors
   
  private:
   int    m_startyear;
   int    m_endyear;
   string m_startdesg;
   string m_enddesg;

};

#endif
