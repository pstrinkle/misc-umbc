#include "Course.h"

using namespace std;

int Course::getNumber( )
{
   return m_number;
}

string Course::getTitle( )
{
   return m_title;
}

string Course::getDesg( )
{
   return m_designator;
}

string Course::getComments( )
{
   return m_comments;
}

char Course::inputnewGrade( char newGrade )
{
   char oldGrade = m_grade;
   m_grade = newGrade;
   return oldGrade;
}

void Course::inputComments( string newComments )
{
   m_comments = newComments;
}
