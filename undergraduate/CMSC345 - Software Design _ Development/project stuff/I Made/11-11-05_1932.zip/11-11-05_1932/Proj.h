#ifndef _Proj_h
#define _Proj_h

#include <ctype.h>
#include <iostream>
#include <vector>
#include <string>

using namespace std;

char displayMainMenu( );

char GetMenuResponse ( const vector<char> & theChoices );

void PrintGreeting ( string title );

bool validateSelection ( const char choice, const vector<char> & theChoices );

#endif
