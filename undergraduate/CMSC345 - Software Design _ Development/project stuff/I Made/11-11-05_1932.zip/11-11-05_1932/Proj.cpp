#include "Course.h"
#include "Semester.h"
#include "GraduationPlan.h"


#include "Proj.h"
#include "View.h"

using namespace std;

int main()
{

   // do database stuff

   // either it returns null and we build one or
   // it has one and builds

   // here we have a GraduationPlan.

   vector<Course> fakeprereqs;
   vector<Course> fakecourses;
   Course fake("Program Design", 345, "CMSC", fakeprereqs);
   fakecourses.push_back(fake);
   Semester fakesemester("FL", 2005, fakecourses);
   GraduationPlan gradplan("Patrick Trinkle", fakesemester, "CMSC");

   char validResponse;

   do
   {
      validResponse = displayMainMenu( );

      switch( validResponse ) 
      {
	 case 'N':
	    // newStudent( );
	    break;
	 case 'M':
	    // modify( );
	    break;
	 case 'V':
	    view( gradplan );
	    break;
	 case 'P':
	    // print( );
	    break;
	 case 'Q':
	    break;
	 default:
	    cerr << "Invalid menu selection, please try again!"
		 << endl;
	    break;
      }
   } while ( validResponse != 'Q' );


   return 0;
}
