#include "Course.h"

using namespace std;

bool Course::operator==( const Course& rhs )
{
   bool sameness = false;
   
   if ( this == &rhs )
      sameness = true;
   
   else if ( getTitle() == rhs.getTitle() && getNumber() == rhs.getNumber() && getDesg() == rhs.getDesg() )
      sameness = true;

   return sameness;
}


int Course::getNumber( ) const
{
   return m_number;
}

string Course::getTitle( ) const
{
   return m_title;
}

string Course::getDesg( ) const
{
   return m_designator;
}

string Course::getComments( ) const
{
   return m_comments;
}

char Course::inputnewGrade( char newGrade )
{
   char oldGrade = m_grade;
   m_grade = newGrade;
   return oldGrade;
}

void Course::inputComments( string newComments )
{
   m_comments = newComments;
}

void Course::loadPrereqs( vector<Course> newprereqs )
{
   m_prereqs.clear();
   m_prereqs = newprereqs;
}

vector<Course> Course::getPrereqs( ) const
{
   return m_prereqs;
}

void Course::addNewPrereq( Course newprereq )
{
   bool old = false;

   for ( unsigned int i = 0; i < m_prereqs.size(); ++i )
   {
      if ( m_prereqs.at(i) == newprereq )
      {
	 old = true;
      }
   }
   
   if ( old == false )
      m_prereqs.push_back( newprereq );

}




