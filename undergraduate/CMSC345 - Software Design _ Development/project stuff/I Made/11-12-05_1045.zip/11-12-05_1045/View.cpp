#include "View.h"

using namespace std;

void view( GraduationPlan & gradplan )
{
   char validResponse;

   do
   {
      validResponse = viewMenu( );

      switch( validResponse ) 
      {
	 case 'R':
	    viewRemainingGrad( gradplan );
	    break;
	 case 'S':
	    viewSemesterSelectionMenu( gradplan );
	    break;
	 case 'B':
	    break;
	 case 'C':
	    // viewCourseInfoMenu( );
	    break;
	 default:
	    break;
      }
     
   } while( validResponse != 'B' );

   return;
}

char viewMenu( )
{
   system( "clear" );

   string screenTitle = "View Graduation Plan";
   PrintGreeting( screenTitle );

   cout << "R - View Remaining Graduation Requirements"
	<< endl
        << "S - View Selectable Semesters"
	<< endl
	<< "C - View Selected Course Information"
	<< endl
        << "B - Back"
	<< endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'R' );
   mainChoices.push_back( 'S' );
   mainChoices.push_back( 'B' );
   mainChoices.push_back( 'C' );

   return GetMenuResponse( mainChoices );
}

void viewRemainingGrad( GraduationPlan & gradplan )
{
   system("clear");

   string screenTitle = "Remaining Graduation Requirements";
   PrintGreeting( screenTitle );

   gradplan.viewRemain( );

   cout << "Return, type B" << endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'B' );
   GetMenuResponse( mainChoices );

   return;
}

void viewSemesterSelectionMenu( GraduationPlan & gradplan )
{
   int choice;
   
   system("clear");
   
   string screenTitle = "Semesters in Grad Plan";
   
   PrintGreeting( screenTitle );

   // pick semester

   gradplan.listSemesters( );

   do {
      
      cout << "Choose a semester to view courses (i.e. 1)" << endl;
      cin >> choice;
      
   } while ( choice < 0 || choice > gradplan.numSemesters() );
   
   system("clear");

   // display semester

   gradplan.getSemester(choice).viewList();

   cout << "Return, type B" << endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'B' );
   GetMenuResponse( mainChoices );

   return;
}
