#ifndef _GraduationPlan_h
#define _GraduationPlan_h

#include "Semester.h"

#include <vector>
#include <string>

using namespace std;

class GraduationPlan
{

  public:
   GraduationPlan( string studentName, Semester startingSemester, string major )
    :m_studentName(studentName), m_startingSemester(startingSemester), m_major(major)
    {
       m_plan.push_back(startingSemester);
    }

   void     printGradPlan( );
   void     viewGradPlan( );
   void     modifyGradPlan( );
   void     viewRemain( );
   void     listSemesters( );
   int      numSemesters( );
   Semester getSemester( int index );


  private:
   string           m_studentName;
   Semester         m_startingSemester;
   string           m_major;
   vector<Semester> m_plan;
   vector<Course>   m_remainReqs; //has major & GFR reqs

   void addSemester( );
   void deleteSemester( );

};

#endif
