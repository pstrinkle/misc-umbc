#include "GraduationPlan.h"

void GraduationPlan::printGradPlan( )
{
   // something...
}

void GraduationPlan::viewGradPlan( )
{
   // will make a version that has an input and one that does not.
   // so we can have a range
}

void GraduationPlan::modifyGradPlan( )
{
   // so you make the plan, and then you add it, and you pass this the plan and a number
   // if the number is 1 you add
   // else you delete the one that matches the plan?
   // i don't know?
   // calls, addSemester or deleteSemester.
}

void GraduationPlan::viewRemain( )
{
   for ( unsigned int i = 0; i < m_remainReqs.size( ); ++i )
   {
      cout << m_remainReqs.at(i).getDesg( ) << " "
	   << m_remainReqs.at(i).getNumber( ) << " "
	   << m_remainReqs.at(i).getTitle( ) << endl;
   }
}

void GraduationPlan::listSemesters( )
{
   for ( unsigned int i = 0; i < m_plan.size( ); ++i )
   {
      cout << i << " " << m_plan.at(i).getDesg() << " "
	   << m_plan.at(i).getYear() << endl;
   }
}

int GraduationPlan::numSemesters( )
{
   return static_cast<int>(m_plan.size());
}

Semester GraduationPlan::getSemester( int index )
{
   return m_plan.at(index);
}
