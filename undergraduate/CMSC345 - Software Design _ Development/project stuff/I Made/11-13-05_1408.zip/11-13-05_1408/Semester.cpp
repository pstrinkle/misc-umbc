#include "Semester.h"

Course Semester::viewCourse( int index )
{
   return m_courses.at(index);
}

string Semester::deleteCourse( )
{
   // I have no idea, we need an input.
   // how to identify the course to delete
   // should we use vector index?

   string temp = "temporary";

   return temp;
}

string Semester::addCourse( Course newCourse )
{
   m_courses.push_back( newCourse );
   return newCourse.getTitle();
}  

void Semester::viewList( )
{
   for ( unsigned int i = 0; i < m_courses.size(); ++i )
   {
      cout << m_courses.at(i).getDesg() << " "
	   << m_courses.at(i).getTitle() 
	   << endl;
   }
}
