#include "Proj.h"

using namespace std;

char displayMainMenu( )
{
   system( "clear" );

   vector<char> mainChoices;

   mainChoices.push_back( 'N' );
   mainChoices.push_back( 'M' );
   mainChoices.push_back( 'V' );
   mainChoices.push_back( 'P' );
   mainChoices.push_back( 'Q' );

   string screenTitle = "Quick Grad Planner";
   PrintGreeting( screenTitle );

   cout << "N - New"
        << endl
        << "M - Modify"
        << endl
        << "V - View"
        << endl
        << "P - Print"
        << endl
        << "Q - Quit"
        << endl << endl;

   return GetMenuResponse( mainChoices );

}

char GetMenuResponse ( const vector<char> & theChoices )
{
   char menuChoice;
   bool valid = false;

   do
   {
      cout << "Please enter your selection: ";
      cin >> menuChoice;

      menuChoice = toupper( menuChoice );

      if( validateSelection( menuChoice, theChoices ) )
      {
         valid = true;
      }
      else
      {
	 cout << "Invalid Selection, please select again."
	      << endl;
      }
   } while( ! valid );

   return menuChoice;
}

void PrintGreeting ( string title )
{
   cout << "*************************************************"
        << endl
        << "\t\t"
        << title
        << "\t\t"
        << endl
        << "*************************************************"
        << endl;
}

bool validateSelection ( const char choice, const vector<char> & theChoices )
{
   bool exists = false;

   for( unsigned int i = 0; i < theChoices.size( ); i++ )
   {
      if ( theChoices.at( i ) == choice )
      {
	 exists = true;
      }
   }

   return ( exists );
}
