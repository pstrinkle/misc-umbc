#ifndef _View_h
#define _View_h

#include <iostream>
#include <string>
#include <vector>

#include "Proj.h"
#include "GraduationPlan.h"

using namespace std;

void view( GraduationPlan & gradplan );
char viewMenu( );
void viewRemainingGrad( GraduationPlan & gradplan );
int  viewSemesterSelectionMenu( GraduationPlan & gradplan );
int  viewCoursesSelectionMenu( GraduationPlan & gradplan, int semesterChoice );
void viewCourseInfo( GraduationPlan & gradplan, int semesterChoice, int courseChoice );

#endif
