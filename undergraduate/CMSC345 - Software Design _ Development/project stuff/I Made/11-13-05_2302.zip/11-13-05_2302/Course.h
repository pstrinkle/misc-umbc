#ifndef _Course_h
#define _Course_h

#include <vector>
#include <string>

using namespace std;

class Course
{
   
  public:
   Course( string title = "blank", int number = 123, string designator = "FAKE", vector<Course> prereqs )
      :m_title(title), m_number(number), m_designator(designator), m_prereqs(prereqs), m_grade('P')
      {
      }

   Course( string title = "blank", int number = 123, string designator = "FAKE" )
      :m_title(title), m_number(number), m_designator(designator), m_grade('P')
      {
      }

   Course& operator=(const Course& rhs);




   bool operator==( const Course& rhs );
 
	 // should it be passed by reference or by value to so we can actually capture
	 // the values of the vector as a whole?
	 
   int            getNumber( ) const;
   string         getTitle( ) const;
   string         getDesg( ) const;
   string         getComments( ) const;
   char           getGrade( ) const;
   vector<Course> getPrereqs( ) const;
   
	 
   char   inputnewGrade( char newGrade );
   void   inputComments( string newComments );
   
   void   loadPrereqs( vector<Course> newprereqs );
   void   addNewPrereq( Course newprereq );
	 
	 
  private:
   string         m_title;
   int            m_number;
   string         m_designator;
   vector<Course> m_prereqs;
   char           m_grade;
   
   string         m_comments;
};

#endif
