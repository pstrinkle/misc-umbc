#include "Course.h"
#include "Semester.h"
#include "GraduationPlan.h"


#include "Proj.h"
#include "View.h"
#include "New.h"

using namespace std;

int main()
{

   string personalGradPlan; //personal saved gradplan input

   GraduationPlan gradplan;

   /* build course list with titles */

   ifstream inStream("CourseList.txt");
   if (inStream == NULL)
   {
      cerr << "Invalid Course List File." << endl;
      exit(-1);
   }

   vector<Course> courseList;
   int number;
   string title;
   string designator;

   while ( inStream >> designator )
   {
      inStream >> number;
      getline(inStream, title);

      Course temp(title, number, designator);
      courseList.push_back(temp);
   }

   inStream.close();

   /* To create a new Graduation Plan or not to? */

   system("clear");
   string screenTitle = "Quick Grad Planner ASCII Art";
   PrintGreeting( screenTitle );

   cout << "Welcome, do you already have a GraduationPlan saved? (y/n)" << endl;

   vector<char> gradplanChoices;
   gradplanChoices.push_back('Y');
   gradplanChoices.push_back('N');
   char gradplanChoice = GetMenuResponse( gradplanChoices );

   switch ( gradplanChoice )
   {
      case 'Y':
	 cout << "Please enter filename: ";
	 cin >> personalGradPlan;
	 break;
      case 'N':
	 gradplan = newPlan();
	 break;
   }
   
   // temp code
   vector<Course> fakeprereqs;
   vector<Course> fakecourses;
   Course fake("Program Design", 345, "CMSC", fakeprereqs);
   fakecourses.push_back(fake);
   Semester fakesemester("FL", 2005, fakecourses);
   gradplan = GraduationPlan("Patrick Trinkle", fakesemester, "CMSC");
   // end temp code


   char validResponse;

   do
   {
      validResponse = displayMainMenu( );

      switch( validResponse ) 
      {
	 case 'N':
	    gradplan = newPlan();
	    break;
	 case 'M':
	    // modify( );
	    break;
	 case 'V':
	    view( gradplan );
	    break;
	 case 'P':
	    // print( );
	    break;
	 case 'Q':
	    break;
	 default:
	    cerr << "Invalid menu selection, please try again!"
		 << endl;
	    break;
      }
   } while ( validResponse != 'Q' );

   return 0;
}
