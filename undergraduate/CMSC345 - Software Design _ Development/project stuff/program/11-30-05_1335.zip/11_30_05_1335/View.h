/* View.h
 *
 * Author: Patrick Trinkle
 * Email:  tri1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#ifndef _View_h
#define _View_h

#include <iostream>
#include <string>
#include <vector>

#include "Proj.h"

using namespace std;

//**************************************
// Function: view( )
// PreConditions: A valid GraduationPlan object
// PostConditions: return of control to main menu
//**************************************
void view( GraduationPlan & gradplan );

//**************************************
// Function: viewMenu( )
// PreConditions: None
// PostConditions: a character representing
//                 an option for view()
//**************************************
char viewMenu( );

//**************************************
// Function: viewRemainingGrad( )
// PreConditions: A valid GraduationPlan Object
// PostConditions: None
//**************************************
void viewRemainingGrad( GraduationPlan & gradplan );

//**************************************
// Function: viewCourseInfo( )
// PreConditions: A valid GraduationPlan Object
//                A valid semester and course choices
//                for viewing
// PostConditions: None
//**************************************
void viewCourseInfo( GraduationPlan & gradplan, int semesterChoice, int courseChoice );

//**************************************
// Function: viewStudentInfo( )
// PreConditions: A valid GraduationPlan Object
// PostConditions: None
//**************************************
void viewStudentInfo( GraduationPlan & gradplan );

#endif
