/* Course.cpp
 *
 * Author: Patrick Trinkle
 * Author: Chris Stark
 * Email:  tri1@umbc.edu, cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#include "Course.h"

using namespace std;

//**************************************
// Function: operator==( )
// PreConditions: Two valid Course Objects
// PostConditions: A boolean of their equivalence
//**************************************
bool Course::operator==( const Course & rhs )
{
   bool sameness = false;
   
   if ( this == &rhs )
   {
      sameness = true;
   }

   else if ( getTitle() == rhs.getTitle() 
	     && getNumber() == rhs.getNumber() 
	     && getDesg() == rhs.getDesg() )
   {
      sameness = true;
   }

   return sameness;
}

//**************************************
// Function: operator=( )
// PreConditions: A valid Course Object
// PostConditions: Assignment Operator
//**************************************
Course & Course::operator=(const Course & rhs)
{
   //if they're not the same object
   if ( this != &rhs )
   {
      m_title = rhs.m_title;
      m_number = rhs.m_number;
      m_designator = rhs.m_designator;
      m_prereqs.clear();
      m_prereqs = rhs.m_prereqs;
      m_grade = rhs.m_grade;
      m_comments = rhs.m_comments;
   }
   return *this;
}

//**************************************
// Function: getNumber( )
// PreConditions: None
// PostConditions: the Course Number
//**************************************
int Course::getNumber( ) const
{
   return m_number;
}

//**************************************
// Function: getTitle( )
// PreConditions: None
// PostConditions: the Course Title
//**************************************
string Course::getTitle( ) const
{
   return m_title;
}

//**************************************
// Function: getDesg( )
// PreConditions: None
// PostConditions: the Course Designator
//**************************************
string Course::getDesg( ) const
{
   return m_designator;
}

//**************************************
// Function: getComments( )
// PreConditions: None
// PostConditions: the Course Comments
//**************************************
string Course::getComments( ) const
{
   return m_comments;
}

//**************************************
// Function: getGrade( )
// PreConditions: None
// PostConditions: the Course Grade
//**************************************
char Course::getGrade( ) const
{
   return m_grade;
}

//**************************************
// Function: inputNewGrade( )
// PreConditions: A valid char
// PostConditions: new Grade value in Course
//**************************************
void Course::inputNewGrade( char newGrade )
{
   m_grade = newGrade;
}

//**************************************
// Function: inputComments( )
// PreConditions: A valid string
// PostConditions: new Comment value in Course
//**************************************
void Course::inputComments( string newComments )
{
   m_comments = newComments;
}

//**************************************
// Function: appendComments( )
// PreConditions: A valid string
// PostConditions: more Comment value in Course
//**************************************
void Course::appendComments( string appendage )
{
   if( m_comments == "None" )
   {
      m_comments = "";
   }

   string temp = "";
   temp = m_comments;
   temp += " ";
   temp += appendage;
   m_comments = temp;
}

//**************************************
// Function: loadPreReqs( )
// PreConditions: A valid Course Object &
//                a vector of Courses
// PostConditions: The Course Object will
//                 have prereqs
//**************************************
void Course::loadPrereqs( vector<Course> newprereqs )
{
   m_prereqs.clear();
   m_prereqs = newprereqs;
}

//**************************************
// Function: getPreReqs( )
// PreConditions: None
// PostConditions: the Course PreReqs, a
//                 vector of Courses
//**************************************
vector<Course> Course::getPrereqs( ) const
{
   return m_prereqs;
}

//**************************************
// Function: addNewPreReq( )
// PreConditions: A valid Course Object
// PostConditions: The Course Object will 
//                 have a new Prereqs
//**************************************
void Course::addNewPrereq( Course newprereq )
{
   bool old = false;

   for ( unsigned int i = 0; i < m_prereqs.size(); ++i )
   {
      if ( m_prereqs.at(i) == newprereq )
      {
	 old = true;
      }
   }
   
   if ( old == false )
   {
      m_prereqs.push_back( newprereq );
   }
}
