/* Print.cpp
 *
 * Author: Patrick Trinkle
 * Email:  tri1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#include "Print.h"

using namespace std;


//**************************************
// Function: print( )
// PreConditions: A valid GraduationPlan Object &
//                Writer permissions to the current dir
// PostConditions: A GraduationPlan object written  into
//                 an output file: PrintableGraduationPlan.txt
//**************************************
void print( GraduationPlan & gradplan )
{
 
   ofstream outputStream( "PrintableGraduationPlan.txt" );
   if ( outputStream == NULL )
   {
      cerr << "Invalid output file."
	   << endl
           << "Output file: PrintableGraduationPlan.txt"
	   << endl;
      exit(-3);
   }

   //begin file
   outputStream << "Gradution Plan:" << endl
                << "Name: " << gradplan.getName() << endl
                << "Major: " << gradplan.getMajor() << " Minor: "
                << gradplan.getMinor() << endl;

   outputStream << endl;

   //print semesters
   for ( int j = 0; j < gradplan.numSemesters(); ++j )
   {
      Semester temp = gradplan.getSemester(j);
      outputStream << "Semester: "
                   << temp.getDesg() << " " << temp.getYear() << " " << endl;
      
      for ( int num = 0; num < temp.numCourses(); ++num )
      {
         Course tempCrs = temp.viewCourse(num);
         outputStream << ( num + 1 ) << " " 
                      << tempCrs.getDesg() << " " 
                      << tempCrs.getNumber() << " " 
                      << tempCrs.getGrade() << " "
                      << tempCrs.getComments()
                      << endl;
      }

   }

   outputStream << endl;

   //print remaining courses
   vector<Course> remainder = gradplan.getRemainReqs();

   outputStream << "Remaining Graduation Requirements: " << endl;

   for ( unsigned int i = 0; i < remainder.size(); ++i )
   {
      outputStream << remainder.at(i).getDesg() << " " 
                   << remainder.at(i).getNumber()
                   << endl;
   }

   outputStream.close();

}
