/* Save.cpp
 *
 * Author: Patrick Trinkle
 * Email:  tri1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#include "Save.h"

using namespace std;

//**************************************
// Function: save( )
// PreConditions: A valid GraduationPlan Object &
//                Writer permissions to the current dir
// PostConditions: A GraduationPlan object encoded into
//                 an output file: GraduationPlan.txt
//**************************************
void save( GraduationPlan & gradplan )
{
 
   ofstream outputStream( "GraduationPlan.txt" );
   if ( outputStream == NULL )
   {
      cerr << "Invalid output file." << endl
           << "Output file: GraduationPlan.txt" << endl;
      exit(-3);
   }

   //begin file
   outputStream << START << endl
                << gradplan.getName() << endl
                << gradplan.getMajor() << endl
                << gradplan.getMinor() << endl;

   outputStream << endl;

   //print semesters
   for ( int j = 0; j < gradplan.numSemesters(); ++j )
   {
      Semester temp = gradplan.getSemester(j);
      outputStream << ADD << " " << SEM << " " 
                   << temp.getDesg() << " " << temp.getYear() << " " 
                   << temp.numCourses() << endl;
      
      for ( int num = 0; num < temp.numCourses(); ++num )
      {
         Course tempCrs = temp.viewCourse( num );
         outputStream << tempCrs.getDesg( )
		      << " "
		      << tempCrs.getNumber( )
                      << " "
		      << tempCrs.getGrade( )
		      << " "
		      << tempCrs.getComments( )
		      << endl;
      }

   }

   outputStream << endl;

   //print remaining courses
   vector<Course> remainder = gradplan.getRemainReqs();

   outputStream << ADD
		<< " "
		<< REM
		<< " "
		<< static_cast<int>( remainder.size( ) ) 
		<< endl;

   for ( unsigned int i = 0; i < remainder.size(); ++i )
   {
      outputStream << remainder.at( i ).getDesg( )
		   << " "
		   << remainder.at( i ).getNumber( )
		   << endl;
   }

   outputStream.close();
   
}
