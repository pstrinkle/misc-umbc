/* GraduationPlan.cpp
 *
 * Author: Patrick Trinkle
 * Author: Chris Stark
 * Email:  tri1@umbc.edu, cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#include "GraduationPlan.h"

//**************************************
// Function: viewRemain( )
// PreConditions: None
// PostConditions: Printed to stdout the
//                 remaining Graduation
//                 requirements
//**************************************
void GraduationPlan::viewRemain( )
{
   // display all the remaining prerequisites
   for ( unsigned int i = 0; i < m_remainReqs.size( ); ++i )
   {
      cout << "\t" 
	   << i
	   << ". "
	   << m_remainReqs.at(i).getDesg( ) 
	   << " "
	   << m_remainReqs.at(i).getNumber( ) 
	   << " "
	   << m_remainReqs.at(i).getTitle( ) 
	   << endl;
   }
}

//**************************************
// Function: listSemesters( )
// PreConditions: None
// PostConditions: Printed to stdout the
//                 Semesters in a list
//**************************************
void GraduationPlan::listSemesters( )
{

   // display all the semesters
   for ( unsigned int i = 0; i < m_plan.size( ); ++i )
   {
      cout << "\t" 
	   << i
	   << ". "
	   << m_plan.at(i).getDesg()
	   << " "
	   << m_plan.at(i).getYear()
	   << endl;
   }
}

//**************************************
// Function: addSemester( )
// PreConditions: None
// PostConditions: adds the semester to the
//                 GraduationPlan, returns
//                 if the semester was added
//**************************************
bool GraduationPlan::addSemester( string designator, int year )
{

   // empty vector of courses
   vector<Course> emptyCourses;

   // create new semester and put it in the semester list
   Semester newSemester( designator, year, emptyCourses );
   bool exists = false;

   // check to see if it already exists
   for( unsigned int i = 0; i < m_plan.size( ); ++i )
   {
      if( m_plan.at( i ) == newSemester )
      {
	 exists = true;
      }
   }

   if( exists == false )
   {
      m_plan.push_back( newSemester );
   }
   else
   {
      cout << "Semester already exists!  It will not be added."
	   << endl;
   }

   return( !exists );
}

//**************************************
// Function: numSemesters( )
// PreConditions: None
// PostConditions: The number of Semesters
//**************************************
int GraduationPlan::numSemesters( )
{
   return static_cast<int>( m_plan.size( ) );
}

//**************************************
// Function: getSemesters( )
// PreConditions: A valid index
// PostConditions: a reference to the
//                 requested Semester
//**************************************
Semester & GraduationPlan::getSemester( int index )
{
   return m_plan.at( index );
}

//**************************************
// Function: getName( )
// PreConditions: None
// PostConditions: The Student's name
//**************************************
string GraduationPlan::getName( )
{
   return m_studentName;
}

//**************************************
// Function: getMajor( )
// PreConditions: None
// PostConditions: The Student's Major
//**************************************
string GraduationPlan::getMajor( )
{
   return m_major;
}

//**************************************
// Function: getMinor( )
// PreConditions: None
// PostConditions: The Student's Minor
//**************************************
string GraduationPlan::getMinor( )
{
   return m_minor;
}

//**************************************
// Function: getRemainReqs( )
// PreConditions: None
// PostConditions: The Remaining Graduation
//                 Requirements
//**************************************
vector<Course> GraduationPlan::getRemainReqs( )
{
   return m_remainReqs;
}

Course & GraduationPlan::getFromRemaining( int index )
{
   return( m_remainReqs.at( index ) );
}

void GraduationPlan::removeFromRemaining( Course & toRemove )
{
   unsigned int position = 0;

   // find location of course to remove
   for( unsigned int i = 0; i < m_remainReqs.size( ); ++i )
   {

      if( toRemove == m_remainReqs.at( i ) )
      {
	 position = i;
      }
   }

   // remove from the vector at given position
   m_remainReqs.erase( m_remainReqs.begin( ) + position );
}

void GraduationPlan::addToRemaining( Course toAdd )
{
   // add the course back to the remaining requirements
   m_remainReqs.push_back( toAdd );
}

bool GraduationPlan::checkPrereqs( Course & check, int semester )
{
   vector<Course> coursePrereqs = check.getPrereqs( );
 
   Semester thisSemester = m_plan.at( semester );
   bool checkPassed = true;

   vector<Course> temp;

   // get all courses
   for( unsigned int i = 0; i < m_plan.size( ); ++i )
   {
      if( m_plan.at( i ) < thisSemester )
      {
	 for( int j = 0; j < m_plan.at( i ).numCourses( ); ++j )
	 {
	    temp.push_back( m_plan.at( i ).viewCourse( j ) );
	 }
      }
   }

   unsigned int i = 0;

   // check that the prerequisites are accounted for
   while( i < coursePrereqs.size( ) && checkPassed == true )
   {

      // loop through all the courses you have taken
      checkPassed = false;
      for( unsigned int j = 0; j < temp.size( ); ++j )
      {
	 if( temp.at( j ) == coursePrereqs.at( i ) )
	 {
	    checkPassed = true;
	 }
      }

      ++i;
   }

   return checkPassed;

}
