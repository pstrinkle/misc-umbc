/* Semester.h
 *
 * Author: Patrick Trinkle
 * Author: Chris Stark
 * Email:  tri1@umbc.edu, cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#ifndef _Semester_h
#define _Semester_h

#include "Course.h"

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Semester 
{

  public:
   Semester( string designator, 
	     int year, 
	     vector<Course> courses ):
      m_designator(designator), 
      m_year(year), 
      m_courses(courses)
   {  
      // no code
   }

   Semester( string designator, 
	     int year ):
      m_designator(designator), 
      m_year(year)
   {
      // no code
   }

   //**************************************
   // Function: operator==( )
   // PreConditions: Two valid Semester Objects
   // PostConditions: Their Equivalency
   //**************************************
   bool operator==( const Semester & rhs );

   //**************************************
   // Function: operator<( )
   // PreConditions: Two valid Semester Objects
   // PostConditions: If one Semester falls
   //                 before another
   //**************************************
   bool operator<( const Semester & rhs );

   //**************************************
   // Function: viewCourse( )
   // PreConditions: The index in the Semester
   //                of the Course you'd like
   // PostConditions: Assignment Operator
   //**************************************
   Course & viewCourse( int index );

   //**************************************
   // Function: deleteCourse( )
   // PreConditions: the Course to delete
   // PostConditions: 
   //**************************************
   string deleteCourse( Course & toDelete );

   //**************************************
   // Function: addCourse( )
   // PreConditions: A valid Course Object
   // PostConditions: A semester plus that Course
   //                 and returns the title
   //                 of the Course added
   //**************************************
   string addCourse( Course newCourse );

   //**************************************
   // Function: viewList( )
   // PreConditions: None
   // PostConditions: Prints to stdout a list
   //                 of all Course in Semester
   //**************************************
   void   viewList( );

   //**************************************
   // Function: numCourses( )
   // PreConditions: None
   // PostConditions: the Number of Courses
   //                 in Semester
   //**************************************
   int    numCourses( );

   //**************************************
   // Function: getDesg( )
   // PreConditions: None
   // PostConditions: returns the Semester
   //                 designator
   //**************************************
   string getDesg( ) const;

   //**************************************
   // Function: getYear( )
   // PreConditions: None
   // PostConditions: returns the Semester
   //                 year
   //**************************************
   int    getYear( ) const;

  private:
   string         m_designator;
   int            m_year;
   vector<Course> m_courses;
};

#endif
