/*
** Course Files:
** CourseList.txt - List of all courses and Prerequisites
** GFR.txt - List of all GFRs
** CMSC_Maj.txt - List of all Computer Science Major Requirements
** IS_Maj.txt - List of all Information System Major Requirements
** IS_Maj_CMSC_Min.txt - List of all IS Major CMSC Minor Requirements
** IS_CMSC_Dbl_Maj.txt - List of all IS CMSC Double Major Requirements
** GraduationPlan.txt - The saved Graduation Plan
*/


#include "Course.h"
#include "Semester.h"
#include "GraduationPlan.h"

#include "Proj.h"
#include "View.h"
#include "New.h"

const int CRSLST = 0;

using namespace std;

int main()
{
   
   GraduationPlan gradplan;

   vector<Course> courseList;
   courseList = buildCourseInfo();

   /* To create a new Graduation Plan or not to? */
   system("clear");
   string screenTitle = "Quick Grad Planner ASCII Art";
   PrintGreeting( screenTitle );

   cout << "Welcome, do you already have a GraduationPlan saved? (y/n)" << endl;

   vector<char> gradplanChoices;
   gradplanChoices.push_back('Y');
   gradplanChoices.push_back('N');
   char gradplanChoice = GetMenuResponse( gradplanChoices );

   switch ( gradplanChoice )
   {
      case 'Y':
	 gradplan = buildPlan( courseList );
	 break;
      case 'N':
	 gradplan = newPlan( courseList );
	 break;
   }
   
   char validResponse;

   do
   {
      validResponse = displayMainMenu( );

      switch( validResponse ) 
      {
	 case 'N':
	    gradplan = newPlan( courseList );
	    break;
	 case 'M':
	    // modify( );
	    break;
	 case 'V':
	    view( gradplan );
	    break;
	 case 'P':
	    // print( );
	    break;
	 case 'S':
	    // save( );
	    break;
	 case 'C':
	    credits( );
	    break;
	 case 'Q':
	    break;
	 default:
	    cerr << "Invalid menu selection, please try again!"
		 << endl;
	    break;
      }
   } while ( validResponse != 'Q' );

   return 0;
}
