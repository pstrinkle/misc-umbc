#include "View.h"

using namespace std;

void view( GraduationPlan & gradplan )
{
   char validResponse;
   int semesterChoice;
   int courseChoice;

   vector<char> mainChoices;
   mainChoices.push_back('B');

   do
   {
      validResponse = viewMenu( );

      switch( validResponse ) 
      {
	 case 'R':
	    viewRemainingGrad( gradplan );
	    break;
	 case 'S':
	    semesterChoice = semesterSelectionMenu( gradplan );
	    system("clear");
	    gradplan.getSemester(semesterChoice).viewList();
	    cout << "Return, type B" << endl;
	    GetMenuResponse( mainChoices );
	    break;
	 case 'B':
	    break;
	 case 'C':
	    // viewCourseInfoMenu( );
	    semesterChoice = semesterSelectionMenu( gradplan );
	    courseChoice = coursesSelectionMenu( gradplan, semesterChoice );
	    if ( courseChoice >= 0 )
	       viewCourseInfo(gradplan, semesterChoice, courseChoice);
	    break;
	 default:
	    break;
      }
     
   } while( validResponse != 'B' );

   return;
}

char viewMenu( )
{
   system( "clear" );

   string screenTitle = "View Graduation Plan";
   PrintGreeting( screenTitle );

   cout << "R - View Remaining Graduation Requirements"
	<< endl
        << "S - View Selectable Semesters"
	<< endl
	<< "C - View Selected Course Information"
	<< endl
        << "B - Back"
	<< endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'R' );
   mainChoices.push_back( 'S' );
   mainChoices.push_back( 'B' );
   mainChoices.push_back( 'C' );

   return GetMenuResponse( mainChoices );
}

void viewRemainingGrad( GraduationPlan & gradplan )
{
   system("clear");

   string screenTitle = "Remaining Graduation Requirements";
   PrintGreeting( screenTitle );

   gradplan.viewRemain( );

   cout << "Return, type B" << endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'B' );
   GetMenuResponse( mainChoices );

   return;
}

void viewCourseInfo( GraduationPlan & gradplan, int semesterChoice, int courseChoice )
{
   system("clear");
   Course displayCourse = gradplan.getSemester(semesterChoice).viewCourse(courseChoice);
   string screenTitle = displayCourse.getTitle();
   PrintGreeting( screenTitle );

   cout << displayCourse.getDesg() << " " << displayCourse.getNumber() << endl
	<< "Grade: " << displayCourse.getGrade() << endl
	<< "Comments: " << displayCourse.getComments()
	<< endl << endl;

   cout << "Return, type B" << endl;
   vector<char> mainChoices;
   mainChoices.push_back('B');
   GetMenuResponse( mainChoices );
}
