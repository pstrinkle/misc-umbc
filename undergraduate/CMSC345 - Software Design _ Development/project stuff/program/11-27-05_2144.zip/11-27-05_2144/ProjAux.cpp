#include "Proj.h"

using namespace std;

char displayMainMenu( )
{

   system( "clear" );

   vector<char> mainChoices;
   mainChoices.push_back( 'N' );
   mainChoices.push_back( 'M' );
   mainChoices.push_back( 'V' );
   mainChoices.push_back( 'P' );
   mainChoices.push_back( 'S' );
   mainChoices.push_back( 'C' );
   mainChoices.push_back( 'Q' );

   string screenTitle = "Quick Grad Planner";
   PrintGreeting( screenTitle );

   cout << endl;
   cout << "\tN - New"
        << endl
        << "\tM - Modify"
        << endl
        << "\tV - View"
        << endl
        << "\tP - Print"
        << endl
	<< "\tS - Save"
	<< endl
	<< "\tC - Credits"
	<< endl
        << "\tQ - Quit"
        << endl << endl;

   return GetMenuResponse( mainChoices );
}

char GetMenuResponse ( const vector<char> & theChoices )
{

   char menuChoice;
   bool valid = false;

   do
   {
      cout << "Please enter your selection: ";
      cin >> menuChoice;

      menuChoice = toupper( menuChoice );

      if( validateSelection( menuChoice, theChoices ) )
      {
         valid = true;
      }
      else
      {
	 cout << "Invalid selection, please select again."
	      << endl;
      }
   } while( ! valid );

   return menuChoice;
}

void PrintGreeting ( string title )
{

   cout << "**************************************************************************************************"
	<< endl
	<< "\t\t"
        << title
        << endl
        << "**************************************************************************************************"
        << endl;
}

void PrintQGPLogo ( )
{

   string logo = "  _______         _____        ______      _________                _________\n  __  __ \\____  _____(_)__________  /__    __  ____/______________ _______  /\n  _  / / /_  / / /__  / _  ___/__  //_/    _  / __  __  ___/_  __ `/_  __  / \n  / /_/ / / /_/ / _  /  / /__  _  ,<       / /_/ /  _  /    / /_/ / / /_/ /  \n  \\___\\_\\ \\__,_/  /_/   \\___/  /_/|_|      \\____/   /_/     \\__,_/  \\__,_/   \n                                                                             \n             ________ ______                                      \n             ___  __ \\___  /______ ________ _______ _____ ________\n             __  /_/ /__  / _  __ `/__  __ \\__  __ \\_  _ \\__  ___/\n             _  ____/ _  /  / /_/ / _  / / /_  / / //  __/_  /    \n             /_/      /_/   \\__,_/  /_/ /_/ /_/ /_/ \\___/ /_/     \n";

   cout << "**************************************************************************************************"
	<< endl
        << logo
        << endl
        << "**************************************************************************************************"
        << endl;
}

bool validateSelection ( const char choice, const vector<char> & theChoices )
{

   bool exists = false;

   for( unsigned int i = 0; i < theChoices.size( ); ++i )
   {
      if ( theChoices.at( i ) == choice )
      {
	 exists = true;
      }
   }

   return ( exists );
}

Course retrieveCourseInfo ( string designator, int number, vector<Course> & courselist )
{

   Course temp;

   for ( unsigned int i = 0; i < courselist.size(); ++i )
   {
      if ( designator == courselist.at( i ).getDesg( ) && 
	   number == courselist.at( i ).getNumber( ) )
      {
	  temp = courselist.at( i );
      }
   }

   return temp;
}

int semesterSelectionMenu( GraduationPlan & gradplan )
{

   int choice = 0;

   system("clear");

   string screenTitle = "Semesters in Grad Plan";
   PrintGreeting( screenTitle );

   // pick semester

   gradplan.listSemesters( );

   do 
   {
      cout << "Choose a semester: ";
      cin >> choice;

      if( choice < 0 || choice > gradplan.numSemesters( ) )
      {
	 cout << "Invalid selection, please select again."
	      << endl;
      }

   } while ( choice < 0 || choice > gradplan.numSemesters( ) - 1 );

   return choice;
}

int coursesSelectionMenu( GraduationPlan & gradplan, int semesterChoice )
{

   int choice = 0;
   int numCourses = 0;
   
   system("clear");

   string screenTitle = "Courses in Semester";
   PrintGreeting( screenTitle );

   // pick semester
   gradplan.getSemester(semesterChoice).viewList( );

   numCourses = gradplan.getSemester(semesterChoice).numCourses( );

   if ( numCourses > 0 )
   {
      do 
      {
	 cout << "Choose a course: ";
	 cin >> choice;

	 if(choice < 0 || choice > gradplan.getSemester(semesterChoice).numCourses() - 1)
	 {
	    cout << "Invalid selection, please select again."
		 << endl;
	 }

      } while ( choice < 0 || choice > gradplan.getSemester(semesterChoice).numCourses() - 1 );
   }
   else
   {
      cout << "No courses in semester." << endl;

      cout << "To return, type B" << endl;

      vector<char> mainChoices;
      mainChoices.push_back( 'B' );
      GetMenuResponse( mainChoices );

      choice = -1;
   }

   return choice;
}

//---------------------------------------

int coursesSelectionMenu( Semester & semester  )
{

   int choice = 0;
   int numCourses = 0;
   
   system("clear");

   string screenTitle = "Courses in Semester";
   PrintGreeting( screenTitle );

   // pick semester

   semester.viewList();

   numCourses = semester.numCourses( );

   if ( numCourses > 0 )
   {
      do 
      {
	
	 cout << "Choose a course: " << endl;
	 cin >> choice;

	 if( choice < 0 || choice > semester.numCourses( ) - 1 )
	 {
	    cout << "Invalid selection, please select again."
		 << endl;
	 }

      } while ( choice < 0 || choice > semester.numCourses( ) - 1 );
   }
   else
   {
      cout << "No courses in semester." 
	   << endl;

      cout << "To return, type B" 
	   << endl;

      vector<char> mainChoices;
      mainChoices.push_back( 'B' );
      GetMenuResponse( mainChoices );

      choice = -1;
   }

   return choice;
}
//------------------------------------------

int remainingSelectionMenu( GraduationPlan & gradplan )
{
   int choice = 0;
   int numCourses = 0;
   
   system("clear");

   string screenTitle = "Choose Course to Add";
   PrintGreeting( screenTitle );

   // pick semester

   gradplan.viewRemain( );

   numCourses = static_cast<int>( gradplan.getRemainReqs( ).size( ) );

   if ( numCourses > 0 )
   {
      do 
      {
	 cout << "Choose a course to add: ";
	 cin >> choice;

	 if( choice < 0 || choice > numCourses - 1 )
	 {
	    cout << "Invalid selection, please select again."
		 << endl;
	 }

      } while ( choice < 0 || choice > numCourses - 1 );
   }
   else
   {
      cout << "No courses left to take!" 
	   << endl;
      cout << "To return, type B" 
	   << endl;

      vector<char> mainChoices;
      mainChoices.push_back( 'B' );
      GetMenuResponse( mainChoices );

      choice = -1;
   }

   return choice;
   
}

//------------------------------------------

void credits( )
{
   system("clear");

   string screenTitle = "The South Pole Tigers";
   PrintGreeting( screenTitle );
   
   cout << endl
	<< "\tTEAM LEAD" 
	<< endl
	<< "\tHeather \"The Elder\" Long" 
	<< endl << endl
	<< "\tIMPLEMENTATION LEAD" 
	<< endl
	<< "\tPayal \"Pi3.14\" Aggarwal" 
	<< endl << endl
	<< "\tDESIGN LEAD" 
	<< endl
	<< "\tEmmanuel \"Afro Mustang\" Tebong" 
	<< endl << endl
	<< "\tTESTING LEAD" 
	<< endl
	<< "\tPatrick \"R4dical 3lement\" Trinkle" 
	<< endl << endl
	<< "\tREQUIREMENTS LEAD" 
	<< endl
	<< "\tChris \"Nerd*\" Stark" 
	<< endl << endl << endl;

   cout << "To return, type B" 
	<< endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'B' );
   GetMenuResponse( mainChoices );

   return;
}

vector<Course> buildCourseInfo( )
{
   string designator = "";
   string title = "";
   int number = 0;
   int preNumber = 0;
   string next = "";
   string preBegin = "";
   string preEnd = "";

   vector<Course> courseList;
   vector<Course> preReqs;

   // read in course title file
   ifstream inStream( "CourseList.txt" );
   if ( inStream == NULL )
   {
      cerr << "Bad Course file, or not found." << endl
	   << "Should be: CourseList.txt" << endl;
      exit( -1 );
   }

   while ( inStream >> designator )
   {
      inStream >> number;
      getline( inStream, title );
      
      Course temp( title, number, designator );
      
      inStream >> preBegin;

      inStream >> next;
      if ( next != ENDPRE )
      {
	 inStream >> preNumber;
	 Course tempPre = retrieveCourseInfo( next, preNumber, courseList );
	 preReqs.push_back( tempPre );
	 
	 inStream >> next;
	 while ( next != ENDPRE )
	 {
	    inStream >> preNumber;
	    Course tempPreNext = retrieveCourseInfo( next, preNumber, courseList );
	    preReqs.push_back( tempPreNext );
	    inStream >> next;
	 }

	 //load prereqs
	 temp.loadPrereqs( preReqs );
	 preReqs.clear( );
      }

      courseList.push_back(temp);
   }

   return courseList;
}
