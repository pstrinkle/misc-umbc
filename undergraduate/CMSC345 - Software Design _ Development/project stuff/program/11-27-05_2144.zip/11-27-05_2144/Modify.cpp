/* Modify.cpp
 *
 * Author: Chris Stark
 * Email: cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#include "Modify.h"

using namespace std;

//**************************************
// Function: modify( GraduationPlan & gradplan )
// PreConditions:  None
// PostConditions: GraduationPlan has been modified by either adding, removing,
//     or modifying semesters or courses
//**************************************
void modify( GraduationPlan & gradplan )
{

   char validResponse = ' ';

   do
   {
      validResponse = modifyMenu( );

      switch( validResponse ) 
      {
	 case 'A':
	    addSemester( gradplan );
	    break;
	 case 'M':
	    modifySemester( gradplan );
	    break;
	 case 'B':
	    break;
	 default:
	    break;
      }
     
   } while( validResponse != 'B' );

}


//**************************************
// Function: modifyMenu( )
// PreConditions:  None
// PostConditions: General modification option selected and returned 
//**************************************
char modifyMenu( )
{

   system( "clear" );

   string screenTitle = "Modify Graduation Plan";
   PrintGreeting( screenTitle );

   cout << endl
	<< "\tA - Add Semester"
	<< endl
        << "\tM - Modify Semester"
	<< endl
        << "\tB - Back"
	<< endl << endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'A' );
   mainChoices.push_back( 'M' );
   mainChoices.push_back( 'B' );
   
   return GetMenuResponse( mainChoices );
   
}


//**************************************
// Function: addSemester( GraduationPlan & gradplan )
// PreConditions:  None
// PostConditions: New semester is added to the graduation plan.
//     Duplicate semesters are not allowed.
//**************************************
void addSemester( GraduationPlan & gradplan )
{
   system( "clear" );

   string screenTitle = "Add Semester";
   PrintGreeting( screenTitle );

   string designator = "";
   int year = 0;

   cout << "Enter Semester Designator (FL/SP/SU/WI): ";
   cin >> designator;

   cout << "Enter Year (yyyy format): ";
   cin >> year;

   cout << "Add the following semester?"
	   << endl;
      
   cout << "\t" 
	<< designator
	<< " "
	<< year
	<< endl;
   
   vector<char> mainChoices;
   mainChoices.push_back( 'Y' );
   mainChoices.push_back( 'N' );
   char confirm = GetMenuResponse( mainChoices );

   if( confirm == 'Y' )
   {
      bool success = gradplan.addSemester( designator, year );

      if( success )
      {
	 cout << "Semester added:"
	      << endl
	      << "\t"
	      << designator
	      << " "
	      << year;
      }

      cout << endl
	   << "To return, type B"
	   << endl;

      mainChoices.clear( );
      mainChoices.push_back( 'B' );
      GetMenuResponse( mainChoices );
   }
   else
   {
      cout << "No course added."
	   << endl
	   << "To return, type B"
	   << endl;
      
      mainChoices.clear( );
      mainChoices.push_back( 'B' );
      GetMenuResponse( mainChoices );
   }
}



//**************************************
// Function: modifySemester( GraduationPlan & gradplan )
// PreConditions:  None
// PostConditions: A selected semester has been modified by either adding, removing,
//     or modifying one or more courses
void modifySemester( GraduationPlan & gradplan )
{

   char validResponse = ' ';
   int semester = semesterSelectionMenu( gradplan );

   do
   {
      validResponse = modifySemesterMenu( );

      switch( validResponse ) 
      {
	 case 'A':
	    addCourse( gradplan, semester );
	    break;
	 case 'D':
	    deleteCourse( gradplan, semester );
	    break;
	 case 'M':
	    modifyCourse( gradplan, semester );
	    break;
	 case 'B':
	    break;
	 default:
	    break;
      }
     
   } while( validResponse != 'B' );
}


//**************************************
// Function: addCourse( )
// PreConditions:  None
// PostConditions: A course from the remaining requirements is added, 
//     if its prerequisites have already been taken.  Note that this means 
//     in the past, not in ANY semester.  No course added if prerequisites
//     fail, nor if it is decided to not add the course after all.  Selected
//     course no longer appears on the remaining requirements list.
//**************************************
void addCourse( GraduationPlan & gradplan, int semester )
{

   // display classes to add
   gradplan.viewRemain( );

   // get user selection
   int userSelection = remainingSelectionMenu( gradplan );
   Course toAdd = gradplan.getFromRemaining( userSelection );

   // check course prerequisites
   bool passed = gradplan.checkPrereqs( toAdd, semester );

   // if not able to, display a message and go back to modifySemester
   if( !passed )
   {

      cout << "You do not have the proper prerequisites for: "
	   << endl
	   << "\t"
           << toAdd.getDesg( )
           << " "
           << toAdd.getNumber( )
           << " - "
           << toAdd.getTitle( )
           << endl;

      cout << "No course added."
	   << endl
	   << "Return, type B"
	   << endl;
      
      vector<char> confirmChoices;
      confirmChoices.push_back( 'B' );
      GetMenuResponse( confirmChoices );
   }
   else
   {

      // if able to add course, do so.  remove the couse from the remaining 
      // requirements
      
      cout << "Add the following course? (Y/N)"
	   << endl;
      
      cout << "\t" 
	   << toAdd.getDesg( )
	   << " "
	   << toAdd.getNumber( )
	   << " - "
	   << toAdd.getTitle( )
	   << endl;
      
      vector<char> mainChoices;
      mainChoices.push_back( 'Y' );
      mainChoices.push_back( 'N' );
      
      char confirm = GetMenuResponse( mainChoices );
      
      // if yes, delete course
      // if not, display message, and return to modifySemester
      if ( confirm == 'Y' )
      {
	 gradplan.removeFromRemaining( toAdd );
	 gradplan.getSemester( semester ).addCourse( toAdd );
      }
      else
      {
	 cout << "No course added."
	      << endl
	      << "To return, type B"
	      << endl;
	 
	 vector<char> confirmChoices;
	 confirmChoices.push_back( 'B' );
	 GetMenuResponse( confirmChoices );
      }
   }
}


//**************************************
// Function: deleteCourse( )
// PreConditions:  None
// PostConditions: A course from those in the semester is removed and added back, 
//     to the list of remaining requirements.  This is only done if approved of.
//**************************************
void deleteCourse( GraduationPlan & gradplan, int semester )
{

   // display list of courses
   gradplan.getSemester( semester ).viewList( );

   // get user selection   
   int userSelection = coursesSelectionMenu( gradplan, semester );

   if( userSelection == -1 )
   {
      return;
   }

   // get the course
   Course toDelete = gradplan.getSemester( semester ).
      viewCourse( userSelection );

   // ask for user confirmation of deletion
   cout << "Delete the following course? (Y/N)" 
	<< endl;
   
   cout << "\t" 
	<< toDelete.getDesg( )
	<< " "
	<< toDelete.getNumber( )
	<< " - "
	<< toDelete.getTitle( )
	<< endl;
   
   vector<char> mainChoices;
   mainChoices.push_back( 'Y' );
   mainChoices.push_back( 'N' );
   
   char confirm = GetMenuResponse( mainChoices );

   // if yes, delete course
   // if not, display message, and return to modifySemester
   if ( confirm == 'Y' )
   {
      gradplan.addToRemaining( toDelete );
      gradplan.getSemester( semester ).deleteCourse( toDelete );
   }
   else
   {
      cout << "No course deleted."
	   << endl
	   << "To return, type B" 
	   << endl;
      
      vector<char> confirmChoices;
      confirmChoices.push_back( 'B' );
      GetMenuResponse( confirmChoices );
   }
}


//**************************************
// Function: modifyCourse( )
// PreConditions:  None
// PostConditions: Course grade is changed or a comment has been added to the course.
//**************************************
void modifyCourse( GraduationPlan & gradplan, int semester )
{

   // get selection
   gradplan.getSemester( semester ).viewList( );
   
   int userSelection = coursesSelectionMenu( gradplan, semester );
   char validResponse = ' ', newGrade = ' ';
   string newComment = "";

   if( userSelection == -1 )
   {
      return;
   }

   Course temp;

   // get choice of which aspect to modify
   // call corresponding modify
   do
   {
      system( "clear" );

      string screenTitle = "Modify Course";
      PrintGreeting( screenTitle );

      temp = gradplan.getSemester(semester).viewCourse(userSelection);

      cout << "Course Information: "
	   << endl
	   << temp.getDesg( )
	   << " "
	   << temp.getNumber( )
	   << " - "
	   << temp.getTitle( )
	   << endl
	   << "Grade: " << temp.getGrade( )
	   << endl
	   << "Comments: " << temp.getComments( )
	   << endl << endl;

      validResponse = modifyCourseMenu( );
      
      switch( validResponse )
      {
	 case 'G':
	    cout << "Input new grade: ";
	    cin >> newGrade;
	    gradplan.getSemester( semester ).
	       viewCourse( userSelection ).inputNewGrade( newGrade );
	    break;
	 case 'C':
	    cout << "Input new comment: ";
	    cin.ignore( 1000, '\n' );
	    getline( cin, newComment );
	    gradplan.getSemester( semester ).
	       viewCourse( userSelection ).appendComments( newComment );
	    break;
	 case 'B':
	    break;
	 default:
	    break;
      }

   } while( validResponse != 'B' );
}


//**************************************
// Function: modifyCourseMenu( )
// PreConditions:  None
// PostConditions: Course modification option selected and returned
//**************************************
char modifyCourseMenu( )
{
  
   cout << "Choose which aspect to modify: "
	<< endl
	<< "\tG - Modify Grade"
	<< endl
	<< "\tC - Add a Comment"
	<< endl
	<< "\tB - Back"
	<< endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'G' );
   mainChoices.push_back( 'C' );
   mainChoices.push_back( 'B' );
   
   return GetMenuResponse( mainChoices );
}


//**************************************
// Function: modifySemesterMenu( )
// PreConditions:  None
// PostConditions: Semester modification option selected and returned 
//**************************************
char modifySemesterMenu( )
{

   system( "clear" );

   string screenTitle = "Modify Semester";
   PrintGreeting( screenTitle );

   cout << endl
	<< "\tA - Add Course"
	<< endl
	<< "\tD - Delete Course"
	<< endl
        << "\tM - Modify Course"
	<< endl
        << "\tB - Back"
	<< endl << endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'A' );
   mainChoices.push_back( 'D' );
   mainChoices.push_back( 'M' );
   mainChoices.push_back( 'B' );
   
   return GetMenuResponse( mainChoices );
}
