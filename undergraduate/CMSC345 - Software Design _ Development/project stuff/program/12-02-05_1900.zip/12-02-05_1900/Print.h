/* Print.h
 *
 * Author: Patrick Trinkle
 * Email:  tri1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#ifndef _Print_h
#define _Print_h

#include <iostream>
#include <string>
#include <vector>

#include "Proj.h"

using namespace std;

//**************************************
// Function: print( )
// PreConditions: A valid GraduationPlan Object &
//                Writer permissions to the current dir
// PostConditions: A GraduationPlan object written  into
//                 an output file: PrintableGraduationPlan.txt
//**************************************
void print( GraduationPlan & gradplan );

#endif
