/* Modify.h
 *
 * Author: Chris Stark
 * Email: cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */


#ifndef _Modify_h
#define _Modify_h

#include <iostream>
#include <string>
#include <vector>
#include <ctype.h>

#include "Proj.h"


using namespace std;

// to modify a plan
//**************************************
// Function: modify( GraduationPlan & gradplan )
// PreConditions:  None
// PostConditions: GraduationPlan has been modified by either adding, removing,
//     or modifying semesters or courses
//**************************************
void modify( GraduationPlan & gradplan );


//**************************************
// Function: modifyMenu( )
// PreConditions:  None
// PostConditions: General modification option selected and returned 
//**************************************
char modifyMenu( );


// to add a semester
//**************************************
// Function: addSemester( GraduationPlan & gradplan )
// PreConditions:  None
// PostConditions: New semester is added to the graduation plan.
//     Duplicate semesters are not allowed.
//**************************************
void addSemester( GraduationPlan & gradplan );


// to modify an existing semester
//**************************************
// Function: modifySemester( GraduationPlan & gradplan )
// PreConditions:  None
// PostConditions: A selected semester has been modified by either adding, removing,
//     or modifying one or more courses
//**************************************
void modifySemester( GraduationPlan & gradplan );


//**************************************
// Function: modifySemesterMenu( )
// PreConditions:  None
// PostConditions: Semester modification option selected and returned 
//**************************************
char modifySemesterMenu( );


// to modify courses
//**************************************
// Function: modifyCourseMenu( )
// PreConditions:  None
// PostConditions: Course modification option selected and returned
//**************************************
char modifyCourseMenu( );


// to modify courses
//**************************************
// Function: addCourse( )
// PreConditions:  None
// PostConditions: A course from the remaining requirements is added, 
//     if its prerequisites have already been taken.  Note that this means 
//     in the past, not in ANY semester.  No course added if prerequisites
//     fail, nor if it is decided to not add the course after all.  Selected
//     course no longer appears on the remaining requirements list.
//**************************************
void addCourse( GraduationPlan & gradplan, int semester );


//**************************************
// Function: deleteCourse( )
// PreConditions:  None
// PostConditions: A course from those in the semester is removed and added back, 
//     to the list of remaining requirements.  This is only done if approved of.
//**************************************
void deleteCourse( GraduationPlan & gradplan, int semester );


//**************************************
// Function: modifyCourse( )
// PreConditions:  None
// PostConditions: Course grade is changed or a comment has been added to the course.
//**************************************
void modifyCourse( GraduationPlan & gradplan, int semester );

#endif
