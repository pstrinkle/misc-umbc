/* Save.h
 *
 * Author: Patrick Trinkle
 * Email:  tri1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#ifndef _Save_h
#define _Save_h

#include <iostream>
#include <string>
#include <vector>

#include "Proj.h"

using namespace std;

//**************************************
// Function: save( )
// PreConditions: A valid GraduationPlan Object &
//                Writer permissions to the current dir
// PostConditions: A GraduationPlan object encoded into
//                 an output file: GraduationPlan.txt
//**************************************
void save( GraduationPlan & gradplan );

#endif
