/* New.h
 *
 * Author: Patrick Trinkle
 * Email:  tri1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#ifndef _New_h
#define _New_h

#include <iostream>
#include <string>
#include <vector>

#include "Proj.h"
#include "Course.h"
#include "GraduationPlan.h"

const int MJ1 = 0;
const int MJ2 = 1;
const int MJ3 = 2;
const int MJ4 = 3;

using namespace std;

//**************************************
// Function: newPlan( )
// PreConditions: A valid list of all Courses Available
// PostConditions: A GraduationPlan object created via
//                 interface with the user
//**************************************
GraduationPlan newPlan( vector<Course> & courseList );

//**************************************
// Function: buildPlan
// PreConditions:  A valid list of All Courses Available &
//                 a valid input file: GraduationPlan.txt
// PostConditions: a GraduationPlan Object created from 
//                 the file: GraduationPlan.txt
//**************************************
GraduationPlan buildPlan ( vector<Course> & courseList );

//**************************************
// Function: getMajorReqs( )
// PreConditions:  A valid list of All Courses Available
//                 and a valid major code, 0-3
// PostConditions: a vector with the graduation requirements
//**************************************
vector<Course> getMajorReqs( int major, vector<Course> & courseList );

#endif
