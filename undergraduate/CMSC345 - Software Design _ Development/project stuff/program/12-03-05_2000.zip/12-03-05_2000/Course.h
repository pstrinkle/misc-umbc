/* Course.h
 *
 * Author: Patrick Trinkle
 * Author: Chris Stark
 * Email:  tri1@umbc.edu, cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#ifndef _Course_h
#define _Course_h

#include <vector>
#include <string>

using namespace std;

class Course
{
   
  public:
   Course( string title = "blank", int number = 123, string designator = "FAKE", vector<Course> prereqs )
      :m_title(title), 
      m_number(number), 
      m_designator(designator), 
      m_prereqs(prereqs), 
      m_grade('P'), 
      m_comments("None")
      {
	 // no code
      }

   Course( string title = "blank", int number = 123, string designator = "FAKE" )
      :m_title(title), 
      m_number(number), 
      m_designator(designator), 
      m_grade('P'), 
      m_comments("None")
      {
	 // no code
      }

   //**************************************
   // Function: operator=( )
   // PreConditions: A valid Course Object
   // PostConditions: Assignment Operator
   //**************************************
   Course & operator=(const Course & rhs);

   //**************************************
   // Function: operator==( )
   // PreConditions: Two valid Course Objects
   // PostConditions: A boolean of their equivalence
   //**************************************
   bool operator==( const Course & rhs );
  
   //**************************************
   // Function: getNumber( )
   // PreConditions: None
   // PostConditions: the Course Number
   //**************************************
   int            getNumber( ) const;

   //**************************************
   // Function: getTitle( )
   // PreConditions: None
   // PostConditions: the Course Title
   //**************************************
   string         getTitle( ) const;

   //**************************************
   // Function: getDesg( )
   // PreConditions: None
   // PostConditions: the Course Designator
   //**************************************
   string         getDesg( ) const;

   //************************************** 
   // Function: getComments( )
   // PreConditions: None
   // PostConditions: the Course Comments
   //**************************************
   string         getComments( ) const;
   
   //**************************************
   // Function: getGrade( )
   // PreConditions: None
   // PostConditions: the Course Grade
   //**************************************
   char           getGrade( ) const;
   
   //**************************************
   // Function: getPreReqs( )
   // PreConditions: None
   // PostConditions: the Course PreReqs, a
   //                 vector of Courses
   //**************************************   
   vector<Course> getPrereqs( ) const;
   
   //**************************************
   // Function: inputNewGrade( )
   // PreConditions: A valid char
   // PostConditions: new Grade value in Course
   //**************************************
   void   inputNewGrade( char newGrade );

   //**************************************
   // Function: inputComments( )
   // PreConditions: A valid string
   // PostConditions: new Comment value in Course
   //                 does override old Comments
   //**************************************
   void   inputComments( string newComments );

   //**************************************
   // Function: appendComments( )
   // PreConditions: A valid string
   // PostConditions: more Comment value in Course
   //**************************************
   void   appendComments( string appendage );
   
   //**************************************
   // Function: loadPreReqs( )
   // PreConditions: A valid Course Object &
   //                a vector of Courses
   // PostConditions: The Course Object will
   //                 have prereqs
   //**************************************
   void   loadPrereqs( vector<Course> newprereqs );

   //**************************************
   // Function: addNewPreReq( ) 
   // PreConditions: A valid Course Object
   // PostConditions: The Course Object will
   //                 have a new Prereqs
   //**************************************
   void   addNewPrereq( Course newprereq );

	 	 
  private:
   string         m_title;
   int            m_number;
   string         m_designator;
   vector<Course> m_prereqs;
   char           m_grade;
   string         m_comments;
};

#endif
