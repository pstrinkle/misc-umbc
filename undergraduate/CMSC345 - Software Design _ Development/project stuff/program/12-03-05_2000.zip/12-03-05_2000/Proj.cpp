/*
** Course Files:
** CourseList.txt - List of all courses and Prerequisites
** GFR.txt - List of all GFRs
** CMSC_Maj.txt - List of all Computer Science Major Requirements
** IS_Maj.txt - List of all Information System Major Requirements
** IS_Maj_CMSC_Min.txt - List of all IS Major CMSC Minor Requirements
** IS_CMSC_Dbl_Maj.txt - List of all IS CMSC Double Major Requirements
** GraduationPlan.txt - The saved Graduation Plan
*/


#include "Course.h"
#include "Semester.h"
#include "GraduationPlan.h"

#include "Proj.h"
#include "View.h"
#include "New.h"
#include "Save.h"
#include "Modify.h"
#include "Print.h"

const int CRSLST = 0;

using namespace std;

int main()
{
   
   GraduationPlan gradplan;

   vector<Course> courseList;
   courseList = buildCourseInfo();

   /* To create a new Graduation Plan or not to? */
   system("clear");
   PrintQGPLogo( );

   cout << "Welcome, do you already have a GraduationPlan saved? (Y/N)" << endl;

   vector<char> yesNoChoices;
   yesNoChoices.push_back('Y');
   yesNoChoices.push_back('N');
   char gradplanChoice = GetMenuResponse( yesNoChoices );

   switch ( gradplanChoice )
   {
      case 'Y':
	 gradplan = buildPlan( courseList );
	 break;
      case 'N':
	 gradplan = newPlan( courseList );
	 break;
   }
   
   char validResponse = ' ';

   do
   {
      validResponse = displayMainMenu( );

      switch( validResponse ) 
      {
	 case 'N':
	    gradplan = newPlan( courseList );
	    break;
	 case 'M':
	    modify( gradplan );
	    break;
	 case 'V':
	    view( gradplan );
	    break;
	 case 'P':
	    print( gradplan );
	    break;
	 case 'S':
	    save( gradplan );
	    break;
	 case 'C':
	    credits( );
	    break;
	 case 'Q':
	    break;
	 default:
	    cerr << "Invalid menu selection, please try again!"
		 << endl;
	    break;
      }
   } while ( validResponse != 'Q' );


   system( "clear" );

   cout << "Would you like to save the graduation plan? (Y/N)" << endl
	<< "It will be saved as: GraduationPlan.txt" << endl;

   char saveChoice = GetMenuResponse( yesNoChoices );

   switch(saveChoice)
   {
      case 'Y':
	 save( gradplan );
	 cout << "Saved." << endl;
	 break;
      case 'N':
	 break;
   }

   system( "clear" );

   return 0;
}
