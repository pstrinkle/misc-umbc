/* test Driver for GraduationPlan class
 * must have GraduationPlan.o Semester.o Course.o
 * must have GraduationPlan.h Semester.h Course.h
 *
 * to compile:
 * g++ -Wall -ansi -o GradPlanDriver GradPlanDriver.cpp GraduationPlan.o Semester.o Course.o
 */

#include <iostream>

#include "GraduationPlan.h"

int main()
{

   system("clear");

   cout << "\tTesting the GraduationPlan class" << endl;

   cout << "\tTesting Constructor" << endl;

   Semester tempSem("FL", 2005);

   GraduationPlan tempPlan("John Doe", tempSem, "IS", "CMSC");

   cout << "\tTesting GraduationPlan::getName, getMajor, getMinor, numSemesters" << endl;
   cout << "Name: " << tempPlan.getName() << endl
	<< "Major: " << tempPlan.getMajor() << endl
	<< "Minor: " << tempPlan.getMinor() << endl
	<< "NumSemesters: " << tempPlan.numSemesters() << endl
	<< endl;

   GraduationPlan tempPlan2("Jane Doe", "IS", "CMSC");

   cout << "\tTesting GraduationPlan::getName, getMajor, getMinor, numSemesters" 
	<< endl;
   cout << "Name: " << tempPlan2.getName() << endl
	<< "Major: " << tempPlan2.getMajor() << endl
	<< "Minor: " << tempPlan2.getMinor() << endl
	<< "NumSemesters: " << tempPlan2.numSemesters() << endl
	<< endl;

   Semester tempSem3("FL", 2005);
   vector<Course> reqs;
   Course temp;
   reqs.push_back( temp );
   GraduationPlan tempPlan3("Jim Doe", tempSem3, "IS", "CMSC", reqs );

   cout << "\tTesting GraduationPlan::getName, getMajor, getMinor, numSemesters" 
	<< endl;
   cout << "Name: " << tempPlan3.getName() << endl
	<< "Major: " << tempPlan3.getMajor() << endl
	<< "Minor: " << tempPlan3.getMinor() << endl
	<< "NumSemesters: " << tempPlan3.numSemesters() << endl
	<< endl;

   Semester tempSem4("FL", 2005);
   vector<Course> reqs2;
   Course temp2;
   reqs.push_back( temp2 );
   GraduationPlan tempPlan4("Jake Doe", tempSem4, "IS/CMSC Double Major", "None", reqs2 );

   cout << "\tTesting GraduationPlan::getName, getMajor, getMinor, numSemesters" 
	<< endl;
   cout << "Name: " << tempPlan4.getName() << endl
	<< "Major: " << tempPlan4.getMajor() << endl
	<< "Minor: " << tempPlan4.getMinor() << endl
	<< "NumSemesters: " << tempPlan4.numSemesters() << endl
	<< endl;



   cout << "\tTesting GraduationPlan::listSemesters()" << endl << endl;
   tempPlan.listSemesters( );

   cout << endl;

   cout << "\tTesting GraduationPlan::getSemester()" << endl << endl;
  
   Semester tempSem2 = tempPlan.getSemester( 0 );
   
   cout << "Designator: " << tempSem2.getDesg() << endl
	<< "Year: " << tempSem2.getYear() << endl
	<< endl;

   cout << "\tTesting GraduationPlan::addSemester()" << endl;
   bool pass = tempPlan.addSemester("FL", 2005);

   if ( pass == true )
      cout << "Semester added, duplicated, fail" << endl;
   else
      cout << "Semester not added, duplicated, pass" << endl;

   pass = tempPlan.addSemester("SP",2006);

   if ( pass == true )
      cout << "Semester added, non-duplicate, pass" << endl;
   else
      cout << "Semester not added, non-duplicate, fail" << endl;

   cout << endl << endl;

   cout << "TESTS VIEW: EXPECTED - NO OUTPUT" 
	<< endl;
   tempPlan.viewRemain( );
   cout << "END EXPECTED" 
	<< endl << endl;

   cout << "TESTS ADD: EXPECTED - CMSC 201" 
	<< endl;
   Course tempCourse( "Programming I", 201, "CMSC" );
   tempPlan.addToRemaining( tempCourse );
   tempPlan.viewRemain( );
   cout << "END EXPECTED" 
	<< endl << endl;

   cout << "TESTS ADD: EXPECTED - CMSC 201, 202" 
	<< endl;
   Course tempCourse2( "Programming II", 202, "CMSC" );
   tempPlan.addToRemaining( tempCourse2 );
   tempPlan.viewRemain( );
   cout << "END EXPECTED" 
	<< endl << endl;

   cout << "TESTS GET: EXPECTED - CMSC 202" 
	<< endl;
   tempCourse2 = tempPlan.getFromRemaining( 0 );
   tempPlan.viewRemain( );
   cout << "END EXPECTED" 
	<< endl << endl;

   cout << "TESTS REMOVE: EXPECTED - NO OUTPUT" 
	<< endl;
   tempPlan.removeFromRemaining( tempCourse );
   tempPlan.viewRemain( );
   cout << "END EXPECTED" 
	<< endl << endl;

   cout << "\tItems not yet tested: " << endl
	<< "GraduationPlan::checkPrereqs() (unable to test?)" << endl;

   return ( 0 );
}
