/* Semester.h
 *
 * Author: Patrick Trinkle
 * Author: Chris Stark
 * Email:  tri1@umbc.edu, cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#include "Semester.h"

//**************************************
// Function: operator<( )
// PreConditions: Two valid Semester Objects
// PostConditions: If one Semester falls
//                 before another
//**************************************
bool Semester::operator<( const Semester & rhs )
{

   string WI = "WI";
   string SP = "SP";
   string SU = "SU";
   string FL = "FL";

   bool lesser = false;
   if( getYear( ) < rhs.getYear( ) )
   {
      lesser = true;
   }
   else
   {
      string desg = getDesg( );
      int desgNum = 0;
      string rhsDesg = rhs.getDesg( );
      int rhsDesgNum = 0;
    
      if( desg == WI )
      {
	 desgNum = 0;
      }
      else if( desg == SP )
      {
	 desgNum = 1;
      }
      else if( desg == SU )
      {
	 desgNum = 2;
      }
      else if( desg == FL )
      {
	 desgNum = 3;
      }

      if( rhsDesg == WI )
      {
	 rhsDesgNum = 0;
      }
      else if( rhsDesg == SP )
      {
	 rhsDesgNum = 1;
      }
      else if( rhsDesg == SU )
      {
	 rhsDesgNum = 2;
      }
      else if( rhsDesg == FL )
      {
	 rhsDesgNum = 3;
      }

      if( desgNum < rhsDesgNum )
      {
	 lesser = true;
      }

   }

   return( lesser );
}

//**************************************
// Function: operator==( )
// PreConditions: Two valid Semester Objects
// PostConditions: Their Equivalency
//**************************************
bool Semester::operator==( const Semester & rhs )
{

   bool same = false;

   if( this == &rhs )
   {
      same = true;
   }
   else if( ( getDesg( ) == rhs.getDesg( ) ) 
	    && ( getYear( ) == rhs.getYear( ) ) )
   {
      same = true;
   }


   return ( same );
}

//**************************************
// Function: viewCourse( )
// PreConditions: The index in the Semester
//                of the Course you'd like
// PostConditions: Assignment Operator
//**************************************
Course & Semester::viewCourse( int index )
{
   return ( m_courses.at( index ) );
}

//**************************************
// Function: deleteCourse( )
// PreConditions: the Course to delete
// PostConditions:
//**************************************
string Semester::deleteCourse( Course & toDelete )
{
   // I have no idea, we need an input.
   // how to identify the course to delete
   // should we use vector index?

   string temp = "temporary";
   int foundPos = -1;

   unsigned int i = 0;
   for( i = 0; i < m_courses.size( ); i++ )
   {

      if( m_courses.at( i ) == toDelete )
      {
	 foundPos = i;
      }

   }

   if( foundPos != -1 )
   {
      m_courses.erase( m_courses.begin( ) + foundPos );
   }

   return temp;
}

//**************************************
// Function: addCourse( )
// PreConditions: A valid Course Object
// PostConditions: A semester plus that Course
//                 and returns the title
//                 of the Course added
//**************************************
string Semester::addCourse( Course newCourse )
{
   m_courses.push_back( newCourse );
   return newCourse.getTitle();
}  

//**************************************
// Function: viewList( )
// PreConditions: None
// PostConditions: Prints to stdout a list
//                 of all Course in Semester
//**************************************
void Semester::viewList( )
{
   for ( unsigned int i = 0; i < m_courses.size(); ++i )
   {
      cout << "\t" 
	   << i 
	   << ". " 
	   << m_courses.at(i).getDesg() 
	   << " "
	   << m_courses.at(i).getNumber()
	   << " - "
	   << m_courses.at(i).getTitle() 
	   << endl;
   }
}

//**************************************
// Function: numCourses( )
// PreConditions: None
// PostConditions: the Number of Courses
//                 in Semester
//**************************************
int Semester::numCourses( )
{
   return static_cast<int>(m_courses.size());
}

//**************************************
// Function: getDesg( )
// PreConditions: None
// PostConditions: returns the Semester
//                 designator
//**************************************
string Semester::getDesg( ) const
{
   return m_designator;
}

//**************************************
// Function: getYear( )
// PreConditions: None
// PostConditions: returns the Semester
//                 year
//**************************************
int Semester::getYear( ) const
{
   return m_year;
}
