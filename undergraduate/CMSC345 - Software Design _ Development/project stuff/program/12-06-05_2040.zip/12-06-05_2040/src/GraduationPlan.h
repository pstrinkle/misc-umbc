/* GraduationPlan.h
 *
 * Author: Patrick Trinkle
 * Author: Chris Stark
 * Email:  tri1@umbc.edu, cstark1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#ifndef _GraduationPlan_h
#define _GraduationPlan_h

#include "Semester.h"

#include <vector>
#include <string>

using namespace std;

class GraduationPlan
{

  public:
   GraduationPlan( string studentName, 
		   Semester startingSemester, 
		   string major, 
		   string minor ):
      m_studentName(studentName), 
      m_startingSemester(startingSemester), 
      m_major(major), 
      m_minor(minor)
    {
       m_plan.push_back(startingSemester);
    }

   GraduationPlan( string studentName = "default", 
		   string major = "None", 
		   string minor = "None" ):
      m_studentName( studentName ), 
      m_startingSemester( "default", 6666 ), 
      m_major( major ), 
      m_minor( minor )
   {
      m_plan.push_back(Semester("default", 6666));
   }

   GraduationPlan( string studentName, 
		   Semester startingSemester, 
		   string major, 
		   string minor, 
		   vector<Course> reqs ):
      m_studentName( studentName ), 
      m_startingSemester( startingSemester ), 
      m_major( major ), 
      m_minor( minor ), 
      m_remainReqs( reqs )
   {
      m_plan.push_back(startingSemester);
   }

   GraduationPlan( string studentName, 
		   Semester startingSemester, 
		   string major, 
		   string minor, 
		   vector<Semester> semesters, 
		   vector<Course> reqs ):
      m_studentName( studentName ), 
      m_startingSemester( startingSemester ), 
      m_major( major ), 
      m_minor( minor ), 
      m_plan( semesters ), 
      m_remainReqs( reqs )
   {
      // no code
   }

   //**************************************
   // Function: viewRemain( )
   // PreConditions: None
   // PostConditions: Printed to stdout the
   //                 remaining Graduation
   //                 requirements
   //**************************************
   void           viewRemain( );

   //**************************************
   // Function: listSemesters( )
   // PreConditions: None
   // PostConditions: Printed to stdout the
   //                 Semesters in a list
   //**************************************
   void           listSemesters( );

   //**************************************
   // Function: numSemesters( )
   // PreConditions: None
   // PostConditions: The number of Semesters
   //**************************************
   int            numSemesters( );

   //**************************************
   // Function: getSemesters( )
   // PreConditions: A valid index
   // PostConditions: a reference to the
   //                 requested Semester
   //**************************************
   Semester &     getSemester( int index );

   //**************************************
   // Function: getName( )
   // PreConditions: None
   // PostConditions: The Student's name
   //**************************************
   string         getName( );

   //**************************************
   // Function: getMajor( )
   // PreConditions: None
   // PostConditions: The Student's Major
   //**************************************
   string         getMajor( );

   //**************************************
   // Function: getMinor( )
   // PreConditions: None
   // PostConditions: The Student's Minor
   //**************************************
   string         getMinor( );

   //**************************************
   // Function: getRemainReqs( )
   // PreConditions: None
   // PostConditions: The Remaining Graduation
   //                 Requirements
   //**************************************
   vector<Course> getRemainReqs( );


   // ?
   Course &       getFromRemaining( int index );

   //**************************************
   // Function: addSemester( )
   // PreConditions: None
   // PostConditions: adds the semester to the
   //                 GraduationPlan, returns 
   //                 if the semester was added
   //**************************************
   bool           addSemester( string designator, int year );

   //**************************
   // checkPrereqs( Course & check )
   // Pre:  
   // Post: 
   //**************************
   bool           checkPrereqs( Course & check, int semester );

   // ?
   void           removeFromRemaining( Course & toRemove );

   // ?
   void           addToRemaining( Course toAdd );

  private:
   string           m_studentName;
   Semester         m_startingSemester;
   string           m_major;
   string           m_minor;
   vector<Semester> m_plan;
   vector<Course>   m_remainReqs; //has major & GFR reqs

};

#endif
