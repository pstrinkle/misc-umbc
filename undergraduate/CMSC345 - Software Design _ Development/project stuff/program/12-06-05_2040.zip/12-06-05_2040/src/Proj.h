#ifndef _Proj_h
#define _Proj_h

#include <ctype.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdlib.h>

#include "Course.h"
#include "Semester.h"
#include "GraduationPlan.h"

const string START = "START";
const string ADD = "ADD";
const string SEM = "SEMESTER";
const string REM = "REMAINDER";

const string ENDPRE = "ENDPRE";

using namespace std;

char displayMainMenu( );

char GetMenuResponse ( const vector<char> & theChoices );

int  GetIntResponse ( int min, int max );

void PrintGreeting ( string title );

void PrintQGPLogo ( );

bool validateSelection ( const char choice, const vector<char> & theChoices );

int  semesterSelectionMenu( GraduationPlan & gradplan );
int  coursesSelectionMenu( GraduationPlan & gradplan, int semesterChoice );
int  coursesSelectionMenu( Semester & semester );
int  remainingSelectionMenu( GraduationPlan & gradplan );

/* get course title from list of courses */
Course  retrieveCourseInfo ( string designator, int number, vector<Course> & courselist );

vector<Course> buildCourseInfo( );

void credits( );
 
#endif
