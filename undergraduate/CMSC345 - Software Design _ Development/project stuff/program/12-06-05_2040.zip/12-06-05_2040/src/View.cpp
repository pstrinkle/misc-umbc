/* View.cpp
 *
 * Author: Patrick Trinkle
 * Email:  tri1@umbc.edu
 * Last Modified: 11/27/05
 * Quick Grad Planner
 */

#include "View.h"

using namespace std;

//**************************************
// Function: view( )
// PreConditions: A valid GraduationPlan object
// PostConditions: return of control to main menu
//**************************************
void view( GraduationPlan & gradplan )
{
   char validResponse = ' ';
   int semesterChoice = 0;
   int courseChoice = 0;

   vector<char> mainChoices;
   mainChoices.push_back('B');

   string damnThing = "Courses in Semester";

   // launch menu
   do
   {
      validResponse = viewMenu( );

      switch( validResponse ) 
      {
	 case 'R':
	    viewRemainingGrad( gradplan );
	    break;
	 case 'S':
	    semesterChoice = semesterSelectionMenu( gradplan );
	    system("clear");
	    PrintGreeting( damnThing );
	    gradplan.getSemester(semesterChoice).viewList();
	    cout << "Return, type B" << endl;
	    GetMenuResponse( mainChoices );
	    break;
	 case 'B':
	    break;
	 case 'C':
	    semesterChoice = semesterSelectionMenu( gradplan );
	    courseChoice = coursesSelectionMenu( gradplan, semesterChoice );
	    if ( courseChoice >= 0 )
	       viewCourseInfo(gradplan, semesterChoice, courseChoice);
	    break;
	 case 'I':
	    viewStudentInfo( gradplan );
	 default:
	    break;
      }
     
   } while( validResponse != 'B' );

}

//**************************************
// Function: viewMenu( )
// PreConditions: None
// PostConditions: a character representing
//                 an option for view()
//**************************************
char viewMenu( )
{
   system( "clear" );

   string screenTitle = "View Graduation Plan";
   PrintGreeting( screenTitle );

   cout << endl 
	<< "\tR - View Remaining Graduation Requirements"
	<< endl
        << "\tS - View Selectable Semesters"
	<< endl
	<< "\tC - View Selected Course Information"
	<< endl
	<< "\tI - View Student Information"
	<< endl
        << "\tB - Back"
	<< endl << endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'R' );
   mainChoices.push_back( 'S' );
   mainChoices.push_back( 'B' );
   mainChoices.push_back( 'C' );
   mainChoices.push_back( 'I' );

   return GetMenuResponse( mainChoices );
}

//**************************************
// Function: viewRemainingGrad( )
// PreConditions: A valid GraduationPlan Object
// PostConditions: None
//**************************************
void viewRemainingGrad( GraduationPlan & gradplan )
{
   system("clear");

   string screenTitle = "Remaining Graduation Requirements";
   PrintGreeting( screenTitle );

   gradplan.viewRemain( );

   cout << "Return, type B" << endl;

   vector<char> mainChoices;
   mainChoices.push_back( 'B' );
   GetMenuResponse( mainChoices );
}

//**************************************
// Function: viewCourseInfo( )
// PreConditions: A valid GraduationPlan Object
//                A valid semester and course choices
//                for viewing
// PostConditions: None
//**************************************
void viewCourseInfo( GraduationPlan & gradplan, int semesterChoice, int courseChoice )
{
   system("clear");
   Course displayCourse = gradplan.getSemester(semesterChoice).viewCourse(courseChoice);
   string screenTitle = displayCourse.getTitle();
   PrintGreeting( screenTitle );

   cout << displayCourse.getDesg() << " " 
	<< displayCourse.getNumber() << endl
	<< "Grade: " << displayCourse.getGrade() << endl
	<< "Comments: " << displayCourse.getComments()
	<< endl << endl;

   cout << endl << "Return, type B" << endl;
   vector<char> mainChoices;
   mainChoices.push_back('B');
   GetMenuResponse( mainChoices );
}

//**************************************
// Function: viewStudentInfo( )
// PreConditions: A valid GraduationPlan Object
// PostConditions: None
//**************************************
void viewStudentInfo( GraduationPlan & gradplan )
{
   system( "clear" );
   string screenTitle = gradplan.getName();
   PrintGreeting( screenTitle );

   cout << "Major: " << gradplan.getMajor() << endl
	<< "Minor: " << gradplan.getMinor() << endl;

   Semester temp = gradplan.getSemester( 0 );

   cout << "Starting Semester: " 
	<< temp.getDesg() << " " 
	<< temp.getYear() << endl;

   cout << endl << "Return, type B" << endl;
   vector<char> mainChoices;
   mainChoices.push_back('B');
   GetMenuResponse( mainChoices );
}
