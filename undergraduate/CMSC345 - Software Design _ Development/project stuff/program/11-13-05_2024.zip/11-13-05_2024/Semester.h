#ifndef _Semester_h
#define _Semester_h

#include "Course.h"

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Semester 
{

  public:
   Semester( string designator, int year, vector<Course> courses )
      :m_designator(designator), m_year(year), m_courses(courses)
      { // 
      }

   Course viewCourse( int index );
   string deleteCourse( );
   string addCourse( Course newCourse );
   void   viewList( );
   int    numCourses( );

   string getDesg( )
      {
	 return m_designator;
      }
   int    getYear( )
      {
	 return m_year;
      }

  private:
   string         m_designator;
   int            m_year;
   vector<Course> m_courses;
};

#endif
