#include "Range.h"


int Range::getStartYear( )
{
   return m_startyear;
}
int Range::getEndYear( )
{
   return m_endyear;
}
string Range::getStartDesg( )
{
   return m_startdesg;
}
string Range::getEndDesg( )
{
   return m_enddesg;
}
