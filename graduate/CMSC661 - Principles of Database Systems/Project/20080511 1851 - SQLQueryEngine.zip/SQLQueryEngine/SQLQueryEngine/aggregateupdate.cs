﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace SQLQueryEngine
{
    public class aggregateupdate
    {
        public aggregateupdate(string update, DataTable updateDb)
        {
            m_updateDb = new DataTable();
            m_updateDb = updateDb.Copy();

            m_update = update;
        }

        public DataTable getDataTable()
        {
            return m_updateDb;
        }

        public string getLabelUpdate()
        {
            return m_update;
        }

        private string m_update;
        private DataTable m_updateDb;
    }
}
