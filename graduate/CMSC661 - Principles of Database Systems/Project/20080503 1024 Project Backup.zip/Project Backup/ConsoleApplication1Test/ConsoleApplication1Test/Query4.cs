﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query4
    {
        public Query4()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable dt = new DataTable("temp");
            List<string> fields = new List<string>();

            fields.Add("customer_name");

            scan s = new scan("customer");

            project p = new project(fields);

            select s1 = new select("customer_street", "like", "Hill$");

            distinct d1 = new distinct(fields);

            s.open();

            dt = s.cloneSchema();

            /* get all tuples from SCAN */
            while (s.hasMore())
            {
                dt.ImportRow(s.next());
            }

            s.close();

            /* add selects here */
            s1.open(dt);

            /* prepare for new set */
            dt.Clear();

            while (s1.hasMore())
            {
                dt.ImportRow(s1.next());
            }

            s1.close();

            d1.open(dt);

            dt.Clear();

            while (d1.hasMore())
            {
                dt.ImportRow(d1.next());
            }

            d1.close();

            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();

            while (p.hasMore())
            {
                dt.ImportRow(p.next());
            }

            p.close();

            return dt;
        }
    }
}
