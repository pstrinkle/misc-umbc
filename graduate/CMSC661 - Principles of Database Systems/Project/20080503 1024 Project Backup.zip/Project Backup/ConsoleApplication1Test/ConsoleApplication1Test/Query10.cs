﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query10
    {
        public Query10()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable dt = new DataTable("temp");
            DataTable dto = new DataTable("temp");
            List<string> fields = new List<string>();

            fields.Add("branch_name");
            fields.Add("count(distinct customer_name)");

            scan sdepositor = new scan("depositor");
            scan saccount = new scan("account");

            count c = new count("customer_name", "branch_name", true);

            renamefield renDep = new renamefield("account_number", "depositor.account_number");
            renamefield renAcc = new renamefield("account_number", "account.account_number");

            List<string> joinon = new List<string>();
            joinon.Add("depositor.account_number");
            joinon.Add("eq");
            joinon.Add("account.account_number");
            joinon.Add("str");

            join j = new join(joinon);

            project p = new project(fields);

            /* read in depositor */
            sdepositor.open();

            dt = sdepositor.cloneSchema();

            /* get all tuples from SCAN */
            while (sdepositor.hasMore())
            {
                dt.ImportRow(sdepositor.next());
            }

            sdepositor.close();

            /* read in account */
            saccount.open();

            dto = saccount.cloneSchema();

            while (saccount.hasMore())
            {
                dto.ImportRow(saccount.next());
            }

            saccount.close();

            /* rename fields before join */
            renAcc.open(dto);
            renDep.open(dt);

            /* join relations */
            j.open(dt, dto);

            dt.Clear();
            dto.Clear();

            dt = j.cloneSchema();

            while (j.hasMore())
            {
                dt.ImportRow(j.next());
            }

            /* count */
            c.open(dt);

            dt.Clear();

            dt = c.cloneSchema();

            while (c.hasMore())
            {
                dt.ImportRow(c.next());
            }

            c.close();
            
            /* project */
            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();

            while (p.hasMore())
            {
                dt.ImportRow(p.next());
            }

            p.close();

            return dt;
        }
    }
}
