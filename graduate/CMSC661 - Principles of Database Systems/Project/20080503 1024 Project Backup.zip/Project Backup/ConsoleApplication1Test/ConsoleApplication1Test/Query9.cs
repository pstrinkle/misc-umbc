﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query9
    {
        public Query9()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable dt = new DataTable("temp");
            List<string> fields = new List<string>();

            scan s = new scan("account");

            project p = new project(fields);

            avg a = new avg("balance", "branch_name");

            select se = new select("avg(balance)", "gt", 700);

            s.open();

            dt = s.cloneSchema();

            /* get all tuples from SCAN */
            while (s.hasMore())
            {
                dt.ImportRow(s.next());
            }

            s.close();

            a.open(dt);

            dt.Clear();

            // because might be returning different columns
            dt = a.cloneSchema();

            while (a.hasMore())
            {
                dt.ImportRow(a.next());
            }

            a.close();

            se.open(dt);

            dt.Clear();

            while (se.hasMore())
            {
                dt.ImportRow(se.next());
            }

            se.close();

            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();

            while (p.hasMore())
            {
                dt.ImportRow(p.next());
            }

            p.close();

            return dt;
        }
    }
}
