﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query14
    {
        public Query14()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable branchData = new DataTable("temp");
            DataTable dt = new DataTable("temp");

            List<string> subfields = new List<string>();
            List<string> fields = new List<string>();

            subfields.Add("assets");
            fields.Add("branch_name");

            scan s = new scan("branch");

            project subp = new project(subfields);
            project p = new project(fields);
            
            select s1 = new select("branch_city", "eq", "Brooklyn");
            
            s.open();

            branchData = s.cloneSchema();

            /* get all tuples from SCAN */
            while (s.hasMore())
            {
                branchData.ImportRow(s.next());
            }

            s.close();

            /* execute sub query */
            dt = branchData.Copy();
            
            s1.open(dt);
            
            dt.Clear();

            while (s1.hasMore())
            {
                dt.ImportRow(s1.next());
            }

            s1.close();

            subp.open(dt);

            dt.Clear();

            List<int> values = new List<int>();

            while (subp.hasMore())
            {
                DataRow dr = subp.next();
                Object[] obs = dr.ItemArray;

                values.Add((int)obs[0]);
            }

            subp.close();

            int maximumvalue = values.Max();

            selectALL sAll = new selectALL("assets", "gt", maximumvalue);

            sAll.open(branchData);

            dt = branchData.Clone();

            while (sAll.hasMore())
            {
                dt.ImportRow(sAll.next());
            }

            sAll.close();

            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();

            while (p.hasMore())
            {
                dt.ImportRow(p.next());
            }

            p.close();

            return dt;
        }
    }
}

