﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query5
    {
        public Query5()
        {
            /* no code is god's code */
        }

        public void exec()
        {
            DataTable dt = new DataTable("temp");
            List<string> fields = new List<string>();
            
            scan s = new scan("loan");

            project p = new project(fields);
                        

            s.open();

            dt = s.cloneSchema();

            /* get all tuples from SCAN */
            while (s.hasMore())
            {
                dt.ImportRow(s.next());
            }

            s.close();

            /* add orderby here */

            /* add second orderby here */


            p.open(dt);

            /* begin output */
            Aux.printschema(p.columns());

            while (p.hasMore())
            {
                Aux.printrow(p.next());
            }

            p.close();
        }
    }
}
