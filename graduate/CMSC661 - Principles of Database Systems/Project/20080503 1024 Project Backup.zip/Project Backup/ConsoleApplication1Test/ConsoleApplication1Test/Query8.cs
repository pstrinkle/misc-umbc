﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query8
    {
        public Query8()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable dt = new DataTable("temp");
            List<string> empty = new List<string>();

            empty.Add("branch_city");
            empty.Add("total_assets");

            scan s = new scan("branch");
            project p = new project(empty);
            sum summation = new sum("assets", "branch_city");
            renamefield totalassets = new renamefield("sum(assets)", "total_assets");
            orderby assetOrdering = new orderby("total_assets", "desc", "int");

            s.open();

            dt = s.cloneSchema();

            /* get all tuples from SCAN */
            while (s.hasMore())
            {
                dt.ImportRow(s.next());
            }

            s.close();

            /* run sum aggregation */
            summation.open(dt);

            dt.Clear();

            dt = summation.cloneSchema();

            while (summation.hasMore())
            {
                dt.ImportRow(summation.next());
            }

            summation.close();

            totalassets.open(dt);

            assetOrdering.openSingleSort(dt);

            dt.Clear();

            while (assetOrdering.hasMore())
            {
                dt.ImportRow(assetOrdering.next());
            }

            assetOrdering.close();

            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();

            while (p.hasMore())
            {
                dt.ImportRow(p.next());
            }

            p.close();

            return dt;
        }
    }
}
