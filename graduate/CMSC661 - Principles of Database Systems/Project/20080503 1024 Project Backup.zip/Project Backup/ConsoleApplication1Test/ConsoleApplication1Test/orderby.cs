﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApplication1Test
{
    public class orderby
    {        
        /* string sorting is untested and probably doesn't quite work right yet */

        public orderby(string field, string ordering, string dataType)
        {
            this.m_field = field;
            this.m_order = ordering;
            this.m_dataType = dataType;

            this.m_dt = new DataTable();
            this.m_current_tuple = 0;
        }

        /* orderby with multiple fields and orderings
         * not yet implemented */

        public void openSingleSort(DataTable data)
        {
            // clean out any garbage
            m_dt.Clear();
            m_dt = data.Clone();
            
            int fieldIndex = data.Columns.IndexOf(m_field);

            // currently only sorting on 1 field

            if (m_dataType.CompareTo("int") == 0)
            {
                int cur_val = 0;

                if (m_order.CompareTo("desc") == 0)
                {
                    int highest = 0;
                    int highestIndex = 0;

                    /* while data still has rows */
                    while (data.Rows.Count > 0)
                    {
                        highest = 0;
                        highestIndex = 0;

                        // super slow sort
                        for (int i = 0; i < data.Rows.Count; i++)
                        {
                            cur_val = (int)data.Rows[i].ItemArray[fieldIndex];

                            if (cur_val > highest)
                            {
                                highest = cur_val;
                                highestIndex = i;
                            }
                        }

                        // so now highestIndex has the highest Valued value

                        m_dt.ImportRow(data.Rows[highestIndex]);
                        data.Rows.Remove(data.Rows[highestIndex]);
                    }

                    /* m_dt now is a sorted table on first field */
                }
                else // if (m_order.CompareTo("asc") == 0)
                {
                    int lowest = 0;
                    int lowestIndex = 0;

                    /* while data still has rows */
                    while (data.Rows.Count > 0)
                    {
                        lowest = 0;
                        lowestIndex = 0;

                        // super slow sort
                        for (int i = 0; i < data.Rows.Count; i++)
                        {
                            cur_val = (int)data.Rows[i].ItemArray[fieldIndex];

                            if (cur_val < lowest)
                            {
                                lowest = cur_val;
                                lowestIndex = i;
                            }
                        }

                        m_dt.ImportRow(data.Rows[lowestIndex]);
                        data.Rows.Remove(data.Rows[lowestIndex]);
                    }
                }
            } /* end of int sorting */
            else
            {
                /* string sorting */
                string cur_val = string.Empty;

                if (m_order.CompareTo("desc") == 0)
                {
                    string highest = string.Empty;
                    int highestIndex = 0;

                    /* while data still has rows */
                    while (data.Rows.Count > 0)
                    {
                        highest = string.Empty;
                        highestIndex = 0;

                        // super slow sort
                        for (int i = 0; i < data.Rows.Count; i++)
                        {
                            cur_val = (string)data.Rows[i].ItemArray[fieldIndex];

                            if (cur_val.CompareTo(highest) == 1)
                            {
                                highest = cur_val;
                                highestIndex = i;
                            }
                        }

                        // so now highestIndex has the highest Valued value

                        m_dt.ImportRow(data.Rows[highestIndex]);
                        data.Rows.Remove(data.Rows[highestIndex]);
                    }
                }
                else
                {
                    /* asc */
                    string lowest = string.Empty;
                    int lowestIndex = 0;

                    /* while data still has rows */
                    while (data.Rows.Count > 0)
                    {
                        lowest = string.Empty;
                        lowestIndex = 0;

                        // super slow sort
                        for (int i = 0; i < data.Rows.Count; i++)
                        {
                            cur_val = (string)data.Rows[i].ItemArray[fieldIndex];

                            if (cur_val.CompareTo(lowest) == -1)
                            {
                                lowest = cur_val;
                                lowestIndex = i;
                            }
                        }

                        m_dt.ImportRow(data.Rows[lowestIndex]);
                        data.Rows.Remove(data.Rows[lowestIndex]);
                    }
                } /* end of asc string sorting */
            } /* end of string sorting */            
        }

        public Boolean hasMore()
        {
            Boolean success = false;

            if (m_dt.Rows.Count > m_current_tuple)
                success = true;

            return success;
        }

        public DataRow next()
        {
            DataRow dr = m_dt.Rows[m_current_tuple];
            m_current_tuple++;

            return dr;
        }

        public void close()
        {
            m_dt.Clear();           
        }

        private string m_field;
        private string m_order;
        private string m_dataType;
        private DataTable m_dt;
        private int m_current_tuple;
    }
}
