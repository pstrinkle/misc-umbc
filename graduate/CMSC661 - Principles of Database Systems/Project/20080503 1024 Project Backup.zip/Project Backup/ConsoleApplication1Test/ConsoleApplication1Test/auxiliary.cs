﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    class Aux
    {
        /* print output schema */
        public static void printschema(DataColumnCollection columns)
        {
            StringBuilder sb = new StringBuilder();

            /* print out each column name tab delimited */
            foreach (DataColumn c in columns)
            {
                sb.Append(c.ColumnName);
                sb.Append("\t");
            }
           
            Console.WriteLine(sb.ToString());
        }

        /* print tuple */
        public static void printrow(DataRow row)
        {
            /* prints the row, each column tab delimited */

            StringBuilder sb = new StringBuilder();

            Object[] obs = null;
            obs = row.ItemArray;

            foreach (object o in obs)
            {
                sb.Append(o.ToString());
                sb.Append("\t");
            }
            
            Console.WriteLine(sb.ToString());
        }

        /* print aggregate updates */
        public static void printUpdates(DataTable table)
        {
            // just do stuff.
            Console.WriteLine("Aggregate Update:");

            Aux.printschema(table.Columns);

            foreach (DataRow dr in table.Rows)
                Aux.printrow(dr);
        }

        /* print query selection menu */
        public static void printMenu()
        {
            /* prints implemented queries */
            StringBuilder sb = new StringBuilder();

            sb.Append("Query 1: select * from customer;\n");
            sb.Append("Query 2: select account_number from account where balance between 700 and 900;\n");
            sb.Append("Query 3: select customer_name from customer where customer_street like '%Hill';\n");
            sb.Append("Query 4: select distinct customer_name from customer where customer_street like '%Hill';\n");
            sb.Append("Query 6: select count(*) from customer;\n");
            sb.Append("Query 7: select branch_name, avg(balance) from account group by branch_name;\n");
            sb.Append("Query 8: select branch_city, sum(assets) as total_assets from branch group by branch_city order by total_assets desc;");
            sb.Append("Query 9: select branch_name, avg(balance) from account group by branch_name having avg(balance) > 700;\n");
            sb.Append("Query 10: select branch_name, count(distinct customer_name) from depositor, account where depositor.account_number = account.account_number group by branch_name;\n");
            sb.Append("Query 11: select distinct customer.customer_name, customer_city from borrower, customer where borrower.customer_name = customer.customer_name;\n");
            sb.Append("Query 13: select distinct C.customer_name, customer_city from customer C, borrower B, loan L where C.customer_name = B.customer_name and B.loan_number = L.loan_number and branch_name = 'Perryridge';\n");
            sb.Append("Query 14: select branch_name from branch where assets > ALL (select assets from branch where branch_city = 'Brooklyn');\n");

            Console.WriteLine(sb.ToString());
        }

        /* prints whatever you want */
        public static void print(string whateveryouwant)
        {
            Console.WriteLine(whateveryouwant);
        }
    }
}