﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query2
    {
        public Query2()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable dt = new DataTable("temp");
            List<string> fields = new List<string>();

            fields.Add("account_number");

            scan s = new scan("account");

            project p = new project(fields);

            select s1 = new select("balance", "gte", 700);
            select s2 = new select("balance", "lte", 900);

            s.open();

            dt = s.cloneSchema();

            /* get all tuples from SCAN */
            while (s.hasMore())
            {
                dt.ImportRow(s.next());
            }

            s.close();

            /* add selects here */
            s1.open(dt);

            /* prepare for new set */
            dt.Clear();

            while (s1.hasMore())
            {
                dt.ImportRow(s1.next());
            }

            s1.close();

            s2.open(dt);

            dt.Clear();

            while (s2.hasMore())
            {
                dt.ImportRow(s2.next());
            }

            s2.close();

            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();

            while (p.hasMore())
            {
                dt.ImportRow(p.next());
            }

            p.close();

            return dt;
        }
    }
}
