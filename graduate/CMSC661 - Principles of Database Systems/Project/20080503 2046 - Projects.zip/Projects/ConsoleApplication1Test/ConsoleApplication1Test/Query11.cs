﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query11
    {
        public Query11()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable dt = new DataTable("borrower");
            DataTable dto = new DataTable("customer");
            List<string> fields = new List<string>();

            fields.Add("customer.customer_name");
            fields.Add("customer_city");

            scan sL = new scan("borrower");
            scan sR = new scan("customer");

            project p = new project(fields);

            renamefield rL = new renamefield("customer_name", "borrower.customer_name");
            renamefield rR = new renamefield("customer_name", "customer.customer_name");

            List<string> joinon = new List<string>();
            joinon.Add("borrower.customer_name");
            joinon.Add("eq");
            joinon.Add("customer.customer_name");
            joinon.Add("str");

            join j = new join(joinon);

            distinct d = new distinct(fields);
            
            /* Read in Borrower */         
            sL.open();

            dt = sL.cloneSchema();

            /* get all tuples from SCAN */
            while (sL.hasMore())
            {
                dt.ImportRow(sL.next());
            }

            sL.close();

            rL.open(dt);

            /* Read in Customer */
            sR.open();

            dto = sR.cloneSchema();

            while (sR.hasMore())
            {
                dto.ImportRow(sR.next());
            }

            sR.close();

            rR.open(dto);

            /* compute join */
            j.open(dt, dto);

            dt.Clear();
            dt = j.cloneSchema();

            while (j.hasMore())
            {
                dt.ImportRow(j.next());
            }

            j.close();
            
            /* add distinct here */
            d.open(dt);

            dt.Clear();

            while (d.hasMore())
            {
                dt.ImportRow(d.next());
            }

            d.close();

            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();

            while (p.hasMore())
            {
                dt.ImportRow(p.next());
            }

            p.close();

            return dt;
        }
    }
}
