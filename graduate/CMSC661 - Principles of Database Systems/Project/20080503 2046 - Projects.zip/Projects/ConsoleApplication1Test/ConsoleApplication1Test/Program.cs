﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    class Program
    {
        static void Main(string[] args)
        {
            /* This contains the program code */
            /* So I will need to put the main loop here. */

            /* display menu of SQL Queries */
            string input = string.Empty;

            /* look into making exec return a DataTable versus printing out within it;
             * so I can leave printing up to calling Aux functions from main */

            DataTable temp = null;
            Boolean quit = false;
            List<string> relations = new List<string>();

            relations.Add("customer");
            relations.Add("borrower");
            relations.Add("loan");
            relations.Add("branch");
            relations.Add("depositor");
            relations.Add("account");

            StatisticsManager statman = new StatisticsManager(relations);

            Aux.print("Calculating some statistics; please stand by.");

            /* need to have a way to check to see 
             * if we have a correct statistic before we
             * start estimating */

            /* Need to print stats on each attribute: will make this change
             * once I have a nice GUI to write out that information cleanly. */

            while(input.CompareTo("q") != 0)
            {
                Aux.printMenu();

                input = Console.ReadLine();

                quit = false;

                switch (input)
                {
                    case "q":
                        quit = true;
                        break;
                    case "1":                        
                        /* print stats */
                        StringBuilder query1 = new StringBuilder();
                        query1.Append("count.customer");

                        int query1Count = statman.retrieveStat(query1.ToString());

                        Aux.print("Estimated Tuples: " + query1Count.ToString());

                        /* execute query */
                        Query1 q1 = new Query1();
                        temp = q1.exec();

                        /*update stats */

                        break;
                    case "2":
                        /* print stats */
                        int distinctAcctBalanceVals = statman.retrieveStat("distinct.account.balance");
                        int countAcctVals = statman.retrieveStat("count.account");

                        Aux.print("Estimated Tuples: " + (countAcctVals / 3).ToString());
                        Aux.print("Estimated Distinct Values: " + (distinctAcctBalanceVals / 3).ToString());

                        /* execute query */
                        Query2 q2 = new Query2();
                        temp = q2.exec();
                        
                        /* update stats */

                        break;
                    case "3":
                        /* print stats */
                        int countCustVals = statman.retrieveStat("count.customer");
                        int distinctCusStreet = statman.retrieveStat("distinct.customer.customer_street");

                        Aux.print("Estimated Tuples: " + (countCustVals / 3).ToString());
                        Aux.print("Estimated Distinct Values: " + (distinctCusStreet / 3).ToString());

                        /* execute query */
                        Query3 q3 = new Query3();
                        temp = q3.exec();

                        /* update stats */

                        break;
                    case "4":
                        /* prints stats */
                        int countCustomerVals = statman.retrieveStat("count.customer");
                        int distinctCustomerStreet = statman.retrieveStat("distinct.customer.customer_street");

                        Aux.print("Estimated Tuples: " + (countCustomerVals / 3).ToString());
                        Aux.print("Estimated Distinct Values: " + (distinctCustomerStreet / 3).ToString());

                        /* execute query */
                        Query4 q4 = new Query4();
                        temp = q4.exec();

                        /* update stats */

                        break;
                    case "6":
                        /* print stats */
                        Aux.print("Estimated Tuples: 1");

                        /* execute query */
                        Query6 q6 = new Query6();
                        temp = q6.exec();
                        
                        break;
                    case "7":
                        /* print stats */
                        int query7result = statman.retrieveStat("distinct.account.branch_name");
                        Aux.print("Estimated Tuples: " + query7result.ToString());

                        /* execute query */
                        Query7 q7 = new Query7();
                        temp = q7.exec();

                        /* update stats */

                        break;
                    case "8":
                        /* print stats */
                        int query8result = statman.retrieveStat("distinct.branch.branch_city");
                        Aux.print("Estimated Tuples: " + query8result.ToString());

                        /* execute query */
                        Query8 q8 = new Query8();
                        temp = q8.exec();

                        /* update stats */

                        break;
                    case "9":
                        /* print stats */
                        int AcctBranchName = statman.retrieveStat("distinct.account.branch_name");
                        Aux.print("Estimated Tuples: " + (AcctBranchName / 3).ToString());

                        /* execute query */
                        Query9 q9 = new Query9();
                        temp = q9.exec();
                        
                        /* update stats */
                        
                        break;
                    case "10":
                        /* print stats */                                                
                        int d_dep = statman.retrieveStat("distinct.depositor.account_number");
                        int d_acc = statman.retrieveStat("distinct.account.account_number");                        
                        int minDistinct = (d_dep > d_acc) ? d_acc : d_dep;
                        
                        Aux.print("Estimated Tuples: " + minDistinct.ToString());                        

                        /* execute query */
                        Query10 q10 = new Query10();
                        temp = q10.exec();

                        /* update stats */

                        break;
                    case "11":
                        /* print stats */

                        /* execute query */
                        Query11 q11 = new Query11();
                        temp = q11.exec();
                        
                        /* update stats */
                        
                        break;
                    case "13":
                        /* print stats */

                        /* execute query */
                        Query13 q13 = new Query13();
                        temp = q13.exec();
                        
                        /* update stats */
                        
                        break;
                    case "14":
                        /* print stats */

                        /* execute query */
                        Query14 q14 = new Query14();
                        temp = q14.exec();

                        /* update stats */

                        break;
                    default:
                        quit = true; // so it won't try to print nothing
                        Aux.print("Invalid option.");
                        break;
                } /* end switch */

                if (!quit)
                {
                    Aux.printschema(temp.Columns);

                    foreach (DataRow dr in temp.Rows)
                        Aux.printrow(dr);

                    temp.Clear();
                }
            } /* end menu while loop */

            statman.clearStats();

        } /* end main */
    }
}
