﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleApplication1Test
{
    public class Query1
    {
        public Query1()
        {
            /* no code is god's code */
        }

        public DataTable exec()
        {
            DataTable dt = new DataTable("temp");
            List<string> empty = new List<string>();

            scan s = new scan("customer");
            project p = new project(empty);            

            s.open();

            dt = s.cloneSchema();
            
            /* get all tuples from SCAN */
            while (s.hasMore())
            {
                dt.ImportRow(s.next());                
            }

            s.close();

            p.open(dt);

            dt.Clear();

            dt = p.cloneSchema();
            
            while (p.hasMore())
            {
                dt.ImportRow(p.next());                
            }

            p.close();

            return dt;
        }
    }
}
