﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace SQLQueryEngine
{
    public class orderby
    {
        /* string sorting is untested and probably doesn't quite work right yet */

        public orderby(string field, string ordering, string dataType)
        {
            this.m_field = field;
            this.m_order = ordering;
            this.m_dataType = dataType;

            this.m_twoSort = false;

            this.m_dt = new DataTable();          
            this.m_current_tuple = 0;
        }

        public orderby(string firstfield, string firstordering, string firstdataType, 
            string secondfield, string secondordering)
        {
            this.m_field = firstfield;
            this.m_order = firstordering;
            this.m_dataType = firstdataType;

            this.m_secondfield = secondfield;
            this.m_secondorder = secondordering;

            this.m_twoSort = true;
            
            this.m_dt = new DataTable();
            this.m_current_tuple = 0;
        }
        
        public void open(DataTable data)
        {
            // clean out any garbage
            m_dt.Clear();            
            m_dt = data.Clone();
            
            int fieldIndex = data.Columns.IndexOf(m_field);            

            DataSet container = new DataSet();
          
            List<string> strBinValues = new List<string>();
            List<int> intBinValues = new List<int>();
            
            /* build set of bins on first field; first pass*/
            foreach (DataRow row in data.Rows)
            {
                if (m_dataType.CompareTo("str") == 0)
                {
                    /* we are dealing with strings */
                    string value = (string)row.ItemArray[fieldIndex];

                    /* we have a bin */
                    if (container.Tables.Contains(value))
                    {
                        container.Tables[value].ImportRow(row);
                    }
                    else
                    {
                        DataTable newTable = new DataTable(value);
                        newTable = data.Clone();
                        newTable.TableName = value;

                        container.Tables.Add(newTable);                        

                        container.Tables[value].ImportRow(row);

                        /* for later sorting purposes */
                        strBinValues.Add(value);
                    }
                }
                else if (m_dataType.CompareTo("int") == 0)
                {
                    /* we are dealing with ints */
                    int value = (int)row.ItemArray[fieldIndex];

                    if (container.Tables.Contains(value.ToString()))
                    {
                        container.Tables[value.ToString()].ImportRow(row);
                    }
                    else
                    {
                        DataTable newTable = new DataTable(value.ToString());
                        newTable = data.Clone();
                        newTable.TableName = value.ToString();

                        container.Tables.Add(newTable);

                        container.Tables[value.ToString()].ImportRow(row);

                        /* for later sorting purposes */
                        intBinValues.Add(value);
                    }
                }
            } /* end of foreach on rows in Data */
            
            /* all values are in their bins */

            if (m_twoSort)
            {
                /* sort the values in each bin by second field and second ordering */
                foreach (DataTable bin in container.Tables)
                {
                    bin.DefaultView.Sort = m_secondfield + " " + m_secondorder;
                }

                /* bin contents should be sorted */
            }
            
            /* second pass */
            if (m_dataType.CompareTo("str") == 0)
            {
                /* default asc */
                strBinValues.Sort();

                if (m_order.CompareTo("desc") == 0)
                    strBinValues.Reverse();

                /* now I can pull out the tables in sorted order */
                foreach (string tableName in strBinValues)
                {
                    /* should be in sorted order */
                    foreach (DataRow row in container.Tables[tableName].Rows)
                    {
                        m_dt.ImportRow(row);
                    }

                    /* remove table from list */
                    container.Tables.Remove(tableName);
                }
            }
            else if (m_dataType.CompareTo("int") == 0)
            {                
                intBinValues.Sort(); /* default ASC */

                if (m_order.CompareTo("desc") == 0)
                    intBinValues.Reverse();
                
                /* now I can pull out the tables in sorted order */
                foreach (int tableName in intBinValues)
                {
                    /* should be in sorted order */
                    foreach (DataRow row in container.Tables[tableName.ToString()].Rows)
                    {
                        m_dt.ImportRow(row);
                    }

                    /* remove table from list */
                    container.Tables.Remove(tableName.ToString());
                }
            }
                        
            /* m_dt should be sorted by first field, first order, then second field second order */            
        }

        public Boolean hasMore()
        {
            Boolean success = false;

            if (m_dt.Rows.Count > m_current_tuple)
                success = true;

            return success;
        }

        public DataRow next()
        {
            DataRow dr = m_dt.Rows[m_current_tuple];
            m_current_tuple++;

            return dr;
        }

        public void close()
        {
            m_dt.Clear();
        }

        private string m_field;
        private string m_order;
        private string m_dataType;
        private string m_secondfield;
        private string m_secondorder;
        private Boolean m_twoSort;
        private DataTable m_dt;
        private int m_current_tuple;        
    }
}
