
To compile and execute Tic-Tac-Toe, see ttt.erl.


Files:
  Reports:
    tech_report.pdf: The Technical Report
  Code:
    ttt.erl: The Tic-Tac-Toe Project
    span_children.erl: Gossip Spanning Tree tracking children
    span_parent.erl: Gossip Spanning Tree tracking parent
    prj.erl: Epidemic Rumor Spreading
    bully_avg.erl: Bully Variation of Average Calculation
    prj_avg2.erl: Another Variation of Average Calculation
  Results:
    "ttt - output 500 - 500nodes.xlt": Some output from running Tic-Tac-Toe to generate
      graph.

