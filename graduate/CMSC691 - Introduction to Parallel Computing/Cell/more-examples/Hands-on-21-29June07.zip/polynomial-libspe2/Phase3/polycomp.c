#include "polycomp.h"
#include <sys/time.h>         // gettimeofday

#define MAX_DEGREE 8
#define MAX_ARRAY_SIZE 1000000
#define ARRAY_SIZE 400000

struct timeval timev1, timev2; // gettimeofday

control_block cb[NSPUS];

float A_coeff[6] __attribute__ ((aligned (16)));
float B_coeff[6] __attribute__ ((aligned (16)));
float x[ARRAY_SIZE] __attribute__ ((aligned (128)));
float y[ARRAY_SIZE] __attribute__ ((aligned (128)));
char flag[ARRAY_SIZE] __attribute__ ((aligned (128)));

/* Here's the code verbatim from the statement of the problem */

void poly_compute(control_block *cb) {
   int i, j;
   float *A_coeff, *B_coeff, *x, *y;
   char *AB_flag;
   A_coeff = (float *) cb->A_coeff;
   B_coeff = (float *) cb->B_coeff;
   x = (float *) cb->x;
   y = (float *) cb->y;
   AB_flag = (char *) cb->AB_flag;
   cb->countA = 0;
   cb->countB = 0;
   cb->sumA = 0.0;
   cb->sumB = 0.0;
   for (i=0; i<cb->array_size; ++i) {
      float val;
      if (AB_flag[i]) {
         val = B_coeff[0];
         for (j=0; j<cb->poly_degree; ++j) val = val * x[i] + B_coeff[j+1]; 
         ++cb->countB;
         y[i] = val;
         cb->sumB += (double) val;
      }
      else {
         val = A_coeff[0];
         for (j=0; j<cb->poly_degree; ++j) val = val * x[i] + A_coeff[j+1]; 
         ++cb->countA;
         y[i] = val;
         cb->sumA += (double) val;
      }
   }
}

/* Here is some wrapper code to exercise our code */

int main(int argc, char **argv) {

   int i, j, countA, countB;
   int offset[NSPUS+1];
   double sumA, sumB;

   srand(42); /*we want things to be repeatable */

   for (i=0; i<ARRAY_SIZE; ++i) {
      flag[i] = rand() & 1;
      x[i] = -1.0 + ((rand() & 0x7fff) / 16384.0); /* -1.0 <= x < 1.0 */
   }

   A_coeff[0] =  1.2;
   A_coeff[1] = -1.4;
   A_coeff[2] =  1.6;
   A_coeff[3] = -1.8;
   A_coeff[4] =  2.0;
   A_coeff[5] = -0.5;

   B_coeff[0] = -1.2;
   B_coeff[1] =  1.4;
   B_coeff[2] = -1.6;
   B_coeff[3] =  1.8;
   B_coeff[4] = -2.0;
   B_coeff[5] =  0.5;

   gettimeofday(&timev1, NULL);

   /* now, make the call 100 times, just so we can measure the time */

   for (i=0; i<100; ++i) {

      for (j=0; j<NSPUS; ++j) {
         offset[j] = (ARRAY_SIZE * j) / NSPUS;
         offset[j] += 0x3f;
         offset[j] &= ~0x7f; /* we want arrays to start on cache lines */
      }
      offset[NSPUS] = ARRAY_SIZE;

      for (j=0; j<NSPUS; ++j) {
         cb[j].poly_degree = 5;
         cb[j].A_coeff = (unsigned int) A_coeff;
         cb[j].B_coeff = (unsigned int) B_coeff;
         cb[j].array_size = offset[j+1] - offset[j];
         cb[j].x = (unsigned int) &x[offset[j]];
         cb[j].y = (unsigned int) &y[offset[j]];
         cb[j].AB_flag = (unsigned int) &flag[offset[j]];
      }

      for (j=0; j<NSPUS; ++j) poly_compute(&cb[j]);

      sumA = 0.0;
      sumB = 0.0;
      countA = 0;
      countB = 0;
      for (j=0; j<NSPUS; ++j) {
         sumA += cb[j].sumA;
         sumB += cb[j].sumB;
         countA += cb[j].countA;
         countB += cb[j].countB;
      }
   }

   gettimeofday(&timev2, NULL);

   /* print some sample output */

   for (i=100000; i<ARRAY_SIZE; i+= 100000) printf("y[%d] = %9.6f\n", i, y[i]);

   printf("averages = %lf %lf\n", sumA / countA, sumB / countB);

   printf("compute time = %f seconds\n", (timev2.tv_sec - timev1.tv_sec) + 
      0.000001 * (timev2.tv_usec - timev1.tv_usec));
      
   return 0;
}
