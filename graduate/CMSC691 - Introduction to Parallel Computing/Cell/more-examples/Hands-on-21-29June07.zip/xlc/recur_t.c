float a[1000], b[1000], c[1000];
int main() {
   int i;
   for (i=0; i<1000; i++)
      a[i] = a[i-1] + c[i];
}
