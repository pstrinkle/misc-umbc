#include <math.h>
float a[16], b[16], c[16];
int main ()
{
	int i, n;	
	for (i=0; i<n; i++)
	{
	a[i] = b[i] * exp(c[i]);
	}
	return 0;
}
