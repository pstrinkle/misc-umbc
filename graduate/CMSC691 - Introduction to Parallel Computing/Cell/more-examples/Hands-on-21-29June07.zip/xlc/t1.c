float a, b, c;
int main ()
{
	a = b + c;
	return 0;
}
