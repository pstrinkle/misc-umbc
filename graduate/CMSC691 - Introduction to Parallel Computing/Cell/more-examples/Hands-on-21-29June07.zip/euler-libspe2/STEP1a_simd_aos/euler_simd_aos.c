/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* STEP1a
 *
 * Euler integration particle simulator SIMDized to run on the 
 * Vector/SIMD Multimedia Extension (aka VMX). This implementation
 * has been SIMDized as an Array of Structures (aos, also known as
 * a vec-across form), in that the 4-D particle vectors are maintained
 * naturally in the 128-bit VMX vector registers.
 */
#include "euler.h"

vec4D pos[PARTICLES] __attribute__ ((aligned (16)));
vec4D vel[PARTICLES] __attribute__ ((aligned (16)));
vec4D force __attribute__ ((aligned (16)));
float inv_mass[PARTICLES] __attribute__ ((aligned (16)));
float dt __attribute__ ((aligned (16))) = 1.0f;

int main()
{
  int i;
  float time;
  float dt_inv_mass __attribute__ ((aligned (16)));
  vector float dt_v, dt_inv_mass_v;
  vector float *pos_v, *vel_v, force_v;
  vector float zero = (vector float){0.0f, 0.0f, 0.0f, 0.0f};

  pos_v = (vector float *)pos;
  vel_v = (vector float *)vel;
  force_v = *((vector float *)&force);

  // Replicate the variable time step across elements 0-2 of
  // a floating point vector. Force the last element (3) to zero.
  dt_v = vec_sld(vec_splat(vec_lde(0, &dt), 0), zero, 4);

  // For each step in time
  for (time=0; time<END_OF_TIME; time += dt) {
    // For each particle
    for (i=0; i<PARTICLES; i++) {

      pos_v[i] = vec_madd(vel_v[i], dt_v, pos_v[i]);

      dt_inv_mass = dt * inv_mass[i];
      dt_inv_mass_v = vec_splat(vec_lde(0, &dt_inv_mass), 0);

      vel_v[i] = vec_madd(dt_inv_mass_v, force_v, vel_v[i]);
    }
  }
  return (0);
}
