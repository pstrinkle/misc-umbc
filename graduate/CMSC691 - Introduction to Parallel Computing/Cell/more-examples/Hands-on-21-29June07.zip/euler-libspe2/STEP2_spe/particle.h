/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include "../euler.h"

typedef struct {
  int particles;	// number of particle to process
  vector float *pos_v;	// pointer to array of positions vectors
  vector float *vel_v;	// pointer to array of velocity vectors
  float *inv_mass;	// pointer to array of mass vectors
  vector float force_v;	// force vector
  float dt;		// current step in time
} parm_context;

