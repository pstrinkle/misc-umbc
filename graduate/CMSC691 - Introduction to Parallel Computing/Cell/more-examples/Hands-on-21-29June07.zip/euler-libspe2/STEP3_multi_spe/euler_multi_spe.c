/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* STEP 3
 *
 * Parallelize code for execution across multiple SPEs
 *
 * The most common and practicle method of parallelizing computation across 
 * multiple SPE is to data partition the problem. The works well for 
 * applications with little or no data dependency. In our example, we can 
 * partition the Euler integration of the particle equally amongst the 
 * available SPEs. If there are 4 SPEs, then the first quarter of the
 * particples is processed by the first SPE, the second quarter of the 
 * particle is processed by the second SPE, and so forth.
 *
 * In this step we reuse the SPE program developed in STEP 2 (see 
 * ../STEP2_spe/spu)
 */

#include <stdio.h>
#include <stdlib.h>
#include <libspe2.h>
#include <pthread.h>
#include "particle.h"

#define SPE_THREADS		7

vec4D pos[PARTICLES] __attribute__ ((aligned (16)));
vec4D vel[PARTICLES] __attribute__ ((aligned (16)));
vec4D force __attribute__ ((aligned (16)));
float inv_mass[PARTICLES] __attribute__ ((aligned (16)));
float dt = 1.0f;

extern spe_program_handle_t particle;

typedef struct ppu_pthread_data {
  spe_context_ptr_t spe_ctx;
  pthread_t pthread;
  void *argp;
} ppu_pthread_data_t;

void *ppu_pthread_function(void *arg) {
  ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
  unsigned int entry = SPE_DEFAULT_ENTRY;
  if (spe_context_run(datap->spe_ctx, &entry, 0, datap->argp, NULL, NULL) < 0) {
    perror ("Failed running context");
    exit (1);
  }
  pthread_exit(NULL);
}


int main()
{
  int i, offset, count;
  ppu_pthread_data_t datas[SPE_THREADS];
  parm_context ctxs[SPE_THREADS] __attribute__ ((aligned (16)));


  /* Create multiple SPE threads */
  for (i=0, offset=0; i<SPE_THREADS; i++, offset+=count) {
    /* Construct a parameter context for each SPE. Make sure
     * that each SPEs (excluding the last) particle count is a multiple
     * of 4 so that inv_mass context pointer is always quadword aligned.
     */
    count = (PARTICLES / SPE_THREADS + 3) & ~3;
    ctxs[i].particles = (i==(SPE_THREADS-1)) ? PARTICLES - offset : count;
    ctxs[i].pos_v = (vector float *)&pos[offset];
    ctxs[i].vel_v = (vector float *)&vel[offset];
    ctxs[i].force_v = *((vector float *)&force);
    ctxs[i].inv_mass = &inv_mass[offset];
    ctxs[i].dt = dt;
    
    /* Create SPE context */
    if ((datas[i].spe_ctx = spe_context_create (0, NULL)) == NULL) {
        perror ("Failed creating context");
        exit (1);
    }
    /* Load SPE program into the SPE context */
    if (spe_program_load (datas[i].spe_ctx, &particle)) {
      perror ("Failed loading program");
      exit (1);
    }
    /* Initialize context run data */
    datas[i].argp = &ctxs[i];
    /* Create pthread for each of the SPE conexts */
    if (pthread_create (&datas[i].pthread, NULL, &ppu_pthread_function, &datas[i])) {
      perror ("Failed creating thread");
    }
  }

  /* Wait for all the SPE threads to complete.*/
  for (i=0; i<SPE_THREADS; i++) {
    if (pthread_join (datas[i].pthread, NULL)) {
      perror ("Failed joining thread");
      exit (1);
    }
  }

  return (0);
}

