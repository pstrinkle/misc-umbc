/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _EULER_H_
#define _EULER_H_

#define END_OF_TIME	10
#define PARTICLES	100000

/* 4-D vector definition.
 */
typedef struct {
  float x, y, z, w;  
} vec4D;

#endif /* _EULER_H_ */
