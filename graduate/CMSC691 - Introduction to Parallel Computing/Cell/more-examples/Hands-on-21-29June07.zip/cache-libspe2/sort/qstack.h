/* --------------------------------------------------------------- */
/* (C)Copyright 2006                                               */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
/* qstack.h
 *
 * Copyright (C) 2006 IBM Corp.
 */

#ifndef _QSTACK_H_
#define _QSTACK_H_

#include <sys/mman.h>

typedef struct qitem
{
    unsigned r, l;
} qitem_t;

static int qtop = 0;

#ifdef __SPU__
#define USE_CACHE
#endif

#ifdef USE_CACHE
#define CACHE_NAME		qstack
#define CACHED_TYPE		qitem_t
#define CACHELINE_LOG2SIZE	7       /* 128 bytes */
#define CACHE_LOG2NWAY		0       /* direct */
#define CACHE_LOG2NSETS		0       /* 1 set/line */
#define CACHE_TYPE		1       /* r/w */	
#include <cache-api.h>

static qitem_t *qstk;


static inline void
qstack_init(size_t size)
{
    qstk = (qitem_t *)(unsigned)mmap_ea(0ULL, size, PROT_READ|PROT_WRITE,
	    MAP_ANON|MAP_PRIVATE, -1, 0);
}

static inline void
qstack_fini()
{
    cache_flush(qstack);
    cache_pr_stats(qstack);
}

#define PUSH(val) cache_wr(qstack, &qstk[qtop], (val))
#define POP()	  cache_rd(qstack, &qstk[qtop])
#else /* !USE_CACHE */

#define QSTACK_SZ	1024
static qitem_t qstk[QSTACK_SZ];

#define PUSH(val)	(qstk[qtop] = (val))
#define POP()		(qstk[qtop])

#define qstack_init(size)
#define qstack_fini()

#endif

int max_qtop = 0;

static inline void
qstack_push (qitem_t *item)
{
    PUSH(*item);
    qtop++;
    max_qtop = (qtop > max_qtop) ? qtop : max_qtop;
}

static inline void
qstack_pop (qitem_t *item)
{
    qtop--;
    *item = POP();
}

static inline int
qstack_empty (void)
{
    return (qtop == 0);
}
#endif
