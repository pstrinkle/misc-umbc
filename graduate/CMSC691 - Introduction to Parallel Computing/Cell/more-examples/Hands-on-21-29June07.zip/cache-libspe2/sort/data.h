/* --------------------------------------------------------------- */
/* (C)Copyright 2006                                               */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
/*
 * data.h
 *
 * Services for reading and generating
 * data and mapping it
 *
 * If USE_CACHE is defined, the caller needs
 * to have defined a cache and defined CACHE_NAME
 * and CACHED_TYPE.
 */
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>

#ifdef __SPU__
#define mmap mmap_ea
static unsigned long long src;
#else
static void *src;
#endif

#ifdef USE_VECTOR
#define SIZE_SHIFT 4
#else
#define SIZE_SHIFT 2
#endif

#ifdef USE_CACHE
#define _STORE(ea, val)	__cache_wr((unsigned)(ea), (val))
#else
#define _STORE(ea, val)	(*(ea) = (val))
#endif

/*
 * generate an array of random floats, using the cache
 */
static inline void *
map_rand (int nitems)
{
    int i;
    CACHED_TYPE *a;
    /* amount of space needed, rounded up to next 4K */
    unsigned space = (((nitems * sizeof(CACHED_TYPE) >> 12) + 1) << 12);

    src = mmap (0ULL, space, PROT_READ|PROT_WRITE,
	    MAP_ANON|MAP_PRIVATE, -1, 0);

    if (src == MAP_FAILED)
	return NULL;

    a = (CACHED_TYPE *)(unsigned)src;

    for (i=0; i < nitems; i++) {
#ifdef USE_VECTOR
	    _STORE (&a[i],
		spu_splats ((float)(1000.0f * (rand() / (RAND_MAX + 1.0)))));
#else
	    _STORE (&a[i],
		(float) 1000.0f * (rand() / (RAND_MAX + 1.0)));
#endif
    }
    return (void *)(unsigned)src;
}


/*
 * map the data file
 */
static inline void *
map_file (char *fname, int *nitems)
{
    int fd;
    struct stat buf;

    /* Open the file. */
    if ((fd = open (fname, O_RDONLY, 0)) == -1)
    {
	perror ("Can't open file");
	return NULL;
    }

    /* Set up memory mapping. */
    if (fstat (fd, &buf) != 0)
    {
	perror ("Can't stat file");
	return NULL;
    }
    if (!buf.st_size)
    {
	printf ("Input file is zero-sized\n");
	return NULL;
    }
    if (buf.st_size & 0xf)
    {
	printf ("Input file is not quad-word sized!\n");
	return NULL;
    }

    src = mmap (0ULL, buf.st_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (src == MAP_FAILED)
    {
	perror ("Can't mmap source file");
	return NULL;
    }
    *nitems = buf.st_size >> SIZE_SHIFT;
    return (void *)(unsigned)src;
}
