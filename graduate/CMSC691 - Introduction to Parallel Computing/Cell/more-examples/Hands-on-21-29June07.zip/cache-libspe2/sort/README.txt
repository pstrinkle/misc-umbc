%% --------------------------------------------------------------- 
%% (C)Copyright 2006                                               
%% International Business Machines Corporation,                    
%% All Rights Reserved.                                            
%%                                                                 
%% This program is made available under the terms of the           
%% Common Public License v1.0 which accompanies this distribution. 
%% --------------------------------------------------------------- 
%% PROLOG END TAG zYx                                              
Summary: Samples of sorting algorithms using a software managed cache.

Target: SPE

Description:

    This directory contains samples of quicksort and heapsort that use
    a software managed data cache.  Two binaries are built: qsort and
    hsort.

  Files:

    qsort.c - Iterative quicksort implementation that uses a read/write
    cache to sort an array of floats or vector floats.  It uses a second
    cache to create a stack of partition information.  The algorithm
    switches to insertion sort when the partition size has reached a
    tunable threshold.

    hsort.c - Heapsort implementation that uses a read/write cache.

    qstack.h - Stack implementation that uses a read/write cache.

    data.h - Utility routines for mapping the data used by the sorts.

    util.h - Utility routines used by the sorts.


  Defines (all on by default in the samples):

    USE_VECTOR - Determines whether to use vector float or float data.
    USE_CACHE - Determines whether or not the software cache will be
    used.  When built for the SPU, this must be on for the array cache
    for both qsort and hsort. It is optional for qstack.h.
    CACHE_STATS - Determines whether or not cache statistics are
    maintained (valid only with USE_CACHE).

How to run:

    Both binaries have a command line option to either read the data
    from a file, or generate it themselves.  qsort also has an option
    to specify the threshold for which it will switch to insertion sort.
    If no option is specified, and internal default number of items
    will be sorted.  The output is the cache statistics.

    Quicksort:
    # qsort [ -i <q2ins> ] [ -n <num_rand_items> | -f <file_name> ]

    Heapsort:
    # hsort [ -n <num_rand_items> | -f <file_name> ]
