/* --------------------------------------------------------------- */
/* (C)Copyright 2006                                               */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
/*
 * cache-cp.c
 *
 * Copyright (C) 2005 IBM Corp.
 *
 * Stand-alone 'spulet' that copies one file to another.
 * The file contents are mmap'd into the effective address
 * space and a software managed cache is used to stage the
 * data into LS.
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

#define CACHE_NAME		cp
#define CACHED_TYPE		char
#define CACHE_TYPE		1	/* r/w */
#define CACHELINE_LOG2SIZE	7	/* 128 bytes */
#define CACHE_LOG2NWAY		2	/* 4-way */
#define CACHE_LOG2NSETS		5	/* 32 lines */
#define CACHE_READ_X4
#include <cache-api.h>

typedef union {
    unsigned long long all64;
    unsigned int by32[2];
} addr64;

/* Load/store 1 byte */
#define LOAD1(name, addr)	\
    (cache_rd(name, (addr)))

#define STORE1(name, addr, val)	\
    name ## _cache_wr((addr), (val))

#ifdef CACHE_READ_X4
#define LOAD4(name, addr4)	\
    (cache_rd_x4(name, (addr4)))
#endif

static void memcpy_ea(unsigned int dst, unsigned int src, size_t size)
{
#ifdef CACHE_READ_X4
    while (size & ~0x3) {
        vec_uint4 src4 = __load_vec_uint4(src, src+1, src+2, src+3);
        vec_uint4 c4 = LOAD4(cp, src4);

        STORE1(cp, dst,   (char)spu_extract(c4, 0));
        STORE1(cp, dst+1, (char)spu_extract(c4, 1));
        STORE1(cp, dst+2, (char)spu_extract(c4, 2));
        STORE1(cp, dst+3, (char)spu_extract(c4, 3));

        size -= 4;
        src += 4;
        dst += 4;
    }
#endif
    while (size > 0) {
        unsigned char c = LOAD1(cp, src);
        STORE1(cp, dst, c);
        size--;
        src++;
        dst++;
    }
}

int main(int argc, char **argv)
{
    char *src_name, *dst_name;
    int src_fd, dst_fd;
    int prot = PROT_READ | PROT_WRITE;
    int flags = O_RDWR | O_CREAT | O_TRUNC;
    struct stat buf;
    addr64 src, dst;

    if (argc != 3) {
        printf("Usage: %s [from] [to].\n", argv[0]);
        return 1;
    }
    src_name = argv[1];
    dst_name = argv[2];

    /* Open both files. */
    if ((src_fd = open(src_name, O_RDONLY, 0)) == -1) {
        perror("Can't open source file");
        return 1;
    }
    if ((dst_fd = open(dst_name, flags, buf.st_mode | S_IWUSR | S_IRUSR)) < 0) {
        perror("Can't create destination file");
        return 1;
    }

    /* Set up memory mappings. */
    if (fstat(src_fd, &buf) != 0) {
        perror("Can't stat source file");
        return 1;
    }
    if (!buf.st_size) {
        return 0;
    }
    if (lseek(dst_fd, buf.st_size - 1, SEEK_SET) == -1) {
        perror("Can't lseek destination file");
        return 1;
    }
    if (write(dst_fd, "", 1) != 1) {
        perror("Can't write to destination file");
        return 1;
    }
    src.all64 = mmap_ea(0ULL, buf.st_size, PROT_READ, MAP_PRIVATE, src_fd, 0);
    if (src.all64 == MAP_FAILED) {
        perror("Can't mmap source file");
        return 1;
    }
    dst.all64 = mmap_ea(0ULL, buf.st_size, prot, MAP_SHARED, dst_fd, 0);
    if (dst.all64 == MAP_FAILED) {
        perror("Can't mmap destiation file");
        return 1;
    }

    /* Copy from src->LS->dst using software managed cache. */
    memcpy_ea(dst.by32[1], src.by32[1], buf.st_size);

    /* we're done, flush the cache */
    cp_cache_flush();

    return 0;
}
