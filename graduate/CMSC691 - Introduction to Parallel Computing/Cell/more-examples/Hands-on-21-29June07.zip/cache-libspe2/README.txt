%% --------------------------------------------------------------- 
%% (C)Copyright 2006                                               
%% International Business Machines Corporation,                    
%% All Rights Reserved.                                            
%%                                                                 
%% This program is made available under the terms of the           
%% Common Public License v1.0 which accompanies this distribution. 
%% --------------------------------------------------------------- 
%% PROLOG END TAG zYx                                              
Summary: Software Cache Samples

Target: SPE

Description:

    This directory contains samples that demonstrate the use of a software
    managed cache for the SPE.  The implementation of the cache can be
    found in the src/include/spu (cache*.h) directory of the SDK
    installation. Documentation for the SW managed cache functions are 
    located in SDK library documentation docs/libraries_SDK.pdf.

