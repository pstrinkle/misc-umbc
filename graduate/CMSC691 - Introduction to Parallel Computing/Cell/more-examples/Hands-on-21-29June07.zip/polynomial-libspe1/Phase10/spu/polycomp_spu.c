#include "../polycomp.h"
#include <spu_mfcio.h>

/* control structure */
control_block cb __attribute__ ((aligned (128)));

float A_coeff[MAX_DEGREE] __attribute__ ((aligned (16)));
float B_coeff[MAX_DEGREE] __attribute__ ((aligned (16)));
vector float A_coeffV[MAX_DEGREE] __attribute__ ((aligned (16)));
vector float B_coeffV[MAX_DEGREE] __attribute__ ((aligned (16)));
vector float X[2048] __attribute__ ((aligned (128)));
vector float Y[2048] __attribute__ ((aligned (128)));
vector signed char flag[512] __attribute__ ((aligned (128)));

vector double ZeroDV = (vector double) {0.0, 0.0};
vector float ZeroFV = (vector float) {0.0f, 0.0f, 0.0f, 0.0f};
vector unsigned int ZeroIV = (vector unsigned int) {0,0,0,0};
vector unsigned int OneV = (vector unsigned int) {1,1,1,1};

vector unsigned int workcountAA, workcountAB, workcountAC, workcountAD;
vector unsigned int workcountBA, workcountBB, workcountBC, workcountBD;
vector double worksumAA, worksumAB, worksumAC, worksumAD;
vector double worksumBA, worksumBB, worksumBC, worksumBD;

vector float *xp0, *xp1, *yp0, *yp1;
vector signed char *flagp0, *flagp1;

void poly_compute(vector float *vxp, 
                  vector float *vyp, 
                  vector signed char *vflagp, unsigned int n) {

   unsigned int i, j;

   workcountAA = ZeroIV;
   workcountAB = ZeroIV;
   workcountAC = ZeroIV;
   workcountAD = ZeroIV;
   workcountBA = ZeroIV;
   workcountBB = ZeroIV;
   workcountBC = ZeroIV;
   workcountBD = ZeroIV;

   worksumAA = ZeroDV;
   worksumAB = ZeroDV;
   worksumAC = ZeroDV;
   worksumAD = ZeroDV;
   worksumBA = ZeroDV;
   worksumBB = ZeroDV;
   worksumBC = ZeroDV;
   worksumBD = ZeroDV;

   for (i=0; i<n>>4; ++i) {
      unsigned short bits;
      vector float xA, xB, xC, xD;
      vector float valA, valB, valC, valD;
      vector float wsfAA,wsfAB,wsfAC,wsfAD,wsfBA,wsfBB,wsfBC,wsfBD;
      vector unsigned int flagA, flagB, flagC, flagD;
      bits = spu_extract(((vector unsigned short) spu_gather(vflagp[i])), 1);
      flagA = spu_maskw(bits>>12);
      flagB = spu_maskw(bits>>8);
      flagC = spu_maskw(bits>>4);
      flagD = spu_maskw(bits);
      xA = vxp[4*i];
      xB = vxp[4*i+1];
      xC = vxp[4*i+2];
      xD = vxp[4*i+3];
      valA = spu_sel(A_coeffV[0], B_coeffV[0], flagA);
      valB = spu_sel(A_coeffV[0], B_coeffV[0], flagB);
      valC = spu_sel(A_coeffV[0], B_coeffV[0], flagC);
      valD = spu_sel(A_coeffV[0], B_coeffV[0], flagD);

      for (j=1; j<cb.poly_degree+1; ++j) {
         valA = spu_madd(valA, xA, spu_sel(A_coeffV[j], B_coeffV[j], flagA));
         valB = spu_madd(valB, xB, spu_sel(A_coeffV[j], B_coeffV[j], flagB));
         valC = spu_madd(valC, xC, spu_sel(A_coeffV[j], B_coeffV[j], flagC));
         valD = spu_madd(valD, xD, spu_sel(A_coeffV[j], B_coeffV[j], flagD));
      }

      workcountAA = spu_add(workcountAA, spu_sel(OneV, ZeroIV, flagA));
      workcountAB = spu_add(workcountAB, spu_sel(OneV, ZeroIV, flagB));
      workcountAC = spu_add(workcountAC, spu_sel(OneV, ZeroIV, flagC));
      workcountAD = spu_add(workcountAD, spu_sel(OneV, ZeroIV, flagD));
      workcountBA = spu_add(workcountBA, spu_sel(ZeroIV, OneV, flagA));
      workcountBB = spu_add(workcountBB, spu_sel(ZeroIV, OneV, flagB));
      workcountBC = spu_add(workcountBC, spu_sel(ZeroIV, OneV, flagC));
      workcountBD = spu_add(workcountBD, spu_sel(ZeroIV, OneV, flagD));

      vyp[4*i  ] = valA;
      vyp[4*i+1] = valB;
      vyp[4*i+2] = valC;
      vyp[4*i+3] = valD;

      wsfAA = spu_sel(valA, ZeroFV, flagA);
      wsfAB = spu_sel(valB, ZeroFV, flagB);
      wsfAC = spu_sel(valC, ZeroFV, flagC);
      wsfAD = spu_sel(valD, ZeroFV, flagD);
      wsfBA = spu_sel(ZeroFV, valA, flagA);
      wsfBB = spu_sel(ZeroFV, valB, flagB);
      wsfBC = spu_sel(ZeroFV, valC, flagC);
      wsfBD = spu_sel(ZeroFV, valD, flagD);
      worksumAA = spu_add(worksumAA, spu_extend(wsfAA));
      worksumAB = spu_add(worksumAB, spu_extend(wsfAB));
      worksumAC = spu_add(worksumAC, spu_extend(wsfAC));
      worksumAD = spu_add(worksumAD, spu_extend(wsfAD));
      worksumBA = spu_add(worksumBA, spu_extend(wsfBA));
      worksumBB = spu_add(worksumBB, spu_extend(wsfBB));
      worksumBC = spu_add(worksumBC, spu_extend(wsfBC));
      worksumBD = spu_add(worksumBD, spu_extend(wsfBD));
      wsfAA = spu_rlqwbyte(wsfAA, 4);
      wsfAB = spu_rlqwbyte(wsfAB, 4);
      wsfAC = spu_rlqwbyte(wsfAC, 4);
      wsfAD = spu_rlqwbyte(wsfAD, 4);
      wsfBA = spu_rlqwbyte(wsfBA, 4);
      wsfBB = spu_rlqwbyte(wsfBB, 4);
      wsfBC = spu_rlqwbyte(wsfBC, 4);
      wsfBD = spu_rlqwbyte(wsfBD, 4);
      worksumAA = spu_add(worksumAA, spu_extend(wsfAA));
      worksumAB = spu_add(worksumAB, spu_extend(wsfAB));
      worksumAC = spu_add(worksumAC, spu_extend(wsfAC));
      worksumAD = spu_add(worksumAD, spu_extend(wsfAD));
      worksumBA = spu_add(worksumBA, spu_extend(wsfBA));
      worksumBB = spu_add(worksumBB, spu_extend(wsfBB));
      worksumBC = spu_add(worksumBC, spu_extend(wsfBC));
      worksumBD = spu_add(worksumBD, spu_extend(wsfBD));
   }

   workcountAA = spu_add(workcountAA, workcountAB);
   workcountAC = spu_add(workcountAC, workcountAD);
   workcountBA = spu_add(workcountBA, workcountBB);
   workcountBC = spu_add(workcountBC, workcountBD);
   worksumAA = spu_add(worksumAA, worksumAB);
   worksumAC = spu_add(worksumAC, worksumAD);
   worksumBA = spu_add(worksumBA, worksumBB);
   worksumBC = spu_add(worksumBC, worksumBD);

   workcountAA = spu_add(workcountAA, workcountAC);
   workcountBA = spu_add(workcountBA, workcountBC);
   worksumAA = spu_add(worksumAA, worksumAC);
   worksumBA = spu_add(worksumBA, worksumBC);

   workcountAA = spu_add(workcountAA, spu_rlqwbyte(workcountAA, 4));
   workcountBA = spu_add(workcountBA, spu_rlqwbyte(workcountBA, 4));

   worksumAA = spu_add(worksumAA, spu_rlqwbyte(worksumAA, 8));
   worksumBA = spu_add(worksumBA, spu_rlqwbyte(worksumBA, 8));

   workcountAA = spu_add(workcountAA, spu_rlqwbyte(workcountAA, 8));
   workcountBA = spu_add(workcountBA, spu_rlqwbyte(workcountBA, 8));

   cb.countA += spu_extract(workcountAA, 0);
   cb.countB += spu_extract(workcountBA, 0);
   cb.sumA += spu_extract(worksumAA, 0);
   cb.sumB += spu_extract(worksumBA, 0);
}

/* here is the location where the SPE begins execution, once its thread is created */
int main(unsigned long long speid, addr64 argp, addr64 envp) {

   unsigned int i, bigloop, loopcount, remainder, DMA_size;

   xp0 = &X[0];
   xp1 = &X[1024];
   yp0 = &Y[0];
   yp1 = &Y[1024];
   flagp0 = &flag[0];
   flagp1 = &flag[256];

   /* DMA control block information from system memory. */
   mfc_get(&cb, argp.ui[1], sizeof(cb), 31, 0, 0);
   mfc_write_tag_mask(1<<31);
   mfc_read_tag_status_all();

   DMA_size = (cb.poly_degree+1) * sizeof(float);
   DMA_size += 0xf;
   DMA_size &= (~0xf);

   mfc_get(A_coeff, cb.A_coeff, DMA_size, 31, 0, 0);
   mfc_get(B_coeff, cb.B_coeff, DMA_size, 31, 0, 0);
   mfc_write_tag_mask(1<<31);
   mfc_read_tag_status_all();

   for (i=0; i<cb.poly_degree+1; ++i) {
      A_coeffV[i] = spu_splats(A_coeff[i]);
      B_coeffV[i] = spu_splats(B_coeff[i]);
   }

   loopcount = cb.array_size & (~8191);

   for (bigloop=0; bigloop<100; ++bigloop) {

      cb.countA = 0;
      cb.countB = 0;
      cb.sumA = 0.0;
      cb.sumB = 0.0;
  
      mfc_get(xp0, (cb.x), 16384, 20, 0, 0);
      mfc_get(flagp0, (cb.AB_flag), 4096, 20, 0, 0);

      for (i=0; i<loopcount; i+=8192) {
         mfc_get(xp1, (cb.x+(i+4096)*sizeof(float)), 16384, 21, 0, 0);
         mfc_get(flagp1, (cb.AB_flag+(i+4096)*sizeof(char)), 4096, 21, 0, 0);
         mfc_write_tag_mask(1<<20);
         mfc_read_tag_status_all();
    
         poly_compute(xp0, yp0, flagp0, 4096);
     
         mfc_put(yp0, (cb.y+i*sizeof(float)), 16384, 20, 0, 0);

         mfc_get(xp0, (cb.x+(i+8192)*sizeof(float)), 16384, 20, 0, 0);
         mfc_get(flagp0, (cb.AB_flag+(i+8192)*sizeof(char)), 4096, 20, 0, 0);
         mfc_write_tag_mask(1<<21);
         mfc_read_tag_status_all();
    
         poly_compute(xp1, yp1, flagp1, 4096);
     
         mfc_put(yp1, (cb.y+(i+4096)*sizeof(float)), 16384, 21, 0, 0);
      }
    
      remainder = cb.array_size & 8191;

      if (remainder & 4096) {
         mfc_get(xp1, (cb.x+(loopcount+4096)*sizeof(float)), ((remainder & 4095) * sizeof(float)), 21, 0, 0);
         mfc_get(flagp1, (cb.AB_flag+(loopcount+4096)*sizeof(char)), ((remainder & 4095) * sizeof(char)), 21, 0, 0);
         mfc_write_tag_mask(1<<20);
         mfc_read_tag_status_all();
    
         poly_compute(xp0, yp0, flagp0, 4096);
     
         mfc_put(yp0, (cb.y+loopcount*sizeof(float)), 16384, 20, 0, 0);

         remainder -= 4096;
         if (remainder) {
             mfc_write_tag_mask(1<<21);
             mfc_read_tag_status_all();
     
             poly_compute(xp1, yp1, flagp1, remainder);
     
             mfc_put(yp1, (cb.y+(loopcount+4096)*sizeof(float)), (remainder*sizeof(float)), 21, 0, 0);
         }
      }

      else if (remainder) {
          mfc_write_tag_mask(1<<20);
          mfc_read_tag_status_all();
     
          poly_compute(xp0, yp0, flagp0, remainder);
     
          mfc_put(yp0, (cb.y+loopcount*sizeof(float)), (remainder*sizeof(float)), 20, 0, 0);
      }
   }
 
   /* DMA control block information from system memory. */
   mfc_put(&cb, argp.ui[1], sizeof(cb), 31, 0, 0);
   mfc_write_tag_mask((1<<20)|(1<<21)|(1<<31));
   mfc_read_tag_status_all();

   return 0;
}
