#ifndef __polycomp_h__
#define __polycomp_h__

#include <stdio.h>
#include <stdlib.h> 

#define NSPUS 16
#define MAX_DEGREE 6

/* This union helps clarify calling parameters between the PPE and the SPE. */

typedef union
{
  unsigned long long ull;
  unsigned int ui[2];
}
addr64;

typedef struct _control_block {
  double sumA;
  double sumB;
  unsigned int poly_degree;
  unsigned int A_coeff;
  unsigned int B_coeff;
  unsigned int array_size;
  unsigned int x;
  unsigned int y;
  unsigned int AB_flag;
  float countA;
  float countB;
  unsigned char pad[76];  /* pad to a full cache line (128 bytes) */
} control_block;

#endif /* __polycomp_h__ */
