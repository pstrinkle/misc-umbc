#include "../polycomp.h"
#include <sys/time.h>         // gettimeofday

#define MAX_ARRAY_SIZE 1000000
#define ARRAY_SIZE 400000

#include <libspe.h>
#include <errno.h>

/* there's one control block for each SPE. */
control_block cb[16] __attribute__ ((aligned (128)));

/* this is the pointer to the SPE code, to be used at thread creation time */
extern spe_program_handle_t polycomp_spu;

/* these are the handles returned by "spe_create_thread" */
speid_t speids[16];

/* this variable is used to return data regarding an abnormal return from the SPE */
int status[16];

int nspus;

struct timeval timev1, timev2; // gettimeofday

float A_coeff[8] __attribute__ ((aligned (16)));
float B_coeff[8] __attribute__ ((aligned (16)));
float x[ARRAY_SIZE] __attribute__ ((aligned (128)));
float y[ARRAY_SIZE] __attribute__ ((aligned (128)));
char flag[ARRAY_SIZE] __attribute__ ((aligned (128)));

int main(int argc, char *argv[]) {

   int i, j, countA, countB;
   int offset[17];
   double sumA, sumB;

   if (argc == 1) nspus = NSPUS;
   else {
      nspus = atoi(argv[1]);
      if (nspus < 1 || nspus > 16) {
         printf("nspus must be between 1 and 16\n");
         return 0;
      }
   }

   srand(42); /*we want things to be repeatable */

   for (i=0; i<ARRAY_SIZE; ++i) {
      flag[i] = rand() & 1;
      x[i] = -1.0 + ((rand() & 0x7fff) / 16384.0); /* -1.0 <= x < 1.0 */
   }

   A_coeff[0] =  1.2;
   A_coeff[1] = -1.4;
   A_coeff[2] =  1.6;
   A_coeff[3] = -1.8;
   A_coeff[4] =  2.0;
   A_coeff[5] = -0.5;

   B_coeff[0] = -1.2;
   B_coeff[1] =  1.4;
   B_coeff[2] = -1.6;
   B_coeff[3] =  1.8;
   B_coeff[4] = -2.0;
   B_coeff[5] =  0.5;

   gettimeofday(&timev1, NULL);

   if (spe_count_physical_spes() < nspus) {
      fprintf(stderr, "System doesn't have eight working SPEs.  I'm leaving.\n");
      return -1;
   }

   for (i=0; i<nspus; ++i) {
      offset[i] = (ARRAY_SIZE * i) / nspus;
      offset[i] += 0x3f;
      offset[i] &= ~0x7f; /* we want arrays to start on cache lines */
   }
   offset[nspus] = ARRAY_SIZE;

   for (i=0; i<nspus; ++i) {
      cb[i].poly_degree = 5;
      cb[i].A_coeff = (unsigned int) A_coeff;
      cb[i].B_coeff = (unsigned int) B_coeff;
      cb[i].array_size = offset[i+1] - offset[i];
      cb[i].x = (unsigned int) &x[offset[i]];
      cb[i].y = (unsigned int) &y[offset[i]];
      cb[i].AB_flag = (unsigned int) &flag[offset[i]];
   }

   gettimeofday(&timev1, NULL);

   /* allocate SPE tasks */
   for (i = 0; i < nspus; i++) {
      speids[i] = spe_create_thread (SPE_DEF_GRP, &polycomp_spu, ((unsigned long long *) &cb[i]), NULL, -1, 0);
      if (speids[i] == NULL) {
         fprintf (stderr, "FAILED: spe_create_thread(num=%d, errno=%d)\n", i, errno);
         exit (3+i);
      }
   }

   /* wait for SPEs to all finish */
   for (i=0; i<nspus; ++i) spe_wait(speids[i], &status[i], 0);

   /* Issue a sync, just to be safe. */
   __asm__ __volatile__ ("sync" : : : "memory");

   gettimeofday(&timev2, NULL);

   sumA = 0.0;
   sumB = 0.0;
   countA = 0;
   countB = 0;
   for (j=0; j<nspus; ++j) {
      sumA += cb[j].sumA;
      sumB += cb[j].sumB;
      countA += cb[j].countA;
      countB += cb[j].countB;
   }

   /* print some sample output */

   for (i=100000; i<ARRAY_SIZE; i+= 100000) printf("y[%d] = %9.6f\n", i, y[i]);

   printf("averages = %lf %lf\n", sumA / countA, sumB / countB);

   printf("compute time = %f seconds\n", (timev2.tv_sec - timev1.tv_sec) + 
      0.000001 * (timev2.tv_usec - timev1.tv_usec));

   return 0;
}
