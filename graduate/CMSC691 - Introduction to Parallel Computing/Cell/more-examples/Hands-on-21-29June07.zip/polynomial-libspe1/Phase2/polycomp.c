#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>         // gettimeofday
#include "polycomp.h"

#define MAX_DEGREE 8
#define MAX_ARRAY_SIZE 1000000
#define ARRAY_SIZE 400000

struct timeval timev1, timev2; // gettimeofday

float A_coeff[6] __attribute__ ((aligned (16)));
float B_coeff[6] __attribute__ ((aligned (16)));
float x[ARRAY_SIZE] __attribute__ ((aligned (128)));
float y[ARRAY_SIZE] __attribute__ ((aligned (128)));
char flag[ARRAY_SIZE] __attribute__ ((aligned (128)));

/* Here's the code verbatim from the statement of the problem */

void poly_compute(int poly_degree,  /* degree of the two polynomials   */
                  float *A_coeff,   /* array of (degree+1) floats,     */
                                    /* specifying the A polynomial     */
                  float *B_coeff,   /* array of (degree+1) floats,     */
                                    /* specifying the B polynomial     */
                  int array_size,   /* size of the next three arrays   */
                  float *x,         /* the input values                */
                  float *y,         /* the output values               */
                  char *AB_flag,    /* flags to indicate whether to    */
                                    /* compute A(x) (flag == 0) or     */
                                    /* compute B(x) (flag == 1)        */
                  int *counts,      /* how many A, how many B          */
                  double *sums)     /* array of two floats, to contain */
                                    /* the computed sums of the        */
                                    /* A(x) and B(x) values            */
{
   int i, j;
   counts[0] = 0;
   counts[1] = 0;
   sums[0] = 0.0;
   sums[1] = 0.0;
   for (i=0; i<array_size; ++i) {
      float val;
      if (AB_flag[i]) {
         val = B_coeff[0];
         for (j=0; j<poly_degree; ++j) val = val * x[i] + B_coeff[j+1]; 
         ++counts[1];
         y[i] = val;
         sums[1] += (double) val;
      }
      else {
         val = A_coeff[0];
         for (j=0; j<poly_degree; ++j) val = val * x[i] + A_coeff[j+1]; 
         ++counts[0];
         y[i] = val;
         sums[0] += (double) val;
      }
   }
}

/* Here is some wrapper code to exercise our code */

int main(int argc, char **argv) {

   int i, j;
   int work_counts[NSPUS][2];
   int countA, countB;
   double work_sums[NSPUS][2];
   double sumA, sumB;
   int offset[NSPUS+1], size[NSPUS];

   srand(42); /*we want things to be repeatable */

   for (i=0; i<ARRAY_SIZE; ++i) {
      flag[i] = rand() & 1;
      x[i] = -1.0 + ((rand() & 0x7fff) / 16384.0); /* -1.0 <= x < 1.0 */
   }

   A_coeff[0] =  1.2;
   A_coeff[1] = -1.4;
   A_coeff[2] =  1.6;
   A_coeff[3] = -1.8;
   A_coeff[4] =  2.0;
   A_coeff[5] = -0.5;

   B_coeff[0] = -1.2;
   B_coeff[1] =  1.4;
   B_coeff[2] = -1.6;
   B_coeff[3] =  1.8;
   B_coeff[4] = -2.0;
   B_coeff[5] =  0.5;

   gettimeofday(&timev1, NULL);

   /* now, make the call 100 times, just so we can measure the time */

   for (i=0; i<100; ++i) {
      for (j=0; j<NSPUS; ++j) {
         offset[j] = (ARRAY_SIZE * j) / NSPUS;
         offset[j] += 0x3f;
         offset[j] &= ~0x7f; /* we want arrays to start on cache lines */
      }
      offset[NSPUS] = ARRAY_SIZE;
      for (j=0; j<NSPUS; ++j) size[j] = offset[j+1] - offset[j];
      for (j=0; j<NSPUS; ++j) {
         poly_compute(5, A_coeff, B_coeff, 
                      size[j],
                      &x[offset[j]], 
                      &y[offset[j]], 
                      &flag[offset[j]], 
                      work_counts[j],
                      work_sums[j]);
      }
      sumA = 0.0;
      sumB = 0.0;
      countA = 0;
      countB = 0;
      for (j=0; j<NSPUS; ++j) {
         sumA += work_sums[j][0];
         sumB += work_sums[j][1];
         countA += work_counts[j][0];
         countB += work_counts[j][1];
      }
   }

   gettimeofday(&timev2, NULL);

   /* print some sample output */

   for (i=100000; i<ARRAY_SIZE; i+= 100000) printf("y[%d] = %9.6f\n", i, y[i]);

   printf("averages = %lf %lf\n", sumA / countA, sumB / countB);

   printf("compute time = %f seconds\n", (timev2.tv_sec - timev1.tv_sec) + 
      0.000001 * (timev2.tv_usec - timev1.tv_usec));
      
   return 0;
}
