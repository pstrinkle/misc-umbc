#include "../polycomp.h"
#include <spu_mfcio.h>

/* control structure */
control_block cb __attribute__ ((aligned (128)));

float A_coeff[MAX_DEGREE] __attribute__ ((aligned (16)));
float B_coeff[MAX_DEGREE] __attribute__ ((aligned (16)));
vector float X[2048] __attribute__ ((aligned (128)));
vector float Y[2048] __attribute__ ((aligned (128)));
vector signed char flag[512] __attribute__ ((aligned (128)));

vector float *xp0, *xp1, *yp0, *yp1;
vector signed char *flagp0, *flagp1;

void poly_compute(vector float *vxp, 
                  vector float *vyp, 
                  vector signed char *vflagp, unsigned int n) {

   float *xp, *yp;
   unsigned char *flagp;
   unsigned int i, j;

   xp = (float *) vxp;
   yp = (float *) vyp;
   flagp = (unsigned char *) vflagp;

   for (i=0; i<n; ++i) {
      float val;
      val = flagp[i] ? B_coeff[0] : A_coeff[0];
      for (j=0; j<cb.poly_degree; ++j) {
         val = val * xp[i] + (flagp[i] ? B_coeff[j+1] : A_coeff[j+1]); 
      }
      cb.countB += (flagp[i] ? 1 : 0);
      cb.countA += (flagp[i] ? 0 : 1);
      yp[i] = val;
      cb.sumB += (flagp[i] ? (double) val : 0.0);
      cb.sumA += (flagp[i] ? 0.0 : (double) val);
   }
}

/* here is the location where the SPE begins execution, once its thread is created */
int main(unsigned long long speid, addr64 argp, addr64 envp) {

   unsigned int i, bigloop, loopcount, remainder, DMA_size;

   xp0 = &X[0];
   xp1 = &X[1024];
   yp0 = &Y[0];
   yp1 = &Y[1024];
   flagp0 = &flag[0];
   flagp1 = &flag[256];

   /* DMA control block information from system memory. */
   mfc_get(&cb, argp.ui[1], sizeof(cb), 31, 0, 0);
   mfc_write_tag_mask(1<<31);
   mfc_read_tag_status_all();

   DMA_size = (cb.poly_degree+1) * sizeof(float);
   DMA_size += 0xf;
   DMA_size &= (~0xf);

   mfc_get(A_coeff, cb.A_coeff, DMA_size, 31, 0, 0);
   mfc_get(B_coeff, cb.B_coeff, DMA_size, 31, 0, 0);
   mfc_write_tag_mask(1<<31);
   mfc_read_tag_status_all();

   loopcount = cb.array_size & (~8191);

   for (bigloop=0; bigloop<100; ++bigloop) {

      cb.countA = 0;
      cb.countB = 0;
      cb.sumA = 0.0;
      cb.sumB = 0.0;
  
      mfc_get(xp0, (cb.x), 16384, 20, 0, 0);
      mfc_get(flagp0, (cb.AB_flag), 4096, 20, 0, 0);

      for (i=0; i<loopcount; i+=8192) {
         mfc_get(xp1, (cb.x+(i+4096)*sizeof(float)), 16384, 21, 0, 0);
         mfc_get(flagp1, (cb.AB_flag+(i+4096)*sizeof(char)), 4096, 21, 0, 0);
         mfc_write_tag_mask(1<<20);
         mfc_read_tag_status_all();
    
         poly_compute(xp0, yp0, flagp0, 4096);
     
         mfc_put(yp0, (cb.y+i*sizeof(float)), 16384, 20, 0, 0);

         mfc_get(xp0, (cb.x+(i+8192)*sizeof(float)), 16384, 20, 0, 0);
         mfc_get(flagp0, (cb.AB_flag+(i+8192)*sizeof(char)), 4096, 20, 0, 0);
         mfc_write_tag_mask(1<<21);
         mfc_read_tag_status_all();
    
         poly_compute(xp1, yp1, flagp1, 4096);
     
         mfc_put(yp1, (cb.y+(i+4096)*sizeof(float)), 16384, 21, 0, 0);
      }
    
      remainder = cb.array_size & 8191;

      if (remainder & 4096) {
         mfc_get(xp1, (cb.x+(loopcount+4096)*sizeof(float)), ((remainder & 4095) * sizeof(float)), 21, 0, 0);
         mfc_get(flagp1, (cb.AB_flag+(loopcount+4096)*sizeof(char)), ((remainder & 4095) * sizeof(char)), 21, 0, 0);
         mfc_write_tag_mask(1<<20);
         mfc_read_tag_status_all();
    
         poly_compute(xp0, yp0, flagp0, 4096);
     
         mfc_put(yp0, (cb.y+loopcount*sizeof(float)), 16384, 20, 0, 0);

         remainder -= 4096;
         if (remainder) {
             mfc_write_tag_mask(1<<21);
             mfc_read_tag_status_all();
     
             poly_compute(xp1, yp1, flagp1, remainder);
     
             mfc_put(yp1, (cb.y+(loopcount+4096)*sizeof(float)), (remainder*sizeof(float)), 21, 0, 0);
         }
      }

      else if (remainder) {
          mfc_write_tag_mask(1<<20);
          mfc_read_tag_status_all();
     
          poly_compute(xp0, yp0, flagp0, remainder);
     
          mfc_put(yp0, (cb.y+loopcount*sizeof(float)), (remainder*sizeof(float)), 20, 0, 0);
      }
   }
 
   /* DMA control block information from system memory. */
   mfc_put(&cb, argp.ui[1], sizeof(cb), 31, 0, 0);
   mfc_write_tag_mask((1<<20)|(1<<21)|(1<<31));
   mfc_read_tag_status_all();

   return 0;
}
