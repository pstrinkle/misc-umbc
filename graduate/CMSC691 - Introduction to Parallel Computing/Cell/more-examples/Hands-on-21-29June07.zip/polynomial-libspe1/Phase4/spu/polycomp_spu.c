#include "../polycomp.h"
#include <spu_mfcio.h>

/* control structure */
control_block cb __attribute__ ((aligned (128)));

float A_coeff[MAX_DEGREE] __attribute__ ((aligned (16)));
float B_coeff[MAX_DEGREE] __attribute__ ((aligned (16)));
float x[4096] __attribute__ ((aligned (128)));
float y[4096] __attribute__ ((aligned (128)));
char flag[4096] __attribute__ ((aligned (128)));

void poly_compute(int n) {
   unsigned int i, j;
   for (i=0; i<n; ++i) {
      float val;
      if (flag[i]) {
         val = B_coeff[0];
         for (j=0; j<cb.poly_degree; ++j) val = val * x[i] + B_coeff[j+1]; 
         ++cb.countB;
         y[i] = val;
         cb.sumB += (double) val;
      }
      else {
         val = A_coeff[0];
         for (j=0; j<cb.poly_degree; ++j) val = val * x[i] + A_coeff[j+1]; 
         ++cb.countA;
         y[i] = val;
         cb.sumA += (double) val;
      }
   }
}

/* here is the location where the SPE begins execution */
int main(unsigned long long speid, addr64 argp, addr64 envp) {

   unsigned int i, bigloop, loopcount, remainder, DMA_size;

   /* DMA control block information from system memory. */
   mfc_get(&cb, argp.ui[1], sizeof(cb), 31, 0, 0);
   mfc_write_tag_mask(1<<31);
   mfc_read_tag_status_all();

   DMA_size = (cb.poly_degree+1) * sizeof(float);
   DMA_size += 0xf;
   DMA_size &= (~0xf);

   mfc_get(A_coeff, cb.A_coeff, DMA_size, 31, 0, 0);
   mfc_get(B_coeff, cb.B_coeff, DMA_size, 31, 0, 0);
   mfc_write_tag_mask(1<<31);
   mfc_read_tag_status_all();

   loopcount = cb.array_size & (~4095);

   for (bigloop=0; bigloop<100; ++bigloop) {

      cb.countA = 0;
      cb.countB = 0;
      cb.sumA = 0.0;
      cb.sumB = 0.0;
  
      for (i=0; i<loopcount; i+=4096) {
          mfc_get(x, (cb.x+i*sizeof(float)), 16384, 31, 0, 0);
          mfc_get(flag, (cb.AB_flag+i*sizeof(char)), 4096, 31, 0, 0);
          mfc_write_tag_mask(1<<31);
          mfc_read_tag_status_all();
     
          poly_compute(4096);
     
          mfc_put(y, cb.y+i*sizeof(float), 16384, 31, 0, 0);
          mfc_write_tag_mask(1<<31);
          mfc_read_tag_status_all();
      }
    
      remainder = cb.array_size & 4095;
    
      if (remainder) {
          mfc_get(x, (cb.x+loopcount*sizeof(float)), (remainder*sizeof(float)), 31, 0, 0);
          mfc_get(flag, (cb.AB_flag+loopcount*sizeof(char)), (remainder*sizeof(char)), 31, 0, 0);
          mfc_write_tag_mask(1<<31);
          mfc_read_tag_status_all();
     
          poly_compute(remainder);
     
          mfc_put(y, (cb.y+loopcount*sizeof(float)), (remainder*sizeof(float)), 31, 0, 0);
     
          mfc_write_tag_mask(1<<31);
          mfc_read_tag_status_all();
      }
   }
 
   /* DMA control block information from system memory. */
   mfc_put(&cb, argp.ui[1], sizeof(cb), 31, 0, 0);
   mfc_write_tag_mask(1<<31);
   mfc_read_tag_status_all();

  return 0;
}
