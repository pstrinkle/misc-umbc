%% --------------------------------------------------------------  
%% (C)Copyright 2001,2006,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              
Target:
        CBE-Linux (HW or simulator)

Description:
	This directory contains a sample program demonstrating a few simple 
	DMA calls within one SPE.

	The actual executable resides in the ppu subdirectory.  It's 
	called 'simpleDMA'. It's a full, 64-bit CBE executable which is
	a PPE executable with embedded SPE object code. 
	
	The program performs the following sequence of events:
        1)  The PPE uses a malloc() command to allocate a small array in main 
	    memory.
	2)  The PPE fills the array with a fibonacci sequence. 1,1,2,3,...
        3)  The PPE then loads the address of the array into a control block.
        4)  The PPU prints the address of the array.
	5)  The PPE then creates the SPE thread, passing the address of the 
	    control block.
	6)  The SPE performs a simple DMA to load the contents of the control
	    block into its local store.
	7)  The SPE prints the array address contained within the contents
	    of the control block, and exits.
	8)  The SPE DMAs the data array from system memory to its local store.
	9)  The SPE verfies that the DMA contains a valid fibonacci sequence.
