typedef struct 
{
	char * memory;
	int first;
	int last;
	void * lstore[8];
	char padding[84];
	
} control_block;
