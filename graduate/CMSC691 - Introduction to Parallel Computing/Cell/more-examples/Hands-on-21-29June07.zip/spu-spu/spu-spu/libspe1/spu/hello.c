#include <stdio.h>
#include <spu_mfcio.h>
#include <libmisc.h>
#include <string.h>
#include "../control.h"

int main()
{
	int myId;
	char * buffer = malloc_align(128,7);
	control_block * ls_cb = malloc_align(sizeof(control_block),7);
	control_block * cbPtr;
	/* Step 1*/
	spu_write_out_mbox((unsigned int)buffer);
	/* Step 2 */
	cbPtr = (control_block *) spu_read_in_mbox();
	mfc_get (ls_cb, (unsigned int)cbPtr, sizeof(control_block), 1, 0, 0);
	mfc_write_tag_mask(1<<1);
	mfc_read_tag_status_all();
	/* Step 3 */
	myId = spu_read_in_mbox();

	/* Step 4 */
	if (myId == ls_cb->first)
	{
		mfc_get(buffer, (unsigned int)ls_cb->memory, 128, 1, 0, 0);
		mfc_write_tag_mask(1<<1);
		mfc_read_tag_status_all();
	}
	/* Step 5 */
	printf ("SPE %d says %s\n", myId, buffer);
	if (myId == 0)
		strcpy(buffer,"Dobry dien!");
	if (myId == 1)
		strcpy(buffer,"Bon giorno!");
	if (myId == 2)
		strcpy(buffer,"Buenas dias!");
	if (myId == 3)
		strcpy(buffer,"Ohayo gozaimasu!");
	if (myId == 4)
		strcpy(buffer,"Boker tov!");
	if (myId == 5)
		strcpy(buffer,"Dobre jitro!");
	if (myId == 6)
		strcpy(buffer,"Bon jour!");
	if (myId == 7)
		strcpy(buffer,"Chao buoi sang!");	
	/* Step 7 */
	if (myId == ls_cb->last) {
		mfc_put(buffer, (unsigned int)ls_cb->memory, 128, 1, 0, 0);
	}
	else{
		mfc_put(buffer, (unsigned int)ls_cb->lstore[myId+1], 128, 1, 0, 0);
	}
	mfc_write_tag_mask(1<<1);
	mfc_read_tag_status_all();
	
	return 0;
}
