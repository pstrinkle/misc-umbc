#include <stdio.h>
#include <libspe.h>
#include <libmisc.h>
#include <string.h>
#include "control.h"

extern spe_program_handle_t hello_spu;
char buffer[128] __attribute__ ((aligned(128)));
#define ACTIVE_SPUS 6

int main()
{
	speid_t speid[ACTIVE_SPUS];
	int status[ACTIVE_SPUS];
	int i;
	control_block * cb = malloc_align(128,7);
	cb->first = 0;
	cb->last = ACTIVE_SPUS - 1;
	cb->memory = buffer;
	strcpy (buffer, "Zao shang hao!");

	for (i=0;i<ACTIVE_SPUS;i++){
		speid[i] = spe_create_thread(0, &hello_spu, NULL, NULL, -1, 0);
	}
	for (i=0;i<ACTIVE_SPUS;i++){
		cb->lstore[i] = spe_get_ls(speid[i]);
		while (!spe_stat_out_mbox(speid[i])) {}
		cb->lstore[i] += spe_read_out_mbox(speid[i]);
	}	
	for (i=0;i<ACTIVE_SPUS;i++)
		spe_write_in_mbox(speid[i],(unsigned int)cb);

	for (i=0;i<ACTIVE_SPUS;i++){
		spe_write_in_mbox(speid[i],i);
		spe_wait(speid[i], &status[i], 0);
	}

	printf("PPE says %s\n", buffer);
	return 0;
}
