#include <stdio.h>
#include <libspe2.h>
#include <libmisc.h>
#include <pthread.h>
#include <string.h>
#include "control.h"

extern spe_program_handle_t hello_spu;
char buffer[128] __attribute__ ((aligned(128)));
#define ACTIVE_SPUS 6

void *ppu_pthread_function(void *arg)
{
	unsigned int entry = SPE_DEFAULT_ENTRY;

	spe_context_run(*((spe_context_ptr_t *)arg), &entry, 0, NULL, NULL, NULL) ;
	pthread_exit(NULL);
}

int main()
{

	int i;
	spe_context_ptr_t ctxs[ACTIVE_SPUS];
	pthread_t threads[ACTIVE_SPUS];

	control_block * cb = (control_block *)malloc_align(128,7);
	cb->first = 0;
	cb->last = ACTIVE_SPUS - 1;
	cb->memory = buffer;
	strcpy (buffer, "Zao shang hao!");

	for (i=0;i<ACTIVE_SPUS;i++){
		ctxs[i] = spe_context_create (0, NULL);
		spe_program_load (ctxs[i], &hello_spu);
		pthread_create (&threads[i], NULL, &ppu_pthread_function, &ctxs[i]);
	}
	for (i=0;i<ACTIVE_SPUS;i++){
		cb->lstore[i] = spe_ls_area_get(ctxs[i]);
		while (!spe_out_mbox_status(ctxs[i])) {}
		unsigned int temp;
		spe_out_mbox_read(ctxs[i], &temp, 1);
		cb->lstore[i] += temp;
	
	}	
	for (i=0;i<ACTIVE_SPUS;i++){
		unsigned int data;
		data = (unsigned int)(cb);
		spe_in_mbox_write(ctxs[i], &data, 1, SPE_MBOX_ANY_NONBLOCKING);
	}

	for (i=0;i<ACTIVE_SPUS;i++){
		spe_in_mbox_write(ctxs[i], (unsigned int *)&i, 1, SPE_MBOX_ANY_NONBLOCKING);
		pthread_join (threads[i], NULL);
	}

	printf("PPE says %s\n", buffer);
	return 0;
}
