/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * spe-cp.c
 *
 * Copyright (C) 2005 IBM Corp.
 *
 * Stand-alone 'spulet' that copies one file to another.
 * The file contents are mmap'd into the effective address
 * space and multi-buffered DMAs are used to stage data 
 * into and then out from LS.
 * 
 * The purpose here is to illustrate how a simple 
 * SPE-based file filter might be constructed.  For 
 * example a more advanced filter might encrypt or 
 * transcode the file contents, rather than simply 
 * copy.
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

#include "memcpy_ea.h"

int main(int argc, char **argv)
{
    char *src_name, *dst_name;
    int src_fd, dst_fd;
    int prot = PROT_READ | PROT_WRITE;
    int flags = O_RDWR | O_CREAT | O_TRUNC;
    struct stat buf;
    unsigned long long src, dst;

    if (argc != 3) {
	printf("Usage: %s [from] [to].\n", argv[0]);
	return 1;
    }
    src_name = argv[1];
    dst_name = argv[2];

    /* Open both files. */
    if ((src_fd = open(src_name, O_RDONLY, 0)) == -1) {
	perror("Can't open source file");
	return 1;
    }
    if ((dst_fd = open(dst_name, flags, buf.st_mode | S_IWUSR)) < 0) {
	perror("Can't create destination file");
	return 1;
    }

    /* Set up memory mappings. */
    if (fstat(src_fd, &buf) != 0) {
	perror("Can't stat source file");
	return 1;
    }
    if (!buf.st_size) {
	return 0;
    }
    if (lseek(dst_fd, buf.st_size - 1, SEEK_SET) == -1) {
	perror("Can't lseek destination file");
	return 1;
    }
    if (write(dst_fd, "", 1) != 1) {
	perror("Can't write to destination file");
	return 1;
    }
    src = mmap_ea(0ULL, buf.st_size, PROT_READ, MAP_PRIVATE, src_fd, 0);
    if (src == MAP_FAILED) {
	perror("Can't mmap source file");
	return 1;
    }
    dst = mmap_ea(0ULL, buf.st_size, prot, MAP_SHARED, dst_fd, 0);
    if (dst == MAP_FAILED) {
	perror("Can't mmap destiation file");
	return 1;
    }

    /* Copy from src->LS->dst using multi-buffered DMAs. */
    memcpy_ea(dst, src, buf.st_size);

    return 0;
}
