/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * memcpy_ea.h
 *
 * Copyright (C) 2005 IBM Corp.
 *
 * Simple SPE memcpy() for EA->EA copies.  Both 
 * src & dst must begin on 16-byte a boundary, 
 * and the regions must not overlap. The copy 
 * size, however, is arbitrary.
 *
 * This code uses fenced DMAs, which cause
 * the hardware to order transfers within a 
 * given tag group.  Further, this code uses 
 * multi-buffered DMAs and assigns a unique 
 * tag group identifier to each buffer. The 
 * combination of fenced and multibuffered
 * DMAs lets us efficiently multiplex incoming
 * and outgoing transfers, with greatly reduced 
 * complexity for the control logic.
 */

#ifndef __MEMCPY_EA_H__
#define __MEMCPY_EA_H__	1

#include <spu_mfcio.h>

#define NR_BUFS_SHIFT   3
#define NR_BUFS         (1 << NR_BUFS_SHIFT)
#define NR_BUFS_MASK    (NR_BUFS - 1)

#define BUF_SIZE_SHIFT  14
#define BUF_SIZE        (1 << BUF_SIZE_SHIFT)
#define BUF_SIZE_MASK   (BUF_SIZE - 1)

#define likely(_c)     \
    __builtin_expect((_c), 1)
#define unlikely(_c)    \
    __builtin_expect((_c), 0)

#define DMA(_ls, _ea, _size, _tag, _cmd)     \
        spu_mfcdma64(_ls, _ea.by32[0], _ea.by32[1], _size, _tag, _cmd)

#define COPY(_ls, _src, _dst, _sz, _tg) {			\
	unsigned int _size = (_sz);				\
	unsigned int _tag = (_tg);				\
	DMA(_ls, _src, _size, _tag, MFC_GETF_CMD);		\
	DMA(_ls, _dst, _size, _tag, MFC_PUTF_CMD);		\
	_src.all64 += _size;					\
	_dst.all64 += _size;					\
}

typedef union {
    unsigned long long all64;
    unsigned int by32[2];
} addr64;

/* Intermediate buffers */
static char buf[BUF_SIZE * NR_BUFS] __attribute__ ((aligned(128)));
static char partial_buf[BUF_SIZE] __attribute__ ((aligned(128)));

static inline void memcpy_ea_whole(unsigned long long dst, unsigned long long src, int nbufs)
{
    addr64 _src, _dst;
    unsigned int i = 0;

    _src.all64 = src;
    _dst.all64 = dst;

    while (nbufs > 0) {
	COPY(&buf[i * BUF_SIZE], _src, _dst, BUF_SIZE, i);
	i = (i >= NR_BUFS - 1) ? 0 : i + 1;
	nbufs--;
    }
}

static inline void memcpy_ea_partial(unsigned long long dst, unsigned long long src, size_t size)
{
    size_t quadwords = size & ~0xf;
    size_t rem = size & 0xf;
    addr64 _src, _dst;

    _src.all64 = src;
    _dst.all64 = dst;

    if (likely(quadwords)) {
	COPY(&buf[0], _src, _dst, quadwords, 0);
    }
    if (unlikely(rem)) {
	char *ptr = &partial_buf[0];

	if (rem & 0x8) {
	    COPY(ptr, _src, _dst, 8, 3);
	    ptr += 8;
	}
	if (rem & 0x4) {
	    COPY(ptr, _src, _dst, 4, 2);
	    ptr += 4;
	}
	if (rem & 0x2) {
	    COPY(ptr, _src, _dst, 2, 1);
	    ptr += 2;
	}
        if (rem & 0x1) {
	    COPY(ptr, _src, _dst, 1, 0);
	    ptr += 1;
        }
    }
}

static inline void memcpy_ea(unsigned long long dst, unsigned long long src, size_t size)
{
    unsigned int nbufs = size >> BUF_SIZE_SHIFT;
    unsigned int rem = size & BUF_SIZE_MASK;
    unsigned int all_mask = ~0x0;

    /* This code assumes that src & dst are naturally aligned 
     * to BUF_SIZE boundaries (ala mmap), but the size can be 
     * arbitrary.
     */
    if (likely(nbufs > 0)) {
	memcpy_ea_whole(dst, src, nbufs);
	dst += (nbufs * BUF_SIZE);
	src += (nbufs * BUF_SIZE);
    }
    if (likely(rem)) {
	memcpy_ea_partial(dst, src, rem);
    }
    spu_writech(22, all_mask);
    spu_mfcstat(MFC_TAG_UPDATE_ALL);
}

#endif /* __MEMCPY_EA_H__ */
