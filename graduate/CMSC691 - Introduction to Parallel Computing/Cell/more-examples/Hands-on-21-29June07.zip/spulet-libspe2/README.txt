%% --------------------------------------------------------------  
%% (C)Copyright 2001,2006,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              
Target: 
	SPE, Linux

Description:
	This directory contains samples of stand alone SPU programs, 
	refered to here as "spulets".  These are C-language programs 
	that have been compiled to run on an SPU, and may invoke
	C-library functions such as printf(3), open(2), read(2), 
	write(2), mmap(2), etc.

	Further, "spulets" can be executed directly from the Linux
	command prompt.  These programs take standard argument strings 
	and exit with integer return codes.  In short, "spulets" 
	outwardly look just like any other executable in the file system.

	The simplicity of the "spulet" programming model is meant to 
	encourage porting and incremental refinement of legacy code on 
	the SPU.  Further, "spulets" could be used to create a whole
	new generation of reusable media file filters (e.g. transcoders, 
	encrypt/decrypt engines, etc).  And because "spulets" can interact 
	with stdin/stdout/stderr, they may be recombined with existing
	utilities via pipes, shared memory, and so forth.

Notes:
	For spulets to utilize standard argument parameters, they must
	must be linked with a special crt object. This is accomplished by 
	usng the gcc compiler argument "-mstdmain" or the xlc compiler argument
	"-qstdmain".
