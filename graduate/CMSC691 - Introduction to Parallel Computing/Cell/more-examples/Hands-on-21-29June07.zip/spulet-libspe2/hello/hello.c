/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* 
 * src/samples/spulet/hello/hello.c
 *
 * Print a hearty greeting, followed by each of the 
 * command line argument strings.
 *
 * Note: The argument vector and strings are local
 * store addresses (LSA's) and can be dereferenced
 * directly.
 */

#include <stdio.h>

int main(int argc, char **argv)
{
    int i;

    printf("Hello world, from an SPU!\n");
    printf("Printing command line arguments (argc=%d)\n", argc);
    for (i=0; i<argc; i++) {
	printf("  argv[%d] = %s\n", i, argv[i]);
    }
    return 0;
}

