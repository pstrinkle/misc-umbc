/* --------------------------------------------------------------- */
/* (C)Copyright 2006                                               */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
/*
 * cpaudio.c
 *
 * Stand-alone 'spulet' that copies one channel of a stereo
 * audio file to the other channel.
 * The file contents are mmap'd into the effective address
 * space and double-buffered DMAs are used to stage data 
 * into and then out from LS.
 * 
 * This sample illustrates how a SPE-based audio filter 
 * might be constructed. This type of filter might be combined with
 * other filters in a pipeline fashion to apply multiple filters to
 * the same file.
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <spu_mfcio.h>
#include <spu_intrinsics.h>

#define BUF_SIZE_SHIFT 10
#define BUF_SIZE      (1 << BUF_SIZE_SHIFT)
#define BUF_SIZE_MASK (BUF_SIZE - 1)

vector unsigned short in1[BUF_SIZE], in2[BUF_SIZE], 
                      out1[BUF_SIZE], out2[BUF_SIZE] __attribute__ ((aligned (128)));
vector unsigned short *in[2], *out[2];

static void channel_copy(vector unsigned short in[], 
                         vector unsigned short out[],
                         int length,
                         vector unsigned short mask,
                         int rotate_bytes) {
    int i;
    vector unsigned short in0, in1, in2, in3, in4, in5, in6, in7,
                          in0s, in1s, in2s, in3s, in4s, in5s, in6s, in7s,
                          out0, out1, out2, out3, out4, out5, out6, out7;
    for (i = 0; i < length; i+=8) {
        in0 = in[i];
        in1 = in[i+1];
        in2 = in[i+2];
        in3 = in[i+3];
        in4 = in[i+4];
        in5 = in[i+5];
        in6 = in[i+6];
        in7 = in[i+7];
        
        in0s = spu_rlqwbyte(in0, rotate_bytes);
        in1s = spu_rlqwbyte(in1, rotate_bytes);
        in2s = spu_rlqwbyte(in2, rotate_bytes);
        in3s = spu_rlqwbyte(in3, rotate_bytes);
        in4s = spu_rlqwbyte(in4, rotate_bytes);
        in5s = spu_rlqwbyte(in5, rotate_bytes);
        in6s = spu_rlqwbyte(in6, rotate_bytes);
        in7s = spu_rlqwbyte(in7, rotate_bytes);
         
        out0 = spu_sel(in0, in0s, mask);
        out1 = spu_sel(in1, in1s, mask);
        out2 = spu_sel(in2, in2s, mask);
        out3 = spu_sel(in3, in3s, mask);
        out4 = spu_sel(in4, in4s, mask);
        out5 = spu_sel(in5, in5s, mask);
        out6 = spu_sel(in6, in6s, mask);
        out7 = spu_sel(in7, in7s, mask);
           
        out[i] = out0;
        out[i+1] = out1;
        out[i+2] = out2;
        out[i+3] = out3;
        out[i+4] = out4;
        out[i+5] = out5;
        out[i+6] = out6;
        out[i+7] = out7;
    }
}

static void cpaudio(unsigned long long dst, unsigned long long src, size_t size, char source_channel) {
    int i, n_vec_left, n_frames, rem_bytes, rotate_bytes;
    vector unsigned short mask;
    vector unsigned short in0, in0s, out0;

    in[0] = &in1[0];
    in[1] = &in2[0];
    out[0] = &out1[0];
    out[1] = &out2[0];
           
    if (source_channel == 'r') {
        mask = (vector unsigned short)spu_maskb(0x3333);
        rotate_bytes = -2;
    }
    else {
        mask = (vector unsigned short)spu_maskb(0xCCCC);
        rotate_bytes = 2;
    }
       
    n_frames = size >> (BUF_SIZE_SHIFT+4);
    n_vec_left = (size >> 4) & BUF_SIZE_MASK;
    
    /* Read input buffer for the first loop iteration */
    mfc_get(in[0], src, sizeof(vector unsigned short)<<BUF_SIZE_SHIFT, 20, 0, 0);
    src += sizeof(vector unsigned short)<<BUF_SIZE_SHIFT;

    for (i = 0; i < n_frames - 1; i++) {
        /* Initiate read for the second buffer */
        mfc_get(in[(i+1)&1], src, sizeof(vector unsigned short)<<BUF_SIZE_SHIFT, 20+((i+1)&1) , 0, 0);
        src += sizeof(vector unsigned short)<<BUF_SIZE_SHIFT;
        
        /* Wait for the read */
        mfc_write_tag_mask(1 << (20+(i&1)));
        mfc_read_tag_status_all();
        
        /* Wait for the write */
        mfc_write_tag_mask(1 << (30+(i&1)));
        mfc_read_tag_status_all();
        
        /* Do the channel copy */
        channel_copy(in[i&1], out[i&1], BUF_SIZE, mask, rotate_bytes);
        
        /* Write out the vectors */
        mfc_put(out[i&1], dst, sizeof(vector unsigned short)<<BUF_SIZE_SHIFT, 30+(i&1), 0, 0);
        dst += sizeof(vector unsigned short)<<BUF_SIZE_SHIFT;
    }

    /* Calculate the last full frame */
    
    /* Initiate read for the partial buffer */
    mfc_get(in[n_frames&1], src, sizeof(vector unsigned short)*n_vec_left, 20+(n_frames&1), 0, 0);
    src += sizeof(vector unsigned short)*n_vec_left;
    
    /* Wait for the read */
    mfc_write_tag_mask(1 << (20+((n_frames-1)&1)));
    mfc_read_tag_status_all();
    
    /* Wait for the write */
    mfc_write_tag_mask(1 << (30+((n_frames-1)&1)));
    mfc_read_tag_status_all();
    
    /* Do the channel copy */
    channel_copy(in[(n_frames-1)&1], out[(n_frames-1)&1], BUF_SIZE, mask, rotate_bytes);
    
    /* Write out the vectors */
    mfc_put(out[(n_frames-1)&1], dst, sizeof(vector unsigned short)<<BUF_SIZE_SHIFT, 30+((n_frames-1)&1), 0, 0);
    dst += sizeof(vector unsigned short)<<BUF_SIZE_SHIFT;

    /* Calculate the partial frame */
    
    /* Wait for the read */
    mfc_write_tag_mask(1 << (20+(n_frames&1)));
    mfc_read_tag_status_all();
    
    /* Wait for the write */
    mfc_write_tag_mask(1 << (30+(n_frames&1)));
    mfc_read_tag_status_all();
    
    /* Do the channel copy */
    for (i = 0; i < n_vec_left; i++) {
        in0 = in[n_frames&1][i];
        in0s = spu_rlqwbyte(in0, rotate_bytes);
        out0 = spu_sel(in0, in0s, mask);
        out[n_frames&1][i] = out0;
    }
    
    /* Calculate the last chunk if the file size is not a multiple of 16 bytes */
    rem_bytes = size & 15;
    if (rem_bytes) {
        in0 = in[n_frames&1][i];
        in0s = spu_rlqwbyte(in0, rotate_bytes);
        out0 = spu_sel(in0, in0s, mask);
        out[n_frames&1][i] = out0;
        n_vec_left++;
    }
    
    /* Write remaining vectors */
    mfc_put(out[n_frames&1], dst, sizeof(vector unsigned short)*n_vec_left, 31, 0, 0);

    /* Wait */
    mfc_write_tag_mask(1 << 31);
    mfc_read_tag_status_all();
}

int main(int argc, char **argv) {
    char *src_name, *dst_name;
    char source_channel;
    int src_fd, dst_fd;
    int prot = PROT_READ | PROT_WRITE;
    int flags = O_RDWR | O_CREAT | O_TRUNC;
    struct stat buf;
    unsigned long long src, dst;
    
    if (argc != 4 || (argv[1][0] != 'r' && argv[1][0] != 'l')) {
        printf("Usage: %s <source-channel> <input-file> <output-file>\n"
               "  source-channel - r=right, l=left\n"
               "  input-file     - Unsigned halfword stereo audio file name\n"
               "  output-file    - Output file name\n", argv[0]);
        return 1;
    }
    
    source_channel = argv[1][0];
    src_name = argv[2];
    dst_name = argv[3];
    
    /* Open both files. */
    if ((src_fd = open(src_name, O_RDONLY, 0)) == -1) {
        perror("Can't open source file");
        return 1;
    }
    if ((dst_fd = open(dst_name, flags, buf.st_mode | S_IRWXU)) < 0) {
        perror("Can't create destination file");
        return 1;
    }
    
    /* Set up memory mappings. */
    if (fstat(src_fd, &buf) != 0) {
        perror("Can't stat source file");
        return 1;
    }
    
    if (!buf.st_size) {
        perror("Input is empty");
        return 0;
    }
    if (lseek(dst_fd, buf.st_size - 1, SEEK_SET) == -1) {
        perror("Can't lseek destination file");
        return 1;
    }
    if (write(dst_fd, "", 1) != 1) {
        perror("Can't write to destination file");
        return 1;
    }
    
    src = mmap_ea(0ULL, buf.st_size, PROT_READ, MAP_PRIVATE, src_fd, 0);
    
    if (src == MAP_FAILED) {
        perror("Can't mmap source file");
        return 1;
    }
    
    dst = mmap_ea(0ULL, buf.st_size, prot, MAP_SHARED, dst_fd, 0);
    
    if (dst == MAP_FAILED) {
        perror("Can't mmap destiation file");
        return 1;
    }
    
    /* Do the channel copy */
    cpaudio(dst, src, buf.st_size, source_channel);
    
    return 0;
}

