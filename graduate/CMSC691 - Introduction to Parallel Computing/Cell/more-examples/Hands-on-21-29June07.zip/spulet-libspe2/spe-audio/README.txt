%% --------------------------------------------------------------- 
%% (C)Copyright 2006                                               
%% International Business Machines Corporation,                    
%% All Rights Reserved.                                            
%%                                                                 
%% This program is made available under the terms of the           
%% Common Public License v1.0 which accompanies this distribution. 
%% --------------------------------------------------------------- 
%% PROLOG END TAG zYx                                              

Summary: Spulet audio filter samples

Target: SPE binary within simulator, and host executable outside simulator

Description:

        This directory contains source code used to demonstrate audio 
        filtering on the SPU. Two samples are included:
        
        cpaudio   = copies one channel of a stereo audio file to the other
                    channel.
                  
        normalize = normalizes the volume of a mono audio file.

        
        Both samples take raw unsigned halfword audio files as input and 
        output the same format. Input audio files for these samples can be 
        found in the audio resample source directory:
        
                src/samples/resample
     
        See the resample README.txt for more information on the files.
    
How to run:

        To run cpaudio, copy the SPU program 'cpaudio' and at least
        one mono file into the simulator environment, using "callthru".

        The command options are:
        
           cpaudio [source-channel] [input-file] [output-file]

           where:
              source-channel = r=right, l=left
              input-file     = Unsigned halfword stereo audio file name
              output-file    = Output file name
          
        To run normalize, copy the SPU program 'normalize' and at least
        one stereo file into the simulator environment, using "callthru".

        The command options are:
    
           normalize [input-file] [output-file]
           
           where:
              input-file  = Unsigned halfword monophonic audio file name
              output-file = Output file name

  Example 1:
        Copy the left channel of chord.uw (in src/samples/resample)
        to the right channel:

           cpaudio l chord.uw chord_l.uw

        Now, transfer these files back to the host system using
        "callthru sink". 

        Run compdisp (in src/samples/resample) to display them:

           compdisp 1 chord_l.uw chord_l.uw chord_l.uw

        Use "r" and "l" to move right and left along the line.  Keep moving
        right until you can see the wave. There should be only one signal
        displayed since the left channel is duplicated.
        
        
  Example 2:
        Normalize the volume of b13s.uw (in src/samples/resample):
        
           normalize b13s.uw b13s_n.uw
                
        Now transfer these files back to the host system using
        "callthru sink".
        
        Run compdisp (in src/samples/resample) to display them:

           compdisp 0 b13s.uw b13s_n.uw b13s_n.uw
           
        The normalized signal should appear slightly offset vertically
        from the original signal since the amplitude has been adjusted.
    
        To convert the output to a .wav file:
    
           sox -r 16100 -c 1 -x b13s_n.uw b13s_n.wav


Notes:

        Note that b13s.uw and chord.uw can be used unchanged, but beginning.uw
        has an opposite word order than normalize expects, which can be swapped
        with this command:
    
           sox beginning.uw -x beginning_x.uw

