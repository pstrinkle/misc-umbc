#include <stdio.h>
#include <libspe.h>
#include <libmisc.h>
#include <string.h>

extern spe_program_handle_t putbuf_spu;

int main (void)
{
	speid_t speid;
	int status;
	char * buffer;

	buffer    = malloc_align(128,7);

	strcpy (buffer, "Good morning!");
	//buffer = 'good morning'; use of this one will create a bus error	

	// create SPU threads
	speid = spe_create_thread (0, &putbuf_spu, (void *)buffer, 128, -1, 0);

	spe_wait(speid, &status, 0);

	printf("New modified buffer is %s\n", buffer);
	return 0;
}
