#include <stdio.h>
#include <string.h>
#include <libmisc.h>
#include <spu_mfcio.h>

//#define wait_on_mask(x)   mfc_write_tag_mask(x); mfc_read_tag_status_any();

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp)
{
	char * buffer;
	int tag = 31, tag_mask = 1<<tag;

	// we should probably check here to make sure envp/size is a valid DMA size but for the sake
	// of readability I'm going to assume it is....

	printf("ARGP = 0x%llx, ENVP = %d\n", argp, envp);

	buffer = malloc_align(envp, 7);

	// receive buffer
	mfc_get(buffer, (unsigned int)argp, envp, tag, 0, 0);
	mfc_write_tag_mask(tag_mask);
	mfc_read_tag_status_any();
	//wait_on_mask(tag_mask);
	printf("SPE 0 received buffer \"%s\"\n", buffer);

	// modify buffer
	strcpy (buffer, "Guten Morgen!");

	// DMA out buffer to SPE 1
	mfc_put(buffer, (unsigned int)argp, envp, tag, 0, 0);
	mfc_write_tag_mask(tag_mask);
	mfc_read_tag_status_any();
	//wait_on_mask(tag_mask);

	return 0;
}
