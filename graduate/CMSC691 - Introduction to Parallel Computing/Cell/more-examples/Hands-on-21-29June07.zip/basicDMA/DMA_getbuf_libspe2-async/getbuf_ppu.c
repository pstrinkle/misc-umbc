#include <stdio.h>
//#include <libspe.h>
//#include <libmisc.h>
#include <string.h>
#include <libspe2.h>
#include <pthread.h>

typedef struct ppu_pthread_data{
   spe_context_ptr_t context;
   pthread_t pthread;
   unsigned int entry;
   unsigned int flags;
   void *argp;
   void *envp;
   spe_stop_info_t stopinfo;
}  ppu_pthread_data_t;

void *ppu_pthread_function(void *arg)
{
   ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
   int rc;
       rc = spe_context_run(datap->context, &datap->entry, datap->flags, datap->argp, datap->envp, &datap->stopinfo);
   pthread_exit(NULL);
} 
//spu program
extern spe_program_handle_t getbuf_spu;
//local buffer
unsigned char buffer[128] __attribute__ ((aligned(128)));
//spe context
//spe_context_ptr_t speid;
//unsigned int flags = 0;
//unsigned int entry = SPE_DEFAULT_ENTRY;
//spe_stop_info_t stop_info;
//int rc;

int main (void)
{
strcpy (buffer, "Good morning!");
	printf("Original buffer is %s\n", buffer);

//     	speid = spe_context_create(flags, NULL);
//         spe_program_load(speid, &getbuf_spu);
//   	rc = spe_context_run(speid, &entry, 0, buffer, NULL, &stop_info);
//   	spe_context_destroy(speid);

	
   ppu_pthread_data_t data;
   data.context = spe_context_create(0, NULL);
   spe_program_load(data.context, &getbuf_spu);
   data.entry = SPE_DEFAULT_ENTRY;
   data.flags = 0;
   data.argp = buffer;
   data.envp = NULL;
   pthread_create(&data.pthread, NULL, &ppu_pthread_function, &data);
   pthread_join(data.pthread, NULL);
   spe_context_destroy(data.context);

	printf("New modified buffer is %s\n", buffer);
	return 0;
}
