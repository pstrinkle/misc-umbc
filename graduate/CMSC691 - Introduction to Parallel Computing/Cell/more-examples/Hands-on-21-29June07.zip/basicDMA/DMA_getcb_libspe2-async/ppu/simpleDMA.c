#include "../simpleDMA.h"
#include <sched.h>
//#include <libspe.h>
#include <stdio.h>
#include <errno.h>
#include <libspe2.h>
#include <pthread.h>

/* we allocate one control block, to correspond to one SPE */
control_block cb __attribute__ ((aligned (128)));

/* this is the pointer to the SPE code, to be used at thread creation time */
extern spe_program_handle_t simpleDMA_spu;

typedef struct ppu_pthread_data{
   spe_context_ptr_t context;
   pthread_t pthread;
   unsigned int entry;
   unsigned int flags;
   void *argp;
   void *envp;
   spe_stop_info_t stopinfo;
}  ppu_pthread_data_t;

void *ppu_pthread_function(void *arg)
{
   ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
   int rc;
       rc = spe_context_run(datap->context, &datap->entry, datap->flags, datap->argp, datap->envp, &datap->stopinfo);
   pthread_exit(NULL);
} 

//spe_context_ptr_t speid;
//unsigned int flags = 0;
//unsigned int entry = SPE_DEFAULT_ENTRY;
//spe_stop_info_t stop_info;
//int rc;

/* this is the handle which will be returned by "spe_create_thread."  */
//speid_t speid;

/* this variable is used to return data regarding an abnormal return from the SPE */
//int status;

/* here is the variable to hold the address returned by the malloc() call. */
int *data;

int main() {

  /* here is the malloc call */ 
  data = (int *) malloc(128);

  printf("address being sent in control block: %x\n", (unsigned int) data);

  /* load the address into the control block */
  cb.addr       = (unsigned int) data;

  /* allocate the SPE task */
 //speid = spe_create_thread (0, &simpleDMA_spu, (unsigned long long *) &cb, NULL, -1, 0);
  
  /* wait for the SPE to complete */
  //spe_wait(speid, &status, 0);

  /* Issue a sync, just to be safe. */
  //__asm__ __volatile__ ("sync" : : : "memory");

	ppu_pthread_data_t data;
   data.context = spe_context_create(0, NULL);
   spe_program_load(data.context, &simpleDMA_spu);
   data.entry = SPE_DEFAULT_ENTRY;
   data.flags = 0;
   data.argp = &cb;
   data.envp = NULL;
   pthread_create(&data.pthread, NULL, &ppu_pthread_function, &data);
   pthread_join(data.pthread, NULL);
   spe_context_destroy(data.context);

     	//speid = spe_context_create(flags, NULL);
      //spe_program_load(speid, &simpleDMA_spu);
   	//rc = spe_context_run(speid, &entry, 0, (unsigned long long *) &cb, NULL, &stop_info);
   	//spe_context_destroy(speid);



  return 0;
}
