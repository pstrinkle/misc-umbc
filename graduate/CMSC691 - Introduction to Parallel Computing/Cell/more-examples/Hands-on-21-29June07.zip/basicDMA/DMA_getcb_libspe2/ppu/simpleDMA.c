#include "../simpleDMA.h"
#include <sched.h>
//#include <libspe.h>
#include <stdio.h>
#include <errno.h>
#include <libspe2.h>

/* we allocate one control block, to correspond to one SPE */
control_block cb __attribute__ ((aligned (128)));

/* this is the pointer to the SPE code, to be used at thread creation time */
extern spe_program_handle_t simpleDMA_spu;

spe_context_ptr_t speid;
unsigned int flags = 0;
unsigned int entry = SPE_DEFAULT_ENTRY;
spe_stop_info_t stop_info;
int rc;

/* this is the handle which will be returned by "spe_create_thread."  */
//speid_t speid;

/* this variable is used to return data regarding an abnormal return from the SPE */
//int status;

/* here is the variable to hold the address returned by the malloc() call. */
int *data;

int main() {

  /* here is the malloc call */ 
  data = (int *) malloc(128);

  printf("address being sent in control block: %x\n", (unsigned int) data);

  /* load the address into the control block */
  cb.addr       = (unsigned int) data;

  /* allocate the SPE task */
 //speid = spe_create_thread (0, &simpleDMA_spu, (unsigned long long *) &cb, NULL, -1, 0);
  
  /* wait for the SPE to complete */
  //spe_wait(speid, &status, 0);

  /* Issue a sync, just to be safe. */
  //__asm__ __volatile__ ("sync" : : : "memory");

     	speid = spe_context_create(flags, NULL);
         spe_program_load(speid, &simpleDMA_spu);
   	rc = spe_context_run(speid, &entry, 0, (unsigned long long *) &cb, NULL, &stop_info);
   	spe_context_destroy(speid);



  return 0;
}
