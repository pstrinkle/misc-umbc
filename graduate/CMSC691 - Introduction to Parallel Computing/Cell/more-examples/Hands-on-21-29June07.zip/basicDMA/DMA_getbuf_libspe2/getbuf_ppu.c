#include <stdio.h>
//#include <libspe.h>
//#include <libmisc.h>
#include <string.h>
#include <libspe2.h>

//spu program
extern spe_program_handle_t getbuf_spu;
//local buffer
unsigned char buffer[128] __attribute__ ((aligned(128)));
//spe context
spe_context_ptr_t speid;
unsigned int flags = 0;
unsigned int entry = SPE_DEFAULT_ENTRY;
spe_stop_info_t stop_info;
int rc;

int main (void)
{
strcpy (buffer, "Good morning!");
	printf("Original buffer is %s\n", buffer);

     	speid = spe_context_create(flags, NULL);
         spe_program_load(speid, &getbuf_spu);
   	rc = spe_context_run(speid, &entry, 0, buffer, NULL, &stop_info);
   	spe_context_destroy(speid);

	printf("New modified buffer is %s\n", buffer);
	return 0;
}
