#include <stdio.h>
#include <string.h>
//#include <libmisc.h>
#include <spu_mfcio.h>

unsigned char buffer[128] __attribute__ ((aligned(128)));

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp)
{
	int tag = 31, tag_mask = 1<<tag;
	// DMA in buffer from PPE
	mfc_get(buffer, (unsigned long long)argp, 128, tag, 0, 0);	
	mfc_write_tag_mask(tag_mask);
	mfc_read_tag_status_any();
	printf("SPE received buffer \"%s\"\n", buffer);

	// modify buffer
	strcpy (buffer, "Guten Morgen!");
	printf("SPE sent to PPU buffer \"%s\"\n", buffer);
	// DMA out buffer to PPE
	mfc_put(buffer, (unsigned long long)argp, 128, tag, 0, 0);
	mfc_write_tag_mask(tag_mask);
	mfc_read_tag_status_any();
	return 0;
}
