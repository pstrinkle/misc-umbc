/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <libspe2.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

/* allocate memory objects located in the effective address space */
int foo[512] 		__attribute((aligned(128)));
int bar[512] 		__attribute((aligned(128)));
int foobar[1024] 	__attribute((aligned(128)));

/* this is the spe program handle structure */
extern spe_program_handle_t spu_foobar;

int main() {
  spe_context_ptr_t speid;
  int i, rc;
  spe_stop_info_t stopinfo;
  unsigned int entry = SPE_DEFAULT_ENTRY;

  /* initialize the memory objects */
  for (i=0; i<512; i++) {
    foo[i] = i;
    bar[i] = 511-i;
  }

  /* Create context */
  if ((speid = spe_context_create (0, NULL)) == NULL)
    {
      fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit (1);
    }
  /* Load program */
  if ((rc = spe_program_load (speid, &spu_foobar)) != 0)
    {
      fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit (1);
    }
  /* Run context */
  if ((rc = spe_context_run(speid, &entry, 0, NULL, NULL, &stopinfo)) != 0)
    {
      fprintf (stderr, "Failed spe_context_run(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit (1);
    }
  /* Destroy context */
  if ((rc = spe_context_destroy (speid)) != 0)
    {
      fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
      exit (1);
    }
    
  for (i=0; i<512; i++) {
    if ((foobar[2*i] != foo[i]) ||
	(foobar[2*i+1] != bar[i]))
	goto fail;
  }
  fprintf(stderr, "Pass\n");
  return 0;

fail:
  fprintf(stderr, "Failed at %d: %d:%d %d:%d\n", i, 
	foobar[2*i], foo[i],
	foobar[2*i+1], bar[i]);
  return 1;
}
