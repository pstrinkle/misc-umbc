/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <libspe.h>
#include <stdio.h>
#include <errno.h>

/* allocate memory objects located in the effective address space */
int foo[512] 		__attribute((aligned(128)));
int bar[512] 		__attribute((aligned(128)));
int foobar[1024] 	__attribute((aligned(128)));

/* this is the spe program handle structure */
extern spe_program_handle_t spu_foobar;

int main() {
speid_t speid;
int i, status;

  /* initialize the memory objects */
  for (i=0; i<512; i++) {
    foo[i] = i;
    bar[i] = 511-i;
  }

  /* start the SPE thread */
  speid = spe_create_thread (0, &spu_foobar, 0, NULL, -1, 0);

  if (speid == NULL) {
    fprintf (stderr, "FAILED: spe_create_thread(num=%d, errno=%d)\n", 0, errno);
    return (1);
  }

  /* wait for the single SPE to complete */
  spe_wait(speid, &status, 0);

  for (i=0; i<512; i++) {
    if ((foobar[2*i] != foo[i]) ||
	(foobar[2*i+1] != bar[i]))
	goto fail;
  }
  fprintf(stderr, "Pass\n");
  return 0;

fail:
  fprintf(stderr, "Failed at %d: %d:%d %d:%d\n", i, 
	foobar[2*i], foo[i],
	foobar[2*i+1], bar[i]);
  return 1;
}
