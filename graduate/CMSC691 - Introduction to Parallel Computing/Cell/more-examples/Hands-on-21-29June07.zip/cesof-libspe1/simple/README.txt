%% --------------------------------------------------------------  
%% (C)Copyright 2001,2006,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              
Target:
	Linux or System Simulator

Description:
	This directory contains a sample program demonstrating the use of CESOF support

Notes:
	PPU program defines the objects, 3 arrays, in the main memory - foo, bar, and foobar.
	Through the use of CESOF support by the toolchain and libspe runtime environment,
	the addresses of these main memory objects may be resolved into the SPU runtime and 
	use as the target or source of DMA operations.

	The SPU program transfers foo and bar into local store, interleaves their elements
	into the third local array - foobar. It then transfers local foobar back out to the 
	main memory.

	The PPU program verifies the result after SPU program terminates.
