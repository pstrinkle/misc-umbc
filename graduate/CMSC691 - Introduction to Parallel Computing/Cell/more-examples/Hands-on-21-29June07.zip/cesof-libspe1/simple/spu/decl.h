/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#define CESOF_TAG	27
#define UPDATE_LOCAL(s) {\
	mfc_get(_LOCAL_##s, _EAR_##s, sizeof(_LOCAL_##s), CESOF_TAG, 0, 0); \
	mfc_write_tag_mask(1<<CESOF_TAG);\
	mfc_read_tag_status_all();\
}

#define UPDATE_REMOTE(s) {\
	mfc_put(_LOCAL_##s, _EAR_##s, sizeof(_LOCAL_##s), CESOF_TAG, 0, 0); \
	mfc_write_tag_mask(1<<CESOF_TAG);\
	mfc_read_tag_status_all();\
}
