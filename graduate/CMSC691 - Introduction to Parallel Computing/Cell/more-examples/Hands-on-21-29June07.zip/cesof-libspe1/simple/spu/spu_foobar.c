/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>
#include <spu_mfcio.h>
#include "decl.h"

/* reference the memory objects in the effective address space 	*/
/* e.g.	for ea memory object "foo[512]"				*/
/* extern unsigned long long _EAR_foo;				*/
/* int _LOCAL_foo[512];						*/

/* EXTERN_EAR expands to the example above 			*/
#define EXTERN_EAR(sym, type, size) \
	extern unsigned long long _EAR_##sym; \
	type _LOCAL_##sym[size] __attribute((aligned(128)));

EXTERN_EAR(foo, int, 512);
EXTERN_EAR(bar, int, 512);
EXTERN_EAR(foobar, int, 1024);

int main (long long spuid __attribute__ ((__unused__)),
	  char** argp     __attribute__ ((__unused__)),
	  char** envp     __attribute__ ((__unused__)))
{
        int i;

	printf("%llx\n", _EAR_foo);
	printf("%llx\n", _EAR_bar);

                /* DMA the memory objects from system memory */
                UPDATE_LOCAL(foo);
                UPDATE_LOCAL(bar);

        /* local operation */
        for (i=0; i<512; i++) {
                _LOCAL_foobar[2*i] = _LOCAL_foo[i];
                _LOCAL_foobar[2*i+1] = _LOCAL_bar[i];
        }

	printf("%llx\n", _EAR_foobar);

                /* DMA the memroy object back to system memory */
                UPDATE_REMOTE(foobar);

	printf("Done!\n"); 
        return 0;
}
