#include <stdio.h>
#include <profile.h>

#define N 16

int mult1(float *in1, float *in2, float *out, int num);

float a[N+1] = { 1.1, 2.2, 4.4, 5.5,
	      6.6, 7.7, 8.8, 9.9,
	      2.2, 3.3, 3.3, 2.2,
	      5.5, 6.6, 6.6, 5.5,
	      7.7};

float b[N+1] = { 1.1, 2.2, 4.4, 5.5,
	      5.5, 6.6, 6.6, 5.5,
	      2.2, 3.3, 3.3, 2.2,
	      6.6, 7.7, 8.8, 9.9,
	      6.6};

float c[N+1];

int main()
{
	int num = N;
	int i;

	prof_clear();
	prof_start();
	mult1(a, b, c, num);
	prof_stop();

	for (i=0;i<N;i+=4)
		printf("%.2f %.2f %.2f %.2f\n", c[i], c[i+1], c[i+2], c[i+3]);
	
	return 0;
}

