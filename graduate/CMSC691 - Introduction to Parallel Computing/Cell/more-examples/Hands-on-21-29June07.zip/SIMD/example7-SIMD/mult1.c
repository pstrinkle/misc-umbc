#include <stdio.h>

int mult1(float *in1, float *in2, float *out, int N)
{
	int i;

	int j = N%4;

	vector float *a = (vector float *) in1;
	vector float *b = (vector float *) in2;
	vector float *c = (vector float *) out;	

	int Nv = (N-j)/4;

	for (i=0;i<Nv;i++)
	{
		c[i] = spu_mul(a[i], b[i]);
	}

	for (i=Nv;i<N;i++)
	{
		out[i] = in1[i] * in2[i];
	}
	return 0;
}
