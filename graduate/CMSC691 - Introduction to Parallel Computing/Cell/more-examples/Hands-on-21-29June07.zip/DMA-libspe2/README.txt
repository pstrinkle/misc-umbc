%% --------------------------------------------------------------  
%% (C)Copyright 2001,2006,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              
Target:
        CBE-Linux (HW or simulator)

Description:
	This directory contains a sample program demonstrating some non-trivial
        DMA calls within the SPEs.

Notes:
	The actual executable resides in the ppu subdirectory.  It's called 
	'dma_sample'. It's a full CBE executable, with both PPE and SPE code.

        The job of this program is to get the SPEs to increment every element 
        of a pre-loaded large array, such that array[i] = i+1;
        
        Here's what happens when you run "dma_sample":

        * You specify the size of the large array, in elements, as a runtime
          parameter (actually, the log of the number of elements).
          Permitted range for this log is 19 <= log(#elements) <= 24.

        * The PPE assigns a[i] = i for every element of the large array.

        * The PPE then fires up all eight SPEs, pointing them at specific sections 
          of the big array. 

        * The SPEs each use four different DMA styles to load pieces of their sections, 
          increment them, and write them back to main memory.
          The four styles are:
           a) single-buffered DMA
           b) double-buffered DMA
           c) single-buffered DMA List
           d) double-buffered DMA List

        * The PPE checks these results, and prints whether any errors were found.
