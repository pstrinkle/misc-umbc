/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include "../dma_sample.h"
#include <spu_mfcio.h>
#include <stdio.h>

/* here we define the data buffer in local memory, to hold the data we DMA in. */
/* We will DMA in 4096 elements at a time, as that's the largest size which    */
/* fits in a standard DMA (16,384 bytes).                                      */
/* Since we're sometimes going to be double-buffering, we'll allocate 8192.    */
int databuffer[8192] __attribute__ ((aligned (128)));

/* Here we define the pointers which will point at the upper and lower parts   */
/* of this data buffer.                                                        */
int *data[2];

/* here we define buffers to hold DMA List data */
/* there are four buffers to allow us to multi-buffer more effectively */
volatile unsigned int dma_list[4][256];

/* this variable tells us how many DMA cycles each task must perform */
int loopcount;

/* control structure */
control_block cb __attribute__ ((aligned (128)));

/* the next two macros do the same thing, except using lists */

/* for each DMA List task, it's necessary to compute the addresses of */
/* each piece of address to read in.  Here are three different macros */
/* which all do the same thing.  They load the DMA List buffer.       */
/* The first macro is scalar.                                         */
/* The second macro is converted to SIMD code.                        */
/* The third macro is like the second, but hand-unrolled.             */
/* This sample ships using the third macro, but the user can re-code  */
/* the sample to use any of these three.                              */

/* DMA Lists allow you to gather data from arbitrary locations in     */
/* main memory.  This sample simply demonstrates the use of DMA Lists */
/* in gathering sequential cache lines of 128 bytes each.  This is    */
/* a somewhat silly use of the DMA List, as the memory could have     */
/* been collected with a standard DMA call (without a list), but we   */
/* show the code here to help the user understand how DMA Lists work. */

/* The list itself is a sequence of 4-byte words, each pair of which  */
/* specifies a length in bytes, and an address in main memory.        */
/* Since this sample is specifying exactly one cache line for each    */
/* element of the DMA list, the lengths will always be 128.           */

#define FILL_DMA_LIST(_base, _list_addr, _offset) {                     \
  int _k;                                                               \
  for (_k=0; _k<128; ++_k) {                                            \
    _list_addr[2*_k]   = 128;                                           \
    _list_addr[2*_k+1] = _base + _offset * 16384 + 128 * _k;            \
  }                                                                     \
}

#define FILL_DMA_LIST_SIMD(_base, _list_addr, _offset) {                \
  unsigned int _b, _k;                                                  \
  vector unsigned int length = (vector unsigned int) {128, 0, 128, 0};	\
  vector unsigned int addend = (vector unsigned int) {0, 256, 0, 256};  \
  vector unsigned int *p, w;                                            \
  _b = _base + _offset * 16384;                                         \
  p = (vector unsigned int *) _list_addr;                               \
  w = spu_insert(_b,     length, 1);                                    \
  w = spu_insert(_b+128, w, 3);                                         \
  for (_k=0; _k<64; ++_k) {                                             \
    p[_k] = w;                                                          \
    w = spu_add(w, addend);                                             \
  }                                                                     \
}

#define FILL_DMA_LIST_SIMD_UNROLLED(_base, _list_addr, _offset) {       \
  unsigned int _b, _k;                                                  \
  vector unsigned int length = (vector unsigned int) {128, 0, 128, 0};  \
  vector unsigned int addend = (vector unsigned int) {0, 256, 0, 256};  \
  vector unsigned int *_p, w0, w1, w2, w3;                              \
  _b = _base + _offset * 16384;                                         \
  _p = (vector unsigned int *) _list_addr;                              \
  w0 = spu_insert(_b,     length, 1);                                   \
  w0 = spu_insert(_b+128, w0, 3);                                       \
  w1 = spu_add(w0, addend);                                             \
  w2 = spu_add(w1, addend);                                             \
  w3 = spu_add(w2, addend);                                             \
  addend = spu_add(addend, addend);                                     \
  addend = spu_add(addend, addend);                                     \
  for (_k=0; _k<64; _k+=4) {                                            \
    _p[0] = w0;                                                         \
    _p[1] = w1;                                                         \
    _p[2] = w2;                                                         \
    _p[3] = w3;                                                         \
    w0 = spu_add(w0, addend);                                           \
    w1 = spu_add(w1, addend);                                           \
    _p+=4;                                                              \
    w2 = spu_add(w2, addend);                                           \
    w3 = spu_add(w3, addend);                                           \
  }                                                                     \
}

/* here are two versions of the code that actually does the incrementing */
/* of the data we have read in.  There are two versions, the first is    */
/* scalar, and the second is SIMD.                                       */

void load_data(int *dest) { int i;
  for (i=0; i<4096; ++i) {
    ++dest[i];
  }
}

void load_data_SIMD(int *dest) {
  int i;
  vector unsigned int *vdest;
  vector unsigned int v1 = (vector unsigned int) {1, 1, 1, 1};
  vdest = (vector unsigned int *) dest;
  for (i=0; i<1024; ++i) {
    vdest[i] = spu_add(vdest[i], v1);
  }
}

/* Here we have the four DMA task modules. */
/* Each of them processes the data in the assigned regions in 16 kbyte chunks */

void load_singlebuffer(unsigned int addr)
{
  int i;
  for (i=0; i<loopcount; ++i) {
    mfc_get(data[0], addr+16384*i, 16384, 20, 0, 0);
    mfc_write_tag_mask(1<<20);
    mfc_read_tag_status_all();
    load_data_SIMD(data[0]);
    mfc_put(data[0], addr+16384*i, 16384, 20, 0, 0);
    mfc_write_tag_mask(1<<20);
    mfc_read_tag_status_all();
  }
}

void load_doublebuffer(unsigned int addr)
{
  int i;
  mfc_get(data[0], addr, 16384, 20, 0, 0);
  for (i=1; i<loopcount; ++i) {
    mfc_write_tag_mask(1<<(20+(i&1)));
    mfc_read_tag_status_all();
    mfc_get(data[i&1], addr+16384*i, 16384, 20+(i&1), 0, 0);
    mfc_write_tag_mask(1<<(21-(i&1)));
    mfc_read_tag_status_all();
    load_data_SIMD(data[(i-1)&1]);
    mfc_put(data[(i-1)&1], addr+16384*(i-1), 16384, 21-(i&1), 0, 0);
  }
  mfc_write_tag_mask(1<<21);
  mfc_read_tag_status_all();
  load_data_SIMD(data[1]);
  mfc_put(data[1], addr+16384*(loopcount-1), 16384, 21, 0, 0);
  mfc_write_tag_mask((1<<20)|(1<<21));
  mfc_read_tag_status_all();
}

void load_singlebuffer_list(unsigned int addr)
{
  int  i;
  for (i=0; i<loopcount; ++i) {
    FILL_DMA_LIST_SIMD_UNROLLED(addr, dma_list[0], i)
    mfc_getl(data[0], 0, dma_list[0], 1024, 20, 0, 0);
    mfc_write_tag_mask(1<<20);
    mfc_read_tag_status_all();
    load_data_SIMD(data[0]);
    mfc_putl(data[0], 0, dma_list[0], 1024, 20, 0, 0);
    mfc_write_tag_mask(1<<20);
    mfc_read_tag_status_all();
  }
}

void load_doublebuffer_list(unsigned int addr)
{
  int  i;
  FILL_DMA_LIST_SIMD_UNROLLED(addr, dma_list[0], 0)
  mfc_getl(data[0], 0, dma_list[0], 1024, 20, 0, 0);
  for (i=1; i<loopcount; ++i) {
    mfc_write_tag_mask(1<<(20+((i+2)&3)));
    mfc_read_tag_status_all();
    FILL_DMA_LIST_SIMD_UNROLLED(addr, dma_list[i&3], i)
    mfc_getl(data[i&1], 0, dma_list[i&3], 1024, 20+(i&3), 0, 0);
    mfc_write_tag_mask(1<<(20+((i-1)&3)));
    mfc_read_tag_status_all();
    load_data_SIMD(data[(i-1)&1]);
    mfc_putl(data[(i-1)&1], 0, dma_list[(i-1)&3], 1024, 20+((i-1)&3), 0, 0);
  }
  mfc_write_tag_mask(1<<23);
  mfc_read_tag_status_all();
  load_data_SIMD(data[1]);
  mfc_putl(data[1], 0, dma_list[3], 1024, 23, 0, 0);
  mfc_write_tag_mask((1<<20)|(1<<21)|(1<<22)|(1<<23));
  mfc_read_tag_status_all();
}

/* here is the location where the SPE begins execution, once its thread is created */
int main(unsigned long long speid, addr64 argp, addr64 envp) {

  /* DMA control block information from system memory. */
  mfc_get(&cb, argp.ui[1], sizeof(cb), 31, 0, 0);
  mfc_write_tag_mask(1<<31);
  mfc_read_tag_status_all();

printf("addrs = %x %x %x %x\n", cb.addrSB, cb.addrDB, cb.addrSBL, cb.addrDBL);

  /* compute how many DMA cycles will be needed by each task */
  loopcount = cb.chunk_size >> 14;

  /* load the pointers so the point to the right part of the local store buffer */
  data[0] = &databuffer[0];
  data[1] = &databuffer[4096];

  /* run the four tasks, indicating which portion of memory they should work with */
  load_singlebuffer     (cb.addrSB);
  load_doublebuffer     (cb.addrDB);
  load_singlebuffer_list(cb.addrSBL);
  load_doublebuffer_list(cb.addrDBL);

  return 0;
}
