%% --------------------------------------------------------------  
%% (C)Copyright 2001,2006,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary: Simple tutorial example

Target: Linux

Description:

	This simple example creates 8 identical SPE threads that 
	in turn print a message to stdout and then terminate. The 
	SPE thread program (spu/simple_spu.c) is embedded into a 
	PPE executable. 

How to run:

	Invoke the PPE executable at the Linux command prompt:

	       simple

Notes:



