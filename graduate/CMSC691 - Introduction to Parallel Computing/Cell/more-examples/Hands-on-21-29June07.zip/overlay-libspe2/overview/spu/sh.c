/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sh(int p)
{
	printf("\t\t\tsh prints %d\n", p);
	
	printf("\t\t\tsh returns %d\n", 'h');
	return 'h';
}
