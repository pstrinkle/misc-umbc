/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int
main (unsigned long long spuid __attribute__ ((__unused__)),
      unsigned long long argp  __attribute__ ((__unused__)),
      unsigned long long envp  __attribute__ ((__unused__)))
{
  int rc;

  rc = sa(97); // r=0, s=0, f='a'
  TEST("main",'a', rc);
		
  printf("main returns %d\n", 0);
  return 0;
}
