/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>

extern int sa(int);
extern int sb(int);
extern int sc(int);
extern int sd(int);
extern int se(int);
extern int sf(int);
extern int sg(int);
extern int sh(int);
extern int si(int);

#define TEST(f, x, y)							\
  if ((x) != (y)) {							\
    printf("%s expected %d, got %d, failed!\n", f, x, y);		\
    printf("%s returns %d\n", f, 1);					\
    return (1);								\
  } else {								\
    printf("%s expected %d, got %d, succeeded!\n", f, x, y);		\
  }

#endif /*MAIN_H_*/
