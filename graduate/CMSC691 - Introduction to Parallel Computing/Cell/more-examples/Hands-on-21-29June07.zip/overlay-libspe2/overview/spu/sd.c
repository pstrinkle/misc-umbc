/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sd(int p)
{
	int rc;
	
	printf("\t\tsd prints %d\n", p);
	
	rc = se(200200101); // r=2, s=2, f='e'
	TEST("\t\tsd",'e',rc);
	
	printf("\t\tsd returns %d\n", 'd');
	return 'd';
}
