/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sc(int p)
{
	int rc;
	
	printf("\tsc prints %d\n", p);
	
	rc = sd(200200100); // r=2, s=2, f='d'
	TEST("\tsc",'d',rc);
	
	rc = sf(200300102); // r=2, s=3, f='f'
	TEST("\tsc",'f',rc);
	
	printf("\tsc returns %d\n", 'c');
	return 'c';
}
