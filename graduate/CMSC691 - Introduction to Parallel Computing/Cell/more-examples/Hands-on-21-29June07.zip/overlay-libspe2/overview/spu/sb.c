/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sb(int p)
{
	int rc;
	
	printf("sb prints %d\n", p);
	
	rc = sc(100100099); // r=1, s=1, f='c'
	TEST("sb",'c',rc);
	
	rc = sg(100400103); // r=1, s=4, f='g'
	TEST("sb",'g',rc);
	
	printf("sb returns %d\n", 'b');
	return 'b';
}
