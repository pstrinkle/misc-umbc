/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int se(int p)
{
	printf("\t\tse prints %d\n", p);
	
	printf("\t\tse returns %d\n", 'e');
	return 'e';
}
