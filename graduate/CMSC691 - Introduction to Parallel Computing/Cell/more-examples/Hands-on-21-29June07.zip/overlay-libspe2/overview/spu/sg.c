/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sg(int p)
{
	int rc;
	
	printf("\tsg prints %d\n", p);
	
	rc = sh(300500104); // r=3, s=5, f='h'
	TEST("\tsg",'h',rc);
	
	rc = si(300600105); // r=3, s=6, f='i'
	TEST("\tsg",'i',rc);
	
	printf("\tsg returns %d\n", 'g');
	return 'g';
}
