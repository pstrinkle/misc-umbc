/* --------------------------------------------------------------- */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sa(int p)
{
	int rc;
	
	printf("sa prints %d\n", p);
	
	rc = sb(98); // r=0, s=0, f='b'
	TEST("sa",'b',rc);
	
	printf("sa returns %d\n", 'a');
	return 'a';
}
