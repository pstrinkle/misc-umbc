/* --------------------------------------------------------------- */
/* (C)Copyright 2006                                               */
/* International Business Machines Corporation,                    */
/* All Rights Reserved.                                            */
/*                                                                 */
/* This program is made available under the terms of the           */
/* Common Public License v1.0 which accompanies this distribution. */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>

int o1_test1(int p)
{
	printf("o1_test1 prints %d\n", p);
	return 1;
}

int o1_test2(int p)
{
	printf("o1_test2 prints %d\n", p);
	return 2;
}
