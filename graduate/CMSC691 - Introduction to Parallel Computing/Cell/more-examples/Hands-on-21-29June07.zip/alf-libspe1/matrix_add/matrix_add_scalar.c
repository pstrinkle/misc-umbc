#include <stdio.h>
#include <stdlib.h>

#define NUM_ROW		1024
#define NUM_COL		512

/* 
 * Initial scalar implementation of a matrix add. 
 */


float mat_a[NUM_ROW][NUM_COL];
float mat_b[NUM_ROW][NUM_COL];
float mat_c[NUM_ROW][NUM_COL];

void init_mat ()
{
  int i, j;

  for (i = 0; i < NUM_ROW; i++)
  {
    for (j = 0; j < NUM_COL; j++)
    {
      mat_a[i][j] = (float)(i * NUM_COL + j);
      mat_b[i][j] = (float)((i * NUM_COL + j)*2);
      mat_c[i][j] = 0.0f;      
    }

  }

}

int main(void)
{
  int i,j;

  init_mat();

  /* compute */
   for (i=0; i<NUM_ROW; i++)
       for (j=0; j<NUM_COL; j++)
           mat_c[i][j] = mat_a[i][j] + mat_b[i][j];

   printf ("Matrix Addition completes\n");

   /* verifying */
   for (i = 0; i < NUM_ROW; i++)
   {
     for (j = 0; j < NUM_COL; j++)
     {
       if (mat_c[i][j] != (float)((i * NUM_COL + j)*3))
       {
	 printf ("ERROR in matrix addition\n");
       } 

     }
   }

   return 0;
}

