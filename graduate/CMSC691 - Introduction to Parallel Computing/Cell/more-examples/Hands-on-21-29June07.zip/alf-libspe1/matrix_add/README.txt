%% --------------------------------------------------------------  
%% (C)Copyright 2001,2006,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary: ALF Tutorial Example - Matrix Add

Target: Linux

Description:

	This directory contains a sample code to demonstrate how to program 
    with ALF(Accelerated Library Framework) API. By adding two 1024x512 
    single precision float point matrix, the sample code demostrate how 
    a simplified scalar function can be ported and accellerated for 
    parallel execution on ALF. Development will follow the steps:

	STEP 1 - Choose Data Partition Scheme for Parallel Speedup
	STEP 2 - Turn the computing kernel on SPE with SIMD intrinsics.


	The initial scalar code (see matrix_add_scalar.c) is built (matrix_add_scalar)
	and located in this directory. Each of the following steps are located in
	the subdirectories:

	    subdirectory		executable
	    -------------------		-------------------
	    STEP1a_partition_scheme_A	matrix_add_1a
	    STEP1a_partition_scheme_A	matrix_add_1b
	    STEP2_turned		matrix_add_turned

	All the executables containing SPE code are built such that the SPE
	programs are embedded into the PPE executable.

How to run:

	Invoke any executable at the Linux command prompt. For example:

	    matrix_add_turned

Notes:

	Additional information can be found within the source code.
