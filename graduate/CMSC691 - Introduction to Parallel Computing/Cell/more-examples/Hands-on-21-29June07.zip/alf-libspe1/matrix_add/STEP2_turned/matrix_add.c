#include <stdio.h>
#include <stdlib.h>
#include <alf.h>
#include "matrix_add.h"

#define NUM_ROW 1024
#define NUM_COL 512

#define  H  32
#define  V  NUM_COL

#define MY_ALIGN(_my_var_def_, _my_al_)  _my_var_def_  \
__attribute__((__aligned__(_my_al_)))

extern spe_program_handle_t  matrix_add_spu;

MY_ALIGN(float mat_a[NUM_ROW][NUM_COL], 128);
MY_ALIGN(float mat_b[NUM_ROW][NUM_COL], 128);
MY_ALIGN(float mat_c[NUM_ROW][NUM_COL], 128);

void init_mat ()
{
  int i, j;

  for (i = 0; i < NUM_ROW; i++)
  {
    for (j = 0; j < NUM_COL; j++)
    {
      mat_a[i][j] = (float)(i * NUM_COL + j);
      mat_b[i][j] = (float)((i * NUM_COL + j)*2);
      mat_c[i][j] = 0.0f;      
    }

  }
}

   
int main(void)
{
    alf_handle_t  half;
    alf_task_handle_t htask;
    alf_wb_handle_t     hwb;
    alf_task_info_t tinfo;
    alf_task_info_t_CBEA spe_tsk;
    add_parms_t parm;
    int  i,j, rc;
    unsigned int nodes;
   
    init_mat(); 
    alf_configure(NULL);
    
    rc = alf_query_system_info(ALF_INFO_NUM_ACCL_NODES, &nodes); 
    if (rc < 0)
    {
        fprintf(stderr, "Failed to call alf_query_system_info.\n");
        return 1;
    }
    else if( nodes <= 0 )
    {
        fprintf(stderr, "Cannot allocate spe to use.\n");
        return 1;
    }

    rc = alf_init(&half, nodes, ALF_INIT_PERSIST); 
    if( rc <= 0)
    {
        fprintf(stderr, "Cannot init ALF libary(%d).\n", rc);
        return rc;
    };

    spe_tsk.spe_task_image = &matrix_add_spu;
    spe_tsk.max_stack_size = 4096;

    tinfo.p_task_info = &spe_tsk;
    tinfo.parm_ctx_buffer_size = sizeof(add_parms_t);
    tinfo.input_buffer_size = H*V*2*sizeof(float); //128k
    tinfo.output_buffer_size = H*V*sizeof(float);  // 64k
    tinfo.dt_list_entries = 3;
    tinfo.partition_location = ALF_PARTITION_ON_CONTROL_NODE;

    rc = alf_task_create(&htask, half, &tinfo); 
    if( rc < 0)
    {
        fprintf(stderr, "Cannot create ALF task(%d).\n", rc);
        alf_exit(&half, ALF_SHUTDOWN_FORCE);
        return 1;
    };

    parm.h=H;
    parm.v=V;

    for(i=0; i<NUM_ROW; i+=H)
    {
        alf_wb_create (&hwb, htask, ALF_WB_SINGLE_CALL, 1);

        alf_wb_add_param (hwb, &parm, sizeof(parm), 
                ALF_DATA_BYTE, 0);
        alf_wb_add_io_buffer (hwb, ALF_BUFFER_INPUT,
                &mat_a[i][0], H*V, ALF_DATA_FLOAT); 
        alf_wb_add_io_buffer (hwb, ALF_BUFFER_INPUT,
                &mat_b[i][0], H*V, ALF_DATA_FLOAT); 
        alf_wb_add_io_buffer (hwb, ALF_BUFFER_OUTPUT,
                &mat_c[i][0], H*V, ALF_DATA_FLOAT); 

        alf_wb_enqueue(hwb);
    }

    (void)alf_task_wait(&htask, -1);
    (void)alf_exit(&half, ALF_SHUTDOWN_WAIT);
   printf ("Matrix Addition completes. Verifying results...\n");

   /* verifying */
   for (i = 0; i < NUM_ROW; i++)
   {
     for (j = 0; j < NUM_COL; j++)
     {
       if (mat_c[i][j] != (float)((i * NUM_COL + j)*3))
       {
	 printf ("ERROR in matrix addition\n");
       } 

     }
   }

   printf ("All done!\n");

    return 0;
}
 
