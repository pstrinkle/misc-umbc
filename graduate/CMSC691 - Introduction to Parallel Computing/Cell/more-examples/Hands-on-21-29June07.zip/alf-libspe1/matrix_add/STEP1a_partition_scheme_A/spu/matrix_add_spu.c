#include <alf_accel.h> 
#include "../matrix_add.h"

int alf_comp_kernel(volatile void *p_parm_ctx_buffer, 
                    volatile void *p_input_buffer,  
                    volatile void *p_output_buffer, 
                    unsigned int current_count,
                    unsigned int total_count )

{
    unsigned int i, cnt;
    float *sa, *sb, *sc;
    add_parms_t *p_parm = (add_parms_t *)p_parm_ctx_buffer;


    cnt = p_parm->h * p_parm->v;
    sa = (float *) p_input_buffer;
    sb = sa + cnt;
    sc = (float *) p_output_buffer;

    for(i=0; i<cnt; i++)
      sc[i] = sa[i] + sb[i]; 

    return 0;
}
