#ifndef __matrix_trans_h__
#define __matrix_trans_h__

typedef struct _trans_parms_t
{
    unsigned int h;
    unsigned int v;
    unsigned int DIMX, DIMY;
    unsigned int X, Y;
    float *p_mat_a, *p_mat_c;
} trans_parms_t;
 
#endif /* __matrix_trans_h__ */
