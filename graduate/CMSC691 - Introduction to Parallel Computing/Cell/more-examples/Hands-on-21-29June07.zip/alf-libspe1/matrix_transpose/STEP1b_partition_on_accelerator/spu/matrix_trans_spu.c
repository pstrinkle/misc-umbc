#include <alf_accel.h> 
#include "../matrix_trans.h"


int alf_comp_kernel(volatile void *p_parm_ctx_buffer, 
                    volatile void *p_input_buffer,  
                    volatile void *p_output_buffer, 
                    unsigned int current_count,
                    unsigned int total_count )

{
    unsigned int i, j;
    float *sa, *sc;
    trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;

    sa = (float *) p_input_buffer;
    sc = (float *) p_output_buffer;

    for(i=0; i< p_parm->h; i++)
      for(j=0; j< p_parm->v; j++)
          *(sc+j*p_parm->h + i)      /* sc[j][i] */
          = *(sa+i*p_parm->v +j);    /* sa[i][j] */

    return 0;
}


int  alf_prepare_input_list(void *p_parm_ctx_buffer,  
       void *p_dt_list_buffer, unsigned int current_count,
       unsigned int total_count)
{
     trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;
     float *pA;
     unsigned int i;
     addr64  ea;
     
     pA = p_parm->p_mat_a + 
           p_parm->DIMY*p_parm->X + p_parm->Y; // mat_a[X][Y]
     
     ALF_DT_LIST_INIT(p_dt_list_buffer);

     ea.ui[0] = 0;
     for(i=0; i<p_parm->h; i++)
     {
        ea.ui[1] = (unsigned int)(pA + p_parm->DIMY*i); // mat_a[X+i][Y]
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 
                              p_parm->v, 
                              ALF_DATA_FLOAT,
                              ea); 
     }
     
     return 0;
}


int  alf_prepare_output_list(void *p_parm_ctx_buffer,  
       void *p_dt_list_buffer, unsigned int current_count,
       unsigned int total_count)
{
     trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;
     float *pC;
     unsigned int j;
     addr64  ea;
     
     pC = p_parm->p_mat_c + 
            p_parm->DIMX*p_parm->Y + p_parm->X; // mat_c[Y][X]

     ALF_DT_LIST_INIT(p_dt_list_buffer);
     
     ea.ui[0] = 0;
     for(j=0; j<p_parm->v; j++)
     {
        ea.ui[1] = (unsigned int)(pC + p_parm->DIMX*j); // mat_c[Y+j][X]
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 
                              p_parm->h, 
                              ALF_DATA_FLOAT,
                              ea); 

     }
     
     return 0;
}

