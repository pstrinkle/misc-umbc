#ifndef __matrix_trans_h__
#define __matrix_trans_h__

typedef struct _trans_parms_t
{
    unsigned int h;
    unsigned int v;
} trans_parms_t;
 
#endif /* __matrix_trans_h__ */
