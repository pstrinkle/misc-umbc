#include <alf_accel.h> 
#include "../matrix_trans.h"


int alf_comp_kernel(volatile void *p_parm_ctx_buffer, 
                    volatile void *p_input_buffer,  
                    volatile void *p_output_buffer, 
                    unsigned int current_count,
                    unsigned int total_count )

{
    unsigned int i, j;
    float *sa, *sc;
    trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;

    sa = (float *) p_input_buffer;
    sc = (float *) p_output_buffer;

    for(i=0; i< p_parm->h; i++)
      for(j=0; j< p_parm->v; j++)
          *(sc+j*p_parm->h + i)      /* sc[j][i] */
          = *(sa+i*p_parm->v +j);    /* sa[i][j] */

    return 0;
}
