#include <stdio.h>
#include <stdlib.h>

#define NUM_ROW		1024
#define NUM_COL		512
/* 
 * Initial scalar implementation of a matrix transpose. 
 */

float mat_a[NUM_ROW][NUM_COL];
float mat_c[NUM_COL][NUM_ROW];

void init_mat()
{
  int i, j;

  for (i = 0; i < NUM_COL; i++)
  {
    for (j = 0; j < NUM_ROW; j++)
    {
      mat_a[j][i] = j*NUM_COL + i; 
      mat_c[i][j] = 0.0f;
    }
  }
}


int main(void)
{
  int i,j;

  init_mat();

   for (i=0; i<NUM_COL; i++)
       for (j=0; j<NUM_ROW; j++)
           mat_c[i][j] = mat_a[j][i];

   printf ("All done !\n");

   return 0;
}

