#include <stdio.h>
#include <stdlib.h>
#include <alf.h>
#include "matrix_trans.h"

#define NUM_ROW		1024
#define NUM_COL		512


#define  H  128
#define  V  128

#define MY_ALIGN(_my_var_def_, _my_al_)  _my_var_def_  \
__attribute__((__aligned__(_my_al_)))

extern spe_program_handle_t  matrix_trans_spu;

MY_ALIGN(float mat_a[NUM_ROW][NUM_COL], 128);
MY_ALIGN(float mat_c[NUM_COL][NUM_ROW], 128);

void init_mat()
{
  int i, j;

  for (i = 0; i < NUM_COL; i++)
  {
    for (j = 0; j < NUM_ROW; j++)
    {
      mat_a[j][i] = j*NUM_COL + i; 
      mat_c[i][j] = 0.0f;
    }
  }
}



int main(void)
{
    alf_handle_t  half;
    alf_task_handle_t htask;
    alf_wb_handle_t     hwb;
    alf_task_info_t tinfo;
    alf_task_info_t_CBEA spe_tsk;
    trans_parms_t parm;
    int  X, Y, i, j, rc;
    unsigned int nodes;
    

    alf_configure(NULL);
    
    rc = alf_query_system_info(ALF_INFO_NUM_ACCL_NODES, &nodes); 
    if (rc < 0)
    {
        fprintf(stderr, "Failed to call alf_query_system_info.\n");
        return 1;
    }
    else if( nodes <= 0 )
    {
        fprintf(stderr, "Cannot allocate spe to use.\n");
        return 1;
    }

    rc = alf_init(&half, nodes, ALF_INIT_PERSIST); 
    if( rc <= 0)
    {
        fprintf(stderr, "Cannot init ALF libary(%d).\n", rc);
        return rc;
    };

    spe_tsk.spe_task_image = &matrix_trans_spu;
    spe_tsk.max_stack_size = 4096;

    tinfo.p_task_info = &spe_tsk;

    tinfo.parm_ctx_buffer_size = sizeof(trans_parms_t);
    tinfo.input_buffer_size = H*V*sizeof(float); //64k
    tinfo.output_buffer_size = H*V*sizeof(float);  // 64k
    tinfo.dt_list_entries = H;
    tinfo.partition_location =
               ALF_PARTITION_ON_ACCELERATOR;

    rc = alf_task_create(&htask, half, &tinfo); 
    if( rc < 0)
    {
        fprintf(stderr, "Cannot create ALF task(%d).\n", rc);
        alf_exit(&half, ALF_SHUTDOWN_FORCE);
        return 1;
    };

    parm.h=H;
    parm.v=V;

    parm.DIMX = NUM_ROW;
    parm.DIMY = NUM_COL;
    parm.p_mat_a = &mat_a[0][0];
    parm.p_mat_c = &mat_c[0][0];
    
    for(X=0; X<NUM_ROW; X+=H)
      for(Y=0; Y<NUM_COL; Y+=V)
      {
        parm.X = X;
        parm.Y = Y;
        alf_wb_create (&hwb, htask, ALF_WB_SINGLE_CALL, 1);
        alf_wb_add_param (hwb, &parm, sizeof(parm), 
                  ALF_DATA_BYTE, 0);

         alf_wb_enqueue(hwb);
       }

    (void)alf_task_wait(&htask, -1);
    (void)alf_exit(&half, ALF_SHUTDOWN_WAIT);

    printf ("Finished tranposing matrix. Verifying...\n");

    //verifying
    for (i=0; i<NUM_COL; i++)
       for (j=0; j<NUM_ROW; j++)
       {
	 if (mat_c[i][j] != mat_a[j][i])
	 {
	   fprintf (stderr, "ERROR from matrix transpose - Exit\n");
	   fflush (stderr);
	   exit (1);
	 }
       }
    printf ("All done!\n");

    
    return 0;
}
 
