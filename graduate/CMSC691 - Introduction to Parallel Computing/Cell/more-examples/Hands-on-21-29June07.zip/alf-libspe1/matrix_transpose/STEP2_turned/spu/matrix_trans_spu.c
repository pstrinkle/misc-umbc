#include <alf_accel.h> 
#include "../matrix_trans.h"


int alf_comp_kernel(volatile void *p_parm_ctx_buffer, 
                    volatile void *p_input_buffer,  
                    volatile void *p_output_buffer, 
                    unsigned int current_count,
                    unsigned int total_count )

{
    unsigned int i, j;
    float *sa, *sc;
    trans_parms_t *p_parms = (trans_parms_t *)p_parm_ctx_buffer;

    const vector unsigned char step1_pattern1 = 
      {0, 1, 2, 3, 16, 17, 18, 19, 4, 5, 6, 7, 20, 21, 22, 23};
    const vector unsigned char step1_pattern2 = 
      {8, 9, 10, 11, 24, 25, 26, 27, 12, 13, 14, 15, 28, 29, 30, 31};
    const vector unsigned char step2_pattern1 = 
      {0, 1, 2, 3, 4, 5, 6, 7, 16, 17, 18, 19, 20, 21, 22, 23};
    const vector unsigned char step2_pattern2 = 
      {8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31};
    
    vector float f1, f2, f3, f4;
    vector float tmp1, tmp2, tmp3, tmp4;


    sa = (float *) p_input_buffer;
    sc = (float *) p_output_buffer;

    for(i=0; i< p_parms->h; i+=4)
       for(j=0; j< p_parms->v; j+=4)
       {
          f1 = *(vector float *)(sa+(i  )*p_parms->v + j);
          f2 = *(vector float *)(sa+(i+1)*p_parms->v + j);
          f3 = *(vector float *)(sa+(i+2)*p_parms->v + j);
          f4 = *(vector float *)(sa+(i+3)*p_parms->v + j);

          tmp1 = spu_shuffle(f1, f2, step1_pattern1);
          tmp2 = spu_shuffle(f1, f2, step1_pattern2);
          tmp3 = spu_shuffle(f3, f4, step1_pattern1);
          tmp4 = spu_shuffle(f3, f4, step1_pattern2);
          
          f1 = spu_shuffle(tmp1, tmp3, step2_pattern1);
          f2 = spu_shuffle(tmp1, tmp3, step2_pattern2);
          f3 = spu_shuffle(tmp2, tmp4, step2_pattern1);
          f4 = spu_shuffle(tmp2, tmp4, step2_pattern2);
          
          *(vector float *)(sc+(j  )*p_parms->h + i) = f1;
          *(vector float *)(sc+(j+1)*p_parms->h + i) = f2;
          *(vector float *)(sc+(j+2)*p_parms->h + i) = f3;
          *(vector float *)(sc+(j+3)*p_parms->h + i) = f4;

}
    
    return 0;
}


int  alf_prepare_input_list(void *p_parm_ctx_buffer,  
       void *p_dt_list_buffer, unsigned int current_count,
       unsigned int total_count)
{
     trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;
     float *pA;
     unsigned int i;
     addr64  ea;
     
     pA = p_parm->p_mat_a + 
           p_parm->DIMY*p_parm->X + p_parm->Y; // mat_a[X][Y]
     
     ALF_DT_LIST_INIT(p_dt_list_buffer);

     ea.ui[0] = 0;
     for(i=0; i<p_parm->h; i++)
     {
        ea.ui[1] = (unsigned int)(pA + p_parm->DIMY*i); // mat_a[X+i][Y]
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 
                              p_parm->v, 
                              ALF_DATA_FLOAT,
                              ea); 
     }
     
     return 0;
}


int  alf_prepare_output_list(void *p_parm_ctx_buffer,  
       void *p_dt_list_buffer, unsigned int current_count,
       unsigned int total_count)
{
     trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;
     float *pC;
     unsigned int j;
     addr64  ea;
     
     pC = p_parm->p_mat_c + 
            p_parm->DIMX*p_parm->Y + p_parm->X; // mat_c[Y][X]

     ALF_DT_LIST_INIT(p_dt_list_buffer);
     
     ea.ui[0] = 0;
     for(j=0; j<p_parm->v; j++)
     {
        ea.ui[1] = (unsigned int)(pC + p_parm->DIMX*j); // mat_c[Y+j][X]
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 
                              p_parm->h, 
                              ALF_DATA_FLOAT,
                              ea); 

     }
     
     return 0;
}

