#include <stdio.h>
#include <spu_mfcio.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

void transfer_large_region(void *, unsigned int, unsigned int, unsigned int);

MY_ALIGN(float array_a[ARRAY_SIZE],128);
MY_ALIGN(float array_b[ARRAY_SIZE],128);
MY_ALIGN(float array_c[ARRAY_SIZE],128);
MY_ALIGN(control_block cb, 128);
MY_ALIGN(struct dma_list_elem list[16], 8);

#ifdef SDK2
        // SDK2 contains a bug when starting a SPE program with libspe2
        // The bug causes the argp and envp variables to be sent incorrectly
typedef union
{
  unsigned long long ull;
  unsigned int ui[2];
  void *p;
} myaddr64;
#endif

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp){

#ifdef SDK2
        // SDK2 contains a bug when starting a SPE program with libspe2
        // The bug causes the argp and envp variables to be sent incorrectly
        myaddr64 wrongargp;
        myaddr64 wrongenvp;
        myaddr64 myargp;
        myaddr64 myenvp;

        wrongargp.ull = argp;
        wrongenvp.ull = envp;
        myargp.ui[0] = wrongargp.ui[1];
        myargp.ui[1] = wrongargp.ui[0];
        myenvp.ui[0] = wrongenvp.ui[1];
        myenvp.ui[1] = wrongenvp.ui[0];
        argp = myargp.ull;
        envp = myenvp.ull;
#endif
	
	int i;

	/* First: DMA our control block into local store */
	mfc_get(&cb, argp, sizeof(cb), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();

	/*Now that we have the control block we can DMA our data arrays over */
	transfer_large_region((void *)&array_a, (unsigned int)cb.a, (sizeof(float)*cb.size), 1);
	transfer_large_region((void *)&array_b, (unsigned int)cb.b, (sizeof(float)*cb.size), 1);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	
	/*array add*/
	for(i=0; i<cb.size; i++)
	{
		array_c[i]=array_a[i]+array_b[i];
	}

	/* Finally, DMA computed array back to main memory*/
	transfer_large_region((void *)&array_c, (unsigned int)cb.c, (sizeof(float)*cb.size), 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	return 0;
}

void transfer_large_region(void *lsAddr, unsigned int ea_low, unsigned int nbytes, unsigned int get)
{
	unsigned int i = 0;
	unsigned int tagid = 0;
	unsigned int listsize;

	if (!nbytes)
		return;

	while (nbytes > 0)
	{
		unsigned int sz;

		sz = (nbytes < 16384) ? nbytes : 16384;
		list[i].size.all32 = sz;
		list[i].ea_low = ea_low;

		nbytes -= sz;
		ea_low += sz;
		i++;
	}

	listsize = i * sizeof(struct dma_list_elem);
	if (get)
	{
		mfc_getl((volatile *)lsAddr, list[0].ea_low, (unsigned int)&list[0], listsize, 31, 0, 0);
		mfc_write_tag_mask(1<<31);
		mfc_read_tag_status_all();
	}
	else
	{
		mfc_putl((volatile *)lsAddr, list[0].ea_low, (unsigned int)&list[0], listsize, 31, 0, 0);
		mfc_write_tag_mask(1<<31);
		mfc_read_tag_status_all();
	}
}
