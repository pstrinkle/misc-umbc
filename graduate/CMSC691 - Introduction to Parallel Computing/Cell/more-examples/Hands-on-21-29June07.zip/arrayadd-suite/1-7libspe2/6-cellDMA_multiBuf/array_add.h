#ifndef __array_add_h__
#define __array_add_h__

#define ARRAY_SIZE      5120
#define NUM             512
#define BUF_SIZE_BYTES	(256*4)
#define BUF_SIZE	(256)

// This define is used for aspects that are specific to SDK2.0
// Remove this define if running SDK2.1 and later.
#define SDK2

typedef struct _control_block
{
	unsigned int a;
	unsigned int b;
	unsigned int c;
	unsigned int size;
	unsigned char pad[112];
} control_block;

#endif
