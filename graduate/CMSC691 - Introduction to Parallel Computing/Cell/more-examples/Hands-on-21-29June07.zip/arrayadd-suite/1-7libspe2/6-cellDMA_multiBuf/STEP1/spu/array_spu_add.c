#include <stdio.h>
#include <spu_mfcio.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(control_block cb, 128);
MY_ALIGN(float dataBuf[BUF_SIZE * 6], 128);
float * aData[2];
float * bData[2];
float * cData[2];

#ifdef SDK2
        // SDK2 contains a bug when starting a SPE program with libspe2
        // The bug causes the argp and envp variables to be sent incorrectly
typedef union
{
  unsigned long long ull;
  unsigned int ui[2];
  void *p;
} myaddr64;
#endif

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp){

#ifdef SDK2
        // SDK2 contains a bug when starting a SPE program with libspe2
        // The bug causes the argp and envp variables to be sent incorrectly
        myaddr64 wrongargp;
        myaddr64 wrongenvp;
        myaddr64 myargp;
        myaddr64 myenvp;

        wrongargp.ull = argp;
        wrongenvp.ull = envp;
        myargp.ui[0] = wrongargp.ui[1];
        myargp.ui[1] = wrongargp.ui[0];
        myenvp.ui[0] = wrongenvp.ui[1];
        myenvp.ui[1] = wrongenvp.ui[0];
        argp = myargp.ull;
        envp = myenvp.ull;
#endif
	
	int i, j,size;
	unsigned int src_tag, dest_tag, src_mask, dest_mask;
	float *aSrcPtr, *aLocalPtr;
	float *bSrcPtr, *bLocalPtr;
	float *cSrcPtr, *cLocalPtr;

	/* Setup data buffers */
	aData[0] = dataBuf; aData[1] = dataBuf + BUF_SIZE; 
	bData[0] = dataBuf + BUF_SIZE*2; bData[1] = dataBuf + BUF_SIZE*3;
	cData[0] = dataBuf + BUF_SIZE*4; cData[1] = dataBuf + BUF_SIZE*5;

	/* setup src DMAs to use tag 31, dest DMAs to use tag 30*/
	src_tag = 31; src_mask = 1<<src_tag;
	dest_tag = 30; dest_mask = 1<<dest_tag;

	/* First: DMA our control block into local store */
	mfc_get(&cb, argp, sizeof(cb), src_tag, 0, 0);
	mfc_write_tag_mask(src_mask);
	mfc_read_tag_status_all();

	/* obtain information from control block */
	size = cb.size/BUF_SIZE;
	aSrcPtr = (float *)cb.a;
	bSrcPtr = (float *)cb.b;
	cSrcPtr = (float *)cb.c;

	/* Now we can kick off our first DMAs. */
	/* This will load the first section of our A and B data arrays into the local store */
	mfc_get((void *) aData[0], (unsigned int)aSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
	aSrcPtr += BUF_SIZE;
	mfc_get((void *) bData[0], (unsigned int)bSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
	bSrcPtr += BUF_SIZE;

	for (j=0; j<size; j++)
	{	
	
	        mfc_write_tag_mask(src_mask);
	        mfc_read_tag_status_all();

		/* Now that we have some data to work on, we can kick off transfering the */
		/* next block of data over while we work on the first block */

		mfc_get((void *) aData[(j+1)&1], (unsigned int)aSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
		aSrcPtr += BUF_SIZE;
		mfc_get((void *) bData[(j+1)&1], (unsigned int)bSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
		bSrcPtr += BUF_SIZE;

		aLocalPtr = aData[j&1];
		bLocalPtr = bData[j&1];
		cLocalPtr = cData[j&1];

		/*Perform the data add*/
		for(i=0; i<BUF_SIZE; i++, aLocalPtr++, bLocalPtr++, cLocalPtr++)
		{
			*cLocalPtr = *aLocalPtr + *bLocalPtr;
		}

		mfc_write_tag_mask(dest_mask);
		mfc_read_tag_status_all();

		/* Finally, DMA computed array back to main memory*/
		mfc_put((void *) cData[j&1], (unsigned int)cSrcPtr, (BUF_SIZE*sizeof(float)), dest_tag, 0, 0);
		cSrcPtr += BUF_SIZE;
	}
	mfc_write_tag_mask(dest_mask);
	mfc_read_tag_status_all();

	return 0;
}
