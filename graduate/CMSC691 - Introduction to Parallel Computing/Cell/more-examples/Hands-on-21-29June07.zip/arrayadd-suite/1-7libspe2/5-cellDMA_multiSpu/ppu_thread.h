#ifndef __ppu_thread_h__
#define __ppu_thread_h__

typedef struct ppu_thread_data
{
        spe_context_ptr_t context;
        pthread_t pthread;
        unsigned int entry;
        unsigned int flags;
        void *argp;
        void *envp;
        spe_stop_info_t stopinfo;
} ppu_pthread_data_t;

#endif

