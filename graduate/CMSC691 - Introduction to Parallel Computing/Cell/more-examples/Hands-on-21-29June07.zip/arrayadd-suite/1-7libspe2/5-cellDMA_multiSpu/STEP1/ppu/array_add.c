#include <stdio.h>
#include <stdlib.h>
#include <libspe2.h>
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <sched.h>
#include "../../array_add.h"
#include "../../ppu_thread.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(float array_a[ARRAY_SIZE],128);
MY_ALIGN(float array_b[ARRAY_SIZE],128);
MY_ALIGN(float array_c[ARRAY_SIZE],128);
MY_ALIGN(control_block cb[8], 128);  /* one for each spu */

extern spe_program_handle_t array_spu_add;
#ifdef SDK2
        /* For SDK2.0, We'll have to do this ourselves*/
        /* For SDK2.1, This will be re-included in the library as "spe_cpu_info_get"*/
#include <dirent.h>
inline int spe_count_physical_spes();
#endif

void init_array() {
	int i;
	
	for(i=0;i<ARRAY_SIZE; i++)
	{
		array_a[i] = (float)(i * NUM);
		array_b[i] = (float)((i * NUM)*2);
		array_c[i] = 0.0f;
	}
}

/* New thread*/
void *ppu_pthread_function(void *arg)
{
        ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
        int rc;
                rc = spe_context_run(datap->context, &datap->entry, datap->flags, datap->argp,
                                     datap->envp, &datap->stopinfo);

        pthread_exit(NULL);
}

int main(void){
	
	int i, rc;
	int offset[9];
	/* one for each spu */
	ppu_pthread_data_t threadData[8];

	init_array();

	/* check for working hardware */
#ifdef SDK2
	if (spe_count_physical_spes() < 8)
	{
		fprintf(stderr,"System has less than 8 working SPEs. Exiting\n");
		return -1;
	}
#else
        if (spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES, -1) < 8)
        {
                fprintf(stderr,"System has less than 8 working SPEs. Exiting\n");
                return -1;
        }
#endif


	for (i=0; i<8; i++)
	{
		offset[i] = (ARRAY_SIZE * i) / 8;
		offset[i] += 0x3f;
		offset[i] &= ~0x7f;  /*to start each array on cache line*/
	}
	offset[8] = ARRAY_SIZE;

	/* complete control blocks*/
	for (i=0; i<8; i++)
	{
		cb[i].a = (unsigned int) &array_a[offset[i]];
		cb[i].b = (unsigned int) &array_b[offset[i]];
		cb[i].c = (unsigned int) &array_c[offset[i]];
		cb[i].size = offset[i+1] - offset[i];
	}

	/* create spe threads for program add_array_spu*/
	for (i=0; i<8; i++)
	{
        	/* Create a spe context that we'll use to load our spe program into*/
	        if ((threadData[i].context = spe_context_create(0, NULL)) == NULL)
        	{
	                fprintf(stderr, "Failed spe_context_create(errno=%d, strerror=%s)\n", errno, strerror(errno));
        	        exit (3);
	        }

        	/* Load our spe program: array_spu_add*/
	        if ((rc = spe_program_load(threadData[i].context, &array_spu_add)) != 0)
        	{
	                fprintf(stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
        	        exit(3);
	        }

        	/* Setup our SPE program parameters*/
	        threadData[i].entry = SPE_DEFAULT_ENTRY;
        	threadData[i].flags = 0;
	        threadData[i].argp = (unsigned long long *)&cb[i];
        	threadData[i].envp = NULL;

	        /* Now we can create thread to run on a SPE*/
        	if ((rc = pthread_create(&threadData[i].pthread, NULL, &ppu_pthread_function, &threadData[i])) != 0)
	        {
        	        fprintf(stderr, "Failed pthread_create(errno=%d, strerror=%s)\n", errno, strerror(errno));
                	exit(3);
	        }
	}

	/* wait for spes to finish */
	for (i=0; i<8; i++) 
	{
        	if ((rc = pthread_join (threadData[i].pthread, NULL)) != 0)
	        {
        	        fprintf(stderr, "Failed pthread_joib(rc=%d, errno=%d strerror=%s)\n", rc, errno, strerror(errno));
                	exit(1);
	        }
        	if ((rc = spe_context_destroy(threadData[i].context)) != 0)
	        {
        	        fprintf(stderr, "Failed spe_context_destroy(rc=%d, errno=%d strerror=%s)\n", rc, errno, strerror(errno));
                	exit(1);
	        }
	}


	__asm__ __volatile__ ("sync" : : : "memory");

	
printf("Array Addition completes. Verifying results...\n");

	/* verifying */
	for (i=0; i<ARRAY_SIZE; i++) 
	{
	//printf("%f \n",array_c[i]);
		if (array_c[i] != (float)((i * NUM)*3))
		{
			printf("ERROR in array addition\n");
			return 0;
		}	
	}
	printf("	Correct!\n");

	return 0;
}

#ifdef SDK2
        /* For SDK2.0, We'll have to do this ourselves*/
        /* For SDK2.1, This will be re-included in the library as "spe_cpu_info_get"*/
inline int spe_count_physical_spes()
{
        int count = 0;
        DIR *dirp;
        struct dirent *dptr;
        if ((dirp=opendir("/sys/devices/system/spu"))!=NULL)
        {
                while ((dptr=readdir(dirp)))
                {
                        count++;
                }
                closedir(dirp);
        }
        return count;
}
#endif

