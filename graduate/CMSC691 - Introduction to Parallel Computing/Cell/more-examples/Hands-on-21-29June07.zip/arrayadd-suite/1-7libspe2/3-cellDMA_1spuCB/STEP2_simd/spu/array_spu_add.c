#include <stdio.h>
#include <spu_mfcio.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(vector float array_a[ARRAY_SIZE/4],128);
MY_ALIGN(vector float array_b[ARRAY_SIZE/4],128);
MY_ALIGN(vector float array_c[ARRAY_SIZE/4],128);
MY_ALIGN(control_block cb, 128);

#ifdef SDK2
        // SDK2 contains a bug when starting a SPE program with libspe2
        // The bug causes the argp and envp variables to be sent incorrectly
typedef union
{
  unsigned long long ull;
  unsigned int ui[2];
  void *p;
} myaddr64;
#endif


int main(unsigned long long speid, unsigned long long argp, unsigned long long envp){

#ifdef SDK2
        // SDK2 contains a bug when starting a SPE program with libspe2
        // The bug causes the argp and envp variables to be sent incorrectly
        myaddr64 wrongargp;
        myaddr64 wrongenvp;
        myaddr64 myargp;
        myaddr64 myenvp;

        wrongargp.ull = argp;
        wrongenvp.ull = envp;
        myargp.ui[0] = wrongargp.ui[1];
        myargp.ui[1] = wrongargp.ui[0];
        myenvp.ui[0] = wrongenvp.ui[1];
        myenvp.ui[1] = wrongenvp.ui[0];
        argp = myargp.ull;
        envp = myenvp.ull;
#endif
	
	int i;

	/* First: DMA our control block into local store */
	mfc_get(&cb, argp, sizeof(cb), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	
	/*Now that we have the control block we can DMA our data arrays over */
	mfc_get(&array_a, cb.a, (sizeof(float)*cb.size), 31, 0, 0);
	mfc_get(&array_b, cb.b, (sizeof(float)*cb.size), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	
	/*matrix add*/
	for(i=0; i<ARRAY_SIZE/4; i+=4)
	{
	      array_c[i  ] = spu_add(array_a[i  ], array_b[i  ]);
	      array_c[i+1] = spu_add(array_a[i+1], array_b[i+1]);
	      array_c[i+2] = spu_add(array_a[i+2], array_b[i+2]);
	      array_c[i+3] = spu_add(array_a[i+3], array_b[i+3]);

	}

	/* Finally, DMA computed array back to main memory*/
	mfc_put(&array_c, cb.c, (sizeof(float)*cb.size), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	return 0;
}
