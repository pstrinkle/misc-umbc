#include <alf_accel.h> 
#include "../array_add.h"

int alf_comp_kernel(volatile void *p_parm_ctx_buffer, 
                    volatile void *p_input_buffer,  
                    volatile void *p_output_buffer, 
                    unsigned int current_count,
                    unsigned int total_count )

{
    unsigned int i, cnt;
    vector float *sa, *sb, *sc;
    add_parms_t *p_parm = (add_parms_t *) p_parm_ctx_buffer;

    cnt = p_parm->h / 4;  // vector of 4
    sa = (vector float *) p_input_buffer;
    sb = sa + cnt;
    sc = (vector float *) p_output_buffer;

    for(i=0; i<cnt; i+=4)
    {
      sc[i  ] = spu_add(sa[i  ], sb[i  ]);
      sc[i+1] = spu_add(sa[i+1], sb[i+1]);
      sc[i+2] = spu_add(sa[i+2], sb[i+2]);
      sc[i+3] = spu_add(sa[i+3], sb[i+3]);

    }

    return 0;
}
