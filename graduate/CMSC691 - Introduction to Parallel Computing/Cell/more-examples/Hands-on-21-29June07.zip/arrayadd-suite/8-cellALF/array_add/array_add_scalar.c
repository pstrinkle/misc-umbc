#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE	1024
#define NUM		512

/* 
 * scalar implementation of a array add. 
 */


float array_a[ARRAY_SIZE];
float array_b[ARRAY_SIZE];
float array_c[ARRAY_SIZE];

void init_array ()
{
  int i;

  for (i = 0; i < ARRAY_SIZE; i++)
  {
      array_a[i] = (float)(i * NUM);
      array_b[i] = (float)((i * NUM)*2);
      array_c[i] = 0.0f;      
  }

}

int main(void)
{
  int i;

  init_array();

  /* compute */
   for (i=0; i<ARRAY_SIZE; i++)
           array_c[i] = array_a[i] + array_b[i];

   printf ("Array Addition completes\n");

   /* verifying */
   for (i = 0; i < ARRAY_SIZE; i++)
   {
       if (array_c[i] != (float)((i * NUM)*3))
       {
	 printf ("ERROR in array addition\n");
       } 
   }

   return 0;
}

