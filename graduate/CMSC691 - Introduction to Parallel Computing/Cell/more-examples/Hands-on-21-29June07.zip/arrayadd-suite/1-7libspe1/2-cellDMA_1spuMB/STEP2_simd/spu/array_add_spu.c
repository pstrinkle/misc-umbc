#include <stdio.h>
#include <spu_mfcio.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(vector float array_a[ARRAY_SIZE/4],128);
MY_ALIGN(vector float array_b[ARRAY_SIZE/4],128);
MY_ALIGN(vector float array_c[ARRAY_SIZE/4],128);

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp){
	
	int i;
	unsigned int Aaddr, Baddr, Caddr;

	/* First: Read mailbox 3 times to get our array effective addresses */
	Aaddr = (unsigned int) spu_read_in_mbox();
	Baddr = (unsigned int) spu_read_in_mbox();
	Caddr = (unsigned int) spu_read_in_mbox();
	
	/*Now that we have the array EAs we can DMA our data over */
	mfc_get(&array_a, Aaddr, (sizeof(float)*ARRAY_SIZE), 31, 0, 0);
	mfc_get(&array_b, Baddr, (sizeof(float)*ARRAY_SIZE), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	
	/*array add*/
	for(i=0; i<ARRAY_SIZE/4; i+=4)
	{
		array_c[i] = spu_add(array_a[i], array_b[i]);
		array_c[i+1] = spu_add(array_a[i+1], array_b[i+1]);
		array_c[i+2] = spu_add(array_a[i+2], array_b[i+2]);
		array_c[i+3] = spu_add(array_a[i+3], array_b[i+3]);
	}

	/* Finally, DMA computed array back to main memory*/
	mfc_put(&array_c, Caddr, (sizeof(float)*ARRAY_SIZE), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	return 0;
}
