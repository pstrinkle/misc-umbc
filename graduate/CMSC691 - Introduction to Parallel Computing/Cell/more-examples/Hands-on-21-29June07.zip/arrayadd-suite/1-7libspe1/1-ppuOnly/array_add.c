#include <stdio.h>
#include <stdlib.h>
#include "array_add.h"

#define ARRAY_SIZE	1024
#define NUM		512

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(float array_a[ARRAY_SIZE],128);
MY_ALIGN(float array_b[ARRAY_SIZE],128);
MY_ALIGN(float array_c[ARRAY_SIZE],128);

void init_array() {
	int i;
	
	for(i=0;i<ARRAY_SIZE; i++)
	{
		array_a[i] = (float)(i * NUM);
		array_b[i] = (float)((i * NUM)*2);
		array_c[i] = 0.0f;
	}
}

int main(void){
	
	int i;

	init_array();

	/*array add*/
	for(i=0; i<ARRAY_SIZE; i++)
	{
		array_c[i]=array_a[i]+array_b[i];
	}

printf("Array Addition completes. Verifying results...\n");

	/* verifying */
	for (i=0; i<ARRAY_SIZE; i++) 
	{
		if (array_c[i] != (float)((i * NUM)*3))
		{
			printf("ERROR in array addition\n");
			return 0;
		}	
	}
	printf("	Correct!\n");

	return 0;
}
