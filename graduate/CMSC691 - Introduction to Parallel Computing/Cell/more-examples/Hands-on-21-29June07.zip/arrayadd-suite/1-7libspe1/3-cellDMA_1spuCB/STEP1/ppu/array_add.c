#include <stdio.h>
#include <stdlib.h>
#include <libspe.h>
#include <errno.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(float array_a[ARRAY_SIZE],128);
MY_ALIGN(float array_b[ARRAY_SIZE],128);
MY_ALIGN(float array_c[ARRAY_SIZE],128);
MY_ALIGN(control_block cb, 128);

extern spe_program_handle_t array_add_spu;

speid_t speid;
int status;

void init_array() {
	int i;
	
	for(i=0;i<ARRAY_SIZE; i++)
	{
		array_a[i] = (float)(i * NUM);
		array_b[i] = (float)((i * NUM)*2);
		array_c[i] = 0.0f;
	}
}

int main(void){
	
	int i;

	init_array();

	/* check for working hardware */
	if (spe_count_physical_spes() < 1)
	{
		fprintf(stderr,"System has no working SPEs. Exiting\n");
		return -1;
	}

	/* complete control block*/
	cb.a = (unsigned int) &array_a[0];
	cb.b = (unsigned int) &array_b[0];
	cb.c = (unsigned int) &array_c[0];
	cb.size = ARRAY_SIZE;

	/* create an spe thread for program add_array_spu*/
	speid = spe_create_thread (0, &array_add_spu, (unsigned long long *)&cb, NULL, -1, 0);
	if (speid == NULL)
	{
		fprintf(stderr, "FAILED: spe_create_thread(num=%d, errno=%d)\n", 1, errno);
		exit(3);
	}

	/* wait for spe to finish */
	spe_wait(speid, &status, 0);

	__asm__ __volatile__ ("sync" : : : "memory");

	
printf("Array Addition completes. Verifying results...\n");

	/* verifying */
	for (i=0; i<ARRAY_SIZE; i++) 
	{
        //printf("%f \n",array_c[i]);
		if (array_c[i] != (float)((i * NUM)*3))
		{
			printf("ERROR in array addition\n");
			return 0;
		}	
	}
	printf("	Correct!\n");

	return 0;
}
