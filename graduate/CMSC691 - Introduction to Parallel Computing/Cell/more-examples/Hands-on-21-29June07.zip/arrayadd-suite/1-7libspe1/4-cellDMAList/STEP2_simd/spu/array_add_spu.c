#include <stdio.h>
#include <spu_mfcio.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(vector float array_a[ARRAY_SIZE/4],128);
MY_ALIGN(vector float array_b[ARRAY_SIZE/4],128);
MY_ALIGN(vector float array_c[ARRAY_SIZE/4],128);
MY_ALIGN(control_block cb, 128);
MY_ALIGN(struct dma_list_elem list[16], 8);

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp){
	
	int i;

	/* First: DMA our control block into local store */
	mfc_get(&cb, argp, sizeof(cb), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();

	/*Now that we have the control block we can DMA our data arrays over */
	transfer_large_region((void *)&array_a, (unsigned int)cb.a, (sizeof(float)*cb.size), 1);
	transfer_large_region((void *)&array_b, (unsigned int)cb.b, (sizeof(float)*cb.size), 1);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	
	/*array add*/
	for(i=0; i<cb.size/4; i+=4)
	{
	        array_c[i  ] = spu_add(array_a[i  ], array_b[i  ]);
	        array_c[i+1] = spu_add(array_a[i+1], array_b[i+1]);
	        array_c[i+2] = spu_add(array_a[i+2], array_b[i+2]);
      		array_c[i+3] = spu_add(array_a[i+3], array_b[i+3]);
	}

	/* Finally, DMA computed array back to main memory*/
	transfer_large_region((void *)&array_c, (unsigned int)cb.c, (sizeof(float)*cb.size), 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();
	return 0;
}

void transfer_large_region(void *lsAddr, unsigned int ea_low, unsigned int nbytes, unsigned int get)
{
	unsigned int i = 0;
	unsigned int tagid = 0;
	unsigned int listsize;

	if (!nbytes)
		return;

	while (nbytes > 0)
	{
		unsigned int sz;

		sz = (nbytes < 16384) ? nbytes : 16384;
		list[i].size.all32 = sz;
		list[i].ea_low = ea_low;

		nbytes -= sz;
		ea_low += sz;
		i++;
	}

	listsize = i * sizeof(struct dma_list_elem);
	if (get)
	{
		mfc_getl((volatile *)lsAddr, list[0].ea_low, (unsigned int)&list[0], listsize, 31, 0, 0);
		mfc_write_tag_mask(1<<31);
		mfc_read_tag_status_all();
	}
	else
	{
		mfc_putl((volatile *)lsAddr, list[0].ea_low, (unsigned int)&list[0], listsize, 31, 0, 0);
		mfc_write_tag_mask(1<<31);
		mfc_read_tag_status_all();
	}
}
