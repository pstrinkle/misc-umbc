#ifndef __array_add_h__
#define __array_add_h__

#define ARRAY_SIZE      5120
#define NUM             512

typedef struct _control_block
{
	unsigned int a;
	unsigned int b;
	unsigned int c;
	unsigned int size;
	unsigned char pad[112];
} control_block;

struct dma_list_elem {
	union
	{
		unsigned int all32;
		struct
		{
			unsigned int stall	:1;
			unsigned int reserved	:15;
			unsigned int nbytes	:16
		} bits;
	} size;
	unsigned int ea_low;
};

#endif
