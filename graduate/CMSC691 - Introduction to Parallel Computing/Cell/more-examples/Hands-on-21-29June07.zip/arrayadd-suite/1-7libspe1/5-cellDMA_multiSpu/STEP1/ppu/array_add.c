#include <stdio.h>
#include <stdlib.h>
#include <libspe.h>
#include <errno.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

MY_ALIGN(float array_a[ARRAY_SIZE],128);
MY_ALIGN(float array_b[ARRAY_SIZE],128);
MY_ALIGN(float array_c[ARRAY_SIZE],128);
MY_ALIGN(control_block cb[8], 128);  /* one for each spu */

extern spe_program_handle_t array_add_spu;

/* one for each spu */
speid_t speids[8];
int status[8];

void init_array() {
	int i;
	
	for(i=0;i<ARRAY_SIZE; i++)
	{
		array_a[i] = (float)(i * NUM);
		array_b[i] = (float)((i * NUM)*2);
		array_c[i] = 0.0f;
	}
}

int main(void){
	
	int i;
	int offset[9];

	init_array();

	/* check for working hardware */
	if (spe_count_physical_spes() < 1)
	{
		fprintf(stderr,"System has no working SPEs. Exiting\n");
		return -1;
	}

	for (i=0; i<8; i++)
	{
		offset[i] = (ARRAY_SIZE * i) / 8;
		offset[i] += 0x3f;
		offset[i] &= ~0x7f;  /*to start each array on cache line*/
	}
	offset[8] = ARRAY_SIZE;

	/* complete control blocks*/
	for (i=0; i<8; i++)
	{
		cb[i].a = (unsigned int) &array_a[offset[i]];
		cb[i].b = (unsigned int) &array_b[offset[i]];
		cb[i].c = (unsigned int) &array_c[offset[i]];
		cb[i].size = offset[i+1] - offset[i];
	}

	/* create spe threads for program add_array_spu*/
	for (i=0; i<8; i++)
	{
		speids[i] = spe_create_thread (0, &array_add_spu, (unsigned long long *)&cb[i], NULL, -1, 0);
		if (speids[i] == NULL)
		{
			fprintf(stderr, "FAILED: spe_create_thread(num=%d, errno=%d)\n", i, errno);
			exit(3);
		}
	}

	/* wait for spes to finish */
	for (i=0; i<8; i++) spe_wait(speids[i], &status[i], 0);

	__asm__ __volatile__ ("sync" : : : "memory");

	
printf("Array Addition completes. Verifying results...\n");

	/* verifying */
	for (i=0; i<ARRAY_SIZE; i++) 
	{
	//printf("%f \n",array_c[i]);
		if (array_c[i] != (float)((i * NUM)*3))
		{
			printf("ERROR in array addition\n");
			return 0;
		}	
	}
	printf("	Correct!\n");

	return 0;
}
