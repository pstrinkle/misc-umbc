#ifndef __array_add_h__
#define __array_add_h__

#define ARRAY_SIZE      5120
#define NUM             512

typedef struct _control_block
{
	unsigned int a;
	unsigned int b;
	unsigned int c;
	unsigned int size;
	unsigned char pad[112];
} control_block;

#endif
