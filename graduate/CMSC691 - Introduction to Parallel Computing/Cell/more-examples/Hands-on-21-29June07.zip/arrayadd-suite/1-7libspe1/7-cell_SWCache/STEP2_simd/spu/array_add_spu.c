#include <stdio.h>
#include <spu_mfcio.h>
#include <sys/types.h>
#include "../../array_add.h"

#define CACHE_NAME              cacheData
#define CACHED_TYPE             vector float
#define CACHE_TYPE              1       /* r/w */
#define CACHELINE_LOG2SIZE      7       /* 128 bytes */
#define CACHE_LOG2NWAY          2       /* 4-way */
#define CACHE_LOG2NSETS         8       /* 512 lines */
//#define CACHE_READ_X4
#include <cache-api.h>

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

#define VEC_ARRAY_SIZE ARRAY_SIZE/4

MY_ALIGN(vector float array_a[VEC_ARRAY_SIZE],128);
MY_ALIGN(vector float array_b[VEC_ARRAY_SIZE],128);
MY_ALIGN(vector float array_c[VEC_ARRAY_SIZE],128);
MY_ALIGN(control_block cb, 128);

#define LOAD1(name, addr)       \
    (cache_rd(name, (addr)))

#define STORE1(name, addr, val) \
    name ## _cache_wr((addr), (val))

//#ifdef CACHE_READ_X4
//#define LOAD4(name, addr4)      \
//    (cache_rd_x4(name, (addr4)))
//#endif


static void read_cacheA(unsigned int src, unsigned int size)
{
    int i=0;

    while (size > 0) {
        array_a[i] = LOAD1(cacheData, src);
        size--;
        src = src + sizeof(vector float);
	i++;
    }
}

static void read_cacheB(unsigned int src, unsigned int size)
{
    int i=0;

    while (size > 0) {
        array_b[i] = LOAD1(cacheData, src);
        size--;
        src = src + sizeof(vector float);
	i++;
    }
}

static void write_cache(unsigned int dst, unsigned int size)
{
    int i=0;

    while (size > 0) {
        //STORE1(cacheData, dst, array_c[i]);
	cache_wr(cacheData, dst, array_c[i]);
        size--;
        dst = dst + sizeof(vector float);
	i++;
    }
}

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp){
	
	int i;

	/* First: DMA our control block into local store */
	mfc_get(&cb, argp, sizeof(cb), 31, 0, 0);
	mfc_write_tag_mask(1<<31);
	mfc_read_tag_status_all();

	/* Now that we have the control block, use the EAs to move the data */
        /* into our local SW Cache */
	read_cacheA((unsigned int)cb.a, cb.size/4);
	read_cacheB((unsigned int)cb.b, cb.size/4);
	
	/*array add*/
	for(i=0; i<(cb.size/4); i+=4)
	{
		array_c[i]=spu_add(array_a[i], array_b[i]);
		array_c[i+1]=spu_add(array_a[i+1], array_b[i+1]);
		array_c[i+2]=spu_add(array_a[i+2], array_b[i+2]);
		array_c[i+3]=spu_add(array_a[i+3], array_b[i+3]);
	}

	/* Finally, write the data back into the SW Cache*/
	write_cache((unsigned int)cb.c, cb.size/4);

	/* We must flush the cache to make sure that main memory is updated */
	cacheData_cache_flush();
	return 0;
}
