#include <stdio.h>
#include <spu_mfcio.h>
#include "../../array_add.h"

#define MY_ALIGN(_my_var_def_, _my_al_) _my_var_def_ \
__attribute__((__aligned__(_my_al_)))

#define VEC_BUF_SIZE BUF_SIZE/4

MY_ALIGN(control_block cb, 128);
MY_ALIGN(vector float dataBuf[VEC_BUF_SIZE * 6], 128);
vector float * aData[2];
vector float * bData[2];
vector float * cData[2];

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp){
	
	int i, j,size;
	unsigned int src_tag, dest_tag, src_mask, dest_mask;
	vector float *aSrcPtr, *aLocalPtr;
	vector float *bSrcPtr, *bLocalPtr;
	vector float *cSrcPtr, *cLocalPtr;

	/* Setup data buffers */
	aData[0] = dataBuf; aData[1] = dataBuf + VEC_BUF_SIZE; 
	bData[0] = dataBuf + VEC_BUF_SIZE*2; bData[1] = dataBuf + VEC_BUF_SIZE*3;
	cData[0] = dataBuf + VEC_BUF_SIZE*4; cData[1] = dataBuf + VEC_BUF_SIZE*5;

	/* setup src DMAs to use tag 31, dest DMAs to use tag 30*/
	src_tag = 31; src_mask = 1<<src_tag;
	dest_tag = 30; dest_mask = 1<<dest_tag;

	/* First: DMA our control block into local store */
	mfc_get(&cb, argp, sizeof(cb), src_tag, 0, 0);
	mfc_write_tag_mask(src_mask);
	mfc_read_tag_status_all();

	/* obtain information from control block */
	size = cb.size/BUF_SIZE;
	aSrcPtr = (vector float *)cb.a;
	bSrcPtr = (vector float *)cb.b;
	cSrcPtr = (vector float *)cb.c;

	/* Now we can kick off our first DMAs. */
	/* This will load the first section of our A and B data arrays into the local store */
	mfc_get((void *) aData[0], (unsigned int)aSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
	aSrcPtr += VEC_BUF_SIZE;
	mfc_get((void *) bData[0], (unsigned int)bSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
	bSrcPtr += VEC_BUF_SIZE;

	for (j=0; j<size; j++)
	{	
	
	        mfc_write_tag_mask(src_mask);
	        mfc_read_tag_status_all();

		/* Now that we have some data to work on, we can kick off transfering the */
		/* next block of data over while we work on the first block */

		mfc_get((void *) aData[(j+1)&1], (unsigned int)aSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
		aSrcPtr += VEC_BUF_SIZE;
		mfc_get((void *) bData[(j+1)&1], (unsigned int)bSrcPtr, (BUF_SIZE*sizeof(float)), src_tag, 0, 0);
		bSrcPtr += VEC_BUF_SIZE;

		aLocalPtr = aData[j&1];
		bLocalPtr = bData[j&1];
		cLocalPtr = cData[j&1];

		/*Perform the data add*/
		for(i=0; i<VEC_BUF_SIZE; i+=4, aLocalPtr+=4, bLocalPtr+=4, cLocalPtr+=4)
		{
			*cLocalPtr = spu_add(*aLocalPtr, *bLocalPtr);
			*(cLocalPtr+1) = spu_add(*(aLocalPtr+1), *(bLocalPtr+1));
			*(cLocalPtr+2) = spu_add(*(aLocalPtr+2), *(bLocalPtr+2));
			*(cLocalPtr+3) = spu_add(*(aLocalPtr+3), *(bLocalPtr+3));
		}

		mfc_write_tag_mask(dest_mask);
		mfc_read_tag_status_all();

		/* Finally, DMA computed array back to main memory*/
		mfc_put((void *) cData[j&1], (unsigned int)cSrcPtr, (BUF_SIZE*sizeof(float)), dest_tag, 0, 0);
		cSrcPtr += VEC_BUF_SIZE;
	}
	mfc_write_tag_mask(dest_mask);
	mfc_read_tag_status_all();

	return 0;
}
