This is a suite of examples that attempts to show off various techniques and
libraries associated with programming on the Cell/B.E.
Each of these examples contains an initial implementation as well as a more
optimized SIMD version.

Tutorial Directores:
====================
 1-7libspe1/
 1-7libspe2/
 8-cellALF/

 There are 8 tutorials in total. There are 2 separate versions of the first seven
 tutorials, each with a separate directory. The first directory, 1-7libspe1/,
 uses the SPE Runtime Management Library v1.2, which has been depricated
 effective March 31, 2007. The second directory, 1-7libspe2, uses the newer
 SPE Runtime Management Library v2.1. Note the libspe2 naming convention
 of <noun> before <verb> had been adopted in the libspe2 filenames.
 The eighth tutorial has been broken out separately as it does not use the
 SPE Runtime Management Library and instead uses Accelerated Library Framework.

 The first seven tutorials are as follows:
 1-ppuOnly
 2-cellDMA_1spuMB
 3-cellDMA_1spuCB
 4-cellDMAList
 5-cellDMA_multiSpu
 6-cellDMA_multiBuf
 7-cell_SWCache


 Tutorial Descriptions:
=======================
1-ppuOnly
	A PPU-Only Example
	This example is the basis for all the others. This version is a standard C program
	that will run only on the ppu when executed on the Cell/B.E.
	It is a simple example that initializes 2 arrays (A and B, each being 1024 floats) and
	adds each of their elements together and saves the result in a third array of the same
	size (array C). It then verifys the results.
	
	executable
	-----------
	array_add

2-cellDMA_1spuMB
	A Cell/B.E. Example using DMA Transfers and Mailboxes
	In Step 1, we port our code from the previous example to the Cell/B.E. 
	We want the work to be done on an SPE, so we must somehow get our array data
	into an SPE local store. We must also have a way of communicating with the
	SPE doing the work. Our 'main' procedure now creates a SPE thread. The SPE
	needs some information to do it's work, namely the effective addresses of the
	data arrays in main memory. We use the mailbox function to communicate these
	addresses to the SPE. The SPE then uses these addresses to DMA the A and B array
	data from main memory to it's local store. Once the DMA is completed, it can do 
	it's work and DMA the resulting data back to main memory.

	In Step 2, we optimize our SPU code using the type 'vector float' for our local
	arrays. Each vector float contains 4 of the floats of our array.
	Using vector floats will allow us to utilize the SIMD potential of the
	Cell/B.E. We can now use the SPU intrinsic 'spu_add', which accepts
	vector types, to add all four elements of each vector float at once.
	We can further optimize by unrolling our data addition loop to do four
	'spu_add's in each pass. These optimizations allow us to add 16 float
	elements from array A to 16 float elements of array B per pass of the loop.


	executable
	-----------
	STEP1/ppu/array_add_1spuMB
	STEP2_simd/ppu/array_add_1spuMB_SIMD

3-cellDMA_1spuCB
	A Cell/B.E. Example using DMA Transfers and a Control Block
	Step 1
	A cleaner and more efficient way to get the necessary effective address information
	from the ppe to the spe is to bundle everything we need into a single control block.
	The control block is defined in a header file and contains the effective addresses
	and size information the SPE needs. When creating the SPE thread, the ppu passes
	the effective address of only the control block along to the SPE program as an
	argument. The SPE program can now go directly to beginning the DMA transfers of
	the array data.

	Step 2
        We optimize our SPU code using the type 'vector float' for our local
        arrays. Each vector float contains 4 of the floats of our array.
        Using vector floats will allow us to utilize the SIMD potential of the
        Cell/B.E. We can now use the SPU intrinsic 'spu_add', which accepts
        vector types, to add all four elements of each vector float at once.
        We can further optimize by unrolling our data addition loop to do four
        'spu_add's in each pass. These optimizations allow us to add 16 float
        elements from array A to 16 float elements of array B per pass of the
	loop.

	executable
	-----------
	STEP1/ppu/array_add_1spuCB
	STEP2_simd/ppu/array_add_1spuCB_SIMD

4-cellDMAList
	A Cell/B.E. Example using DMA Lists
	Step 1
	We increase the complexity in this example by increasing the size of the A and B
	arrays. They will now hold 5120 floats each. DMA Lists can be useful when your data
	size exceeds the 16K limit of standard DMAs. In our SPE code, we have a new function
	called 'transfer_large_region'. This function will divide our data into 16K chunks,
	assign those chunk to our list and grab those lists in order. We also use a DMAList
	for transfer back into main memory.

        Step 2
        We optimize our SPU code using the type 'vector float' for our local
        arrays. Each vector float contains 4 of the floats of our array.
        Using vector floats will allow us to utilize the SIMD potential of the
        Cell/B.E. We can now use the SPU intrinsic 'spu_add', which accepts
        vector types, to add all four elements of each vector float at once.
        We can further optimize by unrolling our data addition loop to do four
        'spu_add's in each pass. These optimizations allow us to add 16 float
        elements from array A to 16 float elements of array B per pass of the
        loop.

	executable
	-----------
	STEP1/ppu/array_add_1spuList
	STEP2_simd/ppu/array_add_1spuList_SIMD

5-cellDMA_multiSpu
	A Cell/B.E. Example using multiple SPEs
	Step 1
	One of the benefits of the Cell/B.E. is the 8 seperate SPUs. Each of these can be
	doing work simultaneously. In order to take advantage of this, we must create
	and SPE thread for each new SPE we want to use. In this example, the SPE code is
	the same as it was in Example 3, however, our PPU code must change in order to
	initiate and feed all 8 SPEs. The PPU code must have 8 control blocks, each with
	effective addresses and sizes for the SPE. Each SPE will process 1/8th of each
	array. We must setup pointers into each of the arrays and pass them along.
	The SPEs then each process their piece and return their piece to the C array.

        Step 2
        We optimize our SPU code using the type 'vector float' for our local
        arrays. Each vector float contains 4 of the floats of our array.
        Using vector floats will allow us to utilize the SIMD potential of the
        Cell/B.E. We can now use the SPU intrinsic 'spu_add', which accepts
        vector types, to add all four elements of each vector float at once.
        We can further optimize by unrolling our data addition loop to do four
        'spu_add's in each pass. These optimizations allow us to add 16 float
        elements from array A to 16 float elements of array B per pass of the
        loop.

	executable
	-----------
	STEP1/ppu/array_add_multiSpu
	STEP2_simd/ppu/array_add_multiSpu_SIMD

6-cellDMA_multiBuf
	A Cell/B.E. Example using multi-buffering
	Step 1
	Yet another way to handle data sizes too large for a single DMA is to use 
	multi-buffering. In this example we create a large buffer and divide it up
	by assigning pointers to various addresses in the buffer. The idea behind
	multi-buffering is being able to hide the DMA tranfer time by working on
	one piece while DMA transferring the next piece. We double-buffer the
	two data arrays A and B, as well as the output array C, telling us we can
	divide our original large buffer into 6 work buffers.

        Step 2
        We optimize our SPU code using the type 'vector float' for our local
        data buffer. Each vector float contains 4 of the floats of our array.
        Using vector floats will allow us to utilize the SIMD potential of the
        Cell/B.E. We can now use the SPU intrinsic 'spu_add', which accepts
        vector types, to add all four elements of each vector float at once.
	Since we mainly deal with indexes into a large data buffer in this
	array, it is important to note the size differences between a float
	and a vector float, while realizes the actual # of bytes of data
	will remain unchanged.
        We can further optimize by unrolling our data addition loop to do four
        'spu_add's in each pass. These optimizations allow us to add 16 float
        elements from array A to 16 float elements of array B per pass of the
        loop.


	executable
	-----------
	STEP1/ppu/array_add_MultiBuf
	STEP2_simd/ppu/array_add_MultiBuf_SIMD

7-cell_SWCache
	A Cell/B.E. Example using a SPE Software Cache
	Step 1
	An IBM SDK feature that can help us is the SPE Software Managed Cache. This
	feature is primarily useful for hard-to-predict data access patterns. Our
	problem is quite predictable, but we can still it illustrate the use and benefits
	of the SW Cache. Our SPE code changes again as we setup our cache using the
	keyword defines and then including the cache-api.h. We can simple loop through
	our data arrays and add them to the cache, use the values and write the resultant
	values to the cache as well. We must make sure to flush our cache before completion
	to make sure the main memory is up to date.

        Step 2
        We optimize our SPU code using the type 'vector float' for our local
        arrays as well as for our SW Cache type. Each vector float contains 4 
	of the floats of our array.
        Using vector floats will allow us to utilize the SIMD potential of the
        Cell/B.E. We can now use the SPU intrinsic 'spu_add', which accepts
        vector types, to add all four elements of each vector float at once.
        We can further optimize by unrolling our data addition loop to do four
        'spu_add's in each pass. These optimizations allow us to add 16 float
        elements from array A to 16 float elements of array B per pass of the
        loop.

	executable
	-----------
	STEP1/ppu/array_add_SWCache
	STEP2_simd/ppu/array_add_SWCache_SIMD

8-cellALF
	A Cell/B.E. 2 Examples using ALF
	In this final example, we port our code to use the Accelerated Library Framework(ALF).
	ALF abstracts some of the lower-level complexities seen in the previous
	examples with an API well suited for the Cell/B.E.
		This example has 2 parts. The first is our running example of
		an addition to two floating point arrays, executed in ALF (STEP1).
		This part also includes a version with a SIMD optimized compute kernel (STEP2).

		The second part ups the complexity of the problem by adding two 1024x512 
		single precision float point matrices. This part contains a
		version with an alternate data partition scheme (STEP1b) as well as
		a version with a SIMD optimized computer kernel (STEP2).

		These examples demostrate how a simplified scalar function 
		can be ported and accellerated for parallel execution on ALF.

           subdirectory                            executable
           -------------------                    -------------------
           array_add/STEP1                        array_add_alf
           array_add/STEP2_simd                   array_add_alf_SIMD
           matrix_add/STEP1a_partition_scheme_A   matrix_add_alf_1a
           matrix_add/STEP1a_partition_scheme_A   matrix_add_alf_1b
           matrix_add/STEP2_simd                  matrix_add_alf_SIMD

