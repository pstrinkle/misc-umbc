
#include <stdio.h>


int main( int argc, char *argv[] ) {

  printf( "SPU: Hello world!\n" );

  return 0;
}
