/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include "../common.h"

#include <libspe2.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <string.h>


/* String to pass to SPE */
char parameter_data[128] __attribute__ ((aligned (128)));


/* this is the pointer to the SPE code, to be used at thread creation time */
extern spe_program_handle_t hello_spu;


int main( int argc, char *argv[] ) 
{
  puts( "PPE: Hello World!");

  strcpy( parameter_data, "This space for rent\n" );

  spe_context_ptr_t spe_context = spe_context_create( 0, NULL );
  spe_program_load( spe_context, &hello_spu );

  unsigned int runflags = 0;
  unsigned int entry = SPE_DEFAULT_ENTRY;

  spe_context_run( spe_context, &entry, runflags, &parameter_data, NULL, NULL );

  spe_context_destroy( spe_context );

  printf("PPE: Done\n");

  return 0;
}
