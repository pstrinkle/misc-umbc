/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int se(int p)
{
	printf("\t\tse prints %d\n", p);
	
	printf("\t\tse returns %d\n", 'e');
	return 'e';
}
