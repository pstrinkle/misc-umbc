/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sa(int p)
{
	int rc;
	
	printf("sa prints %d\n", p);
	
	rc = sb(98); // r=0, s=0, f='b'
	TEST("sa",'b',rc);
	
	printf("sa returns %d\n", 'a');
	return 'a';
}
