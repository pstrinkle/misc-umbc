/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sc(int p)
{
	int rc;
	
	printf("\tsc prints %d\n", p);
	
	rc = sd(200200100); // r=2, s=2, f='d'
	TEST("\tsc",'d',rc);
	
	rc = sf(200300102); // r=2, s=3, f='f'
	TEST("\tsc",'f',rc);
	
	printf("\tsc returns %d\n", 'c');
	return 'c';
}
