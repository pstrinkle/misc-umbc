/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sd(int p)
{
	int rc;
	
	printf("\t\tsd prints %d\n", p);
	
	rc = se(200200101); // r=2, s=2, f='e'
	TEST("\t\tsd",'e',rc);
	
	printf("\t\tsd returns %d\n", 'd');
	return 'd';
}
