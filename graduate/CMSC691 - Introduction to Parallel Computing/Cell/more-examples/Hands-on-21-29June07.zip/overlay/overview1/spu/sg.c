/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sg(int p)
{
	int rc;
	
	printf("\tsg prints %d\n", p);
	
	rc = sh(300500104); // r=3, s=5, f='h'
	TEST("\tsg",'h',rc);
	
	rc = si(300600105); // r=3, s=6, f='i'
	TEST("\tsg",'i',rc);
	
	printf("\tsg returns %d\n", 'g');
	return 'g';
}
