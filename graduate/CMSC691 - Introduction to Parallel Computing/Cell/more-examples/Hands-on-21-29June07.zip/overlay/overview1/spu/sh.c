/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sh(int p)
{
	printf("\t\t\tsh prints %d\n", p);
	
	printf("\t\t\tsh returns %d\n", 'h');
	return 'h';
}
