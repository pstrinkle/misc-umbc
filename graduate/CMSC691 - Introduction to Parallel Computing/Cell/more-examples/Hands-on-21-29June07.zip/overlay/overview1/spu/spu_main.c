/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int
main (unsigned long long spuid __attribute__ ((__unused__)),
      unsigned long long argp  __attribute__ ((__unused__)),
      unsigned long long envp  __attribute__ ((__unused__)))
{
  int rc;

  rc = sa(97); // r=0, s=0, f='a'
  TEST("main",'a', rc);
		
  printf("main returns %d\n", 0);
  return 0;
}
