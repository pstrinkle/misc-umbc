/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sf(int p)
{
	int rc;
	
	printf("\t\tsf prints %d\n", p);
	
	rc = sh(300500104); // r=3, s=5, f='h'
	TEST("\t\tsf",'h',rc);
	
	rc = si(300600105); // r=3, s=6, f='i'
	TEST("\t\tsf",'i',rc);
	
	printf("\t\tsf returns %d\n", 'f');
	return 'f';
}
