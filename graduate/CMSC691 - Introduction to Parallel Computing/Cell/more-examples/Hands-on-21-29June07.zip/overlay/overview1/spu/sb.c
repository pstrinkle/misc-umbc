/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int sb(int p)
{
	int rc;
	
	printf("sb prints %d\n", p);
	
	rc = sc(100100099); // r=1, s=1, f='c'
	TEST("sb",'c',rc);
	
	rc = sg(100400103); // r=1, s=4, f='g'
	TEST("sb",'g',rc);
	
	printf("sb returns %d\n", 'b');
	return 'b';
}
