/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include "spu_main.h"

int si(int p)
{
	printf("\t\t\tsi prints %d\n", p);
	
	printf("\t\t\tsi returns %d\n", 'i');
	return 'i';
}
