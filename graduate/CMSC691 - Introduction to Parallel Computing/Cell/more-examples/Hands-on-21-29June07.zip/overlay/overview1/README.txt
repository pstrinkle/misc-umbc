%% --------------------------------------------------------------- 
%% (C) Copyright 2001,2006,                                        
%% International Business Machines Corporation,                    
%%                                                                 
%% All Rights Reserved.                                            
%% --------------------------------------------------------------- 
%% PROLOG END TAG zYx                                              
Target:
	CBE_Linux (HW or simulator)

Description:
	This directory contains a sample implementation for SPU 
	code overlay by using the SPU Overlay support to access SPU overlay 
	code sections located in the main memory.

	The SPU program is linked with the overlay sections by using 
	a special link script linker.script. The overlay sections are not 
	loaded by the system loader. Instead, they are brought in by the 
	overlay manager when needed.

	The overlay manager uses tables created during linking to obtain 
	the location of the overlay sections and thus transfer the 
	section in before an overlay function is called.

	To run the program, run program "overlay_overview", on success, it returns
	exit code 0. The displayed message shows which part of the
	code is being executed.

