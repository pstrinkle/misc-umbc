/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <libspe2.h>
#include <sys/wait.h>

extern spe_program_handle_t spu_main;

int main() 
{
  spe_context_ptr_t speid; // LIBSPE2
  int rc; // LIBSPE2
  spe_stop_info_t stopinfo; // LIBSPE2
  unsigned int entry = SPE_DEFAULT_ENTRY; // LIBSPE2

  /* Create context */ // LIBSPE2
  if ((speid = spe_context_create (0, NULL)) == NULL) // LIBSPE2
    { // LIBSPE2
      fprintf (stderr, "Failed spe_context_create(errno=%d)\n", errno); // LIBSPE2
      perror ("failed creating context\n"); // LIBSPE2
      exit (1); // LIBSPE2
    } // LIBSPE2
  /* Load program */ // LIBSPE2
  if ((rc = spe_program_load (speid, &spu_main)) != 0) // LIBSPE2
    { // LIBSPE2
      fprintf (stderr, "Failed spe_program_load(errno=%d)\n", errno); // LIBSPE2
      perror ("failed loading program\n"); // LIBSPE2
      exit (1); // LIBSPE2
    } // LIBSPE2
  /* Run context */ // LIBSPE2
  if ((rc = spe_context_run(speid, &entry, 0, NULL, NULL, &stopinfo)) != 0) // LIBSPE2
    { // LIBSPE2
      fprintf (stderr, "Failed spe_context_run(errno=%d)\n", errno); // LIBSPE2
      perror ("failed running context\n"); // LIBSPE2
      exit (1); // LIBSPE2
    } // LIBSPE2
  /* Destroy context */ // LIBSPE2
  if ((rc = spe_context_destroy (speid)) != 0) // LIBSPE2
    { // LIBSPE2
      fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d)\n", rc, errno); // LIBSPE2
      perror ("failed destroying context\n"); // LIBSPE2
      exit (1); // LIBSPE2
    } // LIBSPE2

  if (stopinfo.stop_reason == SPE_EXIT) { // LIBSPE2
        return (stopinfo.result.spe_exit_code); // LIBSPE2
  }
  else {
	fprintf(stderr, "stopinfo.stop_reason=%x, stopinfo.spe_exit_code=%x \n", // LIBSPE2 
		stopinfo.stop_reason, // LIBSPE2
		stopinfo.result.spe_exit_code); // LIBSPE2
        return -1;
  }

}
