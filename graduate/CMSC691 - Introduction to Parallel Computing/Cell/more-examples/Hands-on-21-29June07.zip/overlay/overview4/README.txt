Try out SPU compiler overlay support:

Get a xlc compiler coming with SDK 2.0
Assume the compiler is installed at /opt/ibmcmp/xlc/8.1/bin/.

To invoke overlay support, use -qipa=overlay option.

An example: 

/opt/ibmcmp/xlc/8.1/bin/spuxlc -qipa=overlay  -qdebug=ninline:tracetpo  test.c -o test

I used two extra options here. I used ninline to disable inlining since this program is too simple and compiler will inline all functions otherwise. I used tracetpo to dump information including partition information. Each code partition corresponds to an overlay segment. The partition information for the above command looks like:

Encode Partition [|
  Partition #0:
    main
    test4
    test6
    test5
    test1
    test2
    test3
|]

That is, all functions are put into one partition, and so one overlay segment.

Execution output:
In entry_event_hook segment=0x00000001 entry-address=0x00002e80
_ovly_buf_table[00000001]=00000000
In dma_event_hook vma=0x00002ac0 ea=00000000f7fc7bc0 sz=00000480
In debug_event_hook link-register=0x000002f4 00000000 0000010c 00000001
_ovly_buf_table[00000001]=00000001
test1
test2
test3
test4
test5
test6

===================================================================================================================

There are several ways to guide the compiler partitioning using -qipa=partition option.
-qipa=partition=minute will give minute partitioning. In most cases, it means each function will have its own partition.

/opt/ibmcmp/xlc/8.1/bin/spuxlc -qipa=overlay  -qipa=partition=minute -qdebug=ninline:tracetpo  test.c -o test

will partition the program as below:

Encode Partition [|
  Partition #0:
    main
|]
Encode Partition [|
  Partition #1:
    test4
|]
Encode Partition [|
  Partition #2:
    test6
|]
Encode Partition [|
  Partition #3:
    test5
|]
Encode Partition [|
  Partition #4:
    test1
|]
Encode Partition [|
  Partition #5:
    test2
|]
Encode Partition [|
  Partition #6:
    test3
|]

Execution output:
In entry_event_hook segment=0x00000001 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000000
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5d00 sz=000000c0
In debug_event_hook link-register=0x00000354 00000000 0000010c 00000001
_ovly_buf_table[00000001]=00000001
In entry_event_hook segment=0x00000005 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000001
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6000 sz=000000c0
In debug_event_hook link-register=0x00000354 00000001 00002b2c 00000005
_ovly_buf_table[00000001]=00000005
test1
In entry_event_hook segment=0x00000006 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000005
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6100 sz=000000c0
In debug_event_hook link-register=0x00000354 00000005 00002b54 00000006
_ovly_buf_table[00000001]=00000006
test2
In entry_event_hook segment=0x00000007 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000006
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6200 sz=00000080
In debug_event_hook link-register=0x00000354 00000006 00002b54 00000007
_ovly_buf_table[00000001]=00000007
test3
In entry_event_hook segment=0x00000006 entry-address=0x00002b54
_ovly_buf_table[00000001]=00000007
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6100 sz=000000c0
In debug_event_hook link-register=0x00000354 00000006 00000354 00000006
_ovly_buf_table[00000001]=00000006
In entry_event_hook segment=0x00000005 entry-address=0x00002b54
_ovly_buf_table[00000001]=00000006
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6000 sz=000000c0
In debug_event_hook link-register=0x00000354 00000005 00000354 00000005
_ovly_buf_table[00000001]=00000005
In entry_event_hook segment=0x00000001 entry-address=0x00002b2c
_ovly_buf_table[00000001]=00000005
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5d00 sz=000000c0
In debug_event_hook link-register=0x00000354 00000001 00000354 00000001
_ovly_buf_table[00000001]=00000001
In entry_event_hook segment=0x00000002 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000001
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5e00 sz=000000c0
In debug_event_hook link-register=0x00000354 00000001 00002b54 00000002
_ovly_buf_table[00000001]=00000002
test4
In entry_event_hook segment=0x00000004 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000002
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5f80 sz=00000080
In debug_event_hook link-register=0x00000354 00000002 00002b54 00000004
_ovly_buf_table[00000001]=00000004
test5
In entry_event_hook segment=0x00000002 entry-address=0x00002b54
_ovly_buf_table[00000001]=00000004
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5e00 sz=000000c0
In debug_event_hook link-register=0x00000354 00000002 00000354 00000002
_ovly_buf_table[00000001]=00000002
In entry_event_hook segment=0x00000003 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000002
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5f00 sz=00000080
In debug_event_hook link-register=0x00000354 00000002 00002b7c 00000003
_ovly_buf_table[00000001]=00000003
test6
In entry_event_hook segment=0x00000002 entry-address=0x00002b7c
_ovly_buf_table[00000001]=00000003
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5e00 sz=000000c0
In debug_event_hook link-register=0x00000354 00000002 00000354 00000002
_ovly_buf_table[00000001]=00000002
In entry_event_hook segment=0x00000001 entry-address=0x00002b54
_ovly_buf_table[00000001]=00000002
In dma_event_hook vma=0x00002b00 ea=00000000f7fc5d00 sz=000000c0
In debug_event_hook link-register=0x00000354 00000001 00000354 00000001
_ovly_buf_table[00000001]=00000001

===================================================================================================================

You can also use -qipa=partition=#### to specify the maximum partition size. For example, -qipa=partition=8192. Compiler only estimates code size now and the estimation is very rough. The compiler tends to give pessimistic estimations.

/opt/ibmcmp/xlc/8.1/bin/spuxlc -qipa=overlay  -qipa=partition=8192 -qdebug=ninline:tracetpo  test.c -o test

The partitioning results:

Encode Partition [|
  Partition #0:
    main
    test1
|]
Encode Partition [|
  Partition #1:
    test4
|]
Encode Partition [|
  Partition #2:
    test6
    test5
|]
Encode Partition [|
  Partition #3:
    test2
    test3
|]

Execution output:
In entry_event_hook segment=0x00000001 entry-address=0x00002bc0
_ovly_buf_table[00000001]=00000000
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6c80 sz=00000180
In debug_event_hook link-register=0x00000334 00000000 0000010c 00000001
_ovly_buf_table[00000001]=00000001
test1
In entry_event_hook segment=0x00000004 entry-address=0x00002b80
_ovly_buf_table[00000001]=00000001
In dma_event_hook vma=0x00002b00 ea=00000000f7fc7000 sz=00000140
In debug_event_hook link-register=0x00000334 00000001 00002b54 00000004
_ovly_buf_table[00000001]=00000004
test2
test3
In entry_event_hook segment=0x00000001 entry-address=0x00002b54
_ovly_buf_table[00000001]=00000004
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6c80 sz=00000180
In debug_event_hook link-register=0x00000334 00000001 00000334 00000001
_ovly_buf_table[00000001]=00000001
In entry_event_hook segment=0x00000002 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000001
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6e00 sz=000000c0
In debug_event_hook link-register=0x00000334 00000001 00002c14 00000002
_ovly_buf_table[00000001]=00000002
test4
In entry_event_hook segment=0x00000003 entry-address=0x00002b00
_ovly_buf_table[00000001]=00000002
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6f00 sz=00000100
In debug_event_hook link-register=0x00000334 00000002 00002b54 00000003
_ovly_buf_table[00000001]=00000003
test5
In entry_event_hook segment=0x00000002 entry-address=0x00002b54
_ovly_buf_table[00000001]=00000003
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6e00 sz=000000c0
In debug_event_hook link-register=0x00000334 00000002 00000334 00000002
_ovly_buf_table[00000001]=00000002
In entry_event_hook segment=0x00000003 entry-address=0x00002b80
_ovly_buf_table[00000001]=00000002
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6f00 sz=00000100
In debug_event_hook link-register=0x00000334 00000002 00002b7c 00000003
_ovly_buf_table[00000001]=00000003
test6
In entry_event_hook segment=0x00000002 entry-address=0x00002b7c
_ovly_buf_table[00000001]=00000003
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6e00 sz=000000c0
In debug_event_hook link-register=0x00000334 00000002 00000334 00000002
_ovly_buf_table[00000001]=00000002
In entry_event_hook segment=0x00000001 entry-address=0x00002c14
_ovly_buf_table[00000001]=00000002
In dma_event_hook vma=0x00002b00 ea=00000000f7fc6c80 sz=00000180
In debug_event_hook link-register=0x00000334 00000001 00000334 00000001
_ovly_buf_table[00000001]=00000001

===================================================================================================================

You can also fully guide the compiler partitioning by using -qipa=overlayproc=proclist. For example, if you want to partition main, test1, test2, test3 to one partition, but partition the other functions into another partition, use the following command:

/opt/ibmcmp/xlc/8.1/bin/spuxlc -qipa=overlay -qipa=overlayproc=main,test1,test2,test3:test4,test5,test6 -qdebug=ninline:tracetpo  test.c -o test

The functions in the same partition are separated by comma. Different partitions are separated by colon.

Execution output:
In entry_event_hook segment=0x00000002 entry-address=0x00002cc0
_ovly_buf_table[00000001]=00000000
In dma_event_hook vma=0x00002ac0 ea=00000000f7fc7dc0 sz=000002c0
In debug_event_hook link-register=0x00000304 00000000 0000010c 00000002
_ovly_buf_table[00000001]=00000002
test1
test2
test3
In entry_event_hook segment=0x00000001 entry-address=0x00002bc0
_ovly_buf_table[00000001]=00000002
In dma_event_hook vma=0x00002ac0 ea=00000000f7fc7bc0 sz=000001c0
In debug_event_hook link-register=0x00000304 00000002 00002d14 00000001
_ovly_buf_table[00000001]=00000001
test4
test5
test6
In entry_event_hook segment=0x00000002 entry-address=0x00002d14
_ovly_buf_table[00000001]=00000001
In dma_event_hook vma=0x00002ac0 ea=00000000f7fc7dc0 sz=000002c0
In debug_event_hook link-register=0x00000304 00000002 00000304 00000002
_ovly_buf_table[00000001]=00000002

===================================================================================================================

You can also specify some functions you would like to stay in the local storage all the time. The option is -qipa=nooverlayproc, for example:

/opt/ibmcmp/xlc/8.1/bin/spuxlc -qipa=overlay -qipa=nooverlayproc=main -qdebug=ninline:tracetpo  test.c -o test

Execution output:
In entry_event_hook segment=0x00000001 entry-address=0x00002cc0
_ovly_buf_table[00000001]=00000000
In dma_event_hook vma=0x00002b80 ea=00000000f7fc7c80 sz=000003c0
In debug_event_hook link-register=0x000003e4 00000000 0000026c 00000001
_ovly_buf_table[00000001]=00000001
test1
test2
test3
In entry_event_hook segment=0x00000001 entry-address=0x00002e80
_ovly_buf_table[00000001]=00000001
test4
test5
test6

===================================================================================================================

You can also mix up options shown above. Hopefully they still work :)
