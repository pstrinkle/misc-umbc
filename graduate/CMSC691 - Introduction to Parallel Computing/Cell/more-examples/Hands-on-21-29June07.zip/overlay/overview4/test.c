#include <stdio.h>

int test1() {
  printf("test1\n");
  test2();
}

int test2() {
  printf("test2\n");
  test3();
}

int test3() {
  printf("test3\n");
}

int test5() {
  printf("test5\n");
}

int test6() {
  printf("test6\n");
}

int test4() {
  printf("test4\n");
  test5();
  test6();
}

int main() {
  test1();
  test4();
}
