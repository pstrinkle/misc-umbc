#include <stdio.h>

int main(unsigned long long speid, unsigned long long argp, unsigned long long envp)
{
	printf("Hello World!\n");
	return 0;
}
