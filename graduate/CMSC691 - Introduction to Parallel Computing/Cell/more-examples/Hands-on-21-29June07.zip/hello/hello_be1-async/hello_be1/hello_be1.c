#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <libspe2.h>
#include <pthread.h>

// Structure for an SPE thread
typedef struct ppu_pthread_data{
   spe_context_ptr_t context;
   pthread_t pthread;
   unsigned int entry;
   unsigned int flags;
   void *argp;
   void *envp;
   spe_stop_info_t stopinfo;
}  ppu_pthread_data_t;

// pthread function to run the SPE context 
void *ppu_pthread_function(void *arg)
{
   ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
   int rc;
       rc = spe_context_run(datap->context, &datap->entry, datap->flags, datap->argp, datap->envp, &datap->stopinfo);
   pthread_exit(NULL);
} 

extern spe_program_handle_t hello_spu;

int main(void)
{

   ppu_pthread_data_t data;
   data.context = spe_context_create(0, NULL);
   spe_program_load(data.context, &hello_spu);
   data.entry = SPE_DEFAULT_ENTRY;
   data.flags = 0;
   data.argp = NULL;
   data.envp = NULL;
   pthread_create(&data.pthread, NULL, &ppu_pthread_function, &data);
   pthread_join(data.pthread, NULL);
   spe_context_destroy(data.context);
   return 0;
}
