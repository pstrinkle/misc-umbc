/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <sys/mman.h>
#include <stdio.h>
//#include <libspe.h>
#include <pthread.h>
#include "string.h"
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <fenv.h>
#include <sys/types.h>
#include <errno.h>
#include <malloc_align.h>
#include <math.h>
#include <sys/time.h>

#include "alf.h"
#include "fft16M.h"

extern spe_program_handle_t spu_fft_stage;

int GenDMAInputLst(alf_wb_handle_t wb_handle, FFTPARAM *myFFTPara);
int GenDMAOutputLst(alf_wb_handle_t wb_handle, FFTPARAM *myFFTPara);

/* The path of input data file */
char *mem_file = "/huge/fft_mem.bin";
char *mem_addr0 = NULL;
char *mem_addr1 = NULL;

float *ar, *ai, *br, *bi;

int GenDMAInputLst(alf_wb_handle_t wb_handle, FFTPARAM *myFFTPara)
{
  int  k;
  unsigned int wr, wi;

  wr = (unsigned int)myFFTPara->pInputDataArrayR;
  wi = (unsigned int)myFFTPara->pInputDataArrayI;
  wr += (((myFFTPara->nDMA << 8) + (myFFTPara->nSPU << 5)) << 2);
  wi += (((myFFTPara->nDMA << 8) + (myFFTPara->nSPU << 5)) << 2);

  for (k=0; k<256; ++k) {
    alf_wb_add_io_buffer(wb_handle, (void *)wr, 128, ALF_DATA_BYTE, ALF_BUFFER_INPUT);
    wr += 262144;

    alf_wb_add_io_buffer(wb_handle, (void *)wi, 128, ALF_DATA_BYTE, ALF_BUFFER_INPUT);
    wi += 262144;
  }
  return 0;
}

unsigned int q_mirror_array[64] =
{
  0x00, 0x20, 0x10, 0x30,
  0x08, 0x28, 0x18, 0x38,
  0x04, 0x24, 0x14, 0x34,
  0x0c, 0x2c, 0x1c, 0x3c,
  0x02, 0x22, 0x12, 0x32,
  0x0a, 0x2a, 0x1a, 0x3a,
  0x06, 0x26, 0x16, 0x36,
  0x0e, 0x2e, 0x1e, 0x3e,
  0x01, 0x21, 0x11, 0x31,
  0x09, 0x29, 0x19, 0x39,
  0x05, 0x25, 0x15, 0x35,
  0x0d, 0x2d, 0x1d, 0x3d,
  0x03, 0x23, 0x13, 0x33,
  0x0b, 0x2b, 0x1b, 0x3b,
  0x07, 0x27, 0x17, 0x37,
  0x0f, 0x2f, 0x1f, 0x3f
};

#define fill_mirror_write_list(_shift) {                                       \
  for( k = 0; k < 64; k++)                                                     \
  {                                                                            \
    m0 = q_mirror_array[k];                                                    \
    m1 = m0 | b0;                                                              \
    m2 = m0 | b1;                                                              \
    m3 = m1 | b1;                                                              \
    m0 = m0 << _shift;                                                         \
    m1 = m1 << _shift;                                                         \
    m2 = m2 << _shift;                                                         \
    m3 = m3 << _shift;                                                         \
    alf_wb_add_io_buffer(wb_handle, (void *)(m0+wr), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
    alf_wb_add_io_buffer(wb_handle, (void *)(m0+wi), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
    alf_wb_add_io_buffer(wb_handle, (void *)(m1+wr), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
    alf_wb_add_io_buffer(wb_handle, (void *)(m1+wi), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
    alf_wb_add_io_buffer(wb_handle, (void *)(m2+wr), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
    alf_wb_add_io_buffer(wb_handle, (void *)(m2+wi), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
    alf_wb_add_io_buffer(wb_handle, (void *)(m3+wr), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
    alf_wb_add_io_buffer(wb_handle, (void *)(m3+wi), 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT); \
  }                                                                            \
}

int GenDMAOutputLst(alf_wb_handle_t wb_handle, FFTPARAM *myFFTPara)
{
  int  k;
  unsigned int wr, wi;
  unsigned int b0=0x80, b1=0x40;
  unsigned int m0, m1, m2, m3;

  switch (myFFTPara->nStage)
  {
    case 1:
      wr = (unsigned int)myFFTPara->pOutputDataArrayR;
      wi = (unsigned int)myFFTPara->pOutputDataArrayI;
      wr += (((myFFTPara->nDMA << 16) + (myFFTPara->nSPU << 13)) << 2);
      wi += (((myFFTPara->nDMA << 16) + (myFFTPara->nSPU << 13)) << 2);

      for( k = 0; k < 256; k++)
      {
        alf_wb_add_io_buffer(wb_handle, (void *)wr, 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT);
        wr += 128;

        alf_wb_add_io_buffer(wb_handle, (void *)wi, 128, ALF_DATA_BYTE, ALF_BUFFER_OUTPUT);
        wi += 128;
      }

      break;
    case 2:
      wr = (unsigned int)myFFTPara->pOutputDataArrayR;
      wi = (unsigned int)myFFTPara->pOutputDataArrayI;
      wr += (((myFFTPara->nDMA << 16) + (myFFTPara->nSPU << 5)) << 2);
      wi += (((myFFTPara->nDMA << 16) + (myFFTPara->nSPU << 5)) << 2);

      fill_mirror_write_list(10);
      break;
    case 3:
      wr = (unsigned int)myFFTPara->pOutputDataArrayR;
      wi = (unsigned int)myFFTPara->pOutputDataArrayI;
      wr += (((myFFTPara->nDMA << 8) + (myFFTPara->nSPU << 5)) << 2);
      wi += (((myFFTPara->nDMA << 8) + (myFFTPara->nSPU << 5)) << 2);

      fill_mirror_write_list(18);
      break;
  }

  return 0;
}

#define MALLOC_BIG_ARRAYS {                                  \
  /* bottom 11 bits of ar and br addrs should be 0x000 */    \
  /* bottom 11 bits of ai and bi addrs shuold be 0x400 */    \
  int ar_raw, ai_raw, br_raw, bi_raw;                        \
  ar_raw = (int) malloc(0x4000800);                          \
  br_raw = (int) malloc(0x4000800);                          \
  ai_raw = (int) malloc(0x4000800);                          \
  bi_raw = (int) malloc(0x4000800);                          \
  if ((ar_raw * br_raw * ai_raw * bi_raw) == 0) {            \
    printf("ERROR: unable to malloc.  Exiting...\n");        \
    return(-1);                                              \
  }                                                          \
  ar_raw += 0x3ff;                                           \
  br_raw += 0x3ff;                                           \
  ai_raw += 0x3ff;                                           \
  bi_raw += 0x3ff;                                           \
  ar_raw &= ~0x3ff;                                          \
  br_raw &= ~0x3ff;                                          \
  ai_raw &= ~0x3ff;                                          \
  bi_raw &= ~0x3ff;                                          \
  ar_raw += (ar_raw & 0x400);                                \
  br_raw += (br_raw & 0x400);                                \
  ai_raw += 0x400 - (ai_raw & 0x400);                        \
  bi_raw += 0x400 - (bi_raw & 0x400);                        \
  ar = (float *) ar_raw;                                     \
  br = (float *) br_raw;                                     \
  ai = (float *) ai_raw;                                     \
  bi = (float *) bi_raw;                                     \
}

float trigfunc(int in) {
   double x;
   x = ((double) in) * 6.2831853071796 / ((double) NP);
   return ((float) (7.0 + sin(x) + cos(2*x)));
}

void Usage(char *argv[])
{
  fprintf (stderr, "Usage %s [-c cycles -n num_spes -m multi_times -P]\n\n", argv[0]);
  exit(-1);
}

int main(int argc, char *argv[])
{
  int i;
  int fmem;
  int ncycles, num_spes;
  unsigned int multi_times;
  float lo_real, hi_real, lo_imag, hi_imag;
  FFTPARAM myFFTPara __attribute__((aligned(128)));
  int iDMA, iSPU, iStage;
  int is_SPU_DMA = 1;
  int ch;

  alf_handle_t alf_handle;
  alf_task_info_t tinfo;
  alf_task_handle_t task_handle;
  alf_wb_handle_t wb_handle;
  alf_wb_sync_handle_t sync_handle;
  alf_task_info_t_CBEA    cbe_ti;

  struct timeval now, last;
  struct timezone tz;

  ncycles = 1;
  num_spes = 8;
  is_SPU_DMA = 1;
  multi_times = 256;
  
  /*process input parameters*/
  while ((ch = getopt (argc, argv, "c:n:m:P")) != -1)
  {
      switch (ch)
      {
        case 'c':
          if (sscanf(optarg, "%d", &ncycles) != 1)
            Usage(argv);
          break;
        case 'n':
          if (sscanf(optarg, "%d", &num_spes) != 1)
            Usage(argv);
          break;
       case 'm':
          if (sscanf(optarg, "%d", &multi_times) != 1)
            Usage(argv);
          break;
        case 'P':
          is_SPU_DMA = 0;
          break;
        default:
          Usage(argv);
          break;
      }
  }

  if ((ncycles <= 0) || (num_spes < 0) || (num_spes > 16) || (multi_times > 256))
    Usage(argv);

  /* Create a large contiguous memory buffer by allocating a large
   * page (or more). Large page memory will also reduce the TLB thrashing.
   */
  if ((fmem = open(mem_file, O_CREAT | O_RDWR, 0755)) == -1) {
    printf("WARNING: unable to open file %s (errno=%d). Using malloc heap.\n", mem_file, errno);
    MALLOC_BIG_ARRAYS
  } else {
    /* Delete file so that huge pages will get freed on program termination.
     */
    remove(mem_file);
    
    mem_addr0 = (char *) mmap(0, 0x9000000, PROT_READ | PROT_WRITE, MAP_SHARED, fmem, 0);
    
    /* touch each of these nine large pages */
    mem_addr0[0x0800000] = (char) 0;
    mem_addr0[0x1800000] = (char) 0;	
    mem_addr0[0x2800000] = (char) 0;
    mem_addr0[0x3800000] = (char) 0;
    mem_addr0[0x4800000] = (char) 0;
    mem_addr0[0x5800000] = (char) 0;
    mem_addr0[0x6800000] = (char) 0;
    mem_addr0[0x7800000] = (char) 0;
    mem_addr0[0x8800000] = (char) 0;

    mem_addr1 = (char *) mmap(0, 0x9000000, PROT_READ | PROT_WRITE, MAP_SHARED, fmem, 0x9000000);
    
    /* touch each of these nine large pages */
    mem_addr1[0x0800000] = (char) 0;
    mem_addr1[0x1800000] = (char) 0;
    mem_addr1[0x2800000] = (char) 0;
    mem_addr1[0x3800000] = (char) 0;
    mem_addr1[0x4800000] = (char) 0;
    mem_addr1[0x5800000] = (char) 0;
    mem_addr1[0x6800000] = (char) 0;
    mem_addr1[0x7800000] = (char) 0;
    mem_addr1[0x8800000] = (char) 0;
    
    if (mem_addr0 == MAP_FAILED || mem_addr1 == MAP_FAILED) {
    	
      printf("ERROR: unable to mmap file %s (errno=%d). Using malloc heap.\n", mem_file, errno);
      close(fmem);
      MALLOC_BIG_ARRAYS
    }
    else {
      ar = (float *) (mem_addr0+0x0000000);
      br = (float *) (mem_addr0+0x4000000);
      ai = (float *) (mem_addr1+0x0000400);
      bi = (float *) (mem_addr1+0x4000400);
    }
  }

#ifndef SIM_RUN 
  printf("big array addrs: %x %x %x %x\n", (int) ar, (int) br, (int) ai, (int) bi);
  printf("loading big array A\n"); fflush(stdout);
  
  for (i=0; i<NP; ++i) {
    if ((i&0xfffff) == 0) { printf("%x of %x done\n", i, NP); fflush(stdout); }
    ai[i] = 0.0f;
    ar[i] = trigfunc(i);
  }
#endif

  /**************************/
  /* Init task server       */
  /**************************/
  gettimeofday(&last, &tz);

  /*begin alf routine*/
  alf_configure(NULL);

  alf_init(&alf_handle, num_spes, ALF_INIT_PERSIST);

  /*filling out the task info structure*/
  cbe_ti.spe_task_image = &spu_fft_stage;
  cbe_ti.max_stack_size = 4096;
  tinfo.p_task_info = &cbe_ti;
  tinfo.parm_ctx_buffer_size = sizeof(myFFTPara);
  tinfo.task_context_buffer_read_only_size = 0;
  tinfo.task_context_buffer_writable_size = 0; 
  /*set each buffer size*/
  tinfo.input_buffer_size = 65536;
  tinfo.overlapped_buffer_size = 0;
  tinfo.output_buffer_size = 65536;
  tinfo.dt_list_entries = 512;

  /* this task is set to generate DMA lists on control node or spu side*/
  if (is_SPU_DMA == 0)
  {
    tinfo.task_attr = 0;
  }
  else
  {
    tinfo.task_attr = ALF_TASK_ATTR_PARTITION_ON_ACCEL;
  }

  /*creating task*/
  alf_task_create(&task_handle, alf_handle, (void*)&tinfo);

  /******************************/
  /* Prepare task queues for Stage 1,2,3 */
  /******************************/
  for (iStage = 0; iStage < STAGE_NUM; iStage++)
  {
    switch (iStage)
    {
      case GRP_STAGE_1:
        myFFTPara.pInputDataArrayR = (void *)ar;
        myFFTPara.pInputDataArrayI = (void *)ai;
        myFFTPara.pOutputDataArrayR = (void *)br;
        myFFTPara.pOutputDataArrayI = (void *)bi;
        myFFTPara.nStage = 1;
        break;

      case GRP_STAGE_2:
        myFFTPara.pInputDataArrayR = (void *)br;
        myFFTPara.pInputDataArrayI = (void *)bi;
        myFFTPara.pOutputDataArrayR = (void *)ar;
        myFFTPara.pOutputDataArrayI = (void *)ai;
        myFFTPara.nStage = 2;
        break;

      case GRP_STAGE_3:
        myFFTPara.pInputDataArrayR = (void *)ar;
        myFFTPara.pInputDataArrayI = (void *)ai;
        myFFTPara.pOutputDataArrayR = (void *)ar;
        myFFTPara.pOutputDataArrayI = (void *)ai;
        myFFTPara.nStage = 3;
        break;
    }

    /*creating wb and add params*/
#ifdef SINGLE_USE
    for (iDMA = 0; iDMA < DMANUM_FOR_SPU; iDMA++)
    {
      for (iSPU = 0; iSPU < 8; iSPU++)
      {
        myFFTPara.nDMA = iDMA;
        myFFTPara.nFFTFlag = IS_FFT;
        myFFTPara.nSPU = iSPU;
        myFFTPara.is_SPU_DMA = is_SPU_DMA;

        alf_wb_create(&wb_handle, task_handle, ALF_WB_SINGLE, 0);
        if (is_SPU_DMA == 0)
        {
          GenDMAInputLst(wb_handle, &myFFTPara);
          GenDMAOutputLst(wb_handle, &myFFTPara);
        }
        alf_wb_add_param(wb_handle, (void *)(&myFFTPara), sizeof(myFFTPara), ALF_DATA_BYTE, 0);
        alf_wb_enqueue(wb_handle);
      }
    }
#endif

#ifdef MULTI_USE   
    for (iSPU = 0; iSPU < 8; iSPU ++)
    {
      for (iDMA = 0; iDMA < DMANUM_FOR_SPU; iDMA += multi_times)
      {
        myFFTPara.nDMA = iDMA;
        myFFTPara.nFFTFlag = IS_FFT;
        myFFTPara.nSPU = iSPU;
        myFFTPara.is_SPU_DMA = is_SPU_DMA;

        alf_wb_create(&wb_handle, task_handle, ALF_WB_MULTI, multi_times);

       if (is_SPU_DMA == 0)
        {
          GenDMAInputLst(wb_handle, &myFFTPara);
          GenDMAOutputLst(wb_handle, &myFFTPara);
        }
        alf_wb_add_param(wb_handle, (void *)(&myFFTPara), sizeof(myFFTPara), ALF_DATA_BYTE, 0);
        alf_wb_enqueue(wb_handle);
      }
    }
#endif

    /* add a sync point so that all the workblocks has been processed before issue the next workblocks */
    alf_wb_sync(&sync_handle, task_handle, ALF_SYNC_BARRIER, NULL, NULL, 0);
  }//iStage

  alf_wb_sync_wait(sync_handle, -1);

  gettimeofday(&now, &tz);
  printf("Overall passed time for FFT is %ld us ===\n",
           (long)(now.tv_sec - last.tv_sec) * 1000000 +
               (long)(now.tv_usec - last.tv_usec));

#ifdef FULLRUN
  printf("Checking frequency results...\n"); fflush(stdout);

  for (i=0; i<NP; ++i)
  {
    if (ar[i] < -0.002 || ar[i] > 0.002 || ai[i] < -0.002 || ai[i] > 0.002)
    {
      printf("a[%d] = (%10.3f, %9.3f)\n", i, ar[i], ai[i]);
    }
  }
#endif

  gettimeofday(&last, &tz);

  /******************************/
  /* Prepare task queues for Stage 1,2,3 */
  /******************************/
  for (iStage = 0; iStage < STAGE_NUM; iStage++)
  {
    switch (iStage)
    {
      case GRP_STAGE_1:
        myFFTPara.pInputDataArrayR = (void *)ar;
        myFFTPara.pInputDataArrayI = (void *)ai;
        myFFTPara.pOutputDataArrayR = (void *)br;
        myFFTPara.pOutputDataArrayI = (void *)bi;
        myFFTPara.nStage = 1;
        break;

      case GRP_STAGE_2:
        myFFTPara.pInputDataArrayR = (void *)br;
        myFFTPara.pInputDataArrayI = (void *)bi;
        myFFTPara.pOutputDataArrayR = (void *)ar;
        myFFTPara.pOutputDataArrayI = (void *)ai;
        myFFTPara.nStage = 2;
        break;

      case GRP_STAGE_3:
        myFFTPara.pInputDataArrayR = (void *)ar;
        myFFTPara.pInputDataArrayI = (void *)ai;
        myFFTPara.pOutputDataArrayR = (void *)ar;
        myFFTPara.pOutputDataArrayI = (void *)ai;
        myFFTPara.nStage = 3;
        break;
    }

#ifdef SINGLE_USE
    for (iDMA = 0; iDMA < DMANUM_FOR_SPU; iDMA++)
    {
      for (iSPU = 0; iSPU < 8; iSPU++)
      {
        myFFTPara.nDMA = iDMA;
        myFFTPara.nFFTFlag = IS_IFFT;
        myFFTPara.nSPU = iSPU;
        myFFTPara.is_SPU_DMA = is_SPU_DMA;

        alf_wb_create(&wb_handle, task_handle, ALF_WB_SINGLE, 0);
        if (is_SPU_DMA == 0)
        {
          GenDMAInputLst(wb_handle, &myFFTPara);
          GenDMAOutputLst(wb_handle, &myFFTPara);
        }
        alf_wb_add_param(wb_handle, (void *)(&myFFTPara), sizeof(myFFTPara), ALF_DATA_BYTE, 0);
        alf_wb_enqueue(wb_handle);
      }
    }
#endif

#ifdef MULTI_USE
    for (iSPU = 0; iSPU < 8; iSPU ++)
    {
      for (iDMA = 0; iDMA < DMANUM_FOR_SPU; iDMA += multi_times)
      {
        myFFTPara.nDMA = iDMA;
        myFFTPara.nFFTFlag = IS_IFFT;
        myFFTPara.nSPU = iSPU;
        myFFTPara.is_SPU_DMA = is_SPU_DMA;
        alf_wb_create(&wb_handle, task_handle, ALF_WB_MULTI, multi_times);

        if (is_SPU_DMA == 0)
        {
          GenDMAInputLst(wb_handle, &myFFTPara);
          GenDMAOutputLst(wb_handle, &myFFTPara);
        }
        alf_wb_add_param(wb_handle, (void *)(&myFFTPara), sizeof(myFFTPara), ALF_DATA_BYTE, 0);
        alf_wb_enqueue(wb_handle);
      }
    }
#endif

    /* add a sync point so that all the workblocks has been processed before issue the next workblocks */
    alf_wb_sync(&sync_handle, task_handle, ALF_SYNC_BARRIER, NULL, NULL, 0);
  }//iStage
  alf_wb_sync_wait(sync_handle, -1);

  gettimeofday(&now, &tz);

  alf_task_wait(task_handle, -1);
  alf_task_destroy(&task_handle);

  printf("Overall passed time for IFFT is %ld us ===\n",
           (long)(now.tv_sec - last.tv_sec) * 1000000 +
               (long)(now.tv_usec - last.tv_usec));

#ifdef FULLRUN
  printf("Now checking results...\n"); fflush(stdout);

  hi_real = -100.0;
  lo_real =  100.0;
  hi_imag = -100.0;
  lo_imag =  100.0;
  for (i=0; i<NP; ++i) {
    float x;
    x = trigfunc(i);
    if (ar[i] - x > hi_real) hi_real = ar[i] - x ;
    if (ar[i] - x < lo_real) lo_real = ar[i] - x ;
    if (ai[i]     > hi_imag) hi_imag = ai[i];
    if (ai[i]     < lo_imag) lo_imag = ai[i];
  }
  fprintf(stdout, "real err*r range = %f %f\n", lo_real, hi_real);
  fprintf(stdout, "imag err*r range = %f %f\n", lo_imag, hi_imag);
  if (lo_real < -0.00003 || hi_real > 0.00003 || lo_imag < -0.00003 || hi_imag > 0.00003)
  {
    fprintf(stderr, "ERROR: range of error values too large...\n");
    fflush(stderr);
    return -1;
  }
#endif
  /*end of alf routine*/
  alf_exit(&alf_handle, ALF_SHUTDOWN_WAIT);

  return 0;
}
