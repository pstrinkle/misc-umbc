/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* --------------------------------------------------------------- */
/* (C) Copyright 2001,2006,                                        */
/* International Business Machines Corporation,                    */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------- */
/* PROLOG END TAG LY                                             */
/***************************************************************
*   PPE side code.This case demonstrates overlay usage
***************************************************************/
//#include <libspe.h>
#include <time.h>
#include "alf.h"
#include "inverse_matrix_overlay.h"

#define MAX_SPUS  8
#define BUFFER_SIZE 64

extern spe_program_handle_t inverse_matrix_matrix_spu;

/*******generate matrix ****************************/
/* This function used to generate 8*8 sub block */
void row_preparation(float * row_p, int size)
{
        int i,j;

        row_p[0]=1.0f+(rand()%9)/10.0f;
        row_p[4*size+4]=1.0f+(rand()%9)/10.0f;

        /* initialize 4 element of first row */
        for (i=1;i<4;i++) {
                row_p[i]=1.0f+row_p[i-1];
                row_p[4*size+4+i]=1.0f+row_p[4*size+4+i-1];
        }
        /* initialize 3*4 element of first 4 rows,*/
        /* other elements in these 4 rows are zero */
        for(i=1;i<4;i++) {
                for(j=0;j<4;j++) {
                        row_p[j+i*size]=row_p[j] * row_p[j+(i-1)*size];
                }
        }

       /* initialize 5-8 rows in total 4*8 elements */
        for(i=5;i<8;i++) {
                for(j=4;j<8;j++) {
                        row_p[j+i*size]=row_p[j + 4*size] * row_p[j+(i-1)*size];
                }
        }

        for(i=5;i<8;i++) {
                for(j=0;j<4;j++) {
                        row_p[j+i*size]=1.0f+(rand()%9)/10.0f;
                }
        }
}

/* This function prepare special matrix for inversement
 * How the matrix is generated is demonstrated in README */
void matrix_preparation(float *matrix_p, int size)
{  
        int i;
        float * row_p;

        for(i=0;i<size*size;i++) {
                matrix_p[i]=0;
        }
    
        for(i=0;i<size;i=i+8) {
                row_p=&matrix_p[i*size+i];
                row_preparation(row_p, size);
        }

}

/* This function performs result verification, multiply original 
 * matrix and inverse result to indentify whether it is a unit matrix */
int matrix_verify(float *matrix_p, float *matrix_bk, int size)
{
        int i,j,k;
        float *unit_p=malloc_align(size*size*sizeof(int),7);
        float *mul_p=malloc_align(size*size*sizeof(int),7);
        int ret=0;

        /* generate unit matrix */
        for(i=0;i<size;i++) {
                for(j=0;j<size;j++) {
                        if(i==j) unit_p[i*size+j]=1.0f;
                        else    unit_p[i*size+j]=0.0f;
                        mul_p[i*size+j]=0.0f;
                }
        }
        /* multiply the original matrix with inverse result matrix */
        for(i=0;i<size;i++) {
                for(j=0;j<size;j++) {
                        for(k=0;k<size;k++)
                        mul_p[i*size+j]+=matrix_bk[i*size+k]*matrix_p[k*size+j];
                }
        }
        /*compare with unit matrix*/
        for(i=0;i<size;i++) {
                for(j=0;j<size;j++) {
                        if(fabs(mul_p[i*size+j]-unit_p[i*size+j])>0.005f) 
                                ret ++;
                }
        }

        if(ret!=0)
                printf("verify failed %d\n",ret);
        else
                printf("verify successful\n");
        return ret;   
}

int main(int argc, char* argv[])
{

        int i,instances;
        int buffer_size=BUFFER_SIZE;
  
        int verify=0;
        int spus=1;      
        srand( (unsigned)time( NULL ) ); 

        alf_handle_t alf_handle=ALF_NULL_HANDLE;
        alf_task_info_t tinfo;
        alf_task_handle_t task_handle=ALF_NULL_HANDLE;
        alf_wb_handle_t wb_handle=ALF_NULL_HANDLE;
        alf_task_info_t_CBEA    cbe_ti;

        udata_t my_udata __attribute__ ((aligned (128)));

        float * matrix_p=malloc_align(buffer_size*buffer_size*sizeof(float),7);
        float * matrix_bk=malloc_align(buffer_size*buffer_size*sizeof(float),7);
        if(matrix_p==NULL ||matrix_bk==NULL)
        {
            printf("matrix malloc failed \n");
            return -1;
        }    

        /* prepare matrix for inverse */
        matrix_preparation(matrix_p, buffer_size);
        memcpy(matrix_bk, matrix_p, buffer_size*buffer_size*sizeof(float));

        my_udata.a=matrix_p;
        my_udata.msize=buffer_size;
        
        /* begin alf routine */
        alf_configure(NULL);
        alf_init(&alf_handle, spus, ALF_INIT_COMPROMISE);

        /* filling out the task info structure */
        cbe_ti.spe_task_image = &inverse_matrix_matrix_spu;
        cbe_ti.max_stack_size = 4096;
        tinfo.p_task_info = &cbe_ti;
        tinfo.task_context_buffer_read_only_size=0;
        tinfo.task_context_buffer_writable_size=0;
        tinfo.parm_ctx_buffer_size = sizeof(udata_t);
  
        /* set each buffer size */
        tinfo.input_buffer_size  =64*sizeof(float);
        tinfo.output_buffer_size =64*sizeof(float);
        tinfo.overlapped_buffer_size = 0;
        /* 8 dma transfer on spu side */
        tinfo.dt_list_entries = 8;                  
        /* this task is set to generate DMA lists on spu side */
        tinfo.task_attr = ALF_TASK_ATTR_PARTITION_ON_ACCEL;
  
        /* creating task */
        instances=alf_task_create(&task_handle, alf_handle, (void*)&tinfo);
        
        /* create wb and add param */
        for (i=0; i< buffer_size; i=i+8)  {
                my_udata.a =matrix_p+i*buffer_size+i;

                alf_wb_create(&wb_handle, task_handle, ALF_WB_SINGLE,0);
                /* Pass matrix pointer and size as parameter */
                alf_wb_add_param(wb_handle, (void *)&my_udata, sizeof(udata_t), ALF_DATA_BYTE, 0);
                alf_wb_enqueue(wb_handle);
        }
 
        /* alf task wait until wb processed */
        alf_task_wait(task_handle,-1);
        alf_task_destroy(&task_handle);
        /* end of alf routine */
        alf_exit(&alf_handle, ALF_SHUTDOWN_WAIT);
   
        /* result verify */
        verify=matrix_verify(matrix_p, matrix_bk,buffer_size);
         
        free_align(matrix_p);
        free_align(matrix_bk);
        return verify;
}


