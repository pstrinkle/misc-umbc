/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include "inverse_matrix4x4.h"

 
void matrix_inverse(float *a)
{
        vector float A[4] __attribute__ ((aligned (128))) ={
                (vector float) {a[0],a[1],a[2],a[3]},
                (vector float) {a[4],a[5],a[6],a[7]},
                (vector float) {a[8],a[9],a[10],a[11]},
                (vector float) {a[12],a[13],a[14],a[15]},};

       vector float B[4] __attribute__ ((aligned (128)));

       _inverse_matrix4x4(B, A);

        a[0]=spu_extract(B[0],0);a[1]=spu_extract(B[0],1);a[2]=spu_extract(B[0],2);a[3]=spu_extract(B[0],3);
        a[4]=spu_extract(B[1],0);a[5]=spu_extract(B[1],1);a[6]=spu_extract(B[1],2);a[7]=spu_extract(B[1],3);
        a[8]=spu_extract(B[2],0);a[9]=spu_extract(B[2],1);a[10]=spu_extract(B[2],2);a[11]=spu_extract(B[2],3);
        a[12]=spu_extract(B[3],0);a[13]=spu_extract(B[3],1);a[14]=spu_extract(B[3],2);a[15]=spu_extract(B[3],3);

}

void inverse_A(float *a)
{
        float b[4*4];

        get_block(a,b);
        matrix_inverse(b);
        put_block(b,a,1);
}

