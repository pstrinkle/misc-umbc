/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include "inverse_matrix_matrix_spu.h"

/* here is the location where the SPE begins execution, once its thread is created */
int alf_comp_kernel(void *p_task_context, void *p_parm_ctx_buffer,
                    void *p_input_buffer, void *p_output_buffer,
                    unsigned int current_count, unsigned int total_count )
{
        udata_t  * my_param=(udata_t *)p_parm_ctx_buffer;
        int size=my_param->msize; 
        float * a=(volatile float *) p_input_buffer;
        float *b=a+32;
        float *c=a+36;
        float *d=(volatile float *) p_output_buffer;
        int i;

        inverse_A(a);
        inverse_A(c);
        inverse_BCA(a,b,c);
        for(i=0;i<64;i++) {
                d[i]=a[i];
        }
   
        return 0;
}

int alf_prepare_input_list(void *p_task_context,
                           void *p_parm_ctx_buffer,
                           void *p_list_entries,
                           unsigned int current_count,
                           unsigned int total_count)
{
        addr64 ea;
        udata_t  * my_param=(udata_t *)p_parm_ctx_buffer;
        float * in_addr=my_param->a;
        int size=my_param->msize; 
        int i;
   
        ea.ui[0] = 0;
        ALF_DT_LIST_CREATE((alf_data_transfer_info_t *)p_list_entries,0);

        /* 8 dt_list for each row */
        for(i=0;i<8;i++) {
                ea.ui[1] =(unsigned int)in_addr+i*size*sizeof(float);
                ALF_DT_LIST_ADD_ENTRY(p_list_entries, 8, ALF_DATA_FLOAT, ea)
        }
        return 0;
}

int alf_prepare_output_list(void *p_task_context,
                            void *p_parm_ctx_buffer,
                            void *p_list_entries,
                            unsigned int current_count,
                            unsigned int total_count)
{   
        addr64 ea;
        udata_t  * my_param=(udata_t *)p_parm_ctx_buffer;
        float * in_addr=my_param->a;
        int size=my_param->msize; 
        int i;
   
        ea.ui[0] = 0;
        ALF_DT_LIST_CREATE((alf_data_transfer_info_t *)p_list_entries,0);

        /* 8 dt_list for each row */
        for(i=0;i<8;i++) {
                ea.ui[1] =(unsigned int)in_addr+i*size*sizeof(float);
                ALF_DT_LIST_ADD_ENTRY(p_list_entries, 8, ALF_DATA_FLOAT, ea)
        }
        return 0;
}

