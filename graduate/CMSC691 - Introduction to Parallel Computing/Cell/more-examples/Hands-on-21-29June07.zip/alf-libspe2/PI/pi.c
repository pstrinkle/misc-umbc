/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* ---------------------------------------------------------------- */
/* Compute PI by Buffon-Needle method based on ALF                  */
/*                                                                  */
/* ---------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <memory.h>
#include <time.h>

#include "alf.h"

#define MAXSPES		8
#define ERR_THRESHOLD	0.001
#define	WORKBLOCKS	3000
#define ITERATIONS	30000

/* This struct used to hold the result type */
typedef struct result_type
{
  double        value;          /* The return value */
  double pad;
} pi_result;

extern spe_program_handle_t alf_pi_spu;

pi_result result[MAXSPES] __attribute__ ((aligned (128)));

/* This function used to display the progress of computing PI */
int show_progress(alf_wb_sync_handle_t sync_handle, void* p_context)
{
    int *prog = (int *)p_context;

    fprintf(stdout, "\b\b\b\b\b");

    fprintf(stdout, "%2d%% ", *prog);
    switch ( (*prog)%4) {
        case 0:
            fprintf(stdout, "\\");
            break;

        case 1:
            fprintf(stdout, "|");
            break;

        case 2:
            fprintf(stdout, "/");
            break;

        case 3:
            fprintf(stdout, "-");
            break;

    }
    fflush(stdout);

    return 0;
}

int main(int argc, char *argv[])
{
    alf_handle_t alf_handle;
    alf_task_info_t tinfo;
    alf_task_handle_t task_handle;
    alf_wb_handle_t wb_handle;
    alf_wb_sync_handle_t sync_handle;
    alf_task_info_t_CBEA cbe_ti;
    alf_task_context_handle_t context_handle;

    int i, num_of_acce;
    int progress;
    double pi;
    unsigned int seed;
    int iter __attribute__ ((aligned (128)));
    
    /* begin alf routine */
    alf_configure(NULL);
    if (alf_init(&alf_handle, MAXSPES, ALF_INIT_COMPROMISE) < 0) {
        printf("failed to call alf_init\n");
        return -1;
    }

    /* init the task attribute */
    cbe_ti.spe_task_image = &alf_pi_spu;
    cbe_ti.max_stack_size = 512;
    tinfo.p_task_info = &cbe_ti;
    tinfo.parm_ctx_buffer_size = 16;
    tinfo.input_buffer_size = 0;
    tinfo.overlapped_buffer_size = 0;
    tinfo.output_buffer_size = 0;
    /* no data movement dma */
    tinfo.dt_list_entries = 0;                   

    /* global parameter for the workblocks */
    tinfo.task_context_buffer_read_only_size = 16;
    /* do data collection on every instances, so that we only need few result buffer. */
    tinfo.task_context_buffer_writable_size = 16;
    /* this task do not use io_buffer */
    tinfo.task_attr = 0;

    srand((unsigned int)time(NULL));
    iter = ITERATIONS;

    /* Issue task */
    num_of_acce = alf_task_create(&task_handle, alf_handle, &tinfo);

    /* create task context and add entry */
    for (i = 0; i < num_of_acce; i++) {
        alf_task_context_create(&context_handle, task_handle, 0);
        result[i].value = 0.0;
        /* Add read only context entry for global param */
        alf_task_context_add_entry(context_handle, &iter, 1, ALF_DATA_DOUBLE, ALF_TASK_CONTEXT_READ);

        /* Add writable context entry for result gathering */
        alf_task_context_add_entry(context_handle, &(result[i].value), 1, ALF_DATA_DOUBLE, ALF_TASK_CONTEXT_WRITABLE);
        alf_task_context_register(context_handle);
    }

    printf("Computing...     ");

    /* create wb and add param */
    for (i = 0; i < WORKBLOCKS; i++) {
        seed = rand();

        alf_wb_create(&wb_handle, task_handle, ALF_WB_SINGLE, 0);
        alf_wb_add_param(wb_handle, (void *)(&seed), 1, ALF_DATA_INT32, 0);
        alf_wb_enqueue(wb_handle);
        /* alf wb sync to call function show_progress */
        if ((i+1) % (WORKBLOCKS/100) == 0) {
            progress = ((i+1)*100)/WORKBLOCKS;
            alf_wb_sync(&sync_handle, task_handle, ALF_SYNC_NOTIFY, show_progress, &progress, sizeof(int));
        }
    }

    /* alf task wait until wb has been processed */
    alf_task_wait(task_handle, -1);
    alf_task_destroy(&task_handle);
    /* end of alf routine */
    alf_exit(&alf_handle, ALF_SHUTDOWN_WAIT);

    /* Get results */
    pi = 0.0;
    for ( i = 0; i < num_of_acce; i ++ ) {
        pi += result[i].value;
    }

    pi = pi / WORKBLOCKS;
    printf("\nPI = %f\n", pi);

    /* Check results */
    if (abs(pi - 3.14159) >= ERR_THRESHOLD) {
         printf("Get a wrong value of pi\n");
         return -1;
    }

    return 0;
}
