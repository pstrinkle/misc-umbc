/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>
#include <stdlib.h>
#include <alf.h>
#include "matrix_trans.h"


#define NUM_ROW		1024
#define NUM_COL		512

#define  H  128
#define  V  128

#define MY_ALIGN(_my_var_def_, _my_al_)  _my_var_def_  \
__attribute__((__aligned__(_my_al_)))

extern spe_program_handle_t  matrix_trans_spu;

MY_ALIGN(float mat_a[NUM_ROW][NUM_COL], 128);
MY_ALIGN(float mat_c[NUM_COL][NUM_ROW], 128);

/* This function perform matrix a c initialization */
void init_mat()
{
  int i, j;

  for (i = 0; i < NUM_COL; i++)
  {
    for (j = 0; j < NUM_ROW; j++)
    {
      mat_a[j][i] = j*NUM_COL + i; 
      mat_c[i][j] = 0.0f;
    }
  }
}



int main(void)
{
    alf_handle_t  half;
    alf_task_handle_t htask;
    alf_wb_handle_t     hwb;
    alf_task_info_t tinfo;
    alf_task_info_t_CBEA spe_tsk;
    trans_parms_t parm;
    int  X, Y, i, j, rc;
    unsigned int nodes;
   
    /* prepare data */
    init_mat();
    /* begin alf routine */
    alf_configure(NULL);

    rc = alf_query_system_info(ALF_INFO_NUM_ACCL_NODES, &nodes);
    if (rc < 0) {
        fprintf(stderr, "Failed to call alf_query_system_info.\n");
        return 1;
    } else if( nodes <= 0 ) {
        fprintf(stderr, "Cannot allocate spe to use.\n");
        return 1;
    }

    rc = alf_init(&half, nodes, ALF_INIT_PERSIST);
    if( rc <= 0) {
        fprintf(stderr, "Cannot init ALF libary(%d).\n", rc);
        return rc;
    };

    spe_tsk.spe_task_image = &matrix_trans_spu;
    spe_tsk.max_stack_size = 4096;

    /* filling out the task info structure */
    memset(&tinfo, 0, sizeof(tinfo));
    tinfo.p_task_info = &spe_tsk;
    tinfo.task_context_buffer_read_only_size=0;
    tinfo.task_context_buffer_writable_size=0;
    tinfo.parm_ctx_buffer_size = sizeof(trans_parms_t);
    tinfo.input_buffer_size = H*V*sizeof(float);   //64k
    tinfo.output_buffer_size = H*V*sizeof(float);  // 64k
    tinfo.overlapped_buffer_size =0;
    tinfo.dt_list_entries = H;                      //input or output buffer need H times dma
    /* this task is set to generate DMA lists on the control node */
    tinfo.task_attr = 0;

    /* creating task */
    rc = alf_task_create(&htask, half, &tinfo);
    if( rc < 0) {
        fprintf(stderr, "Cannot create ALF task(%d).\n", rc);
        alf_exit(&half, ALF_SHUTDOWN_FORCE);
        return 1;
    };

    parm.h=H;
    parm.v=V;

    /* creating wb and adding param & io buffer */
    for(X=0; X<NUM_ROW; X+=H) {
      for(Y=0; Y<NUM_COL; Y+=V) {
        alf_wb_create (&hwb, htask, ALF_WB_SINGLE, 0);
        /* Pass H and V to spu */
        alf_wb_add_param (hwb, &parm, sizeof(parm),
                  ALF_DATA_BYTE, 0);
        /* Add V element of mat_a as input */
        for(i=0; i<H; i++) {
             alf_wb_add_io_buffer (hwb,
                    &mat_a[X+i][Y],  V,
                    ALF_DATA_FLOAT,
                    ALF_BUFFER_INPUT);
        }
        /* Add V element of mat_c as output */
        for(i=0; i<V; i++) {
             alf_wb_add_io_buffer (hwb,
                    &mat_c[Y+i][X],  H,
                    ALF_DATA_FLOAT,
                    ALF_BUFFER_OUTPUT);
        }

        alf_wb_enqueue(hwb);
        }
    }

    /* alf task wait until wb processed */
    alf_task_wait(htask, -1);
    alf_task_destroy(&htask);
    /* end of alf routine */
    alf_exit(&half, ALF_SHUTDOWN_WAIT);

    printf ("Finished tranposing matrix. Verifying...\n");

    //verifying
    for (i=0; i<NUM_COL; i++)
       for (j=0; j<NUM_ROW; j++)
       {
	 if (mat_c[i][j] != mat_a[j][i])
	 {
	   fprintf (stderr, "ERROR from matrix transpose - Exit\n");
	   fflush (stderr);
	   exit (1);
	 }
       }
    printf ("All done!\n");

    return 0;
}
 


 
