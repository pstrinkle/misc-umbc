/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <alf_accel.h> 
#include "../matrix_trans.h"


int alf_comp_kernel(void *p_task_context,
                    void *p_parm_ctx_buffer, 
                    void *p_input_buffer,  
                    void *p_output_buffer, 
                    unsigned int current_count,
                    unsigned int total_count )

{
    unsigned int i, j;
    float *sa, *sc;
    trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;

    sa = (float *) p_input_buffer;
    sc = (float *) p_output_buffer;

    for(i=0; i< p_parm->h; i++)
      for(j=0; j< p_parm->v; j++)
          *(sc+j*p_parm->h + i)      /* sc[j][i] */
          = *(sa+i*p_parm->v +j);    /* sa[i][j] */

    return 0;
}


int  alf_prepare_input_list(void *p_task_context,
                            void *p_parm_ctx_buffer,  
                            void *p_dt_list_buffer, 
                            unsigned int current_count,
                            unsigned int total_count)
{
     trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;
     float *pA;
     unsigned int i;
     addr64  ea;
     
     pA = p_parm->p_mat_a + 
           p_parm->DIMY*p_parm->X + p_parm->Y; // mat_a[X][Y]
     
     ALF_DT_LIST_CREATE(p_dt_list_buffer,0);

     ea.ui[0] = 0;
     for(i=0; i<p_parm->h; i++)
     {
        ea.ui[1] = (unsigned int)(pA + p_parm->DIMY*i); // mat_a[X+i][Y]
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 
                              p_parm->v, 
                              ALF_DATA_FLOAT,
                              ea); 
     }
     
     return 0;
}


int  alf_prepare_output_list(void *p_task_context,
                             void *p_parm_ctx_buffer,  
                             void *p_dt_list_buffer, 
                             unsigned int current_count,
                             unsigned int total_count)
{
     trans_parms_t *p_parm = (trans_parms_t *)p_parm_ctx_buffer;
     float *pC;
     unsigned int j;
     addr64  ea;
     
     pC = p_parm->p_mat_c + 
            p_parm->DIMX*p_parm->Y + p_parm->X; // mat_c[Y][X]

     ALF_DT_LIST_CREATE(p_dt_list_buffer,0);
     
     ea.ui[0] = 0;
     for(j=0; j<p_parm->v; j++)
     {
        ea.ui[1] = (unsigned int)(pC + p_parm->DIMX*j); // mat_c[Y+j][X]
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 
                              p_parm->h, 
                              ALF_DATA_FLOAT,
                              ea); 

     }
     
     return 0;
}

