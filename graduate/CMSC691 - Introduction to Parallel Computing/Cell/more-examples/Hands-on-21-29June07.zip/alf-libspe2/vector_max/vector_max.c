/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/***************************************************************
*   Control  side code
***************************************************************/
#include <stdio.h>
#include <libmisc.h>
#include <float.h>
#include <stdlib.h>
#include <time.h>

#include <alf.h>
#include <vector_max.h>

/* we define the array to have more elements for simplification */
/* of boundary condition check when the calculation comes to a[N-1] */

float a[2][N+4] __attribute__ ((aligned (128)));       
                                                       
float amin, amax;

extern spe_program_handle_t  vector_max_spu;

/* This function performs data preparation for a[2][N+4] */
void prepare_data()
{
    int i;
    for(i=0; i<N; i++) {
        a[0][i] = (float)(rand()%8192 - 4096);
    }
    /* initialize to zero the last 4 elements */
    for(i=N; i<N+4; i++) {
        a[0][i] = (float)0.0f;
        a[1][i] = a[0][i];
    }
    /* init the amin, amax */
    amin = amax = a[0][0];

    /* for the initial A0 */
    for(i=0; i<N; i++) {
        if(amin > a[0][i]) amin = a[0][i];
        else if(amax < a[0][i]) amax = a[0][i];
    }

}

int main(void)
{
    alf_handle_t  half;
    alf_task_handle_t htask;
    alf_wb_handle_t     hwb;
    alf_task_info_t tinfo;
    alf_task_info_t_CBEA spe_tsk;
    my_parm_t parm __attribute__ ((aligned (128)));
    my_task_context_w *pctx_w;
    my_task_context_r *pctx_r;
    alf_wb_sync_handle_t hsync;
    int i,j,instances;
    unsigned int nodes;
    int size=S;

    /* prepare data for a[2][N+4] */
    prepare_data();

    /* begin alf routine */
    alf_configure(NULL);
    if (alf_query_system_info(ALF_INFO_NUM_ACCL_NODES, &nodes) < 0) {
        fprintf(stderr, "Failed to call alf_query_system_info.\n");
        return -1;
    }
    alf_init(&half, nodes, ALF_INIT_PERSIST);

    /* filling out the task info structure */
    spe_tsk.spe_task_image = &vector_max_spu;
    spe_tsk. max_stack_size = 4096;                         
    tinfo. p_task_info = &spe_tsk;

    /* set read only and writable task context buffer size */
    tinfo.task_context_buffer_read_only_size = sizeof(my_task_context_r);
    tinfo.task_context_buffer_writable_size = sizeof(my_task_context_w);
    tinfo.parm_ctx_buffer_size = sizeof(my_parm_t);

    /* we only use overlapped buffer, input buffer size and output buffer size =0 */
    tinfo.input_buffer_size = 0;      
   
    tinfo.overlapped_buffer_size = (size+4)*sizeof(float);   //+4 for iteration requrement 
    tinfo.output_buffer_size = 0;  
    tinfo. dt_list_entries = 8;                              //every dma 16k, so 8 is enough                               

    /* this task is set to generate DMA lists on spu side */
    tinfo.task_attr = ALF_TASK_ATTR_PARTITION_ON_ACCEL;

    /* creating alf task */
    instances = alf_task_create(&htask, half, &tinfo);

    pctx_w = malloc_align(sizeof(my_task_context_w)*instances, 4);
    pctx_r = malloc_align(sizeof(my_task_context_r), 4);

    /* init and assign the context buffers */
    pctx_r->c0=C0;
    pctx_r->c1=C1;
    pctx_r->c2=C2;
    pctx_r->c3=C3;

    /* create alf task context buffer and add entry */
    for(i=0; i<instances; i++) {
        alf_task_context_handle_t hctx;
        alf_task_context_create(&hctx, htask, 0 /* i+1 is ok too */);

        /* Add read only context */
        alf_task_context_add_entry(hctx, pctx_r,sizeof(my_task_context_r),
            ALF_DATA_BYTE,  ALF_TASK_CONTEXT_READ);

        pctx_w[i].min =amin;  
        pctx_w[i].max =amax;
        /* Add writable context */
        alf_task_context_add_entry(hctx, &pctx_w[i], sizeof(my_task_context_w), 
            ALF_DATA_BYTE,  ALF_TASK_CONTEXT_WRITABLE);
        alf_task_context_register(hctx);
    }
    
    
    /* Loop T iterations, in each loop perfomrs wb creating and */
    /* adding param N/size times */
    for(j=0;j<T;j++) {
        for(i=0; i<N/size; i++) {  
            parm.addr_a = &a[j%2][i*size];
            parm.addr_b = &a[(j+1)%2][i*size];            
            parm.size = size;
            alf_wb_create (&hwb, htask, ALF_WB_SINGLE, 1);
            alf_wb_add_param (hwb, &parm, sizeof(my_parm_t), ALF_DATA_BYTE, 0);
            alf_wb_enqueue(hwb);
        }
        /* Call wb sync in each iteration */
        alf_wb_sync(&hsync, htask, ALF_SYNC_BARRIER, NULL, NULL, 0);
    }
    
    /* alf task wait until wb has been processed */
    alf_task_wait(htask, -1);    
    alf_task_destroy(&htask);
  
    /* end of alf routine */
    alf_exit(&half, ALF_SHUTDOWN_WAIT);

    /* now we will merge the max value to get the final result */
    amax = pctx_w[0].max;
    amin = pctx_w[0].min;

    for(i=1; i<instances; i++) {
        if(pctx_w[i].max > amax)
            amax = pctx_w[i].max;
        if(pctx_w[i].min < amin)
            amin = pctx_w[i].min;
    }
   
    free_align(pctx_w);
    free_align(pctx_r);

    printf("The maximum element value is %f minimum element value is %f\n", amax,amin);

    return 0;
}

