/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/*                                                                 */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials          */
/* provided with the distribution.                                 */
/*                                                                 */
/* Neither the name of IBM Corporation nor the names of its        */
/* contributors may be used to endorse or promote products         */
/* derived from this software without specific prior written       */
/* permission.                                                     */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/***************************************************************
*   Accelerator side code
***************************************************************/

#include <alf_accel.h>
#include "vector_max.h"

int alf_comp_kernel(void *p_task_context,
                    void *p_parm_ctx_buffer,
                    void *p_input_buffer,
                    void *p_output_buffer,
                    unsigned int current_count,
                    unsigned int total_count)

{
    my_task_context_r *p_ctx_r = (my_task_context_r *) p_task_context;
    my_task_context_w *p_ctx_w = (my_task_context_w *)((char *)p_task_context+sizeof(my_task_context_r)); 
    my_parm_t *p_parm = (my_parm_t *) p_parm_ctx_buffer;

    float *a = (float *)p_input_buffer;
    float *b = (float *)p_output_buffer;

    float c0 = p_ctx_r->c0;
    float c1 = p_ctx_r->c1;
    float c2 = p_ctx_r->c2;
    float c3 = p_ctx_r->c3;
    int size = p_parm->size;
    int i;

    for(i=0;i<size;i++) {
        b[i]=c0*a[i]+c1*a[i+1]+c2*a[i+2]+c3*a[i+3];

        if(b[i]>p_ctx_w->max) 
            p_ctx_w->max = b[i];

        if(b[i]<p_ctx_w->min) 
            p_ctx_w->min = b[i];        
    } 
    return 0;
}



int  alf_prepare_input_list(void* p_task_context, 
                            void *p_parm_ctx_buffer,
                            void *p_dt_list_buffer,  
                            unsigned int current_count,  
                            unsigned int total_count)
{
    my_parm_t *p_parm = (my_parm_t *) p_parm_ctx_buffer;
    float *addr = p_parm->addr_a;
    int size = p_parm->size;
    int small_size;
    int i,left;
    addr64 ea;

    small_size = (size)/(16*1024/sizeof(float));
    left = size%(16*1024/sizeof(float));

    ALF_DT_LIST_CREATE(p_dt_list_buffer,0);

    /* add a dt list for every 16K */
    for(i=0;i<small_size;i++) {
        ea.ui[0] = 0;
        ea.ui[1] = (unsigned int)addr+i*16*1024+current_count*size*sizeof(float);
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 16*1024, ALF_DATA_BYTE, ea);
    }

    /* add a dt list for the rest */
    ea.ui[1] = (unsigned int)addr+small_size*16*1024+current_count*size*sizeof(float);
    ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, (left+4), ALF_DATA_FLOAT, ea);
    
    return 0;
}


int  alf_prepare_output_list(void* p_task_context, 
                             void *p_parm_ctx_buffer,
                             void *p_dt_list_buffer,  
                             unsigned int current_count,  
                             unsigned int total_count)
{
    my_parm_t *p_parm = (my_parm_t *) p_parm_ctx_buffer;
    float *addr=p_parm->addr_b;
    int size=p_parm->size;
    int small_size;
    int i,left;
    addr64 ea;

    small_size=size/(16*1024/sizeof(float));
    left=size%(16*1024/sizeof(float));
   
    ALF_DT_LIST_CREATE(p_dt_list_buffer,0);

    /* add a dt list for every 16K */
    for(i=0;i<small_size;i++) {
        ea.ui[0] = 0;
        ea.ui[1] = (unsigned int)addr+i*16*1024+current_count*size*sizeof(float);
        ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, 16*1024, ALF_DATA_BYTE, ea);
    }

    /* add a dt list for the rest */
    ea.ui[1] = (unsigned int)addr+small_size*16*1024+current_count*size*sizeof(float);
    ALF_DT_LIST_ADD_ENTRY(p_dt_list_buffer, left, ALF_DATA_FLOAT, ea);

    return 0;
}

