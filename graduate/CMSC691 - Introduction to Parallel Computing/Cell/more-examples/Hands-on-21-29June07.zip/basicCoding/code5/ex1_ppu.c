#include <stdio.h>
#include <libspe.h>

extern spe_program_handle_t ex1_spu;

int main(void)
{
	float A_ppu_data, B_ppu_data, C_ppu_data;
	A_ppu_data = 5.12;
	B_ppu_data = 4.55;
	C_ppu_data = 0.0;

	speid_t speid;
	int status;
        int retVal;
	
	//create an spe thread
	speid = spe_create_thread(0,&ex1_spu,NULL,NULL,-1,0);

	/* Send effective addresses of A_ppu_data to spe through mailboxes*/
	while (spe_stat_in_mbox(speid) == 0);
	do
	{
		retVal = spe_write_in_mbox(speid, (unsigned int) &A_ppu_data);
	}
	while (retVal != 0);

	while (spe_stat_in_mbox(speid) == 0);
	do
	{
		retVal = spe_write_in_mbox(speid, (unsigned int) &B_ppu_data);
	}
	while (retVal != 0);

	while (spe_stat_in_mbox(speid) == 0);
	do
	{
		retVal = spe_write_in_mbox(speid, (unsigned int) &C_ppu_data);
	}
	while (retVal != 0);

	spe_wait(speid,&status,0);
	

	//print data from SPE
	printf("PPE Data: %.2f\n",C_ppu_data);
	return 0;
}
