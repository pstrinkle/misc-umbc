#include <stdio.h>
float a  = 5.12;
float b = 10.25;
float c = 0.0;
int main()
{
     c = a + b;
     printf("Data are: %.2f %.2f %.2f\n",a,b,c);
     return 0;
}
