#include <stdio.h>
#include <libspe.h>
extern spe_program_handle_t ex1_spu;
int main(void)
{
	speid_t speid;
	int status;
	speid = spe_create_thread(0,&ex1_spu,NULL,NULL,-1,0);
	spe_wait(speid,&status,0);
	return 0;
}
