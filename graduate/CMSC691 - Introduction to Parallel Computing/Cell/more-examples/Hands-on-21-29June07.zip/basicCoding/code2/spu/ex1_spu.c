#include <stdio.h>
float a = 5.2;
float b = 4.14;
float c = 0.0;

int main(unsigned long long speid, unsigned long long argp, unsigned long long env)
{
	c = a + b;
	printf("Data are: %.2f %.2f %.2f\n", a, b, c);
	return 0;
}
