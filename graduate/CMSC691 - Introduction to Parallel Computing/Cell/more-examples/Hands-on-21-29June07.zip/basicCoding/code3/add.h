#ifndef __add_h__
#define __add_h__

typedef struct _control_block
{
	float a; //a 
	float b; //b
	float c;  //c
	unsigned char pad[116];  //padded to cache line of 128 bytes
} control_block;
#endif
