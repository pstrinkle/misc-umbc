#include <stdio.h>
#include <libspe.h>
typedef struct {
	float a; 	//input parm
	float b;	//input parm
	float c;	//output
	float padding;	//padding struct to a multiple of 16 bytes
	} data_cb;

extern spe_program_handle_t ex1_spu;

int main(void)
{
/* allocate one control block*/
data_cb ppu_data __attribute__((aligned(16)));

	ppu_data.a = 5.12;
	ppu_data.b = 4.55;
	ppu_data.c = 0.0;

	speid_t speid;
	int status;
	speid = spe_create_thread(0,&ex1_spu,&ppu_data,NULL,-1,0);
	spe_wait(speid,&status,0);
	
	//print data from SPE
	printf("PPE Data: %.2f\n",ppu_data.c);
	return 0;
}
