#include <stdio.h>
#include <spu_mfcio.h>
typedef struct {
	float a;	//input parm
	float b;	//input parm
	float c;	//output
	float padding;	//padding to 16 bytes
	} data_cb;

data_cb spe_data __attribute__((aligned(16))); 

int main(unsigned long long speid, unsigned long long data_ea, unsigned long long env)
{
	int tag_id = 31;

	//read data in
	mfc_get(&spe_data, data_ea, sizeof(spe_data), tag_id, 0, 0);
	mfc_write_tag_mask(1<<tag_id); 
	mfc_read_tag_status_any();

	//process data
	spe_data.c = spe_data.a + spe_data.b;
	printf("SPE Data: %.2f %.2f %.2f\n", spe_data.a, spe_data.b, spe_data.c);
	
	//write data back
	mfc_put(&spe_data, data_ea, sizeof(spe_data), tag_id, 0, 0);
	mfc_write_tag_mask(1<<tag_id);
	mfc_read_tag_status_any();

	return 0;
}
