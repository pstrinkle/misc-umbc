#include <stdio.h>
#include <spu_mfcio.h>
#include <libmisc.h>
#include <profile.h>

#define msize 64

float a_block[msize*msize] __attribute__ ((aligned(128)));
float b_block[msize*msize] __attribute__ ((aligned(128)));
float c_block[msize*msize] __attribute__ ((aligned(128)));

#define wait_on_mask(x)   mfc_write_tag_mask(x); mfc_read_tag_status_any();

void MatMult_scalar (float *c, float *a, float *b)
{
	int i, j, k;
	for (i=0; i<msize; i++) {
		for (j=0; j<msize; j++) {
			c[i*msize+j] = 0.0f;
			for (k=0; k<msize; k++) {
				c[i*msize+j] += a[i*msize+k] * b[k*msize+j];
			}
		}
	}

}

void MatMult_madd (float *c, float *a, float *b)
{
	vector float *va = (vector float *)a;
	vector float *vb = (vector float *)b;
	vector float *vc = (vector float *)c;
	int i, j, k;

	vector unsigned char splat0 = (vector unsigned char) spu_splats(0x00010203);
	vector unsigned char splat1 = (vector unsigned char) spu_splats(0x04050607);
	vector unsigned char splat2 = (vector unsigned char) spu_splats(0x08090A0B);
	vector unsigned char splat3 = (vector unsigned char) spu_splats(0x0C0D0E0F);

	vector float *an_0, *an_1, *an_2, *an_3;
	vector float an_0j, an_1j, an_2j, an_3j;
	int nsize = msize/4;

        /* temp variables so compiler doesn't try and load and store on each array access */
	register vector float tempOut0;
	register vector float tempOut1;
	register vector float tempOut2;
	register vector float tempOut3;

	register vector float vb_0;
	register vector float vb_1;
	register vector float vb_2;
	register vector float vb_3;

	for (i=0; i<nsize;i++) {
		for (j=0; j<nsize;j++) {	
			for (k=0; k<nsize;k++) {
				tempOut0 = vc[(i*msize+0*nsize)+j];
				tempOut1 = vc[(i*msize+1*nsize)+j];
				tempOut2 = vc[(i*msize+2*nsize)+j];
				tempOut3 = vc[(i*msize+3*nsize)+j];

				an_0 = va+(k+0*nsize)+i*msize;
				an_1 = va+(k+1*nsize)+i*msize;
				an_2 = va+(k+2*nsize)+i*msize;
				an_3 = va+(k+3*nsize)+i*msize;

				vb_0 = vb[(k*msize+0*nsize+j)];
				vb_1 = vb[(k*msize+1*nsize+j)];
				vb_2 = vb[(k*msize+2*nsize+j)];
				vb_3 = vb[(k*msize+3*nsize+j)];

				an_0j = spu_shuffle(*an_0, *an_0, splat0);
				an_1j = spu_shuffle(*an_1, *an_1, splat0);
				an_2j = spu_shuffle(*an_2, *an_2, splat0);
				an_3j = spu_shuffle(*an_3, *an_3, splat0);
				tempOut0 = spu_madd(vb_0, an_0j, tempOut0);
				tempOut1 = spu_madd(vb_0, an_1j, tempOut1);
				tempOut2 = spu_madd(vb_0, an_2j, tempOut2);
				tempOut3 = spu_madd(vb_0, an_3j, tempOut3);

				an_0j = spu_shuffle(*an_0, *an_0, splat1);
				an_1j = spu_shuffle(*an_1, *an_1, splat1);
				an_2j = spu_shuffle(*an_2, *an_2, splat1);
				an_3j = spu_shuffle(*an_3, *an_3, splat1);
				tempOut0 = spu_madd(vb_1, an_0j, tempOut0);
				tempOut1 = spu_madd(vb_1, an_1j, tempOut1);
				tempOut2 = spu_madd(vb_1, an_2j, tempOut2);
				tempOut3 = spu_madd(vb_1, an_3j, tempOut3);

				an_0j = spu_shuffle(*an_0, *an_0, splat2);
				an_1j = spu_shuffle(*an_1, *an_1, splat2);
				an_2j = spu_shuffle(*an_2, *an_2, splat2);
				an_3j = spu_shuffle(*an_3, *an_3, splat2);
				tempOut0 = spu_madd(vb_2, an_0j, tempOut0);
				tempOut1 = spu_madd(vb_2, an_1j, tempOut1);
				tempOut2 = spu_madd(vb_2, an_2j, tempOut2);
				tempOut3 = spu_madd(vb_2, an_3j, tempOut3);

				an_0j = spu_shuffle(*an_0, *an_0, splat3);
				an_1j = spu_shuffle(*an_1, *an_1, splat3);
				an_2j = spu_shuffle(*an_2, *an_2, splat3);
				an_3j = spu_shuffle(*an_3, *an_3, splat3);
				tempOut0 = spu_madd(vb_3, an_0j, tempOut0);
				tempOut1 = spu_madd(vb_3, an_1j, tempOut1);
				tempOut2 = spu_madd(vb_3, an_2j, tempOut2);
				tempOut3 = spu_madd(vb_3, an_3j, tempOut3);

				vc[(i*msize+0*nsize)+j] = tempOut0;
				vc[(i*msize+1*nsize)+j] = tempOut1;
				vc[(i*msize+2*nsize)+j] = tempOut2;
				vc[(i*msize+3*nsize)+j] = tempOut3;
			}
		}
	}
}

int main()
{
	int src_tag = 1;
	int src_mask = 1 << src_tag;

	float *aPtr, *bPtr, *cPtr;
	aPtr = (float*)spu_read_in_mbox();
	bPtr = (float*)spu_read_in_mbox();
	cPtr = (float*)spu_read_in_mbox();

	mfc_get (a_block, (unsigned int)aPtr, msize*msize*sizeof(float), src_tag, 0, 0);
	mfc_get (b_block, (unsigned int)bPtr, msize*msize*sizeof(float), src_tag, 0, 0);
	wait_on_mask (src_mask);

	printf("Performing matrix multiply...\n");

	prof_clear();
	prof_start();
	MatMult_madd(c_block, a_block, b_block);
	prof_stop();

	mfc_put (c_block, (unsigned int)cPtr, msize*msize*sizeof(float), src_tag, 0, 0);
	wait_on_mask (src_mask);

	return 0;
}

