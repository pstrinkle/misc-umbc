#include <libspe.h>
#include <stdio.h>
#include <stdlib.h>
#include <libmisc.h>

#define M 64

float *a, *b, *c;
float *tmp;

extern spe_program_handle_t mat_scalar;

void mat_init(int msize)
{
	int i, j;
	printf("Initializing Arrays\n");
	for(i=0; i<msize; i++) {
		for(j=0; j<msize; j++) {
			a[i*msize+j] = rand_0_to_1();
			b[i*msize+j] = rand_0_to_1();
			c[i*msize+j] = 0.0f;
		}
	}
	printf("done\n"); fflush(stdout);
}

int main (void)

{
 	int msize = 64;
	char * mem_addr;
	float *exp;
	int i, j, k;

	int offset = 0;
	a = (float *)offset;
	offset += sizeof(float) * msize * msize;
	b = (float *)offset;
	offset += sizeof(float) * msize * msize;
	c = (float *)offset;
	offset += sizeof(float) * msize * msize;

	mem_addr = malloc_align(offset, 7);




	a = (float  *)(mem_addr + (unsigned int)a);
	b = (float  *)(mem_addr + (unsigned int)b);
	c = (float  *)(mem_addr + (unsigned int)c);
	mat_init(msize);

	/* Construct matrices and expected results
	*/
	exp = (float *)malloc(sizeof(float) * msize * msize);
	tmp = (float *)malloc(sizeof(float) * msize * msize);
	if ((exp == NULL) || (tmp == NULL)) {
		printf("ERROR: failed to allocated verification buffers exp and tmp\n");
		exit(1);
	}
	printf("Computing expected results ... "); 
	fflush(stdout);
	for (i=0; i<msize; i++) {
		for (j=0; j<msize; j++) {
			exp[i*msize+j] = 0.0f;
			for (k=0; k<msize; k++) {
				exp[i*msize+j] += a[i*msize+k] * b[k*msize+j];
			}
		}
	}
	printf("done\n"); fflush(stdout);

	// END INIT

	speid_t speid[8];
	int status;
	
	for (i=0;i<1;i++) {
		speid[i] = spe_create_thread (0, &mat_scalar, NULL, NULL, -1, 0);
		spe_write_in_mbox(speid[i], (unsigned int)a);	
		spe_write_in_mbox(speid[i], (unsigned int)b);	
		spe_write_in_mbox(speid[i], (unsigned int)c);	
	}

	for (i=0;i<1;i++) 
		spe_wait (speid[i], &status, 0);

    float delta;
    int fail = 0;

    printf("Verifying the results ... ");

   for (i=0; i<msize; i++) {
      for (j=0; j<msize; j++) {
        delta = exp[i*msize+j] - c[i*msize+j];
        if (delta < 0.0f) delta = -delta;
        if (delta > 0.01) {
          printf("  %d %d exp=%f got=%f\n", i, j, exp[i*msize+j], c[i*msize+j]);
          fail++;
        }
      }
    }
    if (fail) {
      printf("FAILED (%d)\n", fail);
      fail = 1;
    } else {
      printf("PASSED\n");
    }

	return 0;
}
