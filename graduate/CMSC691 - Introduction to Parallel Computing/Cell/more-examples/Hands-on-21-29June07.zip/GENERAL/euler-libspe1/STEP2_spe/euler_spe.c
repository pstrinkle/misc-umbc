/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* STEP2
 *
 * Port STEP1 to perform the computation in a single SPE. In this case
 * we have ported the Array of Structures implementation (STEP1a) the SPE.
 *
 * To move the code from the PPE/VMX to the SPE required:
 * a) Creating a control structure (called context), that defines parameters of the
 *    computation to be performed on the SPE. This includes, pointers to the particle
 *    array data, current force information, etc... We pass the pointer to the context
 *    by using the parameter passing mechanism to the SPE thread. Alternatively, this 
 *    information could have been passed via the mailbox. 
 *  b) Porting the computation for execution on the SPE. The complexity of this operation
 *     depends upon the types of data and types of intrinsics used. For this case, some
 *     of the intrinsic require just a simple name translation (vec_madd -> spu_madd). 
 *     The translation of the scalar values is a little more extensive.
 *  c) Adding an additional looping construct to partition the data arrays into samller
 *     blocks. This was required because all the data will not fit within the SPE's 
 *     local store.
 *  d) Adding DMAs to move data in and out of the SPU's local store. 
 */

#include <stdio.h>
#include <libspe.h>
#include "particle.h"

vec4D pos[PARTICLES] __attribute__ ((aligned (16)));
vec4D vel[PARTICLES] __attribute__ ((aligned (16)));
vec4D force __attribute__ ((aligned (16)));
float inv_mass[PARTICLES] __attribute__ ((aligned (16)));
float dt = 1.0f;

extern spe_program_handle_t particle;

int main()
{
  int status;
  speid_t spe_id;
  context ctx __attribute__ ((aligned (16)));

  ctx.particles = PARTICLES;
  ctx.pos_v = (vector float *)pos;
  ctx.vel_v = (vector float *)vel;
  ctx.force_v = *((vector float *)&force);
  ctx.inv_mass = inv_mass;
  ctx.dt = dt;

  // Create a SPE thread of execution passing the context as a parameter.
  spe_id = spe_create_thread(0, &particle, &ctx, NULL, -1, 0);
  if (spe_id) {
    // Wait for the SPE to finish
    (void)spe_wait(spe_id, &status, 0);
  } else {
    perror("Unable to create SPE thread");
    return (1);
  }
  return (0);
}
