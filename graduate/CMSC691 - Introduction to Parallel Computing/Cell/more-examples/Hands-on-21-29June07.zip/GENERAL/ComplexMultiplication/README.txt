%% -------------------------------------------------------------- 
%% (C) Copyright 2006
%% International Business Machines Corporation,                   
%%                                                                
%% All Rights Reserved.                                           
%% -------------------------------------------------------------- 
Target:
        CBE-Linux (HW or simulator)

Description:
	This directory contains a simple complex multiplication example for SPE

Notes:
	* This code is meant as an example of how to perform complex
	  multiplication on SPE as well as show a method for double buffering.
	* Taken from a larger suite of example functions so some glue code
	  remains
	  
