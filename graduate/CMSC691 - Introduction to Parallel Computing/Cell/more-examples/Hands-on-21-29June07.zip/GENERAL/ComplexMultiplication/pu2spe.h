#ifndef _PU_SPU_H
#define _PU_SPU_H
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <assert.h>

#include "pu2spe_complexmult.h"


#define NUM_SPU_THREADS (1)

#define COMPLEX_ELEMENTS_PER_TRANSFER (32) 	// 256 bytes
#define BYTES_PER_TRANSFER (256)


#define SPU_EXIT_OP            (1)

#define SPU_PROCESS_COMPLEXMULT	   (6)



#endif
