#include <libspe.h>
#include "pu2spe.h"


static COMPLEXMULT_DATA *complexmult_data[1];
static COMPLEXMULT_DATA data1 __attribute__ ((aligned(128)));

int SpeSendMessage(speid_t speid, int msg, unsigned int value);
int SpeWaitForReturn(speid_t speid);


int complexmult_init()
{
	complexmult_data[0] = &data1;
	return 0;
}

int complexmult_exit()
{
	return 0;
}

int complexmult_spe (SPcmplx *input1, SPcmplx *input2, SPcmplx *output, int vec_size, speid_t * speid)
{
	unsigned int retVal=0;
	int i=0;

	printf("pu2spe_complexmult_spe .....\n");

	complexmult_data[0]->func_code = COMPLEXMULT;
	complexmult_data[0]->input1 = input1;
	complexmult_data[0]->input2 = input2;
	complexmult_data[0]->output = output;
	complexmult_data[0]->size  = vec_size;



/* SPU_PROCESS_COMPLEXMULT defined in pu2spe.h  */

	SpeSendMessage(speid[i], SPU_PROCESS_COMPLEXMULT, (unsigned int)complexmult_data[i]);

	printf("pu2spe_complexmult_spe ....  SpeSendMessage done\n");

/*-----  wait for SPU to finish and report  ------------------------ */
	retVal = SpeWaitForReturn(speid[i]);

	return retVal;
}


