#ifndef _SPU_MAIN_H
#define _SPU_MAIN_H


extern unsigned int src_tag;
extern unsigned int src_mask;
extern unsigned int dest_tag;
extern unsigned int dest_mask;
extern SPcmplx   general_src1[];
extern SPcmplx   general_src2[];
extern SPcmplx   general_src3[];
extern SPcmplx   general_src4[];
//extern float general_src1[];
//extern float general_src2[];


extern SPcmplx   general_dest1[];
extern SPcmplx   general_dest2[];

typedef struct {
	unsigned int size;
	unsigned int ea_low;
}  spe_dma_list_element;


#endif

