#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <spu_mfcio.h>
#include <profile.h>


#include "../pu2spe.h"
#include "spe_main.h"


/* COMPLEX_ELEMENTS_PER_TRANSFER and BYTES_PER_TRANSFR defined in ../pu2spe.h  */


static SPcmplx *d1[2], *a[2], *b[2];


int complexmult_init()
{
    	d1[0] = general_dest1;
	d1[1] = general_dest2;

    	a[0] = general_src1;
	a[1] = general_src2;
    	b[0] = general_src3;
	b[1] = general_src4;

	return 0;

}

int complexmult(COMPLEXMULT_DATA *pData)
{
    int code;

    code = pData->func_code;
    if(code != COMPLEXMULT)  {
		//printf("Bad function code %d\n",code);
		return -1;
	}

	//printf("begin complexmult\n");

	SPcmplx *input1 = pData->input1;
	SPcmplx *input2 = pData->input2;
	SPcmplx *output = pData->output;
	int N = pData->size;		// N = no. complex elements per vector

	//printf("input1=%x, input2=%x, output=%x, N=%d\n",input1,input2,output,N);

	int ji, jo, jjo, jji;
	vector float *vdata, *vweight, *voutput;
	vector float v_zero = (vector float){0,0,0,0};
	vector float A1, A2, B1, B2, I1, I2, Q1, Q2, D1, D2;
	vector unsigned char I_Perm_Vector = (vector unsigned char){0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27};
	vector unsigned char Q_Perm_Vector = (vector unsigned char){4,5,6,7,12,13,14,15,20,21,22,23,28,29,30,31};
	vector unsigned char vcvmrgh = (vector unsigned char) {0,1,2,3,16,17,18,19,4,5,6,7,20,21,22,23};
    	vector unsigned char vcvmrgl = (vector unsigned char) {8,9,10,11,24,25,26,27,12,13,14,15,28,29,30,31};

    	int outerloopcount, innerloopcount;

    	outerloopcount = N/COMPLEX_ELEMENTS_PER_TRANSFER;
	innerloopcount = COMPLEX_ELEMENTS_PER_TRANSFER/2;


	mfc_get ((void *) a[0], (unsigned int)input1, BYTES_PER_TRANSFER, src_tag, 0, 0);
	input1 += COMPLEX_ELEMENTS_PER_TRANSFER;
	mfc_get ((void *) b[0], (unsigned int)input2, BYTES_PER_TRANSFER, src_tag, 0, 0);
	input2 += COMPLEX_ELEMENTS_PER_TRANSFER;

	jo = 0;

	prof_clear();
	prof_start();
	for (jjo = 0; jjo < outerloopcount; jjo++)
	{

		mfc_write_tag_mask (src_mask);
	    	mfc_read_tag_status_all ();

		mfc_get ((void *) a[(jo+1)&1], (unsigned int)input1, BYTES_PER_TRANSFER, src_tag, 0, 0);
		input1 += COMPLEX_ELEMENTS_PER_TRANSFER;
		mfc_get ((void *) b[(jo+1)&1], (unsigned int)input2, BYTES_PER_TRANSFER, src_tag, 0, 0);
		input2 += COMPLEX_ELEMENTS_PER_TRANSFER;

		voutput = ((vector float *) d1[jo&1]);

		vdata  = ((vector float *) a[jo&1]);
		vweight  = ((vector float *) b[jo&1]);

		ji = 0;


		for (jji = 0; jji < innerloopcount; jji+=2)
		{
			A1 = vdata[ji];
			A2 = vdata[ji+1];
			B1 = vweight[ji];
			B2 = vweight[ji+1];
			Q1 = spu_shuffle(A1, A2, Q_Perm_Vector);
			Q2 = spu_shuffle(B1, B2, Q_Perm_Vector);
			I1 = spu_shuffle(A1, A2, I_Perm_Vector);
			I2 = spu_shuffle(B1, B2, I_Perm_Vector);
			A1 = spu_nmsub(Q1, Q2, v_zero);
			A2 = spu_madd(Q1, I2, v_zero);
			Q1 = spu_madd(I1, Q2, A2);
			I1 = spu_madd(I1, I2, A1);
			D1 = spu_shuffle(I1, Q1, vcvmrgh);
			D2 = spu_shuffle(I1, Q1, vcvmrgl);
			voutput[ji] = D1;
			voutput[ji+1] = D2;
			ji += 2;
		}

		// start the xfr to copy the result back to SYS

		mfc_write_tag_mask (dest_mask);
    		mfc_read_tag_status_all ();

		mfc_put ((void *)d1[jo&1], (unsigned int) output, BYTES_PER_TRANSFER, dest_tag, 0, 0);
		output += COMPLEX_ELEMENTS_PER_TRANSFER;

		jo++;

	}
	// wait for the last xfr to finish
    	mfc_write_tag_mask (dest_mask);
    	mfc_read_tag_status_all();

	prof_stop();
	return 0;
}
