#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <profile.h>
#include <spu_mfcio.h>

#include "../pu2spe.h"
#include "../pu2spe_complexmult.h"


typedef union {
    unsigned long long ull;
    void *vp[2];
} addr64;


static unsigned int tag = 1;
static unsigned int mask;
unsigned int src_tag = 1;
unsigned int src_mask;
unsigned int dest_tag = 2;
unsigned int dest_mask;


static COMPLEXMULT_DATA     complexmult_data 		__attribute__ ((aligned (128)));

SPcmplx   general_src1[COMPLEX_ELEMENTS_PER_TRANSFER] 	__attribute__ ((aligned (128)));
SPcmplx   general_src2[COMPLEX_ELEMENTS_PER_TRANSFER] 	__attribute__ ((aligned (128)));
SPcmplx   general_src3[COMPLEX_ELEMENTS_PER_TRANSFER] 	__attribute__ ((aligned (128)));
SPcmplx   general_src4[COMPLEX_ELEMENTS_PER_TRANSFER] 	__attribute__ ((aligned (128)));

SPcmplx   general_dest1[COMPLEX_ELEMENTS_PER_TRANSFER] 	__attribute__ ((aligned (128)));
SPcmplx   general_dest2[COMPLEX_ELEMENTS_PER_TRANSFER] 	__attribute__ ((aligned (128)));


int complexmult_count;

extern int complexmult_init();
extern int complexmult (COMPLEXMULT_DATA *);

int main()
{
  	void *temp;
  	unsigned int opcode;
  	int size = 0;

	complexmult_count = 0;

	mask      = 1 << tag;
	src_mask  = 1 << src_tag;
	dest_mask = 1 << dest_tag;

	complexmult_init();


	while(1) 
	{
		switch ((opcode = (unsigned int) spu_read_in_mbox()))
		{
	    		case SPU_EXIT_OP:
		    		printf("SPU Exit\n");
				return 0;
				break;


			case SPU_PROCESS_COMPLEXMULT:
				printf("SPU_PROCESS_COMPLEXMULT %d\n", ++complexmult_count);
				temp = (void *) spu_read_in_mbox();
				size = (sizeof(COMPLEXMULT_DATA)+15)&(~15);

			        mfc_get ((void *) &complexmult_data, (unsigned int) temp, size, tag, 0, 0);
	       			mfc_write_tag_mask (mask);
		        	mfc_read_tag_status_all ();

				complexmult(&complexmult_data);

				printf("complexmult done in spe_main.c\n");
				// set return value to PU
				spu_write_out_mbox ((unsigned int)1);

				break;

			default:
				break;
		}
	}

	return 0;
}
