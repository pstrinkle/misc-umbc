#include <libspe.h>
#include "pu2spe.h"

int spe_init(void);
int spe_exit(void);



#define VEC_SIZE      2048
#define VEC_SIZE_1    2048

extern spe_program_handle_t cmultspe;
extern int complexmult_spe(SPcmplx *, SPcmplx *, SPcmplx *, int, speid_t *);

static unsigned int buf[VEC_SIZE_1] __attribute__ ((aligned(128)));
static SPcmplx input1_SPcmplx[VEC_SIZE_1] __attribute__ ((aligned(128)));
static SPcmplx input2_SPcmplx[VEC_SIZE_1] __attribute__ ((aligned (128)));
static SPcmplx output_SPcmplx[VEC_SIZE_1] __attribute__ ((aligned (128)));


/*-------------------------------------------------------------------*/
/*  speid indexed for 8 SPUs, only one used here       	             */
/*-------------------------------------------------------------------*/
static speid_t speid[8];

int init=0;


//int main(int argc, char **argv)
int main()
{
	int status = 0, i;
	spe_init();

	// Initialize input vectors
	for(i=0; i<VEC_SIZE; i++)
	{
		input1_SPcmplx[i].I = i;
		input1_SPcmplx[i].Q = VEC_SIZE - i;
		input2_SPcmplx[i].I = i;
		input2_SPcmplx[i].Q = -(VEC_SIZE - i);
	}

	complexmult_spe (&input1_SPcmplx[0],&input2_SPcmplx[0],&output_SPcmplx[0],VEC_SIZE, speid);

	// print first few output values
	for (i=0; i<32; i++)
	{
		printf("i=%d, output.I=%f, output.Q=%f\n",i,output_SPcmplx[i].I, output_SPcmplx[i].Q);
	}

	spe_exit();

	return status;
}


int spe_init()
{
	int i;

	if (init) return 0;

	printf("spe_init ***********************************\n");

	/* Create an SPU-thread, and pass the address of 'buf' as a parameter.*/

	i = 0;
	speid[i] = spe_create_thread(0, &cmultspe, buf, NULL, -1, 0);

	if (speid[i] ==  0) {
		fprintf(stderr, "Failed spe_create_thread(rc=%d, errno=%d)\n",(unsigned int)speid[i], errno);
		exit(1);
	}

	complexmult_init();

	init = 1;
	return 1;
}


int spe_exit()
{
	int i, rc, status =0;

	if (!init) return 0;

	printf("spe_exit ***********************************\n");

	i = 0;

	spe_write_in_mbox(speid[i], SPU_EXIT_OP);

	/* Wait for SPU-thread to complete execution.     */
	rc = spe_wait(speid[i], &status, 0);
	if (rc < 0) {
		fprintf(stderr, "Failed spe_wait(rc=%d, errno=%d)\n", rc, errno);
		exit(1);
  	}

	complexmult_exit();

	init = 0;
	return 0;
}


int SpeSendMessage(speid_t speid, int msg, unsigned int value)
{
	int retVal;

	do {
		retVal = spe_write_in_mbox (speid, msg);
	}while ( retVal != 0);

	do {
		while (spe_stat_in_mbox(speid) != 0)
			retVal = spe_write_in_mbox(speid,  value);
	}while ( retVal != 0);

	return retVal;
}

int SpeWaitForReturn(speid_t speid)
{
	int i;
	int flags[1];
	int retVals[1];
	int retVal=0;


	flags[0] = retVals[0] = 0;

	printf("Waiting for SPUs to finish...\n");

	i = 0;

	while(1)
	{
		if (spe_stat_out_mbox(speid) != 0) {
			retVal = spe_read_out_mbox(speid);
			if (retVal != -1)  {
				flags[i] = 1;
				retVals[i] = retVal;
				//printf("status succeeded for SPU%d\n", i);
				//printf("RetVal(%d) = %d\n",i, retVal);
			}

			break;
		}
	}

	return retVal;
}
