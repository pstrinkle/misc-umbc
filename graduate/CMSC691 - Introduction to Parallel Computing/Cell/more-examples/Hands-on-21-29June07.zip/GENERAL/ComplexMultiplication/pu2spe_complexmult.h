#ifndef _PU_SPU_COMPLEXMULT_H
#define _PU_SPU_COMPLEXMULT_H

/*Complex type*/

typedef struct {
	union{
		struct {
			float I;
			float Q;
		};
		struct {
			float real;
			float imag;
		};
	};
} SPcmplx;


typedef struct {
	int func_code;
	SPcmplx *input1;    	// Must be aligned, prefferably 128byte
	SPcmplx *input2; 		// Must be aligned, prefferably 128byte
	SPcmplx *output; 		// Must be aligned, prefferably 128byte
    int size;
	unsigned char fill[32]; // just to make the size multiple of 16
}COMPLEXMULT_DATA;

// Function codes
#define COMPLEXMULT (1)

#ifndef __SPU__

int complexmult_init();
int complexmult_exit();
int complexmult_spu(SPcmplx *input1, SPcmplx *input2, SPcmplx *output, int size);


#endif


#endif

