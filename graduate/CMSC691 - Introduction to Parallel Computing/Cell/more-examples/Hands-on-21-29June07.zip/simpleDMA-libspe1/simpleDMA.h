/* @(#)46	1.3  src/samples/simpleDMA/simpleDMA.h, sw.samples, sdk_pub 10/11/05 15:26:08 */
/* -------------------------------------------------------------- */
/* (C) Copyright 2001,2005,                                       */
/* International Business Machines Corporation,                   */
/* Sony Computer Entertainment Incorporated,                      */
/* Toshiba Corporation.                                           */
/*                                                                */
/* All Rights Reserved.                                           */
/* -------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#ifndef __simple_DMA_h__
#define __simple_DMA_h__

#include <stdlib.h> 

/* This union helps clarify calling parameters between the PPE and the SPE. */

typedef union
{
  unsigned long long ull;
  unsigned int ui[2];
}
addr64;

typedef struct _control_block {

  unsigned int  chunk_size; /* size, in bytes, of each of these array pieces */
  unsigned int  addr;       /* address to be filled by single-buffered DMA */
  unsigned char pad[120];   /* pad to a full cache line (128 bytes) */

} control_block;

#endif /* __simple_DMA_h__ */
