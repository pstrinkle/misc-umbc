%% @(#)45	1.4  src/samples/simpleDMA/README.txt, sw.samples, sdk_pub 10/11/05 15:26:05 
%% -------------------------------------------------------------- 
%% (C) Copyright 2001,2005,                                       
%% International Business Machines Corporation,                   
%% Sony Computer Entertainment Incorporated,                      
%% Toshiba Corporation.                                           
%%                                                                
%% All Rights Reserved.                                           
%% -------------------------------------------------------------- 
%% PROLOG END TAG zYx                                              
Target:
        CBE-Linux (HW or simulator)

Description:
	This directory contains a sample program demonstrating simple 
	DMA calls within one SPE.

Notes:
	The actual executable resides in the ppu subdirectory.  It's 
	called 'simpleDMA'. It's a full CBE executable, with both PPE and 
	SPE code.

        The job of this program is to get the SPEs to print out the address of
        an array which is passed to it by the PPE.  

        Here are the details:
         *  The PPE uses a malloc() command to allocate a small array in main memory.
         *  The PPE then loads the address of the array into a control block.
         *  The PPU prints the address of the array.
	 *  The PPE then creates the SPE thread, passing the address of the control block.

	 *  The SPE performs a simple DMA to load the contents of the control
	    block into its local store.
	 *  Then the SPE prints the array address contained within the contents
	    of the control block, and exits.

        The user should verify that the two addresses match.
