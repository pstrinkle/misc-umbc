/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <libspe2.h>
#include <sys/wait.h>
#include <string.h>

extern spe_program_handle_t spu_main;

int main() 
{
  spe_context_ptr_t speid;
  int rc;
  spe_stop_info_t stopinfo;
  unsigned int entry = SPE_DEFAULT_ENTRY;

  /* Create context */
  if ((speid = spe_context_create (0, NULL)) == NULL)
    {
      fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit (1);
    }
  /* Load program */
  if ((rc = spe_program_load (speid, &spu_main)) != 0)
    {
      fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit (1);
    }
  /* Run context */
  if ((rc = spe_context_run(speid, &entry, 0, NULL, NULL, &stopinfo)) != 0)
    {
      fprintf (stderr, "Failed spe_context_run(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit (1);
    }
  /* Destroy context */
  if ((rc = spe_context_destroy (speid)) != 0)
    {
      fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
      exit (1);
    }

  if (stopinfo.stop_reason == SPE_EXIT) {
        return (stopinfo.result.spe_exit_code);
  }
  else {
	fprintf(stderr, "stopinfo.stop_reason=%x, stopinfo.spe_exit_code=%x \n", 
		stopinfo.stop_reason,
		stopinfo.result.spe_exit_code);
        return -1;
  }

}
