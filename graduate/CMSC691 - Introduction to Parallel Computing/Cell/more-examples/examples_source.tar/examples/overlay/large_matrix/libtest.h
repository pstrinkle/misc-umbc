/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _LIB_TEST_H_
#define _LIB_TEST_H_	1

#include <stdlib.h>

#ifdef __SPU__

#ifdef STANDALONE
#define PRINT_FUNC	sim_printf
#include <libsim.h>
#else
#define PRINT_FUNC	printf
#include <stdio.h>
#endif

#else	/* __PPU__ */

#define PRINT_FUNC	printf
#include <stdio.h>

#endif	/* __SPU__ */

#define DEBUG_CTL	9
#define DEBUG(_priority, ...) if (DEBUG_CTL >= _priority) PRINT_FUNC(__VA_ARGS__)


#define DUMP_STRING(_priority, _p) {		\
  char *_ptr;					\
  char _chr;					\
						\
  for (_ptr=_p; (_chr=*_ptr); _ptr++) {		\
    DEBUG(_priority, "0x%02x ", _chr&0xFF);	\
  }						\
}


#define DUMP_N_STRING(_priority, _p, _n) {		\
  char *_ptr;						\
  int _i;						\
							\
  for (_i=0, _ptr=(char *)_p; _i<(int)_n; _i++) {	\
    DEBUG(_priority, "0x%02x ", _ptr[_i]&0xFF);		\
  }							\
}


/* This header file contains a set of macros to be used by the library tests
 */
#ifdef __SPU__
#include <spu_mfcio.h>
#endif /* __SPU__ */

#define DECLARE_MAIN()	int main()
#define SCALE_SAMPLES(_samples)		/* No-op for now */

#define DECLARE_TEST_VARS()  int testNumber = 0; int results = 0;

#define INVOKE_TEST(_test) if (_test()) results++; testNumber++;

#define DISPLAY_RESULTS()						   \
  PRINT_FUNC("TEST SUMMARY = ");					   \
  if (results) PRINT_FUNC("%d of %d TESTS FAILED\n", results, testNumber); \
  else         PRINT_FUNC("ALL PASSED\n");				   \
  return (results)
 

#endif /* _LIB_TEST_H_ */


