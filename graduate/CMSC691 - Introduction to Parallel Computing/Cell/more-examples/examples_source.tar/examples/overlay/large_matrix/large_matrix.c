/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <liblarge_matrix.h>
#include "libtest.h"

static int samples  = 100;

static void smatgen (float a[], int lda, int n, float b[])
{
  int i, j, init;
  
  init = 1325;
  for (j = 0; j < n; j++) {
    for (i = 0; i < n; i++) {
      init = 3125 * init % 65536;
      a[j + i*lda] = (init - 32768.0f) * (0.00006103515625f) ;
      b[i] = b[i] + a[j + i*lda];
    }
  }
}

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
#define SIZE 96 

static float c_a[SIZE * SIZE] __attribute__ ((aligned (128))); 
static float c_b[SIZE] __attribute__ ((aligned (128)));
static int c_ipvt[SIZE] __attribute__ ((aligned (128)));

#define EPSILON 	0.01f

int close_to_one (float num)
{
  return ((num > (1.0 - EPSILON)) && (num < 1.0f + EPSILON));
}


int test_solve_linear_system()
{
  int i;
  int n, lda;
   
  lda = SIZE;
  n = SIZE;
  
  DEBUG(1, "solve_linear_system_1 verification ");

  smatgen (c_a, lda, n, c_b);
  
  solve_linear_system_1 (n, c_a, lda, c_ipvt, c_b );
  
  for (i = 0; i < n; i++) {
    if (!close_to_one (c_b[i])) {
      DEBUG(1, "FAILED\n");
      DEBUG(2, "\ti=%d  b=%f\n", i, c_b[i]);
      return (1);
    }
  }

  DEBUG(1, "PASSED\n"); 
  return (0);
}


////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
int test_index_max_abs_vec()
{
  float test_array[51];
  int n = 51;
  int i, j;
  int idx;

  DEBUG(1, "index_max_abs_vec verfication ");
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (i + j < n) {
        test_array[j] = i + j;
      } else {
        test_array[j] = (i+j)-n;
      }
    }
    
    for (j = 0; j < 4; j++) {
      idx = index_max_abs_vec (n-j, &test_array[j]);
      if ((50 - i - j) < 0) {
        if (idx != (50-j)) {
	  DEBUG(1, "FAILED\n");
	  DEBUG(2, "\tgot = %d  expected = %d\n", idx, 50-j);
	  return (1);
        }
      } else {
        if (idx != (50-i-j)) {
	  DEBUG(1, "FAILED\n");
	  DEBUG(2, "\tgot = %d  expected = %d\n", idx, 50-i-j);
	  return (1);
        }
      }
      
    }
  }
  DEBUG(1, "PASSED\n");
  return (0);
}



////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
int test_scale_vector()
{
  int i, j, n, offset;
  float exp, got;
  float test_array[128+36];

  DEBUG(1, "scale_vector verfication ");
  for (i=0; i<samples; i++) {
    /* Initialize the input vector.
     */
    for (j=0; j<(int)(sizeof(test_array)/sizeof(float)); j++) test_array[j] = (float)(j);
    
    /* Randomly vary the size of offset.
     */
    offset = rand() & 31;
    n = 4 + (rand() & 127);

    scale_vector(n, 2.0f, &test_array[offset]);
    
    for (j=0; j<(int)(sizeof(test_array)/sizeof(float)); j++) {
      got = test_array[j];
      exp = (float)(j);
      if ((j >= offset) && (j < (offset+n))) exp *= 2.0f;
      
      if (got != exp) {
	DEBUG(1, "FAILED\n");
	DEBUG(2, "\tsample %d  idx=%d\n", i, j);
	DEBUG(2, "\toffset=%d  n=%d\n", offset, n);
	DEBUG(2, "\tgot=%f exp=%f\n", got, exp);
	return 1;
      }
    }
  }
  DEBUG(1, "PASSED\n");
  return 0;
}



////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
#define T_SIZE 64
float m1[T_SIZE * T_SIZE] __attribute__ ((aligned (16))); 
float m2[T_SIZE * T_SIZE] __attribute__ ((aligned (16)));

int test_transpose()
{
  int sample;
  int rows, cols, stride1, stride2;
  int i, j;

  DEBUG(1, "transpose_matrix verfication ");

  for (sample = 0; sample < samples; sample++) {
    rows = (T_SIZE * (rand() & 0xFFFF)) >> 16;
    cols = (T_SIZE * (rand() & 0xFFFF)) >> 16;
    if (rows == 0) rows=1;
    if (cols == 0) cols=1;
    
    stride1 = cols + (((T_SIZE-cols) * (rand() & 0xFFFF)) >> 16);
    stride2 = rows + (((T_SIZE-rows) * (rand() & 0xFFFF)) >> 16);

    /* Force the stride, rows and columns to a multiple of 4.
     */
    rows = (rows + 3) & ~3;
    cols = (cols + 3) & ~3;
    stride1 = (stride1 + 3) & ~3;
    stride2 = (stride2 + 3) & ~3;

    for (i = 0; i < stride2; i++) {
      for (j = 0; j < stride1; j++) {
	m1[i*stride1 + j] = (float)(i * stride1 + j);
	m2[i*stride1 + j] = -1.0f;
      }
    }
 
    transpose_matrix (rows, cols, m1, stride1, m2, stride2);

    for (i = 0; i < rows; i++) {
      for (j = 0; j < cols; j++) {
	if (m1[i*stride1 + j] != m2[j*stride2 + i]) {
	  DEBUG(1, "FAILED\n");
	  DEBUG(2, "\trows = %d  cols = %d\n", rows, cols);
	  DEBUG(2, "\tstride in = %d out = %d\n", stride1, stride2);
	  DEBUG(2, "\ti=%d j=%d\n", i, j);
	  DEBUG(2, "\tgot = %f, exp = %f\n", m2[j*stride2 + i], m1[i*stride1 + j]);
	  return (1);
	}
      }
    }
  }

  DEBUG(1, "PASSED\n");

  return (0); 
}


DECLARE_MAIN()
{
  DECLARE_TEST_VARS();

  SCALE_SAMPLES(samples);

  INVOKE_TEST(test_solve_linear_system);
  INVOKE_TEST(test_transpose);
  INVOKE_TEST(test_index_max_abs_vec);
  INVOKE_TEST(test_scale_vector);

  DISPLAY_RESULTS();
}
