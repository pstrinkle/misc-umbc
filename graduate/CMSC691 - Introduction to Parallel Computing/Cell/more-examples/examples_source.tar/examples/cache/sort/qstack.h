/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* qstack.h
 *
 */

#ifndef _QSTACK_H_
#define _QSTACK_H_

#include <sys/mman.h>

typedef struct qitem
{
    unsigned r, l;
} qitem_t;

static int qtop = 0;

#ifdef __SPU__
#define USE_CACHE
#endif

#ifdef USE_CACHE
#define CACHE_NAME		qstack
#define CACHED_TYPE		qitem_t
#define CACHELINE_LOG2SIZE	7       /* 128 bytes */
#define CACHE_LOG2NWAY		0       /* direct */
#define CACHE_LOG2NSETS		0       /* 1 set/line */
#define CACHE_TYPE		1       /* r/w */	
#include <cache-api.h>

static qitem_t *qstk;


static inline void
qstack_init(size_t size)
{
    qstk = (qitem_t *)(unsigned)mmap_eaddr(0ULL, size, PROT_READ|PROT_WRITE,
	    MAP_ANON|MAP_PRIVATE, -1, 0);
}

static inline void
qstack_fini()
{
    cache_flush(qstack);
    cache_pr_stats(qstack);
}

#define PUSH(val) cache_wr(qstack, &qstk[qtop], (val))
#define POP()	  cache_rd(qstack, &qstk[qtop])
#else /* !USE_CACHE */

#define QSTACK_SZ	1024
static qitem_t qstk[QSTACK_SZ];

#define PUSH(val)	(qstk[qtop] = (val))
#define POP()		(qstk[qtop])

#define qstack_init(size)
#define qstack_fini()

#endif

int max_qtop = 0;

static inline void
qstack_push (qitem_t *item)
{
    PUSH(*item);
    qtop++;
    max_qtop = (qtop > max_qtop) ? qtop : max_qtop;
}

static inline void
qstack_pop (qitem_t *item)
{
    qtop--;
    *item = POP();
}

static inline int
qstack_empty (void)
{
    return (qtop == 0);
}
#endif
