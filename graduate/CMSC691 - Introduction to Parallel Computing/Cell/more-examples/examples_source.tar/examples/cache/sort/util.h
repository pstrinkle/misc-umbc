/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * util.h
 *
 * Utility services for sort code that uses
 * the software managed cache.  
 *
 * This is as example of how reusable services
 * can be defined to use the software cache.
 *
 * If USE_CACHE is defined, the caller needs to
 * have included the required header file and
 * also (re) defined CACHE_NAME and CACHED_TYPE
 * before including this file.
 *
 * if USE_VECTOR is defined, SORT_AXIS must also
 * be defined.
 *
 */
#ifndef _UTIL_H_
#define _UTIL_H_

#ifndef CACHE_NAME
#error CACHE_NAME not defined!
#endif
#ifndef CACHED_TYPE
#error CACHED_TYPE not defined
#endif

static int nr_compares = 0;

/* macros for accessing the cache */
#ifdef USE_CACHE
#define _LOADPTR(ea)	__cache_rw((unsigned)(ea), 1)
#define _LOAD(ea)	__cache_rd((unsigned)(ea))
#define _STORE(ea, val)	__cache_wr((unsigned)(ea), (val))
#define _LOCK(lsa)	__cache_lock((unsigned)(lsa))
#define _UNLOCK(lsa)	__cache_unlock((unsigned)(lsa))
#else
#define _LOADPTR(ea)    (CACHED_TYPE *)(ea)
#define _LOAD(ea)       (*(ea))
#define _STORE(ea, val) (*(ea) = (val))
#define _LOCK(lsa)
#define _UNLOCK(lsa)
#endif

#ifdef USE_VECTOR
#define spu_cmple(a, b)         spu_xor(spu_cmpgt(a, b), -1)

static inline int
compare_leq(CACHED_TYPE a, CACHED_TYPE b)
{
    vec_uint4 a_leq_b = spu_cmple(a, b);
    nr_compares++;
    return (spu_extract(a_leq_b, SORT_AXIS)) ? 1 : 0;
}
#else
static inline int
compare_leq(CACHED_TYPE a, CACHED_TYPE b) { nr_compares++; return (a <= b); }
#endif

/*
 * returns 2 LSA pointers (in the cache) given
 * two 32-bit effective addresses
*
 * After loading the first item, lock it in the
 * cache so it doesn't get displaced by the next
 * access.  Both items must be resident in the cache
 * when we return since the caller will store to
 * them using the pointers we pass back.
 */
static inline void
get_2ptrs (CACHED_TYPE *eai, CACHED_TYPE *eaj,
            CACHED_TYPE **lsai, CACHED_TYPE **lsaj)
{
    *lsai = _LOADPTR(eai);
    _LOCK(*lsai);
    *lsaj = _LOADPTR(eaj);
    _UNLOCK(*lsai);
}

/*
 * read two values into the cache and
 * swap them with each other.
 */
static inline CACHED_TYPE
swap (CACHED_TYPE *a, int i, int j)
{
    CACHED_TYPE tmp;
#if defined(USE_CACHE) && (CACHE_LOG2NWAY >= 1)
    CACHED_TYPE *pi, *pj;

    get_2ptrs (&a[i], &a[j], &pi, &pj);
    tmp = *pi;
    *pi = *pj;
    *pj = tmp;
#else
    tmp = _LOAD (&a[i]);
    _STORE (&a[i], _LOAD (&a[j]));
    _STORE (&a[j], tmp);
#endif

    return tmp;
}

/*
 * compare element i to the reference value, and if it is
 * '<='  && (polarity == 0) or '>'  && (polarity == 1)
 * swap it with element j.
 *
 * return value is 1 if swap happened, 0 if not
 */ 
static inline int
compare_and_swap (CACHED_TYPE *a, int i, int j,
                    CACHED_TYPE cmp_val, int polarity)
{
    CACHED_TYPE aii, ajj;
    CACHED_TYPE ai, aj;
#if defined(USE_CACHE) && (CACHE_LOG2NWAY >= 1)
    CACHED_TYPE *pi, *pj;

    get_2ptrs (&a[i], &a[j], &pi, &pj);
    ai = *pi;
    aj = *pj;
#else
    ai = _LOAD (&a[i]);
    aj = _LOAD (&a[j]);
#endif

    int ai_leq_pivot = compare_leq (ai, cmp_val) ^ polarity;

    aii = (ai_leq_pivot) ? aj : ai;
    ajj = (ai_leq_pivot) ? ai : aj;

#if defined(USE_CACHE) && (CACHE_LOG2NWAY >= 1)
    *pi = aii;
    *pj = ajj;
#else
    _STORE (&a[i], aii);
    _STORE (&a[j], ajj);
#endif

    return (ai_leq_pivot) ? 1 : 0;
}
#endif
