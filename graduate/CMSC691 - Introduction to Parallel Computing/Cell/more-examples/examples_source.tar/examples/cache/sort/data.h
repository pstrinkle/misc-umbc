/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * data.h
 *
 * Services for reading and generating
 * data and mapping it
 *
 * If USE_CACHE is defined, the caller needs
 * to have defined a cache and defined CACHE_NAME
 * and CACHED_TYPE.
 */
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>

#ifdef __SPU__
#define mmap mmap_eaddr
#define mmap_fail	MAP_FAILED_EADDR
static unsigned long long src;
#else
#define mmap_type	void *
#define mmap_fail	MAP_FAILED
static void *src;
#endif

#ifdef USE_VECTOR
#define SIZE_SHIFT 4
#else
#define SIZE_SHIFT 2
#endif

#ifdef USE_CACHE
#define _STORE(ea, val)	__cache_wr((unsigned)(ea), (val))
#else
#define _STORE(ea, val)	(*(ea) = (val))
#endif

/*
 * generate an array of random floats, using the cache
 */
static inline void *
map_rand (int nitems)
{
    int i;
    CACHED_TYPE *a;
    /* amount of space needed, rounded up to next 4K */
    unsigned space = (((nitems * sizeof(CACHED_TYPE) >> 12) + 1) << 12);

    src = mmap (0ULL, space, PROT_READ|PROT_WRITE,
	    MAP_ANON|MAP_PRIVATE, -1, 0);

    if (src == mmap_fail)
	return NULL;

    a = (CACHED_TYPE *)(unsigned)src;

    for (i=0; i < nitems; i++) {
#ifdef USE_VECTOR
	    _STORE (&a[i],
		spu_splats ((float)(1000.0f * (rand() / (RAND_MAX + 1.0)))));
#else
	    _STORE (&a[i],
		(float) 1000.0f * (rand() / (RAND_MAX + 1.0)));
#endif
    }
    return (void *)(unsigned)src;
}


/*
 * map the data file
 */
static inline void *
map_file (char *fname, int *nitems)
{
    int fd;
    struct stat buf;

    /* Open the file. */
    if ((fd = open (fname, O_RDONLY, 0)) == -1)
    {
	perror ("Can't open file");
	return NULL;
    }

    /* Set up memory mapping. */
    if (fstat (fd, &buf) != 0)
    {
	perror ("Can't stat file");
	return NULL;
    }
    if (!buf.st_size)
    {
	printf ("Input file is zero-sized\n");
	return NULL;
    }
    if (buf.st_size & 0xf)
    {
	printf ("Input file is not quad-word sized!\n");
	return NULL;
    }

    src = mmap (0ULL, buf.st_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (src == mmap_fail)
    {
	perror ("Can't mmap source file");
	return NULL;
    }
    *nitems = buf.st_size >> SIZE_SHIFT;
    return (void *)(unsigned)src;
}
