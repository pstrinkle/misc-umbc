/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* qsort.c
 *
 * Implementation of an iterative quicksort algorithm,
 * using a software managed cache.
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <sys/types.h>

#ifdef __SPU__
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#define USE_VECTOR
#define USE_CACHE
#endif

#ifdef USE_VECTOR
typedef vec_float4 item_t;
#define SORT_X          0
#define SORT_Y          1
#define SORT_Z          2
#define SORT_W          3
#define SORT_AXIS       SORT_Y
#define LOADVAL(ea) \
    spu_extract (LOAD(ea), SORT_AXIS)
#else
typedef float item_t;
#define LOADVAL(ea)     LOAD(ea)
#endif

#ifdef USE_CACHE
#define	CACHE_NAME		qsort
#define CACHED_TYPE		item_t
#define CACHELINE_LOG2SIZE	10
#define CACHE_LOG2NWAY		2
#define CACHE_LOG2NSETS		5
#define CACHE_TYPE		1
#include <cache-api.h>
#define LOAD(ea)                cache_rd (qsort, (unsigned)(ea))
#define STORE(ea, val)          cache_wr (qsort, (unsigned)(ea), (val))
#define CACHE_FLUSH()           cache_flush (qsort)
#define CACHE_PR_STATS()        cache_pr_stats (qsort)
#else
#define LOAD(ea)                (*(CACHED_TYPE *)(ea))
#define STORE(ea, val)          (*(CACHED_TYPE *)(ea) = (val))
#define CACHE_FLUSH()
#define CACHE_PR_STATS()
#endif

#include "qstack.h"

/* use sort utility services */
#define CACHE_NAME	qsort
#define CACHED_TYPE	item_t
#define CACHE_LOG2NWAY  2
#include "util.h"
#include "data.h"

/*
 * threshold for switching to insertion sort
 * for small partitions when doing quicksort.
 */
static int quick_to_insert;

/* defaults */
#define QUICK_TO_INSERT	20
#define NITEMS		8192

static inline int
pick_pivot (int left, int right)
{
    int r = (int) ((float) (right - left) * (rand () / (RAND_MAX + 1.0)));
    int ret = left + r;
    assert(ret < right);
    return ret;
}

static inline int
partition (item_t * a, int left, int right, int pivot_index)
{
    int store_index = left;
    item_t pivot_val;
    int i;

    pivot_val = swap (a, pivot_index, right);
    for (i = left; i <= right - 1; i++)
    {
	store_index += compare_and_swap (a, i, store_index, pivot_val, 0);
    }
    swap (a, right, store_index);
    return store_index;
}

static inline void
insertion_sort (item_t *a, int left, int right)
{
    int i, j;
    item_t val;
    for (i = left+1; i <= right; i++) {
	val = LOAD (&a[i]);
	j = i;
	while (j > 0 && compare_and_swap (a, j-1, j, val, 1))
		j--;

	STORE (&a[j], val);
    }
}

static inline void
iterative_qsort (item_t *a, int size)
{
    qitem_t item;

    item.l = 0;
    item.r = size - 1;
    qstack_push (&item);
    while (!qstack_empty ())
    {
	int left, right;

	qstack_pop (&item);

	right = item.r;
	left = item.l;

	if (right > left)
	{
	    unsigned pivot_index = pick_pivot (left, right);

	    pivot_index = partition (a, left, right, pivot_index);

	    item.r = pivot_index - 1;

	    /* switch to insertion sort for small partitions */
	    if ((pivot_index - item.l) <= (unsigned)quick_to_insert)
		insertion_sort (a, item.l, item.r);
	    else
		qstack_push (&item);

	    item.l = pivot_index + 1;
	    item.r = right;

	    if ((item.r - pivot_index) <= (unsigned)quick_to_insert)
		insertion_sort (a, item.l, item.r);
	    else
		qstack_push (&item);
	}
    }
}

static inline void
usage_exit (char *prog, char *bad)
{
    printf ("Unknown option: %s\n", bad);
    printf ("Usage: %s [ -i <insertion_threshold> ]"
	   " [ -n <num_items> | -f <filename> ]\n", prog);
    exit (1);
}

int
main (int argc, char **argv)
{
    item_t *a;
    int nitems = 0;
    char *fname = NULL;
    int c;
#ifdef DEBUG
    int i;
    float prev = 0.0, curr;
#endif

    while ((c = getopt (argc, argv, "n:i:f:")) != EOF)
    {
	switch (c) {
	    case 'n': nitems = atoi (optarg); break;
	    case 'i': quick_to_insert = atoi (optarg); break;
	    case 'f': fname = optarg; break; /* ignore 'n' */
	    default:
		usage_exit (argv[0], argv[optind-1]);
	}
    }

    /* check for trailing args */
    if (argc > optind)
	usage_exit (argv[0], argv[optind]);

    if (nitems <= 0)
	nitems = NITEMS;

    if (quick_to_insert < 0)
	quick_to_insert = QUICK_TO_INSERT;

    /*
     * use data file if specified, else
     * generate random data
     */
    if (fname)
	a = (item_t *)map_file (fname, &nitems);
    else
	a = (item_t *)map_rand (nitems);

    if (a == NULL) {
	printf("unable to map data!\n");
	exit (1);
    }

    qstack_init (4096);
    iterative_qsort (a, nitems);

#ifdef DEBUG
    printf ("Number of compares: %d\n", nr_compares);
    printf ("Maximum qtop:       %d\n", max_qtop);
    for (i=0; i < nitems; i++) {
	curr = LOADVAL (&a[i]);
	if (curr < prev) {
            printf("Sort failed! Aborting.\n");
            abort();
        }
	prev = curr;
    }
#endif

    qstack_fini ();
    CACHE_FLUSH ();
    CACHE_PR_STATS ();

    return 0;
}
