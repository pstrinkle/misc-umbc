/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* hsort.c
 *
 * Implementation of a heapsort algorithm,
 * using a software managed cache.
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <sys/types.h>

#ifdef __SPU__
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#define USE_VECTOR
#define USE_CACHE
#endif

#ifdef USE_VECTOR
typedef vec_float4 item_t;
#define SORT_X          0
#define SORT_Y          1
#define SORT_Z          2
#define SORT_W          3
#define SORT_AXIS       SORT_Y
#define LOADVAL(ea) \
    spu_extract (LOAD(ea), SORT_AXIS)
#else
typedef float item_t;
#define LOADVAL(ea)     LOAD(ea)
#endif

#ifdef USE_CACHE
#define	CACHE_NAME		hsort
#define CACHED_TYPE		item_t
#define CACHELINE_LOG2SIZE	7
#define CACHE_LOG2NWAY		2
#define CACHE_LOG2NSETS		6
#define CACHE_TYPE		1
#include <cache-api.h>
#define LOAD(ea)                cache_rd (hsort, (unsigned)(ea))
#define STORE(ea, val)          cache_wr (hsort, (unsigned)(ea), (val))
#define CACHE_FLUSH()           cache_flush (hsort)
#define CACHE_PR_STATS()        cache_pr_stats (hsort)
#else
#define LOAD(ea)                (*(CACHED_TYPE *)(ea))
#define STORE(ea, val)          (*(CACHED_TYPE *)(ea) = (val))
#define CACHE_FLUSH()
#define CACHE_PR_STATS()
#endif

#define CACHE_NAME	hsort
#define CACHED_TYPE	item_t
#include "util.h"
#include "data.h"

/* default number of items */
#define NITEMS		8192

static inline void
heapup (item_t *a, int start)
{
    int root, child, rem;

    for (child = start; child > 0;) {
	rem = (child - 1) % 2;
	root = ((child - 1) - rem) / 2;

	if (compare_and_swap (a, root, child, LOAD (&a[child]), 0))
	    child = root;
	else
	    return;
    }

}

static inline void
heapdown (item_t *a, int start, int count)
{
    int root, child;

    for (root = start; child = (root * 2 + 1), child < count;) {
	item_t child_val = LOAD (&a[child]);
	item_t chpp_val = LOAD (&a[child+1]);

	if (child < (count - 1) &&
		compare_leq (child_val, chpp_val))
	{
	    child += 1;
	    child_val = chpp_val;
	}

	if (compare_and_swap (a, root, child, child_val, 0))
	    root = child;
	else
	    return;
    }
}

static inline void
heap_sort (item_t *a, int count)
{
    int start, end;

    for (start = 0; start <= (count - 2);) 
	heapup (a, ++start);

    for (end = count - 1; end > 0; end--) {
	swap (a, end, 0);
	heapdown (a, 0, end);
    }

}

static inline void
usage_exit (char *prog, char *bad)
{
    printf ("Unknown option: %s\n", bad);
    printf ("Usage: %s [ -n <num_items> | -f <filename> ]\n", prog);
    exit (1);
}

int
main (int argc, char **argv)
{
    item_t *a;
    int nitems = 0;
    char *fname = NULL;
    int c;
#ifdef DEBUG
    int i;
    float prev = 0.0, curr;
#endif

    while ((c = getopt (argc, argv, "n:f:")) != EOF)
    {
	switch (c) {
	    case 'n': nitems = atoi (optarg); break;
	    case 'f': fname = optarg; break; /* ignore 'n' */
	    default:
		usage_exit (argv[0], argv[optind-1]);
	}
    }

    /* check for trailing args */
    if (argc > optind)
	usage_exit (argv[0], argv[optind]);

    if (nitems <= 0)
	nitems = NITEMS;

    /*
     * use data file if specified, else
     * generate random data
     */
    if (fname)
	a = (item_t *)map_file (fname, &nitems);
    else
	a = (item_t *)map_rand (nitems);

    if (a == NULL) {
	printf ("Unable to map data!\n");
	exit (1);
    }

    heap_sort (a, nitems);

#ifdef DEBUG
    printf ("Number of compares: %d\n", nr_compares);
    for (i=0; i < nitems; i++) {
	curr = LOADVAL (&a[i]);
	if (curr < prev) {
            printf("Sort failed! Aborting.\n");
            abort();
        }
	prev = curr;
    }
#endif

    CACHE_FLUSH ();
    CACHE_PR_STATS ();

    return 0;
}
