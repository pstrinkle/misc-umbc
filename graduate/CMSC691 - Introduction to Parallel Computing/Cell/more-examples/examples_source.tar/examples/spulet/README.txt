%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              
Target: 
	SPE, Linux

Description:
	This directory contains examples of stand alone SPU programs, 
	refered to here as "spulets".  These are C-language programs 
	that have been compiled to run on an SPU, and may invoke
	C-library functions such as printf(3), open(2), read(2), 
	write(2), mmap(2), etc.

	Further, "spulets" can be executed directly from the Linux
	command prompt.  These programs take standard argument strings 
	and exit with integer return codes.  In short, "spulets" 
	outwardly look just like any other executable in the file system.

	The simplicity of the "spulet" programming model is meant to 
	encourage porting and incremental refinement of legacy code on 
	the SPU.  Further, "spulets" could be used to create a whole
	new generation of reusable media file filters (e.g. transcoders, 
	encrypt/decrypt engines, etc).  And because "spulets" can interact 
	with stdin/stdout/stderr, they may be recombined with existing
	utilities via pipes, shared memory, and so forth.

Notes:
	For spulets to utilize standard argument parameters, they must
	must be linked with a special crt object. This is accomplished by 
	usng the gcc compiler argument "-mstdmain" or the xlc compiler argument
	"-qstdmain".
