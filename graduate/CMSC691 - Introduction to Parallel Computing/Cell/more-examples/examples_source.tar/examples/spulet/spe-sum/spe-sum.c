/* --------------------------------------------------------------  */
/* (C)Copyright 2005,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * spe-sum.c
 *
 * Stand-alone 'spulet' that computes a checksum for file.
 * The file contents are mmap'd into the effective address
 * space and DMAs are used to stage data into LS.
 * 
 * The purpose here is to illustrate how an SPE-based
 * file filter might be constructed.  For example, an
 * SPE could be used to authenticate or decompress data,
 * rather than compute a simple checksum.
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <spu_mfcio.h>

#define NR_BUFS         4
#define BUF_SIZE_SHIFT	12
#define BUF_SIZE        (1 << BUF_SIZE_SHIFT)
#define BUF_SIZE_MASK	(BUF_SIZE - 1)

#define likely(_c)     \
    __builtin_expect((_c), 1)
#define unlikely(_c)    \
    __builtin_expect((_c), 0)

#define min(_a, _b)	((_a < _b) ? _a : _b)

#define DMA(ls, ea, size, tag, cmd)     \
        spu_mfcdma64(ls, ea.by32[0], ea.by32[1], size, tag, cmd)

#define WAIT(msk)			\
    spu_writech(MFC_WrTagMask, msk);	\
    spu_mfcstat(MFC_TAG_UPDATE_ALL)

typedef union {
    unsigned long long all64;
    unsigned int by32[2];
} addr64;

/* Intermediate buffer */
static char buf[BUF_SIZE * NR_BUFS] __attribute__ ((aligned(128)));

int sum = 0;
size_t total_bytes = 0;

static void do_checksum(char *buf, int nbytes)
{
    for (; nbytes > 0; nbytes--, total_bytes++, buf++) {
	sum = (sum >> 1) + ((sum & 1) << 15);
	sum += *buf;
	sum &= 0xffff;
    }
}

static void checksum_ea_whole(unsigned long long src, int nbufs)
{
    unsigned int i = 0;
    unsigned int size = BUF_SIZE;
    unsigned int nbufs_to_xfer = nbufs;
    addr64 _src;

    _src.all64 = src;

    /* Kick off DMAs to get multi-buffer scheme rolling... */
    for (i = 0; i < (unsigned int) min(nbufs, NR_BUFS); i++) {
	DMA(&buf[i * BUF_SIZE], _src, size, i, MFC_GET_CMD);
	_src.all64 += BUF_SIZE;
	nbufs_to_xfer--;
    }

    i = 0;
    while (nbufs > 0) {
	unsigned int mask = (1 << i);

	WAIT(mask);
	do_checksum(&buf[i * BUF_SIZE], BUF_SIZE);
	if (likely(nbufs_to_xfer > 0)) {
	    DMA(&buf[i * BUF_SIZE], _src, size, i, MFC_GET_CMD);
	    _src.all64 += BUF_SIZE;
	    nbufs_to_xfer--;
	}
	i = (i >= NR_BUFS-1) ? 0 : i+1;
	nbufs--;
    }
}

static void checksum_ea_partial(unsigned long long src, size_t size)
{
    unsigned int quadwords = size & ~0xf;
    unsigned int rem = size & 0xf;
    unsigned int i = 0;
    addr64 _src;

    _src.all64 = src;
    if (likely(quadwords)) {
	unsigned int mask = 0x1;

	DMA(&buf[0], _src, quadwords, i, MFC_GETF_CMD);
	_src.all64 += quadwords;
	WAIT(mask);
	do_checksum(&buf[0], quadwords);
    }
    if (unlikely(rem)) {
	unsigned int mask = 0xffff;
	char *ptr = &buf[0];

	if (rem & 0x8) {
	    unsigned int eight_bytes = 8;
	    unsigned int tag = 3;

	    DMA(ptr, _src, eight_bytes, tag, MFC_GETF_CMD);
	    _src.all64 += eight_bytes;
	    ptr += eight_bytes;
	}
	if (rem & 0x4) {
	    unsigned int four_bytes = 4;
	    unsigned int tag = 2;

	    DMA(ptr, _src, four_bytes, tag, MFC_GETF_CMD);
	    _src.all64 += four_bytes;
	    ptr += four_bytes;
	}
	if (rem & 0x2) {
	    unsigned int two_bytes = 2;
	    unsigned int tag = 1;

	    DMA(ptr, _src, two_bytes, tag, MFC_GETF_CMD);
	    _src.all64 += two_bytes;
	    ptr += two_bytes;
	}
	if (rem & 0x1) {
	    unsigned int one_byte = 1;
	    unsigned int tag = 0;

	    DMA(ptr, _src, one_byte, tag, MFC_GETF_CMD);
	    _src.all64 += one_byte;
	    ptr += one_byte;
	}
	WAIT(mask);
	do_checksum(&buf[0], rem);
    }
}

/* Calculate a rotated checksum, using blocksize=1024. */
static void checksum_ea(unsigned long long src, size_t size)
{
    unsigned int nbufs = size >> BUF_SIZE_SHIFT;
    unsigned int rem = size & BUF_SIZE_MASK;

    if (likely(nbufs > 0)) {
	checksum_ea_whole(src, nbufs);
	src += (nbufs * BUF_SIZE);
    }
    if (likely(rem)) {
	checksum_ea_partial(src, rem);
    }
    printf("%05d %5lu\n", sum, (total_bytes+1023) >> 10);
}

int main(int argc, char **argv)
{
    char *name;
    int fd;
    struct stat buf;
    unsigned long long src;

    if (argc != 2) {
	printf("Usage: %s [file].\n", argv[0]);
	return 1;
    }
    name = argv[1];

    /* Open the file. */
    if ((fd = open(name, O_RDONLY, 0)) == -1) {
	perror("Can't open file");
	return 1;
    }

    /* Set up memory mapping. */
    if (fstat(fd, &buf) != 0) {
	perror("Can't stat file");
	return 1;
    }
    if (!buf.st_size) {
	return 0;
    }
    src = mmap_eaddr(0ULL, buf.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (src == MAP_FAILED_EADDR) {
	perror("Can't mmap source file");
	return 1;
    }

    /* Compute checksum. */
    checksum_ea(src, buf.st_size);

    return 0;
}
