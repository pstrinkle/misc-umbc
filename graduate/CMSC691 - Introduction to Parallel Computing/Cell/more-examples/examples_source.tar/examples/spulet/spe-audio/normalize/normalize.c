/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * normalize.c
 *
 * Stand-alone 'spulet' that normalizes the volume of a mono
 * audio file.
 * The file contents are mmap'd into the effective address
 * space and double-buffered DMAs are used to stage data 
 * into and then out from LS.
 * 
 * This sample illustrates how a SPE-based audio filter 
 * might be constructed. This type of filter might be combined with
 * other filters in a pipeline fashion to apply multiple filters to
 * the same file. 
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <spu_mfcio.h>
#include <spu_intrinsics.h>
#include <simdmath/divf4.h>
#include <simdmath/sqrtf4.h>
#include <simdmath/recipf4.h>
#include <clamp_v.h>
#include <assert.h>

#define BUF_SIZE_SHIFT 10
#define BUF_SIZE      (1 << BUF_SIZE_SHIFT)
#define BUF_SIZE_HALF (1 << (BUF_SIZE_SHIFT-1))
#define BUF_SIZE_MASK (BUF_SIZE - 1)

vector unsigned short in1_buff[BUF_SIZE_HALF], 
                      in2_buff[BUF_SIZE_HALF], 
                      in3_buff[BUF_SIZE_HALF], 
                      in4_buff[BUF_SIZE_HALF],
                      in5_buff[BUF_SIZE_HALF],
                      in6_buff[BUF_SIZE_HALF],
                      in7_buff[BUF_SIZE_HALF],
                      in8_buff[BUF_SIZE_HALF],
                      out1_buff[BUF_SIZE_HALF],
                      out2_buff[BUF_SIZE_HALF],
                      out3_buff[BUF_SIZE_HALF],
                      out4_buff[BUF_SIZE_HALF] __attribute__ ((aligned (128)));
vector unsigned short **in[2], **out[2], *in1[4], *in2[4], *out1[2], *out2[2];
vector unsigned char conv_patt = (vector unsigned char){0x02,0x03,0x12,0x13,0x06,0x07,0x16,0x17,
                                                        0x0A,0x0B,0x1A,0x1B,0x0E,0x0F,0x1E,0x1F};
unsigned int in_tags, out_tags;

                                                        
static inline vector float _mult_ushort_to_float_odd_v(vector unsigned short in, vector unsigned short factor) {
    vector unsigned int tmp;
    
    tmp = spu_mulo(in, factor);
    return spu_convtf(tmp, 0);
}

static inline vector float _mult_ushort_to_float_even_v(vector unsigned short in, vector unsigned short factor) {
    vector unsigned int tmp;
    
    tmp = spu_mule(in, factor);
    return spu_convtf(tmp, 0);
}

static inline vector float _sum_across_float4_v(vector float v) {
  vector float c12, c2, c3, c4, c34;

  c2 = spu_rlqwbyte(v, 4);
  c3 = spu_rlqwbyte(v, 8);
  c4 = spu_rlqwbyte(v, 12);
  c12 = spu_add(v,  c2);
  c34 = spu_add(c3, c4);

  return spu_add(c12, c34);
}

static vector float calc_RMS_v(vector unsigned short in[], int length) {
    int i;
    vector unsigned short in0, in1, in2, in3, in4, in5, in6, in7;
    vector float in0f1, in0f2, in1f1, in1f2, in2f1, in2f2, in3f1, in3f2,
                 in4f1, in4f2, in5f1, in5f2, in6f1, in6f2, in7f1, in7f2,
                 sum, avg,
                 sum_in0f1, sum_in0f2, sum_in1f1, sum_in1f2, sum_in2f1, sum_in2f2, sum_in3f1, sum_in3f2,
                 sum_in4f1, sum_in4f2, sum_in5f1, sum_in5f2, sum_in6f1, sum_in6f2, sum_in7f1, sum_in7f2;
    
    sum_in0f1 = spu_splats(0.0f);
    sum_in1f1 = spu_splats(0.0f);
    sum_in2f1 = spu_splats(0.0f);
    sum_in3f1 = spu_splats(0.0f);
    sum_in4f1 = spu_splats(0.0f);
    sum_in5f1 = spu_splats(0.0f);
    sum_in6f1 = spu_splats(0.0f);
    sum_in7f1 = spu_splats(0.0f);
    
    sum_in0f2 = spu_splats(0.0f);
    sum_in1f2 = spu_splats(0.0f);
    sum_in2f2 = spu_splats(0.0f);
    sum_in3f2 = spu_splats(0.0f);
    sum_in4f2 = spu_splats(0.0f);
    sum_in5f2 = spu_splats(0.0f);
    sum_in6f2 = spu_splats(0.0f);
    sum_in7f2 = spu_splats(0.0f);
    
    for (i = 0; i < length - 7; i+=8) {
        in0 = in[i];
        in1 = in[i+1];
        in2 = in[i+2];
        in3 = in[i+3];
        in4 = in[i+4];
        in5 = in[i+5];
        in6 = in[i+6];
        in7 = in[i+7];
        
        /* Square and convert to float vectors */
        /* Each unsigned short vector becomes two float vectors */
        
        in0f1 = _mult_ushort_to_float_odd_v(in0, in0);
        in1f1 = _mult_ushort_to_float_odd_v(in1, in1);
        in2f1 = _mult_ushort_to_float_odd_v(in2, in2);
        in3f1 = _mult_ushort_to_float_odd_v(in3, in3);
        in4f1 = _mult_ushort_to_float_odd_v(in4, in4);
        in5f1 = _mult_ushort_to_float_odd_v(in5, in5);
        in6f1 = _mult_ushort_to_float_odd_v(in6, in6);
        in7f1 = _mult_ushort_to_float_odd_v(in7, in7);
        
        in0f2 = _mult_ushort_to_float_even_v(in0, in0);
        in1f2 = _mult_ushort_to_float_even_v(in1, in1);
        in2f2 = _mult_ushort_to_float_even_v(in2, in2);
        in3f2 = _mult_ushort_to_float_even_v(in3, in3);
        in4f2 = _mult_ushort_to_float_even_v(in4, in4);
        in5f2 = _mult_ushort_to_float_even_v(in5, in5);
        in6f2 = _mult_ushort_to_float_even_v(in6, in6);
        in7f2 = _mult_ushort_to_float_even_v(in7, in7);
        
        /* Sum the elements */
        
        sum_in0f1 = spu_add(sum_in0f1, in0f1);
        sum_in1f1 = spu_add(sum_in1f1, in1f1);
        sum_in2f1 = spu_add(sum_in2f1, in2f1);
        sum_in3f1 = spu_add(sum_in3f1, in3f1);
        sum_in4f1 = spu_add(sum_in4f1, in4f1);
        sum_in5f1 = spu_add(sum_in5f1, in5f1);
        sum_in6f1 = spu_add(sum_in6f1, in6f1);
        sum_in7f1 = spu_add(sum_in7f1, in7f1);
        
        sum_in0f2 = spu_add(sum_in0f2, in0f2);
        sum_in1f2 = spu_add(sum_in1f2, in1f2);
        sum_in2f2 = spu_add(sum_in2f2, in2f2);
        sum_in3f2 = spu_add(sum_in3f2, in3f2);
        sum_in4f2 = spu_add(sum_in4f2, in4f2);
        sum_in5f2 = spu_add(sum_in5f2, in5f2);
        sum_in6f2 = spu_add(sum_in6f2, in6f2);
        sum_in7f2 = spu_add(sum_in7f2, in7f2);
    }  
    
    sum = spu_add(sum_in0f1, sum_in1f1);
    sum = spu_add(sum, sum_in2f1);
    sum = spu_add(sum, sum_in3f1);
    sum = spu_add(sum, sum_in4f1);
    sum = spu_add(sum, sum_in5f1);
    sum = spu_add(sum, sum_in6f1);
    sum = spu_add(sum, sum_in7f1);
    
    sum = spu_add(sum, sum_in0f2);
    sum = spu_add(sum, sum_in1f2);
    sum = spu_add(sum, sum_in2f2);
    sum = spu_add(sum, sum_in3f2);
    sum = spu_add(sum, sum_in4f2);
    sum = spu_add(sum, sum_in5f2);
    sum = spu_add(sum, sum_in6f2);
    sum = spu_add(sum, sum_in7f2);
    
    sum = _sum_across_float4_v(sum);
    
    /* Calculate inverse of root mean square */
    avg = _divf4(sum, spu_splats((float)(length * 8)));
    avg = _sqrtf4((vector float)avg);
    return avg;
}

static void vol_scale_v(vector unsigned short in[], 
                        vector unsigned short out[],
                        int length,
                        vector float scale,
                        vector float slope,
                        vector float min,
                        vector float max) {
    int i;
    vector unsigned short in0, in1, in2, in3, in4, in5, in6, in7,
                          out0, out1, out2, out3, out4, out5, out6, out7;
    vector float in0f1, in0f2, in1f1, in1f2, in2f1, in2f2, in3f1, in3f2,
                 in4f1, in4f2, in5f1, in5f2, in6f1, in6f2, in7f1, in7f2,
                 scale0, scale1, scale2, scale3, scale4, scale5, scale6, scale7;
    vector unsigned int in0i1, in0i2, in1i1, in1i2, in2i1, in2i2, in3i1, in3i2,
                        in4i1, in4i2, in5i1, in5i2, in6i1, in6i2, in7i1, in7i2;
    
    /* Increment scale 8 samples at a time */
    slope = spu_mul(slope, spu_splats(8.0f));
    /* Multiply each sample by the scale factor */
    for (i = 0; i < length - 7; i+=8) {
        in0 = in[i];
        in1 = in[i+1];
        in2 = in[i+2];
        in3 = in[i+3];
        in4 = in[i+4];
        in5 = in[i+5];
        in6 = in[i+6];
        in7 = in[i+7];
        
        /* Convert to unsigned int vectors and then to float vectors */
        in0i1 = (vector unsigned int)spu_sel(in0, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in1i1 = (vector unsigned int)spu_sel(in1, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in2i1 = (vector unsigned int)spu_sel(in2, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in3i1 = (vector unsigned int)spu_sel(in3, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in4i1 = (vector unsigned int)spu_sel(in4, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in5i1 = (vector unsigned int)spu_sel(in5, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in6i1 = (vector unsigned int)spu_sel(in6, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in7i1 = (vector unsigned int)spu_sel(in7, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        
        in0f1 = spu_convtf(in0i1, 0);            
        in1f1 = spu_convtf(in1i1, 0);
        in2f1 = spu_convtf(in2i1, 0);
        in3f1 = spu_convtf(in3i1, 0);
        in4f1 = spu_convtf(in4i1, 0);
        in5f1 = spu_convtf(in5i1, 0);
        in6f1 = spu_convtf(in6i1, 0);
        in7f1 = spu_convtf(in7i1, 0);
        
        in0 = spu_rlqwbyte(in0, -2);
        in1 = spu_rlqwbyte(in1, -2);
        in2 = spu_rlqwbyte(in2, -2);
        in3 = spu_rlqwbyte(in3, -2);
        in4 = spu_rlqwbyte(in4, -2);
        in5 = spu_rlqwbyte(in5, -2);
        in6 = spu_rlqwbyte(in6, -2);
        in7 = spu_rlqwbyte(in7, -2);
           
        in0i2 = (vector unsigned int)spu_sel(in0, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in1i2 = (vector unsigned int)spu_sel(in1, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in2i2 = (vector unsigned int)spu_sel(in2, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in3i2 = (vector unsigned int)spu_sel(in3, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in4i2 = (vector unsigned int)spu_sel(in4, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in5i2 = (vector unsigned int)spu_sel(in5, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in6i2 = (vector unsigned int)spu_sel(in6, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        in7i2 = (vector unsigned int)spu_sel(in7, spu_splats((unsigned short)0), (vector unsigned short)spu_maskb(0xCCCC));
        
        in0f2 = spu_convtf(in0i2, 0);            
        in1f2 = spu_convtf(in1i2, 0);
        in2f2 = spu_convtf(in2i2, 0);
        in3f2 = spu_convtf(in3i2, 0);
        in4f2 = spu_convtf(in4i2, 0);
        in5f2 = spu_convtf(in5i2, 0);
        in6f2 = spu_convtf(in6i2, 0);
        in7f2 = spu_convtf(in7i2, 0);
        
        scale0 = spu_add(slope, scale);
        scale1 = spu_add(slope, scale0);
        scale2 = spu_add(slope, scale1);
        scale3 = spu_add(slope, scale2);
        scale4 = spu_add(slope, scale3);
        scale5 = spu_add(slope, scale4);
        scale6 = spu_add(slope, scale5);
        scale7 = spu_add(slope, scale6);
        /* Increment scale for the next iteration */
        scale = spu_madd(slope, spu_splats(8.0f), scale);
        
        /* Multiply by scale */
        in0f1 = spu_mul(in0f1, scale);
        in1f1 = spu_mul(in1f1, scale);
        in2f1 = spu_mul(in2f1, scale);
        in3f1 = spu_mul(in3f1, scale);
        in4f1 = spu_mul(in4f1, scale);
        in5f1 = spu_mul(in5f1, scale);
        in6f1 = spu_mul(in6f1, scale);
        in7f1 = spu_mul(in7f1, scale);
        
        in0f2 = spu_mul(in0f2, scale);
        in1f2 = spu_mul(in1f2, scale);
        in2f2 = spu_mul(in2f2, scale);
        in3f2 = spu_mul(in3f2, scale);
        in4f2 = spu_mul(in4f2, scale);
        in5f2 = spu_mul(in5f2, scale);
        in6f2 = spu_mul(in6f2, scale);
        in7f2 = spu_mul(in7f2, scale);
        
        /* Clamp */
        in0f1 = _clamp_v(in0f1, min, max);
        in1f1 = _clamp_v(in1f1, min, max);
        in2f1 = _clamp_v(in2f1, min, max);
        in3f1 = _clamp_v(in3f1, min, max);
        in4f1 = _clamp_v(in4f1, min, max);
        in5f1 = _clamp_v(in5f1, min, max);
        in6f1 = _clamp_v(in6f1, min, max);
        in7f1 = _clamp_v(in7f1, min, max);
        
        in0f2 = _clamp_v(in0f2, min, max);
        in1f2 = _clamp_v(in1f2, min, max);
        in2f2 = _clamp_v(in2f2, min, max);
        in3f2 = _clamp_v(in3f2, min, max);
        in4f2 = _clamp_v(in4f2, min, max);
        in5f2 = _clamp_v(in5f2, min, max);
        in6f2 = _clamp_v(in6f2, min, max);
        in7f2 = _clamp_v(in7f2, min, max);
        
        /* Convert to unsigned int vectors */
        in0i1 = spu_convtu(in0f1, 0);            
        in1i1 = spu_convtu(in1f1, 0);
        in2i1 = spu_convtu(in2f1, 0);
        in3i1 = spu_convtu(in3f1, 0);
        in4i1 = spu_convtu(in4f1, 0);
        in5i1 = spu_convtu(in5f1, 0);
        in6i1 = spu_convtu(in6f1, 0);
        in7i1 = spu_convtu(in7f1, 0);
        
        in0i2 = spu_convtu(in0f2, 0);    
        in1i2 = spu_convtu(in1f2, 0);
        in2i2 = spu_convtu(in2f2, 0);
        in3i2 = spu_convtu(in3f2, 0);
        in4i2 = spu_convtu(in4f2, 0);
        in5i2 = spu_convtu(in5f2, 0);
        in6i2 = spu_convtu(in6f2, 0);
        in7i2 = spu_convtu(in7f2, 0);
        
        /* Convert to unsigned short vectors */
        out0 = (vector unsigned short)spu_shuffle(in0i2, in0i1, conv_patt);
        out1 = (vector unsigned short)spu_shuffle(in1i2, in1i1, conv_patt);
        out2 = (vector unsigned short)spu_shuffle(in2i2, in2i1, conv_patt);
        out3 = (vector unsigned short)spu_shuffle(in3i2, in3i1, conv_patt);
        out4 = (vector unsigned short)spu_shuffle(in4i2, in4i1, conv_patt);
        out5 = (vector unsigned short)spu_shuffle(in5i2, in5i1, conv_patt);
        out6 = (vector unsigned short)spu_shuffle(in6i2, in6i1, conv_patt);
        out7 = (vector unsigned short)spu_shuffle(in7i2, in7i1, conv_patt);
        
        out[i] = out0;
        out[i+1] = out1;
        out[i+2] = out2;
        out[i+3] = out3;
        out[i+4] = out4;
        out[i+5] = out5;
        out[i+6] = out6;
        out[i+7] = out7;
    }
}

static void normalize(unsigned long long dst, 
                      unsigned long long src, 
                      size_t size) {
    int i, n_frames, n_vec_left;
    vector float avg, avg1, avg2, scale, initial_scale, curr_scale, next_scale, 
                 min, max, mid, scale_min, scale_max, midscale, slope;
    
    min = spu_splats(0.0f);
    max = spu_splats(65535.0f);
    mid = spu_mul(max, spu_splats(0.5f));
    initial_scale = spu_splats(1.0f);
    next_scale = initial_scale;
    scale_min = spu_splats(0.1f);
    scale_max = spu_splats(5.0f);
    
    in[0] = &in1[0];
    in[1] = &in2[0];
    
    in1[0] = &in1_buff[0];
    in1[1] = &in2_buff[0];
    in1[2] = &in3_buff[0];
    in1[3] = &in4_buff[0];
    in2[0] = &in5_buff[0];
    in2[1] = &in6_buff[0];
    in2[2] = &in7_buff[0];
    in2[3] = &in8_buff[0];
    
    out[0] = &out1[0];
    out[1] = &out2[0];
    
    out1[0] = &out1_buff[0];
    out1[1] = &out2_buff[0];
    out2[0] = &out3_buff[0];
    out2[1] = &out4_buff[0];
    
    /* A frame is one buffer size amount of data */
    /* We'll work on one buffer size amount of data at a time */
    n_frames = size >> (BUF_SIZE_SHIFT+4);
    
    /* The pattern of calculation with double buffering occurs as follows.
     There are two sets of input and output buffers 0 and 1. The input buffers
     are broken up into 4 half frames. The input buffers alternate every two
     iterations while the output buffers alternate every iteration.
     The RMS value is computed for 2 half frames each iteration and then
     2 half frames offset back one are scaled using those RMS values.
     The RMS values are smoothed using linear interpolation between the two
     midpoints of the frames.
     
     Input buffer     |-------0-------|-------0-------|-------1-------|-------1-------|
     Output buffer    |---1---|-------0-------|-------1-------|-------0-------|
     1/2 frame buffer |---0---|---1---|---2---|---3---|---0---|---1---|---2---|---3---|
     
     i value          |------pre------|-------0-------|-------1-------|-------2-------|
     RMS              |------RMS------|------RMS------|------RMS------|------RMS------|
     
     i value          |--pre--|-------0-------|-------1-------|-------2-------|
     Output buffer
     Scale            |-scale-|-----scale-----|-----scale-----|-----scale-----|
     Write            |-write-|-----write-----|-----write-----|-----write-----|
    */
    
    /* Read the first frame into the input buffers */
    /* The input buffers are 1/2 frames to make linear interpolation easier */
    mfc_get(in[0][0], src, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), in_tags, 0, 0);
    src += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    mfc_get(in[0][1], src, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), in_tags, 0, 0);
    src += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    
    mfc_write_tag_mask(1 << in_tags);
    mfc_read_tag_status_all();
    
    /* Start reading the next frame */
    mfc_get(in[0][2], src, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), in_tags, 0, 0);
    src += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    mfc_get(in[0][3], src, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), in_tags, 0, 0);
    src += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    
    /* Calculate the initial scale value */
    avg1 = calc_RMS_v(in[0][0], BUF_SIZE_HALF);
    avg2 = calc_RMS_v(in[0][1], BUF_SIZE_HALF);
    avg = spu_add(avg1, avg2);
    avg = spu_mul(avg, spu_splats(0.5f));
    /* This is the scale factor to get the level to mid*/
    midscale = spu_mul(mid, _recipf4(avg));
    /* Clamp scale */
    curr_scale = _clamp_v(midscale, scale_min, scale_max);
    
    /* Scale the initial 1/2 frame */
    slope = spu_splats(0.0f);
    scale = curr_scale;
    vol_scale_v(in[0][0], out[1][0], BUF_SIZE_HALF, scale, slope, min, max);
    
    mfc_put(out[1][0], dst, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), out_tags+1, 0, 0);
    dst += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
            
    for (i = 0; i < n_frames-2; i++) {
        
        /* Start reading the next frames into the input buffer */
        /* The set of 1/2 frame input buffers used will stay the same for two iterations */
        mfc_get(in[((i+2)&2)>>1][(i&1)*2], src, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), in_tags+((i+1)&1), 0, 0);
        src += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
        mfc_get(in[((i+2)&2)>>1][(i&1)*2+1], src, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), in_tags+((i+1)&1), 0, 0);
        src += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
        
        /* Wait for the read */
        mfc_write_tag_mask(1 << (in_tags+(i&1)));
        mfc_read_tag_status_all();
        
        /* Calculate RMS of current frame */
        avg1 = calc_RMS_v(in[((i+1)&2)>>1][((i+1)&1)*2], BUF_SIZE_HALF);
        avg2 = calc_RMS_v(in[((i+1)&2)>>1][((i+1)&1)*2+1], BUF_SIZE_HALF);
        avg = spu_add(avg1, avg2);
        avg = spu_mul(avg, spu_splats(0.5f));
        
        /* This is the scale factor to get the level to mid*/
        midscale = spu_mul(mid, _recipf4(avg));
        
        /* Clamp scale */
        next_scale = _clamp_v(midscale, scale_min, scale_max);
        
        /* Calculate the slope from prev_scale to scale */
        /* slope = (next_scale - curr_scale)/n_samples; */
        slope = spu_sub(next_scale, curr_scale);
        slope = _divf4(slope, spu_splats((float)(BUF_SIZE<<3)));
        scale = curr_scale;

        /* Wait for the write */
        mfc_write_tag_mask(1 << (out_tags+(i&1)));
        mfc_read_tag_status_all();
        
        /* Scale the first 1/2 frame */
        vol_scale_v(in[(i&2)>>1][(i&1)*2+1], out[i&1][0], BUF_SIZE_HALF, scale, slope, min, max);
        
        /* Start writing the 1/2 frame */
        mfc_put(out[i&1][0], dst, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), out_tags+(i&1), 0, 0);
        dst += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
        
        /* Increment the scale for the next 1/2 frame */
        scale = spu_madd(slope, spu_splats((float)(BUF_SIZE<<2)), scale);
        
        /* Scale the second 1/2 frame */
        vol_scale_v(in[((i+1)&2)>>1][((i+1)&1)*2], out[i&1][1], BUF_SIZE_HALF, scale, slope, min, max);
        
        /* Start writing the half frame */
        mfc_put(out[i&1][1], dst, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), out_tags+(i&1), 0, 0);
        dst += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
        
        curr_scale = next_scale;
    }
    
    /* The size of the last partial frame. */
    n_vec_left = ((size >> 4) & BUF_SIZE_MASK);
    /* If size is not a multiple of 16 add 1 to get the rest */
    if (size & 15) {
        n_vec_left++;
    }
    
    /* Calculate the RMS of the last full frame and scale the second
     * to last full frame */
    /* This is pulled out of the loop so that we don't need an extra branch in
     * the loop to avoid reading past the end of the source file */

    /* Start reading the next 1/2 frames into the input buffer (at least one is partial) */
    if (n_vec_left <= BUF_SIZE_HALF) {
        mfc_get(in[((i+2)&2)>>1][(i&1)*2], src, sizeof(vector unsigned short)*n_vec_left, in_tags+((i+1)&1), 0, 0);
    }
    else {
        mfc_get(in[((i+2)&2)>>1][(i&1)*2], src, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), in_tags+((i+1)&1), 0, 0);
        src += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
        mfc_get(in[((i+2)&2)>>1][(i&1)*2+1], src, sizeof(vector unsigned short)*(n_vec_left-BUF_SIZE_HALF), in_tags+((i+1)&1), 0, 0);
    }
    
    /* Wait for the read */
    mfc_write_tag_mask(1 << (in_tags+(i&1)));
    mfc_read_tag_status_all();
    
    /* Calculate RMS of the last frame */
    avg1 = calc_RMS_v(in[((i+1)&2)>>1][((i+1)&1)*2], BUF_SIZE_HALF);
    avg2 = calc_RMS_v(in[((i+1)&2)>>1][((i+1)&1)*2+1], BUF_SIZE_HALF);
    avg = spu_add(avg1, avg2);
    avg = spu_mul(avg, spu_splats(0.5f));
    
    /* This is the scale factor to get the level to mid*/
    midscale = spu_mul(mid, _recipf4(avg));
    
    /* Clamp scale */
    next_scale = _clamp_v(midscale, scale_min, scale_max);
    
    /* Calculate the slope from prev_scale to scale */
    /* slope = (next_scale - curr_scale)/n_samples; */
    slope = spu_sub(next_scale, curr_scale);
    slope = _divf4(slope, spu_splats((float)(BUF_SIZE<<3)));
    scale = curr_scale;

    /* Wait for the write */
    mfc_write_tag_mask(1 << (out_tags+(i&1)));
    mfc_read_tag_status_all();
    
    /* Scale the first 1/2 frame */
    vol_scale_v(in[(i&2)>>1][(i&1)*2+1], out[i&1][0], BUF_SIZE_HALF, scale, slope, min, max);
    
    /* Start writing the 1/2 frame */
    mfc_put(out[i&1][0], dst, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), out_tags+(i&1), 0, 0);
    dst += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    
    /* Increment the scale for the next 1/2 frame */
    scale = spu_madd(slope, spu_splats((float)(BUF_SIZE<<2)), scale);
    
    /* Scale the second 1/2 frame */
    vol_scale_v(in[((i+1)&2)>>1][((i+1)&1)*2], out[i&1][1], BUF_SIZE_HALF, scale, slope, min, max);
    
    /* Start writing the half frame */
    mfc_put(out[i&1][1], dst, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), out_tags+(i&1), 0, 0);
    dst += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    
    i++;
    
    /* Scale the last full frame. Use the last scale with 0 slope for the remaining frame 
     * and partial frame since there's only a partial frame that we haven't calculated the RMS for.
     */
    scale = next_scale;
    
    /* Wait for the read and write */
    mfc_write_tag_mask((1 << (in_tags+(i&1))) | (1 << (out_tags+(i&1))));
    mfc_read_tag_status_all();
    
    /* Scale the first 1/2 frame */
    vol_scale_v(in[(i&2)>>1][(i&1)*2+1], out[i&1][0], BUF_SIZE_HALF, scale, spu_splats(0.0f), min, max);
    
    /* Write the first 1/2 frame */
    mfc_put(out[i&1][0], dst, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), out_tags+(i&1), 0, 0);
    dst += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    
    if (n_vec_left <= (BUF_SIZE_HALF)) {
        /* Scale the second 1/2 frame */
        vol_scale_v(in[((i+1)&2)>>1][((i+1)&1)*2], out[i&1][1], n_vec_left+((8-(n_vec_left&7))&7), scale, spu_splats(0.0f), min, max);
        /* Write the second 1/2 frame */
        mfc_put(out[i&1][1], dst, sizeof(vector unsigned short)*n_vec_left, out_tags+(i&1), 0, 0);
    }
    else {
	    /* Scale the second 1/2 frame */
	    vol_scale_v(in[((i+1)&2)>>1][((i+1)&1)*2], out[i&1][1], BUF_SIZE_HALF, scale, spu_splats(0.0f), min, max);
        /* Write the second 1/2 frame */
        mfc_put(out[i&1][1], dst, sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1), out_tags+(i&1), 0, 0);
        dst += sizeof(vector unsigned short)<<(BUF_SIZE_SHIFT-1);
    }
    
    /* Scale the last partial 1/2 frame */
    i++;
    /* Wait for the read and write */
    mfc_write_tag_mask((1 << (in_tags+(i&1))) || (1 << (out_tags+(i&1))));
    mfc_read_tag_status_all();
    
    /* Scale the partial frame */
    if (n_vec_left > (BUF_SIZE_HALF)) {
        /* Scale the partial 1/2 frame */
        vol_scale_v(in[(i&2)>>1][(i&1)*2+1], out[i&1][0], n_vec_left-BUF_SIZE_HALF+((8-(n_vec_left&7))&7), scale, spu_splats(0.0f), min, max);
    	/* Write the partial 1/2 frame */
        mfc_put(out[i&1][0], dst, sizeof(vector unsigned short)*(n_vec_left - BUF_SIZE_HALF), out_tags+(i&1), 0, 0);
    }
    
    /* Wait for the write */
    mfc_write_tag_mask((1 << out_tags) | (1 << (out_tags+1)));
    mfc_read_tag_status_all();
}

int main(int argc, char **argv) {
    char *src_name, *dst_name;
    int src_fd, dst_fd;
    int prot = PROT_READ | PROT_WRITE;
    int flags = O_RDWR | O_CREAT | O_TRUNC;
    struct stat buf;
    unsigned long long src, dst;
    
    if (argc != 3) {
        printf("Usage: %s [input-file] [output-file].\n"
               "  input-file  - Unsigned halfword monophonic audio file name\n"
               "  output-file - Output file name\n", argv[0]);
        return 1;
    }
    
    src_name = argv[1];
    dst_name = argv[2];

    /* Reserve tags used by this sample. Two input tags and two output tags
     */
    in_tags = mfc_multi_tag_reserve(2);
    out_tags = mfc_multi_tag_reserve(2);

    assert((in_tags != MFC_TAG_INVALID) && (out_tags != MFC_TAG_INVALID));

    
    /* Open both files. */
    if ((src_fd = open(src_name, O_RDONLY, 0)) == -1) {
        perror("Can't open source file");
        return 1;
    }
    if ((dst_fd = open(dst_name, flags, buf.st_mode | S_IRWXU)) < 0) {
        perror("Can't create destination file");
        return 1;
    }
    
    /* Set up memory mappings. */
    if (fstat(src_fd, &buf) != 0) {
        perror("Can't stat source file");
        return 1;
    }
    
    if (!buf.st_size) {
        perror("Input is empty");
        return 0;
    }
    if (lseek(dst_fd, buf.st_size - 1, SEEK_SET) == -1) {
        perror("Can't lseek destination file");
        return 1;
    }
    if (write(dst_fd, "", 1) != 1) {
        perror("Can't write to destination file");
        return 1;
    }
    
    src = mmap_eaddr(0ULL, buf.st_size, PROT_READ, MAP_PRIVATE, src_fd, 0);
    
    if (src == MAP_FAILED_EADDR) {
        perror("Can't mmap source file");
        return 1;
    }
    
    dst = mmap_eaddr(0ULL, buf.st_size, prot, MAP_SHARED, dst_fd, 0);
    
    if (dst == MAP_FAILED_EADDR) {
        perror("Can't mmap destiation file");
        return 1;
    }
    
    normalize(dst, src, buf.st_size);
    
    return 0;
}

