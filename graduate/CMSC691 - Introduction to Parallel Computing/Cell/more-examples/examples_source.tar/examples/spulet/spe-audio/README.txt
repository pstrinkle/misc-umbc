%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Spulet audio filter examples

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory contains source code used to demonstrate audio 
	filtering on the SPU. Two examples are included:

	cpaudio   = copies one channel of a stereo audio file to the other
	channel.

	normalize = normalizes the volume of a mono audio file.

	Both examples take raw unsigned halfword audio files as input and 
	output the same format. Input audio files for these examples are:

	b13s.uw
		The first 1.3 seconds of beginning.uw.
	beginning.uw
		Short (11.1 seconds) audio excerpt from Douglas Adams
		"Hitchhiker's Guide to the Galaxy". Sampled at 16kHz.
		Unsigned halfword, monophonic raw sampled data.
	chord.uw
		Stereophonic, raw, unsigned halfword, 44.1 kHz, raw
		audio data file of a single chord.

How to run:
	The command options for cpuaudio are:

	cpaudio <source-channel> <input-file> <output-file>

	where:
	source-channel
		r=right, l=left

	input-file
		Unsigned halfword stereo audio file name

	output-file
		Output file name

	To run normalize, copy the SPU program 'normalize' and at least
	one stereo file into the simulator environment, using "callthru".

	The command options for normalize are:

	normalize <input-file> <output-file>

	where:
	input-file
		Unsigned halfword monophonic audio file name

	output-file
		Output file name

Example 1:
	Copy the left channel of chord.uw to the right channel:

	cpaudio l chord.uw chord_l.uw

Example 2:
	Normalize the volume of b13s.uw (in src/samples/resample):

	normalize b13s.uw b13s_n.uw

	To convert the output to a .wav file:

	sox -r 16100 -c 1 -x b13s_n.uw b13s_n.wav

Notes:
	Note that b13s.uw and chord.uw can be used unchanged, but beginning.uw
	has an opposite word order than normalize expects, which can be swapped
	with this command:

	sox beginning.uw -x beginning_x.uw

