/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include "../dma_example.h"
#include <spu_mfcio.h>
#include <stdio.h>

/* here we define the data buffer in local memory, to hold the data we DMA in. */
/* We will DMA in 4096 elements at a time, as that's the largest size which    */
/* fits in a standard DMA (16,384 bytes).                                      */
/* Since we're sometimes going to be double-buffering, we'll allocate 8192.    */
int databuffer[8192] __attribute__ ((aligned (128)));

/* Here we define the pointers which will point at the upper and lower parts   */
/* of this data buffer.                                                        */
int *data[2];

/* here we define buffers to hold DMA List data */
/* there are four buffers to allow us to multi-buffer more effectively */
volatile unsigned int dma_list[4][256];

/* this variable tells us how many DMA cycles each task must perform */
int loopcount;

/* control structure */
control_block cb __attribute__ ((aligned (128)));

/* the next two macros do the same thing, except using lists */

/* for each DMA List task, it's necessary to compute the addresses of */
/* each piece of address to read in.  Here are three different macros */
/* which all do the same thing.  They load the DMA List buffer.       */
/* The first macro is scalar.                                         */
/* The second macro is converted to SIMD code.                        */
/* The third macro is like the second, but hand-unrolled.             */
/* This example ships using the third macro, but the user can re-code */
/* the example to use any of these three.                             */

/* DMA Lists allow you to gather data from arbitrary locations in     */
/* main memory. This example simply demonstrates the use of DMA Lists */
/* in gathering sequential cache lines of 128 bytes each.  This is    */
/* a somewhat silly use of the DMA List, as the memory could have     */
/* been collected with a standard DMA call (without a list), but we   */
/* show the code here to help the user understand how DMA Lists work. */

/* The list itself is a sequence of 4-byte words, each pair of which  */
/* specifies a length in bytes, and an address in main memory.        */
/* Since this example is specifying exactly one cache line for each   */
/* element of the DMA list, the lengths will always be 128.           */

#define FILL_DMA_LIST(_base, _list_addr, _offset) {                     \
  int _k;                                                               \
  for (_k=0; _k<128; ++_k) {                                            \
    _list_addr[2*_k]   = 128;                                           \
    _list_addr[2*_k+1] = _base + _offset * 16384 + 128 * _k;            \
  }                                                                     \
}

#define FILL_DMA_LIST_SIMD(_base, _list_addr, _offset) {                \
  unsigned int _b, _k;                                                  \
  vector unsigned int length = (vector unsigned int) {128, 0, 128, 0};	\
  vector unsigned int addend = (vector unsigned int) {0, 256, 0, 256};  \
  vector unsigned int *p, w;                                            \
  _b = _base + _offset * 16384;                                         \
  p = (vector unsigned int *) _list_addr;                               \
  w = spu_insert(_b,     length, 1);                                    \
  w = spu_insert(_b+128, w, 3);                                         \
  for (_k=0; _k<64; ++_k) {                                             \
    p[_k] = w;                                                          \
    w = spu_add(w, addend);                                             \
  }                                                                     \
}

#define FILL_DMA_LIST_SIMD_UNROLLED(_base, _list_addr, _offset) {       \
  unsigned int _b, _k;                                                  \
  vector unsigned int length = (vector unsigned int) {128, 0, 128, 0};  \
  vector unsigned int addend = (vector unsigned int) {0, 256, 0, 256};  \
  vector unsigned int *_p, w0, w1, w2, w3;                              \
  _b = _base + _offset * 16384;                                         \
  _p = (vector unsigned int *) _list_addr;                              \
  w0 = spu_insert(_b,     length, 1);                                   \
  w0 = spu_insert(_b+128, w0, 3);                                       \
  w1 = spu_add(w0, addend);                                             \
  w2 = spu_add(w1, addend);                                             \
  w3 = spu_add(w2, addend);                                             \
  addend = spu_add(addend, addend);                                     \
  addend = spu_add(addend, addend);                                     \
  for (_k=0; _k<64; _k+=4) {                                            \
    _p[0] = w0;                                                         \
    _p[1] = w1;                                                         \
    _p[2] = w2;                                                         \
    _p[3] = w3;                                                         \
    w0 = spu_add(w0, addend);                                           \
    w1 = spu_add(w1, addend);                                           \
    _p+=4;                                                              \
    w2 = spu_add(w2, addend);                                           \
    w3 = spu_add(w3, addend);                                           \
  }                                                                     \
}

/* Here are two versions of the code that actually does the incrementing */
/* of the data we have read in.  There are two versions, the first is    */
/* scalar, and the second is SIMD. Only the SIMD version is used below.  */

void load_data(int *dest) { int i;
  for (i=0; i<4096; ++i) {
    ++dest[i];
  }
}

void load_data_SIMD(int *dest) {
  int i;
  vector unsigned int *vdest;
  vector unsigned int v1 = (vector unsigned int) {1, 1, 1, 1};
  vdest = (vector unsigned int *) dest;
  for (i=0; i<1024; ++i) {
    vdest[i] = spu_add(vdest[i], v1);
  }
}

/* Here we have the four DMA task modules. */
/* Each of them processes the data in the assigned regions in 16 kbyte chunks */

void load_singlebuffer(unsigned int addr, unsigned int tag)
{
  int i;
  for (i=0; i<loopcount; ++i) {
    mfc_get(data[0], addr+16384*i, 16384, tag, 0, 0);
    mfc_write_tag_mask(1<<tag);
    mfc_read_tag_status_all();
    load_data_SIMD(data[0]);
    mfc_put(data[0], addr+16384*i, 16384, tag, 0, 0);
    mfc_write_tag_mask(1<<tag);
    mfc_read_tag_status_all();
  }
}

void load_doublebuffer(unsigned int addr, unsigned int tags)
{
  int i;
  mfc_get(data[0], addr, 16384, tags, 0, 0);
  for (i=1; i<loopcount; ++i) {
    mfc_write_tag_mask(1<<(tags+(i&1)));
    mfc_read_tag_status_all();
    mfc_get(data[i&1], addr+16384*i, 16384, tags+(i&1), 0, 0);
    mfc_write_tag_mask(1<<(tags+1-(i&1)));
    mfc_read_tag_status_all();
    load_data_SIMD(data[(i-1)&1]);
    mfc_put(data[(i-1)&1], addr+16384*(i-1), 16384, tags+1-(i&1), 0, 0);
  }
  mfc_write_tag_mask(1<<(tags+1));
  mfc_read_tag_status_all();
  load_data_SIMD(data[1]);
  mfc_put(data[1], addr+16384*(loopcount-1), 16384, tags+1, 0, 0);
  mfc_write_tag_mask((1<<tags)|(1<<(tags+1)));
  mfc_read_tag_status_all();
}

void load_singlebuffer_list(unsigned int addr, unsigned int tag)
{
  int  i;
  for (i=0; i<loopcount; ++i) {
    FILL_DMA_LIST_SIMD_UNROLLED(addr, dma_list[0], i)
    mfc_getl(data[0], 0, dma_list[0], 1024, tag, 0, 0);
    mfc_write_tag_mask(1<<tag);
    mfc_read_tag_status_all();
    load_data_SIMD(data[0]);
    mfc_putl(data[0], 0, dma_list[0], 1024, tag, 0, 0);
    mfc_write_tag_mask(1<<tag);
    mfc_read_tag_status_all();
  }
}

void load_doublebuffer_list(unsigned int addr, unsigned int tags)
{
  int  i;
  FILL_DMA_LIST_SIMD_UNROLLED(addr, dma_list[0], 0)
  mfc_getl(data[0], 0, dma_list[0], 1024, tags, 0, 0);
  for (i=1; i<loopcount; ++i) {
    mfc_write_tag_mask(1<<(tags+((i+2)&3)));
    mfc_read_tag_status_all();
    FILL_DMA_LIST_SIMD_UNROLLED(addr, dma_list[i&3], i)
    mfc_getl(data[i&1], 0, dma_list[i&3], 1024, tags+(i&3), 0, 0);
    mfc_write_tag_mask(1<<(tags+((i-1)&3)));
    mfc_read_tag_status_all();
    load_data_SIMD(data[(i-1)&1]);
    mfc_putl(data[(i-1)&1], 0, dma_list[(i-1)&3], 1024, tags+((i-1)&3), 0, 0);
  }
  mfc_write_tag_mask(1<<(tags+3));
  mfc_read_tag_status_all();
  load_data_SIMD(data[1]);
  mfc_putl(data[1], 0, dma_list[3], 1024, tags+3, 0, 0);
  mfc_write_tag_mask((1<<tags)|(1<<(tags+1))|(1<<(tags+2))|(1<<(tags+3)));
  mfc_read_tag_status_all();
}

/* here is the location where the SPE begins execution, once its thread is created */
int main(unsigned long long speid __attribute__ ((unused)), 
	 unsigned long long argp, 
	 unsigned long long envp __attribute__ ((unused))) 
{
  unsigned int tags;

  /* Reserve four sequential tag for application usage */
  if ((tags = mfc_multi_tag_reserve(4)) == MFC_TAG_INVALID) {
    printf("ERROR: unable to reserve 4 tags\n");
    return 1;
  }

  /* DMA control block information from system memory. */
  mfc_get(&cb, argp, sizeof(cb), tags, 0, 0);
  mfc_write_tag_mask(1<<tags);
  mfc_read_tag_status_all();

  printf("addrs = 0x%x 0x%x 0x%x 0x%x\n", cb.addrSB, cb.addrDB, cb.addrSBL, cb.addrDBL);

  /* compute how many DMA cycles will be needed by each task */
  loopcount = cb.chunk_size >> 14;

  /* load the pointers so the point to the right part of the local store buffer */
  data[0] = &databuffer[0];
  data[1] = &databuffer[4096];

  /* run the four tasks, indicating which portion of memory they should work with */
  load_singlebuffer     (cb.addrSB, tags);
  load_doublebuffer     (cb.addrDB, tags);
  load_singlebuffer_list(cb.addrSBL,tags);
  load_doublebuffer_list(cb.addrDBL,tags);

  return 0;
}
