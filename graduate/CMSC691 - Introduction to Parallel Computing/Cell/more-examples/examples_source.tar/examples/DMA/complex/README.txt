%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Example of non-trivial DMA calls.

Target:
        CBE-Linux (HW or simulator)

Description:
	This directory contains an example program showing some non-trivial
        DMA calls within the SPEs.

How to run:
	The command options are:

	dma_example <log_of_elems>

	where:
	<log_of_elems>
		This is the log of the number of elements in the array.
		Permitted range for this is 19 <= log_of_elems <= 24
		(resulting in a value of between 512K and 16M).

Notes:
	The actual executable resides in the ppu subdirectory.  It's called 
	'dma_example'. It's a full CBE executable, with both PPE and SPE code.

	The job of this program is to get the SPEs to increment every element 
	of a pre-loaded large array, such that array[i] = i+1;
        
	Here's what happens when you run "dma_example":

	* The PPE assigns a[i] = i for every element of the large array.

	* The PPE then fires up all eight SPEs, pointing them at specific
		sections of the big array. 

	* The SPEs each use four different DMA styles to load pieces of their
		sections, increment them, and write them back to main memory.
		The four styles are:
		a) single-buffered DMA
		b) double-buffered DMA
		c) single-buffered DMA List
		d) double-buffered DMA List

	* The PPE checks these results, and prints whether any errors were
		found.
