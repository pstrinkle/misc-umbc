/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include "../dma_example.h"
#include <sched.h>
#include <libspe2.h>
#include <pthread.h>
#include <dirent.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

typedef struct ppu_pthread_data {
    spe_context_ptr_t speid;
    pthread_t pthread;
    void *argp;
} ppu_pthread_data_t;

void *ppu_pthread_function(void *arg) {
    ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
    int rc;
    unsigned int entry = SPE_DEFAULT_ENTRY;
    if ((rc = spe_context_run(datap->speid, &entry, 0, datap->argp, NULL, NULL)) < 0) {
        fprintf (stderr, "Failed spe_context_run(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
        exit (1);
    }
    pthread_exit(NULL);
}

/* there are eight control blocks, one for each SPE. */
control_block cb[8] __attribute__ ((aligned (128)));

/* this is the pointer to the SPE code, to be used at thread creation time */
extern spe_program_handle_t dma_example_spu;

/* these are the handles returned by "spe_context_create" and "pthread_create" */
ppu_pthread_data_t datas[8];

/* here is the variable which will hold the big array */
int *data;

int main(int argc, char *argv[]) {
  int i, error_count, rc;
  int log_array_size, array_size, chunk_size;
  int count_spes; 

  /* user specifies the size of the large array */

  if (argc != 2) {
    printf("usage: dma_example <log of #elements in big array (19 <= x <= 24) >\n");
    exit (-1);
  }

  log_array_size = atoi(argv[1]);

  if (log_array_size < 19 || log_array_size > 24) {
    printf("usage: dma_example <log of #elements in big array (19 <= x <= 24) >\n");
    exit (-1);
  }

  /* compute array size from input parameter */
  array_size = 1 << log_array_size;

  /* compute how many elements each DMA task should handle  */
  /* there are four tasks for each of eight SPUs, so the    */
  /* size of each task is 1/32nd the size of the full array */
  chunk_size = array_size >> 5;

  printf("Initializing the array...\n");

  /* the big array needs to be aligned on a 128-byte cache line */
  data = (int *) malloc(127 + array_size*sizeof(int));
  while (((int) data) & 0x7f) ++data;

  /* load the big array with initial values */
  for (i=0; i<array_size; ++i) data[i] = i;

  fprintf(stderr, "ready to call (create) SPE threads\n"); fflush(stderr);

  count_spes = spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES, -1);
  printf("SPE_COUNT_PHYSICAL_SPES=%d\n",count_spes);
  if (count_spes < 8) {
    fprintf(stderr, "System doesn't have eight working SPEs.  I'm leaving.\n");
    exit (-1);
  }

  /* load the control blocks for each SPE with data */
  for (i = 0; i < 8; i++) {
    cb[i].chunk_size = chunk_size * sizeof(int); /* convert to units of bytes */
    cb[i].addrSB     = (unsigned int) &data[chunk_size*(4*i+0)];
    cb[i].addrDB     = (unsigned int) &data[chunk_size*(4*i+1)];
    cb[i].addrSBL    = (unsigned int) &data[chunk_size*(4*i+2)];
    cb[i].addrDBL    = (unsigned int) &data[chunk_size*(4*i+3)];
  }

  /* allocate SPE tasks */
  for (i = 0; i < 8; i++) {
      /* Create context */
      if ((datas[i].speid = spe_context_create (0, NULL)) == NULL)
        {
          fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (3+i);
        }
      /* Load program */
      if ((rc = spe_program_load (datas[i].speid, &dma_example_spu)) != 0)
        {
          fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (3+i);
        }
      /* Initialize data */
      datas[i].argp = (unsigned long long *) &cb[i];
      /* Create thread */
      if ((rc = pthread_create (&datas[i].pthread, NULL, &ppu_pthread_function, &datas[i])) != 0)
        {
          fprintf (stderr, "Failed pthread_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (3+i);
        }
  }

  printf("SPEs are now computing...\n");

  /* wait for SPEs to all finish */
  for (i=0; i<8; ++i) {
      /* Join thread */
      if ((rc = pthread_join (datas[i].pthread, NULL)) != 0)
        {
          fprintf (stderr, "Failed pthread_join(rc=%d, errno=%d strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
      /* Destroy context */
      if ((rc = spe_context_destroy (datas[i].speid)) != 0)
        {
          fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
  }

  /* Issue a sync, just to be safe. */
  __asm__ __volatile__ ("sync" : : : "memory");

  printf("SPEs done.  Now checking results...\n"); fflush(stdout);

  error_count = 0;

  /* the task for the SPEs was to increment the data in every array element */
  /* check to see if any of the array elements was not properly incremented */
  for (i=0; i<array_size; ++i) {
    if (data[i] != i+1) {
      printf("error! data[%x] = %x\n", i, data[i]);
      ++error_count;
    }
  }

  printf("total errors detected = %d\n", error_count);

  if (error_count)
     exit (10 + error_count);
  else
     exit (0);
}
