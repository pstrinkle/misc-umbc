/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include "../simpleDMA.h"
#include <sched.h>
#include <libspe2.h>
#include <pthread.h>
#include <dirent.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <sys/wait.h>
#include <malloc_align.h>
#include <string.h>

/* we allocate one control block, to correspond to one SPE */
control_block cb __attribute__ ((aligned (128)));

/* this is the pointer to the SPE code, to be used at thread creation time */
extern spe_program_handle_t simpleDMA_spu;

/* this is the handle which will be returned by "spe_context_create."  */
spe_context_ptr_t speid;

/* this variable is the SPU entry point address which is initially set to the default */
unsigned int entry = SPE_DEFAULT_ENTRY;

/* this variable is used to return data regarding an abnormal return from the SPE */
spe_stop_info_t stop_info;

/* here is the variable to hold the address returned by the malloc() call. */
int *data;

int main() 
{
  int i;

  /* Here is the malloc call a data array aligned to a cacheline boundary 
     for efficient transfer.
   */ 
  data = (int *)_malloc_align(DATA_BUFFER_SIZE, 7);

  if (data) {
    /* Fill the data array with a fibonacci sequence.
     */
    data[0] = data[1] = 1;
    for (i=2; i<DATA_BUFFER_ENTRIES; i++) {
      data[i] = data[i-1] + data[i-2];
    }
  } else {
    fprintf(stderr, "Failed to allocate buffer of %d bytes\n", (int)(DATA_BUFFER_SIZE));
    return 1;
  }

  if (spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES, -1) < 1) {
    fprintf(stderr, "System doesn't have a working SPE.  I'm leaving.\n");
    return -1;
  }

  printf("Address being sent in control block: %p\n", data);

  /* load the address into the control block */
  cb.addr = (unsigned long long)((uintptr_t)data);
  
  /* create the SPE context */
  if ((speid = spe_context_create(0, NULL)) == NULL) {
    fprintf (stderr, "FAILED: spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
    exit (1);
  }
  
  /* load the SPE program into the SPE context */
  if (spe_program_load(speid, &simpleDMA_spu) != 0) {
    fprintf (stderr, "FAILED: spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
    exit (1);
  }

  /* run the SPE context */
  if (spe_context_run(speid, &entry, 0, &cb, NULL, &stop_info) < 0) {
    fprintf (stderr, "FAILED: spe_context_run(errno=%d strerror=%s)\n", errno, strerror(errno));
    exit (1);
  }

  /* destroy the SPE context */
  if (spe_context_destroy(speid) != 0) {
    fprintf (stderr, "FAILED: spe_context_destroy(errno=%d strerror=%s)\n", errno, strerror(errno));
    exit (1);
  }

  /* check the SPE status */
  if (stop_info.stop_reason == SPE_EXIT) {
    if (stop_info.result.spe_exit_code != 0) {
      fprintf(stderr, "FAILED: SPE returned a non-zero exit status\n");
      exit(1);
    }
  } else {
    fprintf(stderr, "FAILED: SPE abnormally terminated\n");
    exit(1);
  }

  printf("PASSED\n");

  return 0;
}
