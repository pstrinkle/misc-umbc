%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Provide an example implementation of handling SPU interrupts.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory builds two example programs demonstrating interrupt
	handling on the SPU. 

	The first example, spu_interrupt, demonstrates the use of a assembly
	first level interrupt handle (FLIH) that calls ABI compliant, 
	registered, C sourced, second level interrupt handlers as a function of
	the interrupt events. This implementation includes the following 
	key components:
	
	* spu_flih.s - example first level interrupt handler.
	* spu_slih_reg.c - example second level interrupt handler manager. This
	  includes a second level interrupt dispatch table (spu_slih_handlers),
	  a default stub second level interrupt handler (spu_default_slih), 
	  and a second level interrupt handler registration function 
	  (spu_slih_reg).
	* spu_interrupt.c - example program that demonstrates the use of the 
	  interrupt handler functions. This example problem registers a 
	  second level decrementer interrupt handler, enables decrementer 
	  interrupts, and waits until 10 decrementer interrupts occur.

	This hierarchical, generalized solution incurs significant overhead
	and latency because of the number of non-volatile registers that
	must be saved and restored in order to invoke a ABI compliant,
	C-callable function to handle the interrupt. Therefore, a second
	example (spu_interrupt_fast) has been provided that demonstrate a
	functional equivalent minimal interrupt handler. This version consists
	of the following key components:

	* spu_handler_fast.S - fast assembly interrupt handler
	* spu_interrupt_fast.c - example program that demonstrates the use of 
	  the fast interrupt handler. This example problem enables decrementer 
	  interrupts, and waits until 10 decrementer interrupts occur.

How to run:

	Invoke the SPU executable from the Linux command line prompt.

	spu_interrupt

	or

	spu_interrupt_fast

	Successful execution will result in the program running to completion
	and printing the message "Test successfully completed."

	There are no command options for this program.

