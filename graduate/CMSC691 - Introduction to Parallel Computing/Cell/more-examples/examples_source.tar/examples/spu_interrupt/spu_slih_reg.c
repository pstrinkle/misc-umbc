/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/* Example SPU second level interrupt handler (slih) manager. This example
 * consists of an interrupt handler dispatch table (spu_slih_handlers), a 
 * interrupt handler registration routine (spu_slih_reg), and a default 
 * interrupt handler (spu_default_slih).
 *
 * For this implementation, a second level interrupt handler takes as its 
 * input, the current event status word. The handler can assume that it was
 * dispatched to by the most significant non-zero event bit.  The second level
 * handler is assumed to process any or all events and return a new event status
 * back to the first level interrupt handler for further event processing.
 * The first level interrupt handler has already acknowledged all received
 * events before calling any slih.  A slih should only perform subsequent
 * acknowledgements if it is determined that additional events have been
 * received while in the slih.
 */
#include <spu_slih_reg.h>
#include <spu_intrinsics.h>


#define SPU_EVENT_ID(_mask)	(spu_extract(spu_cntlz(spu_promote(_mask, 0)), 0))

/* spu_default_slih
 * ----------------
 * This function is called whenever an event occurs for which 
 * no second level event handler was registered. The default 
 * event handler does nothing and zeros the most significant 
 * event bit indicating that the event was processed (when 
 * in reality, it was discarded..
 */
static unsigned int spu_default_slih(unsigned int events)
{
  unsigned int mse;	

  mse = 0x80000000 >> SPU_EVENT_ID(events);
  events &= ~mse;

  return (events);
}


/* spu_slih_handlers[]
 * ------------------
 * Here we initialize 33 default event handlers.  The first entry in this array
 * corresponds to the event handler for the event associated with bit 0 of
 * Channel 0 (External Event Status).  The 32nd entry in this array corresponds
 * to bit 31 of Channel 0 (DMA Tag Status Update Event).  The 33rd entry in
 * this array is a special case entry to handle "phantom events" which occur
 * when the channel count for Channel 0 is 1, causing an asynchronous SPU
 * interrupt, but the value returned for a read of Channel 0 is 0.  The index 
 * calculated into this array by spu_flih() for this case is 32, hence the 
 * 33rd entry.
 */
spu_slih_func  spu_slih_handlers[33] __attribute__ ((aligned (16))) = {
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,  spu_default_slih, spu_default_slih,  spu_default_slih,
  spu_default_slih,
};

#ifdef WORKAROUND_TOBEY_DEFECT_2994
/* Initialize this temporary global variable to indicate that all members of
 * the spu_slih_handlers[] array have NOT YET been initialized.
 * As of 031215, the TOBEY compiler does not appear to be doing it properly
 * with the global array initialization above.
 */
int spu_slih_handlers_init_done = 0;
#endif /* WORKAROUND_TOBEY_DEFECT_2994 */

/* spu_slih_reg
 * ------------
 * Registers a SPU second level interrupt handler for the events specified by
 * mask. The event mask consists of a set of bits corresponding to the 
 * event status bits (see channel 0 description). A mask containing multiple
 * 1 bits will set the second level event handler for each of the events.
 */
void spu_slih_reg(unsigned int mask, spu_slih_func func)
{
  unsigned int id;

#ifdef WORKAROUND_TOBEY_DEFECT_2994
/* Individually initialize all members of the spu_slih_handlers[] array
 * since the TOBEY compiler does not appear to be doing it properly
 * with the global array initialization above.
 */
  if (!spu_slih_handlers_init_done)
  {
    int i;
    for (i=0; i < 33; i++)
    {
	spu_slih_handlers[i] = spu_default_slih;
    }
    spu_slih_handlers_init_done = 1;
  }
#endif /* WORKAROUND_TOBEY_DEFECT_2994 */

  while (mask) {
    id = SPU_EVENT_ID(mask);
    spu_slih_handlers[id] = func;
    mask &= ~(0x80000000 >> id);
  }
}
