/* --------------------------------------------------------------  */
/* (C)Copyright 2005,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * spe-cp-prof.c
 *
 * Usage: 
 *	./spe-cp-prof [src-filename] [dst-filename]
 *
 * This example demonstrates use of channel profiling
 * from within an SPU application program.  
 *
 * After initial setup [opening input files, etc.], channel 
 * profiling is enabled by calling ch_prof_enable().  Some 
 * work is performed [in this example, a file is copied].  
 * During this time ch_prof accumulates information related 
 * to MFC I/O activity of the program. 
 *
 * This example is based on src/example/spulet/spe-cp, which
 * copies one file to another, entirely from an SPE.
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <memcpy_ea.h>

/* Include ch_prof header file. */
#include <ch_prof.h>

extern void exit(int rc);

static void setup(int argc, char **argv, 
		  unsigned long long *psrc, 
		  unsigned long long *pdst,
		  size_t *psize);

int main(int argc, char **argv)
{
    unsigned long long src, dst;
    size_t size;

    setup (argc, argv, &src, &dst, &size);

    /* Enable channel profiling. */
    ch_prof_enable ();

    /* Do some work, in this case copy a file. */
    memcpy_ea(dst, src, size);

    /* Disable channel profiling. */
    ch_prof_disable ();

    /* Dump channel statistics to STDOUT. */
    ch_prof_dump ();

    return 0;
}

static void setup(int argc, char **argv, 
		  unsigned long long *psrc, 
		  unsigned long long *pdst,
		  size_t *psize)
{
    char *src_name, *dst_name;
    int src_fd, dst_fd;
    int prot = PROT_READ | PROT_WRITE;
    int flags = O_RDWR | O_CREAT | O_TRUNC;
    struct stat buf;
    unsigned long long src, dst;

    if (argc != 3) {
	printf("Usage: %s [from] [to].\n", argv[0]);
	exit (1);
    }
    src_name = argv[1];
    dst_name = argv[2];

    /* Open both files. */
    if ((src_fd = open(src_name, O_RDONLY, 0)) == -1) {
	perror("Can't open source file");
	exit (1);
    }
    if ((dst_fd = open(dst_name, flags, buf.st_mode | S_IWUSR)) < 0) {
	perror("Can't create destination file");
	exit (1);
    }

    /* Set up memory mappings. */
    if (fstat(src_fd, &buf) != 0) {
	perror("Can't stat source file");
	exit (1);
    }
    if (!buf.st_size) {
	exit (0);
    }
    if (lseek(dst_fd, buf.st_size - 1, SEEK_SET) == -1) {
	perror("Can't lseek destination file");
	exit (1);
    }
    if (write(dst_fd, "", 1) != 1) {
	perror("Can't write to destination file");
	exit (1);
    }
    src = mmap_eaddr(0ULL, buf.st_size, PROT_READ, MAP_PRIVATE, src_fd, 0);
    if (src == MAP_FAILED_EADDR) {
	perror("Can't mmap source file");
	exit (1);
    }
    dst = mmap_eaddr(0ULL, buf.st_size, prot, MAP_SHARED, dst_fd, 0);
    if (dst == MAP_FAILED_EADDR) {
	perror("Can't mmap destiation file");
	exit (1);
    }

    /* Return size & location of memory mappings. */
    *psrc = src;
    *pdst = dst;
    *psize = buf.st_size;
}
