/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* ch_prof.h
 *
 * SPU-based statistical profiler of channel activity.
 *
 * ch_prof uses decrementer interrupts to sample the
 * application program's current instruction, then 
 * increments counters based on instruction type.  
 * The counters can be dumped to STDOUT, or reset.
 *
 * An application should #include <ch_prof.h>, and must 
 * explicitly call these interfaces to enable, disable 
 * and dump channel profiling information.
 *
 * Applications can configure ch_prof to use either a first 
 * level or second level interrupt handler, depending on their
 * sensitivity to stack space & cycle counts.  The second level 
 * handler is default, while first level handler provides better
 * performance and is used when CH_PROF_FLIH=1.
 *
 */

#ifndef __CH_PROF_H__
#define __CH_PROF_H__

#ifndef CH_PROF_FLIH
#define CH_PROF_FLIH 	0
#endif

#include <stdio.h>
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

#if !(CH_PROF_FLIH)
#include <spu_slih_reg.h>
#endif

static char ch_prof_channel_names[31][20] = {
  {"SPU_RdEventStat"},		// 0
  {"SPU_WrEventMask"},		// 1
  {"SPU_WrEventAck"},		// 2
  {"SPU_RdSigNotify1"},		// 3
  {"SPU_RdSigNotify2"},		// 4
  {"CHAN_5"},			// 5
  {"CHAN_6"},			// 6
  {"SPU_WrDec"},		// 7
  {"SPU_RdDec"},		// 8
  {"MFC_WrMSSyncReq"},		// 9
  {"CHAN_10"},			// 10
  {"SPU_RdEventMask"},		// 11
  {"MFC_RdTagMask"},		// 12
  {"SPU_RdMachStat"},		// 13
  {"SPU_WrSRR0"},		// 14
  {"SPU_RdSRR0"},		// 15
  {"MFC_LSA"},			// 16
  {"MFC_EAH"},			// 17
  {"MFC_EAL"},			// 18
  {"MFC_Size"},			// 19
  {"MFC_TagID"},		// 20
  {"MFC_Cmd"},			// 21
  {"MFC_WrTagMask"},		// 22
  {"MFC_WrTagUpd"},		// 23
  {"MFC_RdTagStat"},		// 24
  {"MFC_RdListStallStat"},	// 25
  {"MFC_RdListStallAck"},	// 26
  {"MFC_RdAtomicStat"},		// 27
  {"SPU_WrOutMbox"},		// 28
  {"SPU_RdInMbox"},		// 29
  {"SPU_WrOutIntr"},		// 30
};

/* Number of timebase ticks per decrementer event. This number
 * must be large enough that we don't spend all our time in the
 * interrupt handler.
 */
#ifndef CH_PROF_DECR_COUNT
#define CH_PROF_DECR_COUNT	1000
#endif

#define SPU_RDCH_INSTR          0x01a00000
#define SPU_WRCH_INSTR          0x21a00000
#define SPU_INSTR_MASK          0xfff00000

volatile unsigned int ch_prof_rdch_cntr __attribute ((aligned (16))) = 0;
volatile unsigned int ch_prof_wrch_cntr __attribute ((aligned (16))) = 0;
volatile unsigned int ch_prof_misc_cntr __attribute ((aligned (16))) = 0;
volatile unsigned int ch_prof_ticks __attribute ((aligned (16))) = 0;

volatile unsigned int ch_prof_tagid_table[32] __attribute ((aligned (16)));
volatile unsigned int ch_prof_ch_table[32] __attribute ((aligned (16)));


#if !(CH_PROF_FLIH)
/* ch_prof_tick - Second-level interrupt handler.
 *
 * This version of the routine operates as a second level
 * interrupt handler for decrementer events.   This has the
 * advantage of being written in C but the disadvantage of
 * increased stack/cycle overhead.
 *
 * The instruction pointed to by SRR0 is put into one of three
 * categories: READCH, WRITECH, or compute.  In the case of
 * READCH of MFC_RdTagStat, the current tagmask is read and
 * counters are accumulated for each tagid that is active in
 * the mask. 
 */
static unsigned int
ch_prof_tick (unsigned int status)
{
  unsigned int npc = spu_readch (SPU_RdSRR0);
  unsigned int tagmask = spu_readch (MFC_RdTagMask);
  unsigned int *npc_ptr = (unsigned int *) npc;
  unsigned int instr = *npc_ptr & SPU_INSTR_MASK;
  unsigned int ch = (*npc_ptr >> 7) & 0x1f;
  unsigned int r = ch_prof_rdch_cntr;
  unsigned int w = ch_prof_wrch_cntr;
  unsigned int m = ch_prof_misc_cntr;
  unsigned int r1 = r + 1;
  unsigned int w1 = w + 1;
  unsigned int m1 = m + 1;
  unsigned int rdch = (instr == SPU_RDCH_INSTR);
  unsigned int wrch = (instr == SPU_WRCH_INSTR);
  unsigned int misc = (!(rdch || wrch));
  int i;

  ch_prof_ticks += 1;
  ch_prof_rdch_cntr = (rdch) ? r1 : r;
  ch_prof_wrch_cntr = (wrch) ? w1 : w;
  ch_prof_misc_cntr = (misc) ? m1 : m;

  if (rdch & (ch == 24))
    {
      for (i = 0; i < 32; i++)
	{
	  if (tagmask & (1 << i))
	    ch_prof_tagid_table[i] += 1;
	}
    }

  if (rdch | wrch)
    {
      /* ISA reserves 7b but only 5b are generally used. */
      ch_prof_ch_table[ch] += 1;
    }

  status &= ~MFC_DECREMENTER_EVENT;

  /* Reset counter. */
  spu_writech (SPU_WrDec, CH_PROF_DECR_COUNT);
  return (status);
}
#endif


/* ch_prof_dump
 *
 * Dump channel profile tables to STDOUT.
 */
static void
ch_prof_dump (void)
{
  float percent_rdch =
    ((float) ch_prof_rdch_cntr / (float) ch_prof_ticks) * 100.0f;
  float percent_wrch =
    ((float) ch_prof_wrch_cntr / (float) ch_prof_ticks) * 100.0f;
  float percent_misc =
    ((float) ch_prof_misc_cntr / (float) ch_prof_ticks) * 100.0f;
  int i;

  printf ("\n");
  printf ("SPE Channel Profiling.\n");
  printf ("  Decr. frequency:           %10d\n", CH_PROF_DECR_COUNT);
  printf ("  Total ticks:               %10d\n", ch_prof_ticks);
  printf ("  Ticks for rdch:            %10d\t (%2.2f %%)\n",
	  ch_prof_rdch_cntr, percent_rdch);
  printf ("  Ticks for wrch:            %10d\t (%2.2f %%)\n",
	  ch_prof_wrch_cntr, percent_wrch);
  printf ("  Ticks for compute:         %10d\t (%2.2f %%)\n",
	  ch_prof_misc_cntr, percent_misc);
  printf ("\n");
  printf ("\n");

  if (ch_prof_rdch_cntr | ch_prof_wrch_cntr)
    {
      printf ("          Ticks by channel id:\n");
      printf ("       ticks\t         %%\t         CH\n");
      printf ("  ==========\t ==========\t ==========\n");
      for (i = 0; i < 32; i++)
	{
	  if (ch_prof_ch_table[i])
	    {
	      float ratio =
		(float) ch_prof_ch_table[i] / (float) ch_prof_ticks;

	      printf ("  %10d\t %10.2f\t %10d (%s)\n",
		      ch_prof_ch_table[i], ratio * 100.0f, i,
		      ch_prof_channel_names[i]);
	    }
	}
      printf ("\n");
      printf ("\n");

      if (ch_prof_ch_table[24])
	{
	  printf ("          Ticks by tag group id:\n");
	  printf ("       ticks\t         %%\t      tagid\n");
	  printf ("  ==========\t ==========\t ==========\n");
	  for (i = 0; i < 32; i++)
	    {
	      if (ch_prof_tagid_table[i])
		{
		  float ratio =
		    (float) ch_prof_tagid_table[i] / (float) ch_prof_ticks;

		  printf ("  %10d\t %10.2f\t %10d\n",
			  ch_prof_tagid_table[i], ratio * 100.0f, i);
		}
	    }
	  printf ("\n");
	  printf ("\n");
	}
    }
}

/* ch_prof_reset - clear channel profiling counters.
 */
static inline void
ch_prof_reset (void)
{
  int i;

  ch_prof_ticks = 0;
  ch_prof_rdch_cntr = 0;
  ch_prof_wrch_cntr = 0;
  ch_prof_misc_cntr = 0;

  for (i = 0; i < 32; i++)
    {
      ch_prof_ch_table[i] = 0;
      ch_prof_tagid_table[i] = 0;
    }
}

/* ch_prof_enable - enable channel profiling.
 *
 * This call enables channel profiling
 * by turning on decrementer interrupts.
 */
static inline void
ch_prof_enable (void)
{
#if !(CH_PROF_FLIH)
  /* Register a decrementer event handler */
  spu_slih_reg (MFC_DECREMENTER_EVENT, ch_prof_tick);
#endif

  /* Initialize the decrementer state including:
   * 1) event mask
   * 2) decrementer counter
   * 3) interrupt enable state
   */
  spu_writech (SPU_WrEventMask, MFC_DECREMENTER_EVENT);
  spu_writech (SPU_WrDec, CH_PROF_DECR_COUNT);

  spu_ienable ();
}

/* ch_prof_disable - disable channel profiling.
 *
 * This call disables channel profiling by
 * turning off interrupts.
 */
static inline void
ch_prof_disable (void)
{
  spu_idisable ();
}

#endif
