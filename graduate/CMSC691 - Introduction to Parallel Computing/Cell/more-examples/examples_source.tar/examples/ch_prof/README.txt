%% --------------------------------------------------------------  
%% (C)Copyright 2006,2007,                                         
%% International Business Machines Corporation                     
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	SPU-based statistical profiler of channel activity.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory contains source code for 'ch_prof', a 
	profiling utility that can be used to determine channel
	read/write activity of an SPU program.  The information
	gathered by ch_prof provides an estimate of time spent 
	in compute versus channel stalls.

	This directory also includes a sub-directory with a example
	application.

	ch_prof uses decrementer interrupts to sample the program's 
	current instruction, classifies the instruction by type, 
	then increments counters based on that type.  The counters 
	can be dumped to STDOUT, or reset.

	This approach has several attractive features.  

	1.  ch_prof can gather information entirely on the 
	    SPU, without intervention from PPE or OS.  

	2. ch_prof provides immediate feedback and does not 
	   require post-processing.  This allows programmers
	   to quickly identify whether their code is compute 
	   bound or I/O bound.  

	3. ch_prof does not require elaborate instrumentation 
	   and so it is non-invasive from a coding perspective.  

	4. ch_prof can detect stalls on all channels, including
	   mailboxes, signal notification, DMA command queue,
	   etc.

	5. The ch_prof approach is fairly light weight with 
	   regard to its impact to application performance,
	   particularly when the FLIH codepath is used.

	The major drawback to this approach is that statistical
	sampling may give variable results from one run to the 
	next.  

	Additionally, ch_prof does not identify NPC hotspots, 
	nor does it gather results by function.

How to use ch_prof in an application:

	The application program must #include <ch_prof.h>, 
	and must explicitly call these interfaces to enable, 
	disable and dump the profiling information.  

	Applications may choose to configure ch_prof to use either 
	a first level interrupt handler [FLIH] or a second level
	interrupt handler [SLIH], depending on their sensitivity 
	to stack space & cycle counts.  The FLIH is default.
	See the Makefile for details.

	When ch_prof detects that the current instruction is a
	read channel [rdch] or write channel [wrch] instruction, 
	it increments a counter for the given channel number.

	When ch_prof detects that the current instruction is a
	rdch of MFC_RdTagStat, it further reads the current
	setting of MFC_RdTagMask and increments a counter for 
	each bit that is set in the current tagmask.

	By examining the ticks for each of the various tagids
	used in an application, the programmer can evaluate
	which sections of code are data transfer bound.
	ch_prof is also capable of detecting stalls due to
	mailbox or signal notification activity.

	The example program provided here is entirely bound on
	data transfer.  The vast majority of ticks will likely
	be on the MFC_Cmd channel, as the DMA command queue will
	be full after 16 DMA requests.

	In a multi-SPE application, there may be ordering issues
	with regard to dumping the ch_prof information to STDOUT.
	In this case the programmer simply enable ch_prof on just 
	one SPE.  Another option is to control the shut-down order 
	of the SPE's, so as to serialize the order that ch_prof 
	information is spilled ot STDOUT.

	If an application requires that there be no source code 
	modification, then one alternative would be to be to create 
	a custom crt0.o that enables profiling in 'start' (before 
	main is called) and disables and dumps profiling information 
	in 'exit' (after main has returned).  By linking against
	such a crt0.o, one could gain the benefit of profiling
	without modifying any application source code.

