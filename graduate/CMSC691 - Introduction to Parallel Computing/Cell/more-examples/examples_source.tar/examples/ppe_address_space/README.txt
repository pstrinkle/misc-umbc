%% --------------------------------------------------------------  
%% (C)Copyright 2007                                               
%% International Business Machines Corporation                     
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
        Quick-sort on a random list of floats using compiler
	PPE address space support.

Target:
        CBE-Linux PPU or SPU (HW or simulator)

Description:
	This version of the standard quick-sort algorithm has been
	modified to use iterative rather than stack based recursion.  
	This allows the program to be compiled and executed on either
	SPU or PPU with minimal differences in the source code.

        The purpose here is to illustrate automatic software caching 
	feature supported by the SPU compiler.  The '__ea' qualifier
	is used within the source file to indicate to the SPU compiler
	that a memory reference is in the remote (or effective) address
	space, rather than in local store.  The compiler automatically
	generates code to DMA these data objects into local store and
	caches references to these data objects.  The size of the cache
	in local store is configurable to the programmer (-mcache-size=128) 
	but the line size and cache type are fixed by the compiler at 128 
	bytes and 4-way set associative.

	When the program is compiled for the SPU, it executes as a 
	stand-alone SPU-let, taking command line arguments and performing 
	its file I/O just as would any other Linux program would.

How to run:
        This example may be run directly from the Linux command
        line, as

        ppu-qsort [-sphv] [-g <size>] [-r <seed>] <filename>
        spu-qsort [-sphv] [-g <size>] [-r <seed>] <filename>

        where:

	  <filename>    file containing floating point data to be sorted

  	  -s            Sort file.
  	  -g size       Generate a file with <size> items.
  	  -r seed       Random seed <value> for file generation, default=1.
  	  -p            Print items.
          -v            Verify the data is sorted.
  	  -h            Help message.

