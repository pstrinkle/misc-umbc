/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>


/* 
 * The __ea qualifier indicates to the SPU 
 * compiler that a memory reference is in 
 * the remote (or effective) address space, 
 * rather than in local store.  The compiler 
 * caches references to these objects.
 *
 * The __ea qualifier is not meaningful on
 * the PPU, which has a unified memory space.
 */

#ifdef __PPU__
#define __ea			/* ignored */
#define mmap_func	mmap
#define mmap_fail	MAP_FAILED
#else
#include <ea.h>
#define mmap_func	mmap_ea
#define mmap_fail	MAP_FAILED_EA
#endif

__ea float *data;


static inline void
swap (int idx1, int idx2)
{
  float tmp;

  tmp = data[idx1];
  data[idx1] = data[idx2];
  data[idx2] = tmp;
}

static inline int
compare_and_swap (int i, int j, float val, int polarity)
{
  float di = data[i];
  int leq = (di <= val);
  if (leq ^ polarity) {
    data[i] = data[j];
    data[j] = di;
    return 1;
  }
  return 0;
}

/* Called by quicksort() to partition data about pivot index. */
static inline int
partition (int left, int right, int pivot)
{
  float pval = data[pivot];
  int idx = left;
  int i = 0;

  swap (pivot, right);

  for (i = left; i < right; i++) {
    if (data[i] <= pval) {
      swap (i, idx);
      idx++;
    }
  }

  swap (right, idx);
  return idx;
}

#define INSERTION_SORT_THRESHOLD        20

/* Called by quicksort() when number of elements is small */
static inline void
insertionsort (int left, int right)
{
  int i;

  for (i = left + 1; i <= right; i++) {
    float val = data[i];
    int j = i;

    while (j > 0 && compare_and_swap (j - 1, j, val, 1))  j--;

    data[j] = val;
  }
}

__ea int *qstack = NULL;
int depth = 0;
int stacksize = 0;

static inline void
push (int left, int right)
{
  depth += 2;
  if (depth < (int)(stacksize/sizeof(int))) {
    qstack[0] = left;
    qstack[1] = right;
    qstack += 2;
  } else {
    printf ("Stack overflow. The stack size of %d overflowed\n", stacksize);
    exit (-1);
  }
}

static inline void
pop (int *left, int *right) 
{
  qstack -= 2;
  depth -= 2;
  *left = qstack[0];
  *right = qstack[1];
}

static inline int
stack_empty (void) 
{
  return (depth == 0);
}


/* Swap the values, _a and _b of data type _t
 */
#define SWAP(_a, _b, _t) {			\
  _t  _tmp;					\
  _tmp = _a;					\
  _a  = _b;					\
  _b  = _tmp;					\
}


static inline int
pickpivot(int left, int right)
{
  float lval, rval, cval;
  int center, pivot;

  /* We pick the pivot as the median of three values -- the left, right, and 
   * center.
   */
  center = left + (right - left)/2;

  lval = data[left];
  cval = data[center];
  rval = data[right];
  if (lval > cval) {
    SWAP(left, center, int);
    SWAP(lval, cval, float);
  }
  if (lval > rval) {
    SWAP(left, right, int);
    rval = lval;
  }
  pivot = (cval > rval) ? right : center;

  return (pivot);
}

/* iterative version of quicksort */
void
quicksort (int left, int right)
{
  if ((right - left + 1) <= INSERTION_SORT_THRESHOLD) {
    insertionsort (left, right);
    return;
  }

  push (left, right);

  while (!stack_empty ()) {
    pop (&left, &right);

    if (right <= left)
      continue;

    int pivot = pickpivot (left, right);
    int newpivot = 0;

    newpivot = partition (left, right, pivot);

    if (((newpivot - 1) - left) <= INSERTION_SORT_THRESHOLD)
      insertionsort (left, newpivot - 1);
    else
      push (left, newpivot - 1);

    if ((right - (newpivot + 1)) <= INSERTION_SORT_THRESHOLD)
      insertionsort (newpivot + 1, right);
    else
      push (newpivot + 1, right);
  }
}

void
exit_usage (char *cmd)
{
  printf ("Usage : %s [-sprh] [-g <size>] <filename>\n", cmd);
  printf ("  -s\t\tSort file.\n");
  printf ("  -g size\tGenerate a file with <size> items\n");
  printf ("  -r value\tRandom seed <value> for file generation, default=1.\n");
  printf ("  -p\t\tPrint items.\n");
  printf ("  -v\t\tVerify the data is sorted.\n");
  printf ("  -h\t\tThis help.\n\n");
  printf ("Example: %s -spg 128 test.dat\n", cmd);
  printf ("Generate 128 random floats, sort them and print both sets.\n");
  exit (-1);
}

unsigned int randseed = 1;

/* Write random data to file, for use.  */
void
write_data (char *filename, int items)
{
  FILE *fp = NULL;
  float f = 0.0;
  int i = 0;

  printf ("Creating file: %s\n", filename);

  if ((fp = fopen (filename, "w")) == NULL) {
    printf ("Opening %s failed!\n", filename);
    exit (-1);
  }

  srand (randseed);

  for (i = 0; i < items; i++) {
    f = (float) (rand () / (RAND_MAX + 1.0));
    if (!fwrite (&f, 4, 1, fp)) {
      printf ("Writing to  %s failed!\n", filename);
      exit (-1);
    }
  }

  if (fclose (fp)) {
    printf ("Closing %s failed!\n", filename);
    exit (-1);
  }
}

/* Print data.  */
void
print_data (int items)
{
  int i = 0;

  for (i = 0; i < items; i++)
    printf ("  %.9f\n", data[i]);
}

/* Get data from previously generated file.  */
void
get_data (char *filename, int *items)
{
  struct stat buf;
  int prot = PROT_READ | PROT_WRITE;
  int flags = MAP_SHARED;
  int fd = 0;

  printf ("Using file: %s\n", filename);

  if ((fd = open (filename, O_RDWR, 0)) == -1) {
    printf ("Opening file %s failed!\n", filename);
    exit (-1);
  }

  if (fstat (fd, &buf) == -1) {
    printf ("Statting file %s failed!\n", filename);
    exit (-1);
  }

  data = mmap_func (NULL, buf.st_size, prot, flags, fd, 0);

  if (data == mmap_fail) {
    printf ("Mmap of %s failed!\n", filename);
    exit (-1);
  }

  if (close (fd) == -1) {
    printf ("Closing %s failed.\n", filename);
    exit (-1);
  }

  *items = buf.st_size >> 2;
}

/* Get anonymous page(s) for user-managed stack. */
void
get_stack (__attribute ((unused))
	   int items)
{
  int prot = PROT_READ | PROT_WRITE;
  int flags = MAP_ANON | MAP_PRIVATE;

  stacksize = getpagesize();

  qstack = mmap_func (NULL, stacksize, prot, flags, -1, 0);

  if (qstack == mmap_fail) {
    printf ("Mmap of stack space failed!\n");
    exit (-1);
  }
}

int
main (int argc, char **argv)
{
  char *filename = NULL;

  int items = 0;
  int i = 0;

  char c = 0;
  int sort = 0;
  int print = 0;
  int verify = 0;

  /* Argument parsing. */
  while ((c = getopt (argc, argv, "g:rshpv")) != (char) -1) {
    switch (c)  {
    case 'g':
      items = atoi (optarg);
      break;
    case 'p':
      print = 1;
      break;
    case 'r':
      randseed = atoi (optarg);
      break;
    case 's':
      sort = 1;
      break;
    case 'v':
      verify = 1;
      break;
    case 'h':
    default:
      exit_usage (argv[0]);
      break;
    }
  }

  if (optind == (argc - 1))
    filename = argv[optind];
  else {
    printf ("No filename.\n");
    exit_usage (argv[0]);
  }

  /* Write random items to file.  */
  if (items)
    write_data (filename, items);

  if (!sort)
    exit (-1);

  /* Load items from file.  */
  get_data (filename, &items);

  /* Get space for user-managed stack. */
  get_stack (items);

  if (print) {
    printf ("Data:\n");
    print_data (items);
  }

  /* Run the sort. */
  quicksort (0, items - 1);

  if (print) {
    printf ("Sorted data:\n");
    print_data (items);
  }

  /* And just to verify our work, check the whole thing.  */
  if (verify) { 
    printf ("Checking the sort of %d items.\n", items);
    for (i = 1; i < items; i++)	{
      if (data[i] < data[i - 1]) {
	printf ("Sort failed! (%d)\n", i);
	return -1;
      }
    }
    printf ("Sorted!\n");
  }

  return 0;
}
