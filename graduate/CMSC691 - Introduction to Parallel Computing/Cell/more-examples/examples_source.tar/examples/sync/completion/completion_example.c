/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <libspe2.h>
#include <pthread.h>
#include <unistd.h>
#include <libsync.h>
#include <malloc_align.h>
#include <free_align.h>
#include <string.h>
#include "completion_example.h"

extern spe_program_handle_t completion_spu_example;

volatile int completion_var[MAX_NUM_SPUS * MAX_NUM_CBES + 2] __attribute__ ((aligned (128)));

typedef struct ppu_pthread_data {
    spe_context_ptr_t spuid;
    pthread_t pthread;
    void *argp;
} ppu_pthread_data_t;

void *ppu_pthread_function(void *arg) {
	ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
	int rc;
    unsigned int entry = SPE_DEFAULT_ENTRY;
    if ((rc = spe_context_run(datap->spuid, &entry, 0, datap->argp, NULL, NULL)) < 0) {
        fprintf (stderr, "Failed spe_context_run(rc=%d, errno=%d)\n", rc, errno);
        exit (1);
    }
	pthread_exit(NULL);
}

/*
 * completion_example
 *      This example shows the usage of ....
 *      The PPE ...
 */ 
int main (int argc, char **argv)
{
  ppu_pthread_data_t datas[MAX_NUM_SPUS * MAX_NUM_CBES];   
  int max_spes;
  int num_spes;	// default number of spes
  int rc;                                   
  int i;   
  long long comp_res;	// what the computer result should be
  volatile completion_spu_example_argv_t* example_argv;
  long long* input_ea;
  completion_ea_t completion_ea[MAX_NUM_SPUS * MAX_NUM_CBES + 2];

  // Test can run on 2 to 16 SPEs, the default is the number of usable SPEs
  num_spes = spe_cpu_info_get(SPE_COUNT_USABLE_SPES,-1);
  if (argc > 1) {                                                       
    max_spes = atoi(argv[1]);                                           
    if (( max_spes < 2 ) || ( max_spes > MAX_NUM_SPUS*MAX_NUM_CBES ) || ( max_spes > num_spes )) { 
      printf("FAILED: Illegal max number of SPEs (%d).\n", max_spes);    
      exit(1);                                                         
    }                                                                   
    num_spes = max_spes;                         
  }
  printf ("%s, begins, number of SPUs = %d\n", __PRETTY_FUNCTION__, num_spes);

  // Allocate argument structure 
  example_argv = (volatile completion_spu_example_argv_t*) _malloc_align (sizeof(completion_spu_example_argv_t), 7);
  if (!example_argv)
    {
      fprintf (stderr, "%s, cannot malloc memory for test_argv\n", __PRETTY_FUNCTION__);
      return 1;
    }

  // Allocate and initialize input buffer
  input_ea = (long long*)_malloc_align (BUFFER_SIZE * sizeof (long long), 7);
  if (!input_ea)
  {
      fprintf (stderr, "%s, cannot malloc memory for input_ea\n", __PRETTY_FUNCTION__);
      return 1;
  }
  for (i = 0; i < BUFFER_SIZE; i++)
  {
      input_ea[i] = 0;
  }
    
  /* initialize the completion structures that will be passed into the SPUs */
  for (i = 0; i < num_spes+2; i++) {
    completion_ea[i] = (completion_ea_t)(uintptr_t)(&completion_var[i]);
    example_argv->input_buf_ea = (unsigned long long)(uintptr_t)(input_ea);
    init_completion(completion_ea[i]);
    example_argv->completion_ea[i] = completion_ea[i];
  }
  example_argv->num_spes = num_spes;

  /* create the threads  */
  for (i = 0; i < num_spes; i++)
    {
      /* Create context */
      if ((datas[i].spuid = spe_context_create (0, NULL)) == NULL)
        {
          fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Load program */
      if ((rc = spe_program_load (datas[i].spuid, &completion_spu_example)) != 0)
        {
          fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Initialize data */
      datas[i].argp = (void *)example_argv;
      /* Create thread */
      if ((rc = pthread_create (&datas[i].pthread, NULL, &ppu_pthread_function, &datas[i])) != 0)
        {
          fprintf (stderr, "Failed pthread_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
    }
  printf ("PPU: %s, finished initializing SPUs, now send them their IDs\n", __PRETTY_FUNCTION__ );

  // Send each SPU their unique ID
  for (i=0; i<num_spes; ++i) { 
     unsigned int foo;                     
     while (spe_out_mbox_status(datas[i].spuid) <= 0);
     spe_out_mbox_read(datas[i].spuid, &foo, 1);
     spe_in_mbox_write(datas[i].spuid, (unsigned int *)(&i), 1, SPE_MBOX_ANY_NONBLOCKING);
  }

  // Mark first variable complete to start the SPEs
  printf("PPU: Start the completion cycle\n");
  complete(completion_ea[0]);

  // Want to test a failure?  Uncomment this next line.
  //complete_all(completion_ea[num_spes-1]);

  // Wait for our completion variable
  wait_for_completion(completion_ea[num_spes]);

  // Send final completion to all SPUs
  printf("PPU: Run complete_all to end all SPUs\n");
  complete_all(completion_ea[num_spes+1]);

  /* wait for SPU threads to complete execution */
  for (i = 0; i < num_spes; i++) 
    {
      /* Join thread */
      if ((rc = pthread_join (datas[i].pthread, NULL)) != 0)
        {
          fprintf (stderr, "Failed pthread_join(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
      /* Destroy context */
      if ((rc = spe_context_destroy (datas[i].spuid)) != 0)
        {
          fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
    }

  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);
  // Compute expected result
  // Each SPU takes the current total, adds its SPU number and then multiplies
  // by the SPU number.  If this is done out of order or some SPUs are not run,
  // the result will not be the same.
  comp_res = 0;
  for (i = 0; i < num_spes ; i++) {
    comp_res = (comp_res + i) * i;
  }
  PRINTF("Check result (should be %lld)\n",comp_res);
  for (i = 0; i < BUFFER_SIZE; i++)
    {
      if (comp_res != input_ea[i])
        {
          printf ("%s, FAILED, compres = %lld, input_ea[%d] = %lld\n", 
              __PRETTY_FUNCTION__, comp_res, i, input_ea[i]);
          return 1;
        }
    }

  printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);

  // Free allocated memory
  _free_align ((void*)example_argv);
  _free_align ((void*)input_ea);

  return 0;
}

