%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Completion variable example.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This example program shows how the completion variable provided
	with this SDK works. 

	You can find the PPU side of the program in completion_example.c
	in this directory and the SPU side of the program in 
	spu/completion_spu_example.c
        
	The binary (completion_example) takes an optional argument that
	gives the number of SPUs to use.  The PPU uses init_completion()
	to create a completion variable for it and each SPU and an input
	buffer, initialized to 0.  It then starts the SPU threads, sends
	them each their ID, marks the first variable as complete with 
	complete_all() and then runs wait_for_completion() on the 
	last variable.

	The SPUs use wait_for_completion() to wait for their completion 
	variable (based on their ID).  Once it has been marked, they load
	the input buffer and for each value, add their ID and then multiply
	by their ID (x = (x+ID)*ID).  After updating the buffer they use
	complete() to mark the next variable (ID+1, which signals the 
	next SPU to start working) and then does a wait_for_completion() on
	the last completion variable.

	The last SPU's call to complete() signals the PPU that all are 
	complete.  The PPU runs complete_all() on the last variable, which
	triggers all SPUs to exit.

	The PPU then computes what the final value should be and
	compares it with the input buffer.  This confirms the completion
	chain was done in order and that the test has passed.

How to run:
	The command options are:

	completion_example [ <number_of_spes> ]

	where:
	<number_of_spes>
		Sets the number of SPEs used in the testing. The value
		must be in the range [2 .. 16].
		Default value is the number of usable SPEs.
