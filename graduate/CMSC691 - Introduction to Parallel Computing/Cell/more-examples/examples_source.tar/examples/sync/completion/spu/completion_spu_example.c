/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>
#include <spu_mfcio.h>
#include <libsync.h>
#include <completion_example.h>

static volatile long long inputbuf[BUFFER_SIZE] __attribute__ ((aligned (128)));
static completion_spu_example_argv_t spu_argv __attribute__ ((aligned (128)));
volatile int spe_num;


void do_work ()
{
  int i;
  PRINTF("SPU #%d: BEFORE inputbuf=%lld\n",spe_num, inputbuf[0]);
  for (i = 0; i < BUFFER_SIZE; i++)
  {
      inputbuf[i] = (inputbuf[i]+spe_num)*spe_num;
  }
  PRINTF("SPU #%d: AFTER  inputbuf=%lld\n",spe_num, inputbuf[0]);
}

int main (unsigned long long spuid __attribute__ ((unused)), 
          unsigned long long argp)
{ 
  addr64 argp64;
  unsigned int tag_id;
  argp64.ull = argp;

  // reserve a tag id
  tag_id = mfc_tag_reserve() & 31;

  // dma_get to get the content of argv 
  mfc_write_tag_mask (1 << tag_id);
  mfc_get ((void*)&spu_argv, argp, sizeof(completion_spu_example_argv_t), tag_id, 0, 0);
  mfc_read_tag_status_all();
  
  // Tell PPE I'm alive
  spu_write_out_mbox(1);

  // Wait for PPE to send our SPE number
  while (spu_stat_in_mbox () < 1);
  spe_num = spu_read_in_mbox();
  PRINTF ("SPU #%d: initialized\n", spe_num);

  wait_for_completion(spu_argv.completion_ea[spe_num]);
  PRINTF ("SPU #%d: Received completion\n",spe_num);

  // Read input buffer
  mfc_write_tag_mask (1 << tag_id);
  mfc_get ((void*)inputbuf, (long)spu_argv.input_buf_ea, sizeof(long long) * BUFFER_SIZE, tag_id, 0, 0);
  mfc_read_tag_status_all();
  PRINTF ("SPU #%d: finished getting inputbuffer\n",spe_num); 

  // Do some work
  do_work();

  // Write input buffer
  mfc_write_tag_mask (1 << tag_id);
  mfc_put ((void*)inputbuf, (long)spu_argv.input_buf_ea, sizeof(long long) * BUFFER_SIZE, tag_id, 0, 0);
  mfc_read_tag_status_all();

  // Mark next number complete
  PRINTF ("SPU #%d: Send #%d completion\n",spe_num, spe_num+1);
  complete(spu_argv.completion_ea[spe_num+1]);

  // Wait for final completion from PPU
  wait_for_completion(spu_argv.completion_ea[spu_argv.num_spes + 1]);

  PRINTF ("SPU #%d: exiting\n",spe_num);

  return 0; 
}
