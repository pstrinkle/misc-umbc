/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdio.h>
#include <spu_mfcio.h>
#include <libsync.h>
#include <cond_example.h>
#define DEBUGGING 1

static volatile int inputbuf[BUFFER_SIZE] __attribute__ ((aligned (128)));
static cond_spu_example_argv_t spu_argv __attribute__ ((aligned (128)));

static void do_work (unsigned long long spuid __attribute__ ((unused)), int count)
{
  int i;
  int start;
  int stop;
   
  start = count * NUM_ELEMENTS_PER_SPU;
  stop = start + NUM_ELEMENTS_PER_SPU; 

  for (i = start; i < stop; i++)
    {
      inputbuf[i] += i;
//      PRINTF ("SPU 0x%llx inputbuf[%d] = %d\n", spuid, i, inputbuf[i]);
    }
}

int main (unsigned long long spuid __attribute__ ((unused)), 
          unsigned long long argp)
{ 
  unsigned int tag_id;
  mutex_ea_t cond_mutex;
  mutex_ea_t buf_mutex;
  cond_ea_t cond;
  unsigned int ls_addr;
  unsigned int buf_addr;
  atomic_ea_t proceed_atomic_ea;
  atomic_ea_t count_atomic_ea;

  PRINTF ("SPU 0x%llx main begins argp = 0x%llx\n", spuid, argp);
 
  /* reserve a tag id */
  tag_id = mfc_tag_reserve() & 31;

  /* dma_get to get the content of argv */
  mfc_write_tag_mask (1 << tag_id);
  mfc_get ((void*)&spu_argv, argp, sizeof(cond_spu_example_argv_t), tag_id, 0, 0);
  mfc_read_tag_status_all();
  
  cond_mutex = spu_argv.cond_mutex_ea;
  buf_mutex = spu_argv.buf_mutex_ea;
  cond = spu_argv.cond_ea; 
  ls_addr = (unsigned int)inputbuf;
 
  mutex_lock (cond_mutex);
  PRINTF ("SPU 0x%llx finished locking, entering cond_wait\n", spuid); 
  while (spu_argv.proceed != 1) {
    cond_wait (cond, cond_mutex);
    proceed_atomic_ea = argp + 44;
    spu_argv.proceed = atomic_read (proceed_atomic_ea);
  }
  mutex_unlock (cond_mutex);

  PRINTF ("SPU 0x%llx getting input buffer, ls_addr=0x%x, ea=0x%llx\n", spuid, ls_addr, spu_argv.input_buf_ea);

  mfc_write_tag_mask (1 << tag_id);
  mfc_get ((void*)ls_addr, spu_argv.input_buf_ea, sizeof(int) * BUFFER_SIZE, tag_id, 0, 0);
  mfc_read_tag_status_all();

  PRINTF ("SPU 0x%llx finished cond_wait\n", spuid);
  
  count_atomic_ea = argp + offsetof(cond_spu_example_argv_t,count);
  spu_argv.count = atomic_inc_return (count_atomic_ea);
  PRINTF ("SPU 0x%llx count = %d\n", spuid, spu_argv.count);
  do_work (spuid, spu_argv.count);

  ls_addr = (unsigned int)inputbuf + sizeof(int)*spu_argv.count*NUM_ELEMENTS_PER_SPU;
  buf_addr = (unsigned int)spu_argv.buf_ea + sizeof(int)*spu_argv.count*NUM_ELEMENTS_PER_SPU;
  mfc_write_tag_mask (1 << tag_id);
  mfc_put ((void*)(ls_addr), buf_addr, 
      sizeof(int) * NUM_ELEMENTS_PER_SPU, tag_id, 0, 0);
  mfc_read_tag_status_all();
 
  PRINTF ("SPU 0x%llx main ends\n", spuid);

  return 0; 
}
