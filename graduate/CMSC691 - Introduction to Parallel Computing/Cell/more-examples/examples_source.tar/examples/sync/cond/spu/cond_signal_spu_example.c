/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdio.h>
#include <spu_mfcio.h>
#include <libsync.h>
#include <cond_example.h>

static volatile int inputbuf[BUFFER_SIZE] __attribute__ ((aligned (128)));
static cond_spu_example_argv_t spu_argv __attribute__ ((aligned (128)));

int do_work (unsigned long long spuid __attribute__ ((unused)))
{
  int i;
  int val = 0;

  for (i = 0; i < BUFFER_SIZE; i++)
    {
      val += inputbuf[i];
//      PRINTF ("SPU 0x%llx inputbuf[%d] = %d\n", spuid, i, inputbuf[i]);
    }
  return val;
}

int main (unsigned long long spuid __attribute__ ((unused)), 
          unsigned long long argp)
{ 
  int i;
  unsigned int tag_id;
  mutex_ea_t cond_mutex;
  mutex_ea_t buf_mutex;
  cond_ea_t cond;
  unsigned int ls_addr;
  volatile int j = 0;

  PRINTF ("SPU 0x%llx main begins argp = 0x%llx\n", spuid, argp);
 
  // reserve a tag id
  tag_id = mfc_tag_reserve() & 31;
   
  for (i = 0; i < 1000000; i++) {
    j += i;
  }

  PRINTF ("SPU 0x%llx main, j = %d\n", spuid, j);
  /* dma_get to get the content of argv */
  mfc_write_tag_mask (1 << tag_id);
  mfc_get ((void*)&spu_argv, argp, sizeof(cond_spu_example_argv_t), tag_id, 0, 0);
  mfc_read_tag_status_all();

  PRINTF ("SPU 0x%llx main, buf_ea = 0x%llx\n", spuid, spu_argv.buf_ea);
  
  cond_mutex = spu_argv.cond_mutex_ea;
  buf_mutex = spu_argv.buf_mutex_ea;
  cond = spu_argv.cond_ea; 

  mfc_write_tag_mask (1 << tag_id);
  mfc_get ((void*)inputbuf, spu_argv.input_buf_ea, sizeof(int) * BUFFER_SIZE, tag_id, 0, 0);
  mfc_read_tag_status_all();

  ls_addr = (unsigned int)&spu_argv;

  /* wait for PPE to signal or broadcast */

  PRINTF ("SPU 0x%llx main, finished getting inputbuffer\n", spuid); 
  for (i = 0; i < LOOP_COUNT; i++) {
    int count_orig;
    atomic_ea_t atomic_ea;
    atomic_ea_t count_atomic_ea;
    int stop = 0;
    int val;

    count_atomic_ea = argp + offsetof(cond_spu_example_argv_t,count);
    PRINTF ("SPU 0x%llx main, spu_argv.count = %d, count_ae=0x%llx\n", spuid, spu_argv.count, count_atomic_ea);
    spu_argv.count = atomic_inc_return (count_atomic_ea);
    PRINTF ("SPU 0x%llx main, spu_argv.count = %d\n", spuid, spu_argv.count);

    count_orig = spu_argv.count; 

    spu_argv.count++;
    
    if (spu_argv.count > COUNT_LIMIT) break;
    
    val = do_work (spuid);
    
    PRINTF ("SPU 0x%llx val = %d\n", spuid, val);

    /* update buffer in system memory */
    atomic_ea = (atomic_ea_t)spu_argv.buf_ea + sizeof (int) * count_orig;
    atomic_set (atomic_ea, val);
    
    if (spu_argv.count == COUNT_LIMIT) {
      mutex_lock (cond_mutex);
      /* signal the PPE that the SPEs are done */
      
      PRINTF ("SPU 0x%llx calling cond_signal PPE that we've reached limit\n", spuid);
      cond_signal (cond);
      stop = 1;
      PRINTF ("SPU 0x%llx finished calling\n", spuid);
      
      mutex_unlock (cond_mutex);
    }
 
    if (stop)
      break;
  }
  PRINTF ("SPU 0x%llx main ends\n", spuid);

  return 0; 
}
