/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <libspe2.h>
#include <pthread.h>
#include <unistd.h>
#include <libsync.h>
#include <malloc_align.h>
#include <free_align.h>
#include <string.h>
/*
#include "mutex_init.h"
#include "mutex_lock.h"
#include "mutex_unlock.h"
#include "cond_init.h"
#include "cond_wait.h"
#include "cond_signal.h"
#include "cond_broadcast.h"
*/
#include "cond_example.h"

extern spe_program_handle_t cond_signal_spu_example;
extern spe_program_handle_t cond_wait_spu_example;

volatile int cond_var __attribute__ ((aligned (128)));
volatile int cond_mutex_var __attribute__ ((aligned (128)));
volatile int buf_mutex_var __attribute__ ((aligned (128)));

typedef struct ppu_pthread_data {
    spe_context_ptr_t spuid;
    pthread_t pthread;
    void *argp;
} ppu_pthread_data_t;

void *ppu_pthread_function(void *arg) {
    ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
    int rc;
    unsigned int entry = SPE_DEFAULT_ENTRY;
    if ((rc = spe_context_run(datap->spuid, &entry, 0, datap->argp, NULL, NULL)) < 0) {
        fprintf (stderr, "Failed spe_context_run(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
        exit (1);
    }
    pthread_exit(NULL);
}

static int do_ppu_cond_wait_example (int num_spus)
{
  ppu_pthread_data_t datas[MAX_NUM_SPUS * MAX_NUM_CBES];
  int rc;
  int i;   
  cond_ea_t cond_ea;                                  
  volatile cond_spu_example_argv_t* example_argv;
  volatile int* buf_ea;
  int* input_ea;
  mutex_ea_t cond_mutex_ea;                                  
  mutex_ea_t buf_mutex_ea;                                  

  printf ("%s, begins, num_spus = %d\n", __PRETTY_FUNCTION__, num_spus);

  buf_ea = (volatile int*)_malloc_align (BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES *  sizeof (int), 7);
  if (!buf_ea)
    {
      fprintf (stderr, "%s, cannot malloc memory for buf_ea\n", __PRETTY_FUNCTION__);
      return 1;
    }

  input_ea = (int*)_malloc_align (BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES *  sizeof (int), 7);
  if (!input_ea)
    {
      fprintf (stderr, "%s, cannot malloc memory for input_ea\n", __PRETTY_FUNCTION__);
      return 1;
    }
  
  example_argv = (volatile cond_spu_example_argv_t*) _malloc_align (sizeof(cond_spu_example_argv_t), 7);
  if (!example_argv)
    {
      fprintf (stderr, "%s, cannot malloc memory for test_argv\n", __PRETTY_FUNCTION__);
      return 1;
    }
  
  cond_ea = (cond_ea_t)(uintptr_t)(&cond_var);
  cond_mutex_ea  = (mutex_ea_t)(uintptr_t)(&cond_mutex_var);
  buf_mutex_ea = (mutex_ea_t)(uintptr_t)(&buf_mutex_var);

  /* initialize the parameters that will be passed into the SPU */
  example_argv->cond_ea = cond_ea;
  example_argv->cond_mutex_ea = cond_mutex_ea;
  example_argv->buf_mutex_ea = buf_mutex_ea;
  example_argv->buf_ea = (unsigned long long)(uintptr_t)buf_ea;
  example_argv->input_buf_ea = (unsigned long long)(uintptr_t)input_ea;
  example_argv->count = 0;

  /* Initializing the condition variable */
  cond_init (cond_ea);
  
  /* Initializing the mutex variables */
  mutex_init (cond_mutex_ea);
  mutex_init (buf_mutex_ea);

  /* initialize buffer */
  for (i = 0; i < BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES; i++)
    {
      buf_ea[i] = 0;
    }

  for (i = 0; i < BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES; i++)
    {
      input_ea[i] = i;
    }
  printf ("%s, creating SPU threads\n", __PRETTY_FUNCTION__);

  /* create the threads  */                                                             
  for (i = 0; i < num_spus; i++)
    {
      /* Create context */
      if ((datas[i].spuid = spe_context_create (0, NULL)) == NULL)
        {
          fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Load program */
      if ((rc = spe_program_load (datas[i].spuid, &cond_signal_spu_example)) != 0)
        {
          fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Initialize data */
      datas[i].argp = (void *)example_argv;
      /* Create thread */
      if ((rc = pthread_create (&datas[i].pthread, NULL, &ppu_pthread_function, &datas[i])) != 0)
        {
          fprintf (stderr, "Failed pthread_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
    }
  printf ("PPU %s, finished initializing SPUs, wait for SPUs to signal\n", 
      __PRETTY_FUNCTION__ );

   /* let's wait */
  mutex_lock (cond_mutex_ea);
  while ((volatile int)(example_argv->count) < COUNT_LIMIT)
    {
      PRINTF ("PPU %s, calling cond_wait, count=%d, COUNT_LIMIT=%d\n", 
          __PRETTY_FUNCTION__, example_argv->count, COUNT_LIMIT);
      cond_wait (cond_ea, cond_mutex_ea);
    }
  mutex_unlock (cond_mutex_ea);
  
  printf ("PPU %s, finished cond_wait\n", __PRETTY_FUNCTION__);
 
  /* wait for SPU-thread to complete execution */                                       
  for (i = 0; i < num_spus; i++)
    {
      /* Join thread */
      if ((rc = pthread_join (datas[i].pthread, NULL)) != 0)
        {
          fprintf (stderr, "Failed pthread_join(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
      /* Destroy context */
      if ((rc = spe_context_destroy (datas[i].spuid)) != 0)
        {
          fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
    }

  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  for (i = 0; i < COUNT_LIMIT; i++)
    {
      int comp_res = ((BUFFER_SIZE) * (BUFFER_SIZE-1))/2;
      if (comp_res != buf_ea[i])
        {
          printf ("%s, FAILED, compres = %d(0x%x), buf_ea[%d] = %d(0x%x)\n", 
              __PRETTY_FUNCTION__, comp_res, comp_res, i, buf_ea[i], buf_ea[i]);
          return 1;
        }
    }

  _free_align ((void*)buf_ea);
  _free_align ((void*)example_argv);
  _free_align ((void*)input_ea);
  printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);

  return 0;

}

static int do_ppu_cond_broadcast_example (int num_spus)
{
  ppu_pthread_data_t datas[MAX_NUM_SPUS * MAX_NUM_CBES];
  int rc;
  int i;   
  cond_ea_t cond_ea;                                  
  volatile cond_spu_example_argv_t* example_argv;
  volatile int* buf_ea;
  int* input_ea;
  mutex_ea_t cond_mutex_ea;                                  
  mutex_ea_t buf_mutex_ea;                                  

  printf ("%s, begins, num_spus = %d\n", __PRETTY_FUNCTION__, num_spus);

  buf_ea = (volatile int*)_malloc_align (BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES *  sizeof (int), 7);
  if (!buf_ea)
    {
      fprintf (stderr, "%s, cannot malloc memory for buf_ea\n", __PRETTY_FUNCTION__);
      return 1;
    }

  input_ea = (int*)_malloc_align (BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES *  sizeof (int), 7);
  if (!input_ea)
    {
      fprintf (stderr, "%s, cannot malloc memory for input_ea\n", __PRETTY_FUNCTION__);
      return 1;
    }
  
  example_argv = (volatile cond_spu_example_argv_t*) _malloc_align (sizeof(cond_spu_example_argv_t), 7);
  if (!example_argv)
    {
      fprintf (stderr, "%s, cannot malloc memory for test_argv\n", __PRETTY_FUNCTION__);
      return 1;
    }
  cond_ea = (cond_ea_t)(uintptr_t)(&cond_var);
  cond_mutex_ea = (mutex_ea_t)(uintptr_t)(&cond_mutex_var);
  buf_mutex_ea = (mutex_ea_t)(uintptr_t)(&buf_mutex_var);

  /* initialize the parameters that will be passed into the SPU */
  example_argv->cond_ea = cond_ea;
  example_argv->cond_mutex_ea = cond_mutex_ea;
  example_argv->buf_mutex_ea = buf_mutex_ea;

  example_argv->buf_ea = (unsigned long long)(uintptr_t)buf_ea;
  example_argv->input_buf_ea = (unsigned long long)(uintptr_t)input_ea;

  example_argv->count = 0;
  example_argv->proceed = 0;

  /* Initializing the condition variable */
  cond_init (cond_ea);
  
  /* Initializing the mutex variables */
  mutex_init (cond_mutex_ea);
  mutex_init (buf_mutex_ea);

  /* create the threads  */                        
  for (i = 0; i < num_spus; i++)
    {
      /* Create context */
      if ((datas[i].spuid = spe_context_create (0, NULL)) == NULL)
        {
          fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Load program */
      if ((rc = spe_program_load (datas[i].spuid, &cond_wait_spu_example)) != 0)
        {
          fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Initialize data */
      datas[i].argp = (void *)example_argv;
      /* Create thread */
      if ((rc = pthread_create (&datas[i].pthread, NULL, &ppu_pthread_function, &datas[i])) != 0)
        {
          fprintf (stderr, "Failed pthread_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
    }
  printf ("PPU %s, finished initializing SPUs, wait for SPUs to signal\n", 
      __PRETTY_FUNCTION__ );

  /* initialize buffer */
  for (i = 0; i < BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES; i++)
    {
      buf_ea[i] = 0 ;
    }

  for (i = 0; i < BUFFER_SIZE * MAX_NUM_SPUS * MAX_NUM_CBES; i++)
    {
      int j;
      input_ea[i] = 0;
      for (j = 0; j < BUFFER_SIZE; j++)
        {
          input_ea[i] += j;
        }
    }

  //sleep (1);
   /* let's wait */
  mutex_lock (cond_mutex_ea);
  example_argv->proceed = 1;
  cond_broadcast (cond_ea);
  printf ("PPU %s, cond_var = 0x%x\n", __PRETTY_FUNCTION__, cond_var );
  mutex_unlock (cond_mutex_ea);
  
  printf ("PPU %s, finished cond_broadcast\n", __PRETTY_FUNCTION__);
 
  /* wait for SPU-thread to complete execution */                    
  for (i = 0; i < num_spus; i++)
    {
      /* Join thread */
      if ((rc = pthread_join (datas[i].pthread, NULL)) != 0)
        {
          fprintf (stderr, "Failed pthread_join(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
      /* Destroy context */
      if ((rc = spe_context_destroy (datas[i].spuid)) != 0)
        {
          fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
    }

  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  for (i = 0; i < NUM_ELEMENTS_PER_SPU*num_spus; i++)
    {
      int comp_res = (((BUFFER_SIZE) * (BUFFER_SIZE-1))/2) + i;
      if (comp_res != buf_ea[i])
        {
          printf ("%s, FAILED, compres = %d(0x%x), buf_ea[%d] = %d(0x%x)\n", 
              __PRETTY_FUNCTION__, comp_res, comp_res, i, buf_ea[i], buf_ea[i]);
          return 1;
        }
    }

  _free_align ((void*)buf_ea);
  _free_align ((void*)example_argv);
  _free_align ((void*)input_ea);
  printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);

  return 0;

}

/*
 * mutex_example
 *      This example shows the usage of mutex_init, mutex_lock, mutex_unlock
 *      In this short program, the PPU initiates _n_ number of SPE threads, 
 *      each SPE will try to get a lock for buf_ea, update buf_ea, then releases 
 *      the lock. Meanwhile, the PPE also attempts to lock on the buffer, 
 *      updates the buffer, then releases the lock.
 */ 
int main()
{
	int num_spus;
	int rc = 0;
	
	num_spus = spe_cpu_info_get(SPE_COUNT_USABLE_SPES,-1);
	
  if (( num_spus <= 0 ) || ( num_spus > MAX_NUM_SPUS*MAX_NUM_CBES )) {
    printf("FAILED: Illegal number of SPEs (%d).\n", num_spus);
    exit(1);
  }

  rc |= do_ppu_cond_wait_example (num_spus);
 
  rc |= do_ppu_cond_broadcast_example (num_spus);
  
  return rc;

}


