/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <libspe2.h>
#include <pthread.h>
//#include <libsync.h>
#include <malloc_align.h>
#include <free_align.h>
#include <string.h>
#include "mutex_init.h"
#include "mutex_lock.h"
#include "mutex_unlock.h"
#include "mutex_trylock.h"
#include "mutex_example.h"

extern spe_program_handle_t mutex_spu_example;

typedef struct ppu_pthread_data {
    spe_context_ptr_t spuid;
    pthread_t pthread;
    void *argp;
} ppu_pthread_data_t;

void *ppu_pthread_function(void *arg) {
    ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
    int rc;
    unsigned int entry = SPE_DEFAULT_ENTRY;
    if ((rc = spe_context_run(datap->spuid, &entry, 0, datap->argp, NULL, NULL)) < 0) {
        fprintf (stderr, "Failed spe_context_run(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
        exit (1);
    }
    pthread_exit(NULL);
}

/* test mutex_lock and mutex_unlock functions on the SPU */
static int do_mutex_example (int num_spus)
{
  ppu_pthread_data_t datas[MAX_NUM_SPUS * MAX_NUM_CBES];
  int rc;
  int i;                                                
  unsigned int mutex_var;                               
  mutex_ea_t mutex_ea;                                  
  volatile int* buf_ea;
  mutex_spu_test_argv_t* test_argv;

  printf ("%s, begins, num_spus = %d\n", __PRETTY_FUNCTION__, num_spus);

  buf_ea = (volatile int*)_malloc_align (BUFFER_SIZE * sizeof (int), 7);
  if (!buf_ea)
    {
      fprintf (stderr, "%s, cannot malloc memory for buf_ea\n", __PRETTY_FUNCTION__);
      return 1;
    }

  test_argv = (mutex_spu_test_argv_t*) _malloc_align (sizeof(mutex_spu_test_argv_t), 7);
  if (!test_argv)
    {
      fprintf (stderr, "%s, cannot malloc memory for test_argv\n", __PRETTY_FUNCTION__);
      return 1;
    }
  mutex_ea = (mutex_ea_t)(uintptr_t)(&mutex_var);

  test_argv->mutex_ea = mutex_ea;
  test_argv->buf_ea = (unsigned long long)(uintptr_t)buf_ea;

  printf ("%s, begins\n", __PRETTY_FUNCTION__);

  /* Initializing the mutex variable */
  _mutex_init (mutex_ea);

  PRINTF ("%s, after mutex_init\n", __PRETTY_FUNCTION__);
  PRINTF ("%s, buf_ea = %p\n", __PRETTY_FUNCTION__, test_argv->buf_ea);

  /* initialize buffer */
  for (i = 0; i < BUFFER_SIZE; i++)
    {
      buf_ea[i] = i;
    }

  /* create the threads  */                                                             
  for (i = 0; i < num_spus; i++)
    {
      /* Create context */
      if ((datas[i].spuid = spe_context_create (0, NULL)) == NULL)
        {
          fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Load program */
      if ((rc = spe_program_load (datas[i].spuid, &mutex_spu_example)) != 0)
        {
          fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
      /* Initialize data */
      datas[i].argp = test_argv;
      /* Create thread */
      if ((rc = pthread_create (&datas[i].pthread, NULL, &ppu_pthread_function, &datas[i])) != 0)
        {
          fprintf (stderr, "Failed pthread_create(errno=%d strerror=%s)\n", errno, strerror(errno));
          exit (1);
        }
    }
  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  _mutex_lock (mutex_ea);
  if (_mutex_trylock(mutex_ea)) {
    printf("PPU incorrectly got the lock a second time!\n");
  }
  else {
    PRINTF("PPU did not get lock a second time.\n");

    for (i = 0; i < LOOP_COUNT; i++)
      {
        int j;
        for (j = 0; j < BUFFER_SIZE; j++)
          {
            buf_ea[j] += 1;
          }
      }
  }
  _mutex_unlock (mutex_ea);
  
  /* wait for SPU-thread to complete execution */
  for (i = 0; i < num_spus; i++)
    {
      /* Join thread */
      if ((rc = pthread_join (datas[i].pthread, NULL)) != 0)
        {
          fprintf (stderr, "Failed pthread_join(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
      /* Destroy context */
      if ((rc = spe_context_destroy (datas[i].spuid)) != 0)
        {
          fprintf (stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
          exit (1);
        }
    }

  // Mutex should be available now since all SPEs have exited.
  if (_mutex_trylock(mutex_ea)) {
    PRINTF("PPU correctly took lock with mutex_trylock\n");
    _mutex_unlock (mutex_ea);
  }
  else {
    printf ("%s, FAILED, could not take lock with mutex_trylock\n", __PRETTY_FUNCTION__);
    return 1;
  }

  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);
  for (i = 0; i < BUFFER_SIZE; i++)
    {
      if (buf_ea[i] != (i + ((num_spus + 1) * LOOP_COUNT)))
        {
          printf ("%s, FAILED, buf_ea[%d]=%d\n", __PRETTY_FUNCTION__, i, buf_ea[i]);
          return 1;
        }
      else
        {
          printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
          return 0;
        }
    }

  _free_align ((void*)buf_ea);
  _free_align ((void*)test_argv);

  return 0;

}


/*
 * mutex_example
 *      This example shows the usage of mutex_init, mutex_lock, mutex_unlock
 *      In this short program, the PPU initiates _n_ number of SPE threads, 
 *      each SPE will try to get a lock for buf_ea, update buf_ea, then releases 
 *      the lock. Meanwhile, the PPE also attempts to lock on the buffer, 
 *      updates the buffer, then releases the lock.
 */ 
int main()
{
	int num_spus;
	int rc = 0;
	
	num_spus = spe_cpu_info_get(SPE_COUNT_USABLE_SPES,-1);
		
  if (( num_spus <= 0 ) || ( num_spus > MAX_NUM_SPUS*MAX_NUM_CBES )) {
    printf("FAILED: Illegal number of SPEs (%d).\n", num_spus);
    exit(1);
  }
	 
  rc |= do_mutex_example (num_spus);
   
  return rc;
}


