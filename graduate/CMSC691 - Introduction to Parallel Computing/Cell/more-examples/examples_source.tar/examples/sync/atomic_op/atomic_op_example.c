/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <libspe2.h>
#include <pthread.h>
#include <string.h>
#include <atomic_add.h>
#include <atomic_add_return.h>
#include <atomic_dec.h>
#include <atomic_dec_return.h>
#include <atomic_dec_and_test.h>
#include <atomic_dec_if_positive.h>
#include <atomic_inc.h>
#include <atomic_inc_return.h>
#include <atomic_read.h>
#include <atomic_set.h>
#include <atomic_sub.h>
#include <atomic_sub_return.h>
#include <atomic_sub_and_test.h>
#include <atomic_op_example.h>

extern spe_program_handle_t atomic_add_test;
extern spe_program_handle_t atomic_add_return_test;
extern spe_program_handle_t atomic_dec_test;
extern spe_program_handle_t atomic_dec_return_test;
extern spe_program_handle_t atomic_dec_and_test_test;
extern spe_program_handle_t atomic_dec_if_positive_test;
extern spe_program_handle_t atomic_inc_test;
extern spe_program_handle_t atomic_inc_return_test;
extern spe_program_handle_t atomic_set_test;
extern spe_program_handle_t atomic_sub_test;
extern spe_program_handle_t atomic_sub_return_test;
extern spe_program_handle_t atomic_sub_and_test_test;

unsigned int data[RETURN_COUNT * RETURN_SZ]            __attribute((aligned(128)));

typedef struct ppu_pthread_data {
  spe_context_ptr_t spuid;
  pthread_t pthread;
  void *argp;
} ppu_pthread_data_t;

void *ppu_pthread_function(void *arg) {
  ppu_pthread_data_t *datap = (ppu_pthread_data_t *)arg;
  int rc;
  unsigned int entry = SPE_DEFAULT_ENTRY;
  if ((rc = spe_context_run(datap->spuid, &entry, 0, datap->argp, NULL, NULL)) < 0) {
    fprintf (stderr, "Failed spe_context_run(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
    exit (1);
  }
  pthread_exit(NULL);
}

#define ATOMIC_OP_TEST_DECL()                            \
  ppu_pthread_data_t datas[MAX_NUM_SPUS * MAX_NUM_CBES]; \
  int rc;                                                \
  int i;                                                 \
  volatile signed int atomic_var;                        \
  signed int atomic_init;                                \
  atomic_ea_t atomic_ea;                                 \
  atomic_ea = (atomic_ea_t)(uintptr_t)(&atomic_var)

#define ATOMIC_OP_TEST_DECL_64()                         \
  ppu_pthread_data_t datas[MAX_NUM_SPUS * MAX_NUM_CBES]; \
  int rc;                                                \
  int i;                                                 \
  volatile signed int atomic_var;                        \
  signed int atomic_init;                                \
  atomic_ea_t atomic_ea;                                 \
  atomic_ea = (atomic_ea_t)(&atomic_var)		

// ATOMIC_OP_TEST_START_SPUS_WAIT initializes atomic_var to -1, which is
// a signal to the SPEs that they should not start their work yet.  This
// helps sync them up so they are all doing their atomic modifications at
// the same time.  Start the SPEs and then wait for them to start updating
// the atomic variable before exiting, so the PPE updates are also done when 
// the SPEs are modifying.
#define ATOMIC_OP_TEST_START_SPUS_WAIT(__spu_program_handle, atomic_value) \
   atomic_var = -1; /* set to -1 so SPEs will wait */                      \
   ATOMIC_OP_TEST_START_SPUS(__spu_program_handle);                        \
   /* set value to trigger start of all SPEs */                            \
   PRINTF ("%s, calling atomic_set\n", __PRETTY_FUNCTION__);		   \
   _atomic_set(atomic_ea, atomic_value);                                   \
   PRINTF ("%s, after calling atomic_set, atomic_value=%d\n", __PRETTY_FUNCTION__, atomic_value);	   \
   /* Wait for change, showing SPEs have started their work */             \
   /* prof_cp1(); */	\
   while (_atomic_read(atomic_ea) == atomic_value);			   \
   PRINTF ("%s, after atomic_read\n", __PRETTY_FUNCTION__)

#define ATOMIC_OP_TEST_START_SPUS(__spu_program_handle)                                 \
  /* create the threads  */                                                             \
  for (i = 0; i < num_spus; i++)                                                        \
    {                                                                                   \
      /* create context */                                                              \
      if ((datas[i].spuid = spe_context_create (0, NULL)) == NULL)                      \
        {                                                                               \
          fprintf (stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));   \
          exit (1);                                                                     \
        }                                                                               \
      /* load program */                                                                \
      if ((rc = spe_program_load (datas[i].spuid,&__spu_program_handle)) != 0)          \
        {                                                                               \
          fprintf (stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));     \
          exit (1);                                                                     \
        }                                                                               \
      /* initialize data */                                                             \
      datas[i].argp = (void *)&atomic_var;                                              \
      /* create thread */                                                               \
      if ((rc = pthread_create (&datas[i].pthread, NULL, &ppu_pthread_function, &datas[i])) != 0)          \
        {                                                                               \
          fprintf (stderr, "Failed pthread_create(errno=%d strerror=%s)\n", errno, strerror(errno));       \
          exit (1);                                                                     \
        }                                                                               \
    }

#define ATOMIC_OP_TEST_WAIT_SPUS()                                                      \
  /* wait for SPU-thread to complete execution */                                       \
  for (i = 0; i < num_spus; i++)                                                        \
    {                                                                                   \
      /* wait for thread to complete */                                                 \
      if ((rc = pthread_join (datas[i].pthread, NULL)) < 0)                             \
        {                                                                               \
          fprintf (stderr, "Failed pthread_join(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));    \
          exit (1);                                                                     \
        }                                                                               \
      /* destroy context */                                                             \
      if ((rc = spe_context_destroy (datas[i].spuid)) != 0)                             \
        {                                                                               \
          fprintf (stderr, "Failed spe_context_destroy(errno=%d, strerror=%s)\n", errno, strerror(errno));        \
          exit (1);                                                                     \
        }                                                                               \
    }


/*
 * Verify SPU atomic_add operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_add_spu_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  atomic_init = 0;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);

  //prof_cp2();

  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_add_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  ATOMIC_OP_TEST_WAIT_SPUS();

  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  /* check result */
  if (atomic_var != (signed int)num_spus * LOOP_COUNT)
    {
      printf ("%s, failed\n", __PRETTY_FUNCTION__);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_add_spu_test */


/*
 * Verify SPU and PPE atomic_add operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_add
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_add_cbe_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  atomic_init = 0;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);

  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_add_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );
 
  for (i = 0; i < LOOP_COUNT; i++)
    {
      _atomic_add (1, atomic_ea);
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  /* check result */
  if (atomic_var != (signed int)(num_spus +1) * LOOP_COUNT)
    {
      printf ("%s, failed\n", __PRETTY_FUNCTION__);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_add_cbe_test */


/*
 * Verify SPU and PPE atomic_add_return operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_add_return
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_add_return_test (int num_spus)
{
  
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  int atomic_ret;
  int compute_tot, real_tot;

  atomic_init = 0;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);

  atomic_var = -1; /* set to -1 so SPEs will wait */              
  ATOMIC_OP_TEST_START_SPUS(atomic_add_return_test);

   // initialize the data
  for (i = 0; i < (RETURN_COUNT * RETURN_SZ); i++) {
    data[i]=0;
  }

  // send the data address to the SPEs
  for (i = 0; i < num_spus; i++) {
    union {
      unsigned long long ull;
      unsigned int ui[2];
    } data_addr;

    data_addr.ull = (unsigned long long)((uintptr_t)(&(data[0])));
    spe_in_mbox_write (datas[i].spuid, data_addr.ui, 2, SPE_MBOX_ANY_NONBLOCKING);
  }
  printf ("%s, finished sending data address to spes\n", __PRETTY_FUNCTION__);

  /* set value to trigger start of all SPEs */  
  _atomic_set(atomic_ea, atomic_init);        
  /* Wait for change, showing SPEs have started their work */        
  while ((volatile int)(_atomic_read(atomic_ea)) == atomic_init);

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );
 
  // Just one from PPU otherwise it starves the SPEs
  atomic_ret = _atomic_add_return (1, atomic_ea);
  PRINTF("PPU: atomic_ret=%d\n",atomic_ret);
  if (atomic_ret < 100) {
     for (i=0; i<RETURN_SZ; i++) {
        data[atomic_ret*RETURN_SZ + i] = atomic_ret;
     }
  }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  /* Compute what the total should be */
  compute_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   compute_tot+=i;
  }
  PRINTF("COMPUTE_TOT=%d\n",compute_tot);

  /* Get the real total */
  real_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   real_tot+=data[i*RETURN_SZ];
  }
  PRINTF("REAL_TOT=%d\n",real_tot);

  /* check result */
  if (compute_tot != real_tot)
    {
      printf ("%s, FAILED - Total=%d Should be %d\n\n", __PRETTY_FUNCTION__, real_tot, compute_tot);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }

}					/* do_atomic_add_return_test */


/*
 * Verify SPU and PPE atomic_inc operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_inc
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_inc_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  atomic_init = 0;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);

  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_inc_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );
 
  for (i = 0; i < LOOP_COUNT; i++)
    {
      _atomic_inc (atomic_ea);
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  /* check result */
  if (atomic_var != (signed int)(num_spus +1) * LOOP_COUNT)
    {
      printf ("%s, failed\n", __PRETTY_FUNCTION__);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_inc_test */


/*
 * Verify SPU and PPE atomic_inc_return operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_inc_return
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_inc_return_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  
  int atomic_ret;
  int compute_tot, real_tot;

  atomic_init = 0;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);

  atomic_var = -1; /* set to -1 so SPEs will wait */              
  ATOMIC_OP_TEST_START_SPUS(atomic_inc_return_test);

   // initialize the data
  for (i = 0; i < (RETURN_COUNT * RETURN_SZ); i++) {
    data[i]=0;
  }

  // send the data address to the SPEs
  for (i = 0; i < num_spus; i++) {
    union {
      unsigned long long ull;
      unsigned int ui[2];
    } data_addr;

    data_addr.ull = (unsigned long long)((uintptr_t)(&(data[0])));
    spe_in_mbox_write (datas[i].spuid, data_addr.ui, 2, SPE_MBOX_ANY_NONBLOCKING);
  }

  /* set value to trigger start of all SPEs */  
  _atomic_set(atomic_ea, atomic_init);        
  /* Wait for change, showing SPEs have started their work */        
  while (_atomic_read(atomic_ea) == atomic_init) ;

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  // Just one from PPU otherwise it starves the SPEs
  atomic_ret = _atomic_inc_return (atomic_ea);
  PRINTF("PPU: atomic_ret=%d\n",atomic_ret);
  if (atomic_ret < 100) {
     for (i=0; i<RETURN_SZ; i++) {
        data[atomic_ret*RETURN_SZ + i] = atomic_ret;
     }
  }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  /* Compute what the total should be */
  compute_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   compute_tot+=i;
  }
  PRINTF("COMPUTE_TOT=%d\n",compute_tot);

  /* Get the real total */
  real_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   real_tot+=data[i*RETURN_SZ];
  }
  PRINTF("REAL_TOT=%d\n",real_tot);

  /* check result */
  if (compute_tot != real_tot)
    {
      printf ("%s, failed\n\n", __PRETTY_FUNCTION__);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_inc_return_test */


/*
 * Verify SPU & PPE atomic_sub_and_test operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_sub_and_test
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_sub_and_test_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  int atomic_ret;

  atomic_init = (num_spus + 1) * (LOOP_COUNT);

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
  
  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_sub_and_test_test,atomic_init); 

  printf ("%s, finished initializing %d SPUs\n", __PRETTY_FUNCTION__,num_spus);

  for (i = 0; i < LOOP_COUNT; i++)
    {
      atomic_ret = _atomic_sub_and_test (1, atomic_ea);
      if (atomic_ret == 1) {	// should not happen
        printf ("PPU incorrect output: atomic_ret=%d atomic_read=%d\n", atomic_ret,_atomic_read(atomic_ea));
        printf ("%s, failed\n\n", __PRETTY_FUNCTION__);
        return 1;
      }
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  // atomic_var should now be 0, so this should return 1
  atomic_ret = _atomic_sub_and_test (1, atomic_ea);
  if (atomic_ret != 1) {
     printf ("PPU incorrect output: atomic_ret=%d atomic_read=%d\n", atomic_ret,_atomic_read(atomic_ea));
     printf ("%s, failed\n\n", __PRETTY_FUNCTION__);
     return 1;
  }

  // final value should now be -1
  if (atomic_var != -1)
    {
      printf ("%s, FAILED, atomic_var=%d\n\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_sub_and_test_test */

/*
 * Verify SPU atomic_sub operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_sub_return_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  
  int atomic_ret;
  int compute_tot, real_tot;

  atomic_init = RETURN_COUNT;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
 
  atomic_var = 0xdeadbeef; /* set to 0xdeadbeef so SPEs will wait */              
  ATOMIC_OP_TEST_START_SPUS(atomic_sub_return_test);

   // initialize the data
  for (i = 0; i < (RETURN_COUNT * RETURN_SZ); i++) {
    data[i]=0;
  }

  // send the data address to the SPEs
  for (i = 0; i < num_spus; i++) {
    union {
      unsigned long long ull;
      unsigned int ui[2];
    } data_addr;

    data_addr.ull = (unsigned long long)((uintptr_t)(&(data[0])));
    spe_in_mbox_write (datas[i].spuid, data_addr.ui, 2, SPE_MBOX_ANY_NONBLOCKING);
  }

  /* set value to trigger start of all SPEs */  
  _atomic_set(atomic_ea, atomic_init);        
  /* Wait for change, showing SPEs have started their work */        
  while (_atomic_read(atomic_ea) == atomic_init) ;

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  // Just one from PPU otherwise it starves the SPEs
  atomic_ret = _atomic_sub_return (1, atomic_ea);
  PRINTF("PPU: atomic_ret=%d\n",atomic_ret);
  if (atomic_ret > 0) {
     atomic_ret--; /* subtracting, so 100 needs to access element 99 */
     for (i=0; i<RETURN_SZ; i++) {
        data[atomic_ret*RETURN_SZ + i] = atomic_ret;
     }
  }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  /* Compute what the total should be */
  compute_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   compute_tot+=i;
  }
  PRINTF("COMPUTE_TOT=%d\n",compute_tot);

  /* Get the real total */
  real_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   real_tot+=data[i*RETURN_SZ];
  }
  PRINTF("REAL_TOT=%d\n",real_tot);

  /* check result */
  if (compute_tot != real_tot)
    {
     printf ("%s, FAILED - Total=%d Should be %d\n\n", __PRETTY_FUNCTION__, real_tot, compute_tot);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_sub_return_test */

/*
 * Verify SPU atomic_sub operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_sub_spu_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  atomic_init = num_spus * LOOP_COUNT;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
  
  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_sub_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  ATOMIC_OP_TEST_WAIT_SPUS();

  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);
 
  /* check result */
  if (atomic_var != 0)
    {
      printf ("%s, failed, atomic_var=%d\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_sub_spu_test */

/*
 * Verify SPU & PPE atomic_sub operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_sub
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_sub_cbe_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  atomic_init = (num_spus +1) * LOOP_COUNT;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
  
  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_sub_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  for (i = 0; i < LOOP_COUNT; i++)
    {
      _atomic_sub (1, atomic_ea);
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);
 
  /* check result */
  if (atomic_var != 0)
    {
      printf ("%s, failed, atomic_var=%d\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_sub_cbe_test */

/*
 * Verify SPU & PPE atomic_dec_and_test operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_dec_and_test
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_dec_and_test_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  int atomic_ret;

  atomic_init = (num_spus + 1) * (LOOP_COUNT);

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
  
  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_sub_test,atomic_init); 

  printf ("%s, finished initializing %d SPUs\n", __PRETTY_FUNCTION__,num_spus);

  for (i = 0; i < LOOP_COUNT; i++)
    {
      atomic_ret = _atomic_dec_and_test (atomic_ea);
      if (atomic_ret == 1) {	// should not happen
        printf ("PPU incorrect output: atomic_ret=%d atomic_read=%d\n", atomic_ret,_atomic_read(atomic_ea));
        printf ("%s, failed\n\n", __PRETTY_FUNCTION__);
        return 1;
      }
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  // atomic_var should now be 0, so this should return 1
  atomic_ret = _atomic_dec_and_test (atomic_ea);
  if (atomic_ret != 1) {
     printf ("PPU incorrect output: atomic_ret=%d atomic_read=%d\n", atomic_ret,_atomic_read(atomic_ea));
     printf ("%s, failed\n\n", __PRETTY_FUNCTION__);
     return 1;
  }

  // final value should now be -1
  if (atomic_var != -1)
    {
      printf ("%s, FAILED, atomic_var=%d\n\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_dec_and_test_test */


/*
 * Verify SPU & PPE atomic_dec_return operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_dec_return
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_dec_return_test (int num_spus)
{

#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */


  int atomic_ret;
  int compute_tot, real_tot;

  atomic_init = RETURN_COUNT;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
 
  atomic_var = 0xdeadbeef; /* set to 0xdeadbeef so SPEs will wait */
  ATOMIC_OP_TEST_START_SPUS(atomic_dec_return_test);

   // initialize the data
  for (i = 0; i < (RETURN_COUNT * RETURN_SZ); i++) {
    data[i]=0;
  }

  // send the data address to the SPEs
  for (i = 0; i < num_spus; i++) {
    union {
      unsigned long long ull;
      unsigned int ui[2];
    } data_addr;

    data_addr.ull = (unsigned long long)((uintptr_t)(&(data[0])));
    spe_in_mbox_write (datas[i].spuid, data_addr.ui, 2, SPE_MBOX_ANY_NONBLOCKING);
  }

  /* set value to trigger start of all SPEs */  
  _atomic_set(atomic_ea, atomic_init);        
  /* Wait for change, showing SPEs have started their work */        
  while (_atomic_read(atomic_ea) == atomic_init) ;

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  // Just one from PPU otherwise it starves the SPEs
  atomic_ret = _atomic_dec_return (atomic_ea);
  PRINTF("PPU: atomic_ret=%d\n",atomic_ret);
  if (atomic_ret > 0) {
     atomic_ret--; /* subtracting, so 100 needs to access element 99 */
     for (i=0; i<RETURN_SZ; i++) {
        data[atomic_ret*RETURN_SZ + i] = atomic_ret;
     }
  }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);

  /* Compute what the total should be */
  compute_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   compute_tot+=i;
  }
  PRINTF("COMPUTE_TOT=%d\n",compute_tot);

  /* Get the real total */
  real_tot=0;
  for (i=0;i<RETURN_COUNT;i++) {
   real_tot+=data[i*RETURN_SZ];
  }
  PRINTF("REAL_TOT=%d\n",real_tot);

  /* check result */
  if (compute_tot != real_tot)
    {
      printf ("%s, FAILED, atomic_var=%d\n\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_dec_return_test */


/*
 * Verify SPU & PPE atomic_dec operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_dec
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_dec_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */


  atomic_init = (num_spus +1) * (LOOP_COUNT);

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
  
  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_dec_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  for (i = 0; i < LOOP_COUNT; i++)
    {
      _atomic_dec (atomic_ea);
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);
  
  /* check result */
  if (atomic_var != 0)
    {
      printf ("%s, FAILED, atomic_var=%d\n\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_dec_test */


/*
 * Verify SPU & PPE atomic_dec_if_positive operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_dec_if_positive
 * 3. Wait for SPU threads to exit
 * 3. Verify result.
 */ 
static int do_atomic_dec_if_positive_cbe_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */

  atomic_init = (num_spus ) * (LOOP_COUNT-1);

  printf ("%s, begins - with %d SPUs, atomic_init =%d\n", __PRETTY_FUNCTION__, num_spus, atomic_init);
  
  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_dec_if_positive_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  for (i = 0; i < LOOP_COUNT; i++)
    {
      _atomic_dec_if_positive (atomic_ea);
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);
  
  /* check result */
  if (atomic_var != 0)
    {
      printf ("%s, FAILED, atomic_var=%d\n\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}				/* do_atomic_dec_if_positive_cbe_test */


/*
 * Verify SPU & PPE atomic_set operation
 * The PU steps are:
 *
 * 1. Create SPU threads
 * 2. atomic_set - Each SPU (and PPU) sets it to 0 through LOOP_COUNT - 1
 * 3. Wait for SPU threads to exit
 * 3. Verify result. - Should be LOOP_COUNT - 1
 */ 
static int do_atomic_set_test (int num_spus)
{
#ifdef __powerpc64__
  ATOMIC_OP_TEST_DECL_64();
#else /* ! __powerpc64__ */
  ATOMIC_OP_TEST_DECL();
#endif /* __powerpc64__ */


  atomic_init = 0;

  printf ("%s, begins - with %d SPUs\n", __PRETTY_FUNCTION__, num_spus);
  
  ATOMIC_OP_TEST_START_SPUS_WAIT(atomic_set_test,atomic_init); 

  printf ("%s, finished initializing SPUs\n", __PRETTY_FUNCTION__ );

  for (i = 0; i < LOOP_COUNT; i++)
    {
      _atomic_set (atomic_ea, i);
    }

  ATOMIC_OP_TEST_WAIT_SPUS();
  printf ("%s, Finished with SPUs, checking results\n", __PRETTY_FUNCTION__);
 
  /* check result */
  if (atomic_var != (LOOP_COUNT - 1))
    {
      printf ("%s, FAILED, atomic_var=%d\n\n", __PRETTY_FUNCTION__, atomic_var);
      return 1;
    }
  else
    {
      printf ("%s, PASSED\n\n", __PRETTY_FUNCTION__);
      return 0;
    }
}					/* do_atomic_set_test */



int main(int argc, char **argv)
{
  int fails = 0;
  int num_spes, max_spes;

  printf ("\n%s: STARTING\n\n", argv[0]);
  PRINTF ("DEBUGGING mode\n");

  // Test can run on 2 to 16 SPEs, default is the number of usable SPEs 
  num_spes = spe_cpu_info_get(SPE_COUNT_USABLE_SPES,-1);
  
  if (argc > 1) {
    max_spes = atoi(argv[1]);
    if (( max_spes < 2 ) || ( max_spes > MAX_NUM_SPUS*MAX_NUM_CBES ) || ( max_spes > num_spes )) {
      printf("FAILED: Illegal max number of SPEs (%d).\n", max_spes);
      exit(1);
    }
    num_spes = max_spes;
  }
  printf ("%s, begins, number of SPUs = %d\n", __PRETTY_FUNCTION__, num_spes);

  fails += do_atomic_add_spu_test (num_spes);
  fails += do_atomic_add_cbe_test (num_spes);
  fails += do_atomic_add_return_test (num_spes);

  fails += do_atomic_dec_test (num_spes);
  fails += do_atomic_dec_return_test (num_spes);
  fails += do_atomic_dec_and_test_test (num_spes);
  fails += do_atomic_dec_if_positive_cbe_test (num_spes);

  fails += do_atomic_inc_test (num_spes);
  fails += do_atomic_inc_return_test (num_spes);

  fails += do_atomic_set_test (num_spes);

  fails += do_atomic_sub_spu_test (num_spes);
  fails += do_atomic_sub_cbe_test (num_spes);
  fails += do_atomic_sub_return_test (num_spes);
  fails += do_atomic_sub_and_test_test (num_spes);

  if (fails) {
    printf("==> %s: Number of FAILED tests: %d\n\n", argv[0], fails);
  }
  else {
    printf ("%s: PASSED\n\n", argv[0]);
  }
  return fails;
}


