/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>
#include <atomic_op_example.h>
#include <libsync.h>
#include <spu_mfcio.h>

unsigned int data[RETURN_SZ] __attribute__ ((aligned(128)));

int main (unsigned long long spuid __attribute__ ((unused)), 
          unsigned long long argp)
{ 
  int i;
  int atomic_ret;
  unsigned int tag;
  union {
    unsigned long long ull;
    unsigned int ui[2];
  } data_addr;


  PRINTF ("SPU main begins\n");

  atomic_ea_t ea = argp;

  // reserve a tag
  tag = mfc_tag_reserve() & 31;

  // get data address
  data_addr.ui[0] = spu_read_in_mbox();
  data_addr.ui[1] = spu_read_in_mbox();

  // wait for ready signal from PPE
  while (atomic_read(ea) == 0xdeadbeef) ;

  while ((atomic_ret = atomic_dec_return (ea)) > 0 ) {
    PRINTF("SPU: atomic_ret=%d\n",atomic_ret);
    atomic_ret--; /* subtracting, so 100 needs to access element 99 */

    mfc_get (&data, data_addr.ull + atomic_ret*RETURN_SZ*sizeof(unsigned int), RETURN_SZ*sizeof(unsigned int), tag, 0, 0);
    mfc_write_tag_mask (1 << tag);
    mfc_read_tag_status_all ();

    for (i=0; i<RETURN_SZ; i++) {
      data[i] = atomic_ret;
    }

    mfc_put (&data, data_addr.ull + atomic_ret*RETURN_SZ*sizeof(unsigned int), RETURN_SZ*sizeof(unsigned int), tag, 0, 0);
    mfc_write_tag_mask (1 << tag);
    mfc_read_tag_status_all ();
  }

  PRINTF ("SPU main ends\n");

  return 0; 

}
