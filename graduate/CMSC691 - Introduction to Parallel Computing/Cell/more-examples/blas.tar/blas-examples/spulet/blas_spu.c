/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#define PRECISION_S

#include <stdio.h>
#include <stdlib.h>

#include <blas_s.h>

#define BUF_SIZE 32
#define THRESH_DIFF ((float)0.0001)

/*************** VERIFY SDOT ROUTINE ***************/
int verify_sdot( float *sx, float *sy, int size, float sum )
{
    int i ;
    float expected_sum = 0.0, diff = 0.0 ;

    for( i = 0 ; i < size ; i++ )
        expected_sum  += sx[i] * sy[i] ;

    if( sum < 0 )
        sum = sum * (float)(-1) ;
    if( expected_sum < 0 )
        expected_sum = expected_sum * (float)(-1) ;

    diff = expected_sum - sum ;

    if( diff < 0 )
        diff = diff * (float)(-1) ;

        if ( diff > THRESH_DIFF * (expected_sum) )
        {
            printf( "Expected SDOT SUM = %f\n", expected_sum ) ;
            printf( "Computed SDOT SUM = %f\n", sum ) ;

            return -1 ;
        }
    return 0 ;
}

/********************** MAIN ROUTINE **********************/
int main()
{
    int   size,	 k ;
    float buf_x[BUF_SIZE] __attribute__ (( aligned (16) )) ;
    float buf_y[BUF_SIZE] __attribute__ (( aligned (16) )) ;
    float sum = 0.0 ;
    size = BUF_SIZE;
            
    for(k=0;k<size;k++) 
    {
        buf_x[k] = k * 1.0;
        buf_y[k] = buf_x[k] ;
    }

    sum = sdot_spu( buf_x, buf_y, size ) ;

    printf("computation done, verifying result...\n");
    
    if ( verify_sdot( buf_x, buf_y, size, sum ) < 0 )
    {
        printf( "Error in verification. -> SDOT \n \n" ) ;
        exit(1) ;
    }
    else
        printf( "success SDOT \n" ) ;


    return 0 ;
}
