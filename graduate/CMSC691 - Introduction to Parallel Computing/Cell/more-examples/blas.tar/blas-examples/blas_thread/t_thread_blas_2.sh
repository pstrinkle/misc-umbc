# --------------------------------------------------------------  
# (C)Copyright 2006,2007,                                         
# International Business Machines Corporation                     
# All Rights Reserved.                                            
#                                                                 
# Redistribution and use in source and binary forms, with or      
# without modification, are permitted provided that the           
# following conditions are met:                                   
#                                                                 
# - Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer. 
#                                                                 
# - Redistributions in binary form must reproduce the above       
#   copyright notice, this list of conditions and the following   
#   disclaimer in the documentation and/or other materials        
#   provided with the distribution.                               
#                                                                 
# - Neither the name of IBM Corporation nor the names of its      
#   contributors may be used to endorse or promote products       
#   derived from this software without specific prior written     
#   permission.                                                   
#                                                                 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
# --------------------------------------------------------------  
# PROLOG END TAG zYx                                              

#!/bin/bash

# This script file verifies the correct working of BLAS library when
# more than one test program instances (executables) are running together.

# Run 2 instances (executables) of test programs together by running this
# script file on different shells with different node numbers passed as 
# command line arguments. This will ensure that there is no contention
# between these two program executables for SPEs.
#
# Running the script to execute test programs on different nodes:
# (on first shell) $<this_script> 0
# (on second shell) $<this_script> 1 

# The test program executables can also be run together on the same numa
# node by adjusting the number of SPEs used per test program.

PROGRAM=./t_thread_blas

if [ $# -eq 0 ]; then
echo "$0 : NUMA node number not supplied. Not using numa binding."
NODE=-1
else
echo "$0 : Using NUMA binding to node $1"
NODE=$1
fi

# Run test program launching 3 threads, with each thread using 2 SPEs 
echo "Running env BLAS_NUMSPES=2 BLAS_NUMA_NODE=$NODE $PROGRAM -t 3" 
env BLAS_NUMSPES=2 BLAS_NUMA_NODE=$NODE $PROGRAM -t 3 

if [ $? -eq 0 ]; then
echo "2.1 Passed"
else
echo "2.1 Failed"
fi
