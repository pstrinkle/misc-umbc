/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdio.h>
#include <stdlib.h>

#include <sched.h>
#include <errno.h>
#include <pthread.h>
#include <numa.h>

#include "spe_info_user.h"

__thread  blas_spes_info si_user;

static inline void set_numa_node(int nodenum, 
                                 nodemask_t* cur_run_mask, nodemask_t* cur_mem_mask)
{
    int nodes;
    nodemask_t mask0;

    if ( numa_available() >= 0 )
    {
        nodes = numa_max_node() + 1 ;
        if ( nodes > 1 )
        {
            *cur_run_mask = numa_get_run_node_mask();
            *cur_mem_mask = numa_get_membind();
            
            nodemask_zero( &mask0 ) ;
            nodemask_set( &mask0, nodenum ) ;
            numa_bind( &mask0 ) ;
	    }
	}
}

static inline void set_numa_nodemask(nodemask_t* run_mask, nodemask_t* mem_mask)
{
    int nodes;
    
    if ( numa_available() >= 0 )
    {
        nodes = numa_max_node() + 1 ;
  	    if ( nodes > 1 )
	    {
            numa_run_on_node_mask( run_mask );
            numa_set_membind( mem_mask );
	    }
	}
}


int init_spes_user()
{
    int i ;
    char *numastr;
    int numa_node = BLAS_NUMA_NODE;
    nodemask_t cur_run_mask, cur_mem_mask;
    void *blas_thread( void * ) ;
    char *ns = getenv( "BLAS_NUMSPES" ) ;
    si_user.num_spes = (ns) ? atoi(ns) : MAX_SPES ;

    /* numa binding */
    numastr = getenv("NUMA_NODE_USER");
    if ( numastr )
        numa_node = atoi(numastr);
    
    if ( numa_node >= 0 ) 
    {
        /* Use numa binding */
        DBG ( printf("init_spes_user(): Requesting spe thread numa binding "
                     "on node %d\n", numa_node) );
        set_numa_node(numa_node, &cur_run_mask, &cur_mem_mask);
    }

    for ( i = 0 ; i < si_user.num_spes ; i++ )
    {
        si_user.spe[i].spe_ctxt = spe_context_create( 0, NULL ) ;
        si_user.spe[i].processed = si_user.spe[i].scheduled = 0 ;
        pthread_mutex_init( &si_user.spe[i].m, NULL )  ;
        pthread_cond_init( &si_user.spe[i].c, NULL )  ;
        DBG( printf( "init: Creating thread\n" ) ) ;
        pthread_create( &si_user.spe[i].pts, NULL, blas_thread, &si_user.spe[i] ) ;
        DBG( printf( "init: Created thread\n" ) ) ;
    }

    /* Restore old numa binding */
    if ( numa_node >= 0 ) 
    {
        DBG ( printf("init_spes_user(): Restoring old spe thread numa binding\n") );
        set_numa_nodemask(&cur_run_mask, &cur_mem_mask);
    }

    return 0 ;
}

int cleanup_spes_user()
{
    int i ;

    for ( i = 0 ; i < si_user.num_spes ; i++ )
    {
        DBG( printf( "cleanup: Before Schedule 0\n" ) ) ;
        spe_schedule_user( &si_user.spe[i], NULL, 0, NULL, NULL ) ;
        DBG( printf( "cleanup: After Schedule 0, before join\n" ) ) ;
        pthread_join( si_user.spe[i].pts, NULL ) ;
        DBG( printf( "cleanup: After join\n" ) ) ;
        pthread_mutex_destroy( &si_user.spe[i].m )  ;
        pthread_cond_destroy( &si_user.spe[i].c )  ;
    }

    DBG( printf( "cleanup: returning\n" ) ) ;
    return 0 ;
}

spes_info_handle_t* get_spes_info_user()
{
    return (spes_info_handle_t*) (&si_user) ;
}

spe_info_handle_t* get_spe_info_user(spes_info_handle_t* spes_ptr, int index)
{
    blas_spes_info *spes = (blas_spes_info*) spes_ptr;
    return (spe_info_handle_t*) ( &spes->spe[index] ); 
}

int get_num_spes_user(spes_info_handle_t* spes_ptr)
{
    blas_spes_info *spes = (blas_spes_info*) spes_ptr;
    return spes->num_spes;
}

void *blas_thread( void *spe_ptr )
{
    blas_spe_info *spe = (blas_spe_info *) spe_ptr ;
    while(1)
    {
        DBG( printf( "pthread: Waiting for mutex\n" ) ) ;
        pthread_mutex_lock( &spe->m ) ;
        DBG( printf( "pthread: Got mutex\n" ) ) ;

        DBG( printf( "pthread: processed=%d, scheduled=%d\n", 
                     spe->processed, spe->scheduled ) ) ;
        if ( spe->processed == spe->scheduled )
        {
            DBG( printf( "pthread: Getting into cond_wait\n" ) ) ;
            pthread_cond_wait( &spe->c, &spe->m ) ;
            DBG( printf( "pthread: Got signal\n" ) ) ;
        }

        /* Wait for indication to start */
        if ( spe->spe_ph == NULL )
        {
            DBG( printf( "pthread: Got indication for termination\n" ) ) ;
            spe->processed++ ;
            pthread_mutex_unlock( &spe->m ) ;
            DBG( printf( "pthread: Released mutex\n" ) ) ;
            break ;
        }

        DBG( printf( "pthread: Loading program\n" ) ) ;
        spe_program_load( spe->spe_ctxt, spe->spe_ph ) ;
        spe_context_run( spe->spe_ctxt, &spe->entry, spe->runflags,
                         spe->argp, spe->envp, NULL ) ;
        DBG( printf( "pthread: Program terminated\n" ) ) ;

        spe->processed++ ;

        pthread_mutex_unlock( &spe->m ) ;
        DBG( printf( "pthread: Released mutex\n" ) ) ;
    }

    DBG( printf( "pthread: Exiting\n" ) ) ;
    return NULL ;
}

void spe_wait_job_user( spe_info_handle_t* spe_ptr )
{ 
    blas_spe_info *spe = (blas_spe_info*) spe_ptr;
    int done = 0 ;

    DBG( printf( "waitjob: Waiting\n" ) ) ;
    while ( ! done )
    {
        pthread_mutex_lock( &spe->m ) ;

        if ( spe->processed < spe->scheduled )
        {
            /* pthread_cond_signal( &spe->c ) ; */
        }
        else
        {
            done = 1 ;
        }

        pthread_mutex_unlock( &spe->m ) ;
        /* Relinquish cpu ? */
        /*  if ( ! done )
            usleep(0) ;*/
    }
    DBG( printf( "waitjob: Done wait\n" ) ) ;
}

void spe_schedule_user( spe_info_handle_t* spe_ptr, spe_program_handle_t *spe_ph,
                        unsigned int runflags, void *argp, void *envp )
{
    blas_spe_info *spe = (blas_spe_info*) spe_ptr;

    DBG( printf( "schedule: Locking mutex\n" ) ) ;
    pthread_mutex_lock( &spe->m ) ;
    DBG( printf( "schedule: Got mutex\n" ) ) ;

    DBG( printf( "schedule: processed=%d, scheduled=%d\n", 
                 spe->processed, spe->scheduled ) ) ;
    while ( spe->processed < spe->scheduled )
    {
        /* pthread_cond_signal( &spe->c ) ; */
        pthread_mutex_unlock( &spe->m ) ;
        /* Relinquish cpu ? */
        DBG( printf( "schedule: proc>sched, relinquishing mutex and locking again\n" ) ) ;
        pthread_mutex_lock( &spe->m ) ;
        DBG( printf( "schedule: proc>sched, Got mutex\n" ) ) ;
    }

    DBG( printf( "schedule: processed=%d, scheduled=%d\n", 
                 spe->processed, spe->scheduled ) ) ;
    DBG( printf( "schedule: Setting parameters\n" ) ) ;
    spe->entry = SPE_DEFAULT_ENTRY ;
    spe->spe_ph = spe_ph ;
    spe->runflags = runflags ;
    spe->argp = argp ;
    spe->envp = envp ;

    spe->scheduled++ ;

    DBG( printf( "schedule: Signalling thread\n" ) ) ;
    /* Tell thread to start */
    pthread_cond_signal( &spe->c ) ;
    pthread_mutex_unlock( &spe->m ) ;
    DBG( printf( "schedule: Released mutex\n" ) ) ;
}
