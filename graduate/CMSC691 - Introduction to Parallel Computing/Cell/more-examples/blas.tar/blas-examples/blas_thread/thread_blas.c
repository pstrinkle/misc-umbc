/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/* 
   thread_blas.c : Contains main, launches one or more threads where
   each thread calls multiple blas routines. This is used to test
   the thread-safety of BLAS library. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <libspe2.h>

#include <blas_callback.h>
#include "spe_info_user.h"
#include "memory_user.h"

/* Test routines */
int test_syrk(int tid);
int test_gemm(int tid);
int test_axpy(int tid);

/* Number of test routines */
#define NROUTINE 3
#define MAX_THREAD 16

typedef int (*TROUTINE) (int);

typedef struct RoutineData_
{
    TROUTINE ptr;
    char name[100];
} RoutineData;

RoutineData test_routine[NROUTINE] = { 
    {test_gemm, "GEMM"},
    {test_syrk, "SYRK"}, 
    {test_axpy, "AXPY"}
};

typedef struct Tdata_
{
    int id;
    int mem_register;
    int spe_register;
    int ret;
} Tdata;

void* thread_func(void* arg)
{
 
    Tdata tdata = *( (Tdata*) arg );
    int i, ret = 0;
    
    DBG (printf( "func: PID %d, thread id %d.\n", getpid(), tdata.id) ); 
    
    if (tdata.mem_register)
    {
        blas_register_mem(malloc_user, free_user);
    }
    
    if (tdata.spe_register) 
    {
        blas_register_spe(get_spes_info_user(), spe_schedule_user, spe_wait_job_user,
                          get_num_spes_user, get_spe_info_user);
        
        init_spes_user();
    }
    
    
    for (i = 0; i < NROUTINE; i++)
        ret |= test_routine[i].ptr(tdata.id);
    
    if (tdata.spe_register)
    {
        cleanup_spes_user();
    }
    
    /* Store the return value from the test routines */
    ( (Tdata*) arg )->ret = ret;

    return NULL;   
}

static void print_usage(char* name)
{
    printf("USAGE: %s [options]\n", name);
    printf("       Valid Options include:\n");
    printf("         -t #   : launch specified number of threads. Default is 1.\n");
    printf("         -m     : use custom memory allocation routines. \n");
    printf("         -s     : use custom SPE thread launching routines.\n");
    exit(1);
}


int main(int argc, char* argv[]) 
{
    int nthread = 1, mem_register = 0, spe_register = 0;
    pthread_t tid[MAX_THREAD];
    Tdata tdata[MAX_THREAD];
    int i, phys_spes;
    char* numspe_str = NULL;
    int ret = 0, spes_per_thread = 0;

    for (i=1; i<argc; i++) 
    {
        if (*argv[i] == '-') 
        {
            switch (*(argv[i]+1)) 
            {
                case 't':
                    i++;
                    if (i < argc) 
                    {
                        nthread = atoi(argv[i]);
                        printf("input: Number of threads = %d\n", nthread);
                    } else {
                        printf("ERROR: Number of threads is not specified.\n");
                        print_usage(argv[0]);
                    }
                    break;
                    
                case 'm':		/* Memory callback registration */
                    mem_register = 1;
                    printf("input: Registering custom Memory Callbacks\n");
                    break;
                    
                case 's':		/* SPE callback registration */
                    spe_register = 1;
                    printf("input: Registering custom SPE Callbacks\n");
                    break;
                    
                case 'h':
                default:
                    print_usage(argv[0]);
                    break;
            }
        } 
        else 
        {
            print_usage(argv[0]);
        }
    }
    
    /* Determine the number of physical SPEs present in the system */
    phys_spes = spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES, -1);
    printf("main: Number of SPEs available in the system = %d\n", phys_spes);
    
    numspe_str = getenv("BLAS_NUMSPES");
    spes_per_thread = (numspe_str) ? atoi(numspe_str) : MAX_SPES; 
    printf("main: Number of SPEs used per thread = %d\n", spes_per_thread);
    
    if ( (spes_per_thread * nthread) > phys_spes )
    {
        fprintf(stderr, "main: Total number of required SPEs (%d) "
                "exceeds available SPEs (%d). Quitting.\n", 
                spes_per_thread*nthread, phys_spes);
        fprintf(stderr,
                "main: Set SPEs used per thread using env variable BLAS_NUMSPES\n"); 
        
        exit(1);
    }
        
    /* Fill thread specific Data */
    for (i = 0; i < MAX_THREAD; i++) 
    {
        tdata[i].id = i;
        tdata[i].mem_register = mem_register;
        tdata[i].spe_register = spe_register;
    }

    for (i = 0; i < nthread; i++) 
    {
        pthread_create(&tid[i], NULL, thread_func, &tdata[i]);
    }
    
    for (i = 0; i < nthread; i++) 
    {
        pthread_join(tid[i], NULL);
        ret |= tdata[i].ret;
    }

    if ( ret != 0 )
        fprintf(stderr, "main():FAILED\n");
    else
        printf("main():PASSED\n");

    return ret;
}
