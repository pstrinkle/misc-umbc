# --------------------------------------------------------------  
# (C)Copyright 2006,2007,                                         
# International Business Machines Corporation                     
# All Rights Reserved.                                            
#                                                                 
# Redistribution and use in source and binary forms, with or      
# without modification, are permitted provided that the           
# following conditions are met:                                   
#                                                                 
# - Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer. 
#                                                                 
# - Redistributions in binary form must reproduce the above       
#   copyright notice, this list of conditions and the following   
#   disclaimer in the documentation and/or other materials        
#   provided with the distribution.                               
#                                                                 
# - Neither the name of IBM Corporation nor the names of its      
#   contributors may be used to endorse or promote products       
#   derived from this software without specific prior written     
#   permission.                                                   
#                                                                 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
# --------------------------------------------------------------  
# PROLOG END TAG zYx                                              

#!/bin/bash

PROGRAM=./t_thread_blas

# Without any NUMA binding, 1 SPE / thread 
env BLAS_NUMSPES=1 $PROGRAM -t 16
if [ $? -eq 0 ]; then
echo "1.1 Passed"
else
echo "1.1 Failed"
fi

# Without any NUMA binding, 1 SPE / thread 
env BLAS_NUMSPES=1 $PROGRAM -t 8
if [ $? -eq 0 ]; then
echo "1.2 Passed"
else
echo "1.2 Failed"
fi

# Without any NUMA binding 2 SPEs/thread
env BLAS_NUMSPES=2 $PROGRAM -t 4
if [ $? -eq 0 ]; then
echo "1.3 Passed"
else
echo "1.3 Failed"
fi

# Using huge pages for input matrix/vector allocation

env USE_HUGE_PAGES=1 BLAS_NUMSPES=2 $PROGRAM -t 8 
if [ $? -eq 0 ]; then
echo "1.4 Passed"
else
echo "1.4 Failed"
fi

# With NUMA binding to node 0

env BLAS_NUMSPES=2 BLAS_NUMA_NODE=0 $PROGRAM -t 4
if [ $? -eq 0 ]; then
echo "1.5 Passed"
else
echo "1.5 Failed"
fi

# Using swap space of 16 MB for blas3 routines

env BLAS_SWAP_SIZE=16384 BLAS_NUMSPES=3 $PROGRAM -t 2
if [ $? -eq 0 ]; then
echo "1.6 Passed"
else
echo "1.6 Failed"
fi

# Swap space with huge pages and numa binding

env BLAS_NUMSPES=2 USE_HUGE_PAGES=1 BLAS_NUMA_NODE=1 BLAS_SWAP_NUMA_NODE=1 BLAS_SWAP_SIZE=16384 $PROGRAM -t 3
if [ $? -eq 0 ]; then
echo "1.7 Passed"
else
echo "1.7 Failed"
fi
