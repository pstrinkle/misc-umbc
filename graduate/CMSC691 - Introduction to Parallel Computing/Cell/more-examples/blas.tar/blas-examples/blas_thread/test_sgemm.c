/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/* 
   test_sgemm.c : Contains routines to test sgemm routine
*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>

#include <blas.h>
#include "input.h"

#define THRESH ((DTYPE) 0.0001)

static int verify_result_gemm( input_params *inp, DTYPE *data_Corig)
{
    int i, j, k;
    DTYPE diff = 0;
    DTYPE *data_c = inp->C, *data_a = inp->A, *data_b = inp->B;
    DTYPE alpha = inp->alpha, beta = inp->beta;
    int lda = inp->lda, ldb = inp->ldb, ldc = inp->ldc;
    int M = inp->m, N = inp->n, K = inp->k; 
    int transa = inp->transa, transb = inp->transb;
    DTYPE result ;
    
    if (!transa && !transb)
    {   
        DBG( printf("verify_result_gemm:Computing expected result for C = alpha.A.B + C \n") );
        /* compute the expected result */
        for( j=0; j<N; j++ )
        {
            for( i=0; i<M; i++ )
            {
                data_Corig[ldc * j + i] *= beta ;
                for (k = 0; k < K; k++)
                {
                    data_Corig[ldc * j + i] += alpha * data_a[lda * k + i] * data_b[ldb * j + k];
                }
            }
        }
    } 
    else if (transa && !transb) 
    {   
        DBG( printf("verify_result_gemm:Computing expected result for C = alpha.Trans(A).B + beta.C \n"));
        /* compute the expected result */
        for( j=0; j<N; j++ )
        {
            for( i=0; i<M; i++ )
            {
                data_Corig[ldc * j + i] *= beta ;
                for (k = 0; k < K; k++)
                {
                    data_Corig[ldc * j + i] += alpha * data_a[lda * i + k] * data_b[ldb * j + k];
                }
            }
        }   
    }
    else if (!transa && transb)
    {
        DBG(  printf("verify_result_gemm:Computing expected result for C = alpha.A.Trans(B) + beta.C \n"));
        /* compute the expected result */
        for( j=0; j<N; j++ )
        {
            for( i=0; i<M; i++ )
            {
                data_Corig[ldc * j + i] *= beta ;
                for (k = 0; k < K; k++)
                {
                    data_Corig[ldc * j + i] += alpha * data_a[lda * k + i] * data_b[ldb * k + j];
                }
            }
        }   
    } else   // both transa and transb true 
    {
        DBG(  printf("verify_result_gemm:Computing expected result for "
                     "C = alpha.Trans(A).Trans(B) + beta.C \n") );
        /* compute the expected result */
        for( j=0; j<N; j++ )
        {
            for( i=0; i<M; i++ )
            {
                data_Corig[ldc * j + i] *= beta ;
                for (k = 0; k < K; k++)
                {
                    data_Corig[ldc * j + i] += alpha * data_a[lda * i + k] * data_b[ldb * k + j];
                }
            }
        }   
    }
    
    DBG ( printf("verify_result_gemm:Verifying results...\n"));
    /* verify the computed result from SPU */
    for( j=0; j<N; j++ )
    {
        for( i = 0; i < M; i++)
        {
            result =   data_Corig[ldc * j + i] ;
            diff = data_Corig[ldc * j + i] - data_c[ldc * j + i];
            
            if (diff < (DTYPE) 0.0)
                diff = -diff;
            
            result = (result > 0) ? result : ( (DTYPE)(-1) * result ) ;
            
            if ( diff > THRESH * result )  
            {
                printf( "Corig(%d,%d) =%f\n",i, j, data_Corig[ldc * j + i] ) ;
                printf( "C(%d,%d)     =%f\n",i, j, data_c[ldc * j + i] ) ;
                return -1 ;
            }
        }
        
    }
    return 0 ;
}

int test_gemm(int tid) 
{
    DTYPE  *data_corig ;
    input_params inp;
    char *transa = "N", *transb = "N";
    int result = 0;

#ifdef DO_PROFILE
    struct tms tbuf ;
    clock_t start_tick, end_tick;
    double elapsed, flops;
#endif

    int i, iters;
    char* mem_file = "/huge/blas_app.bin";

    sprintf(inp.mem_file, "%s.%d", mem_file, tid);
    DBG (printf("test_sgemm:File name for hugepages = %s\n", inp.mem_file) );
    
    /* Fetching the input paramaters */
    get_params (&inp) ;

    if (inp.transa)
	    transa = "T";

    if (inp.transb)
	    transb = "T";
    
    inp.useHugePages = useHuge();
    iters = getIter();

    for ( i = 0 ; i < iters ; i++ )
    {
        init_data(&inp, &data_corig); 

#ifdef DO_PROFILE
        start_tick = times(&tbuf);
#endif
        
        sgemm_( transa, transb, &inp.m, &inp.n, &inp.k, &inp.alpha, 
                inp.A, &inp.lda, inp.B, &inp.ldb, &inp.beta, inp.C, &inp.ldc ) ;
        
#ifdef DO_PROFILE
        end_tick = times( &tbuf ) ;
        
        elapsed = (double) (end_tick - start_tick) / (double) sysconf(_SC_CLK_TCK) ;
        flops = ((double)(inp.m*inp.n) * (double)(2*inp.k) * (double)iters)
            / (1000000000.0 * elapsed);
        
        printf("Performance Statistics:\n");
        printf("  execution time     = %.2f seconds\n", elapsed);
        printf("  computation rate   = %.2f GFlops/sec\n", flops);
        printf("  %% Peak Computation Rate  = %.2f%% \n", flops*100.0/204.8);
#endif        
        
        DBG (printf("test_gemm: Computation done, verifying result\n"));
        
        /* Verification of result for each Matrix */
        
        if ( (result = verify_result_gemm ( &inp, data_corig)) < 0 ) 
        {
            fprintf(stderr, "test_gemm: FAILED: Verification failed\n") ;
        } 
        else 
        {
#ifdef PRINT_PASS
            printf("test_gemm: PASSED\n") ;
#endif
        }
        
        cleanup_data(&inp, data_corig) ; 
    }

    
    return result;
}





