/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __SPE_INFO_USER_H__
#define __SPE_INFO_USER_H__

#include "blas_callback.h"

#define MAX_SPES 8

typedef struct {
    spe_context_ptr_t spe_ctxt ;
    pthread_t pts ;
    pthread_mutex_t m ;
    pthread_cond_t c ;
    spe_program_handle_t *spe_ph ;
    unsigned int entry ;
    unsigned int runflags ;
    void *argp ;
    void *envp ;
    spe_stop_info_t *stopinfo ;
    unsigned int scheduled ;
    unsigned int processed ;
} blas_spe_info ;
                                                                                
typedef struct  {
    int num_spes ;
    blas_spe_info spe[16] ;
} blas_spes_info ;


int init_spes_user() ;
int cleanup_spes_user() ;

void spe_schedule_user( spe_info_handle_t *spe_ptr, spe_program_handle_t *spe_ph,
                        unsigned int runflags, void *argp, void *envp ) ;
void spe_wait_job_user( spe_info_handle_t* spe_ptr ) ;
int get_num_spes_user(spes_info_handle_t* spes_ptr);
spes_info_handle_t* get_spes_info_user() ;
spe_info_handle_t* get_spe_info_user(spes_info_handle_t* spes_ptr, int index);

/* Macros used for configuring memory allocation strategy */
#define BLAS_NUMA_NODE (-1)

#ifdef DEBUG
#define DBG(stmt) stmt
#else
#define DBG(stmt) 
#endif 

#endif
