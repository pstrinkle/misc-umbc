/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/* 
   input.c : Contains some common utils functions used in testing of 
   blas routines 
*/

#include <stdio.h>
#include <stdlib.h>
#include <malloc_align.h>
#include <free_align.h>
#include <unistd.h>
#include <numa.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>

#include "input.h"


/******* PARAMETER FETCH ROUTINE FOR SGEMM and SSYRK ROUTINES  ******/
void get_params( input_params  *inp )
{

    /* Some random input values */
    inp->transa = 0 ;
    inp->transb = 0 ;
    inp->m = 300;
    inp->n = 200;
    inp->k = 350;
    inp->alpha = 2.0;
    inp->lda = 400;
    inp->ldb = 420;
    inp->beta = 3.0;
    inp->ldc = 403;
    
    inp->off_a = 13;
    inp->off_b = 4;
    inp->off_c = 1;
    
}

/* Use Hugepages for memory allocation ? */
int useHuge()
{
    int isHuge = 0;
    char* hugeStr = getenv("USE_HUGE_PAGES");
    isHuge = (hugeStr != NULL);

#ifdef DEBUG
    if (isHuge) 
        DBG (printf("useHuge(): Huge Pages Requested\n") );
#endif
                                                                                                           
    return isHuge;
}

/* Get user specified number of iterations */
int getIter()
{
    int niter = 1;
    char* iterStr = getenv("NITER");

    if (iterStr != NULL)
    {
        niter = atoi(iterStr);
        
        printf("getIter: iterations = %d\n", niter);
    }

    return niter;
}


/********************* BEGIN OF INIT FUNCTION ******************************/

void init_data(input_params *inp, DTYPE **data_corig) 
{
    int i, j;
    int sizeA, sizeB, sizeC;
    DTYPE *data_A, *data_B, *data_C, *orig = NULL;
    int off_A, off_B, off_C ;
    int useHugePages = inp->useHugePages;
    int hugeSize = 0;
    int fmem = -1;
    char* mem_file = inp->mem_file;
 
    off_A = inp->off_a ;
    off_B = inp->off_b ;
    off_C = inp->off_c ;

#ifdef USE_NUMA
    if ( numa_available() >= 0 )
    {
        nodemask_t mask0;
        int nodes = numa_max_node() + 1 ;
        if ( nodes > 1 )
        {
            nodemask_zero( &mask0 ) ;
            nodemask_set( &mask0, 0 ) ;
            numa_set_membind( &mask0 ) ;
            numa_bind( &mask0 ) ;
        }
    }
#endif

    /* Calculate the number of elements in input array required for each matrix */
    if (inp->transa)
        sizeA = inp->lda * inp->m;
    else
        sizeA = inp->lda * inp->k;

    if (inp->transb)
        sizeB = inp->ldb * inp->k;
    else
        sizeB = inp->ldb * inp->n;

    sizeC = inp->ldc * inp->n;

    if ( useHugePages )
    {
        if ( ( fmem = open( mem_file,  O_CREAT | O_RDWR, 0755 ) ) == -1 )
        {
            printf( "Unable to open Huge Pages file\n") ;
            
            /* Fallback to normal pages */
            useHugePages = 0 ;
        }
        else
        {
            remove(mem_file);

            hugeSize = ( (sizeA+sizeB+sizeC + (128*3) ) * sizeof(DTYPE) + HUGE_PAGE_SIZE -1) 
                & ~(HUGE_PAGE_SIZE-1);
            
            data_A = mmap(0, hugeSize, PROT_READ | PROT_WRITE, MAP_PRIVATE,
                          fmem, 0);

            if (data_A == MAP_FAILED) 
            {
                close(fmem);
                useHugePages = 0;
            } 
            else 
            {
                data_B = (DTYPE*) ( (char*) data_A + sizeA * sizeof(DTYPE) +128 );
                data_C = (DTYPE*) ( (char*) data_A + (sizeA + sizeB) * sizeof(DTYPE) + (2*128) );
                
                memset(data_A, 0, hugeSize);
                
                DBG (printf("Using HugePages, hugeSize = %d MB\n", hugeSize/(1024*1024)));
            }
        }
    }


    if (!useHugePages) 
    {
        DBG (printf("Using heap for memory allocation of input matrices.\n" ));
        
        if (sizeA < 0 )
            data_A = (DTYPE *)_malloc_align( -sizeA * sizeof(DTYPE) + 128, 7);
        else
            data_A = (DTYPE *)_malloc_align( sizeA * sizeof(DTYPE) + 128, 7);
        
        
        if (sizeB < 0 )
            data_B = (DTYPE *)_malloc_align( -sizeB * sizeof(DTYPE) + 128, 7);
        else
            data_B = (DTYPE *)_malloc_align( sizeB * sizeof(DTYPE) + 128, 7);
        
        
        
        if (sizeC < 0 )
            data_C = (DTYPE *)_malloc_align( -sizeC * sizeof(DTYPE) + 128, 7);
        else
            data_C = (DTYPE *)_malloc_align( sizeC * sizeof(DTYPE) + 128, 7);
        
        
        
        if (!data_A || !data_B || !data_C) 
        {
            fprintf(stderr, "Failed to allocate buffers for input matrices A, B and C\n");
            exit(1);
        }
		
    }

    /* 
       reserving 128 bytes extra so that the upto 128 bytes can be added 
       as offset for mis-alignment
    */

    DBG ( printf("The OFF_A = %d\t OFF_B = %d \t OFF_C = %d \n",off_A, off_B,off_C) ) ;
    data_A = data_A  + (off_A )  ;
    data_B = data_B  + (off_B )  ;
    data_C = data_C  + (off_C )  ;

    /* Buffer for matrix C, used for verification */
    if (sizeC < 0 )
        orig = (DTYPE*) _malloc_align(- sizeC * sizeof(DTYPE), 7);
    else
        orig = (DTYPE*) _malloc_align( sizeC * sizeof(DTYPE), 7);
    

    if ( !orig )
    {
        fprintf(stderr, "Failed to allocate buffer for matrix C for expected result comp\n");
        cleanup_data(inp, NULL);
        exit(1);
    }
   
    /* Filling up values*/
    // matrix A
    for (j = 0; j < inp->k; j++) 
    {
        for (i = 0; i < inp->m; i++)  
        {
            data_A[j*inp->lda + i] = (DTYPE) (0.1f * i);
        }
    }
    
    // matrix B
   
    for (j=0;j<inp->n;j++)
    {
        for (i = 0; i < inp->k; i++) 
        {
            data_B[j*inp->ldb + i] = ( (DTYPE) (0.1f * j) );
        }
    }
    
    // matrix C, data_corig
    for (j = 0; j < inp->n; j++) 
    {
        for (i = 0; i < inp->m; i++) 
        {
            data_C[j*inp->ldc + i] = (DTYPE) (0.01f * i);
            
            orig[j*inp->ldc + i] = data_C[j*inp->ldc + i];
        }
    }


    inp->A = data_A;
    inp->B = data_B;
    inp->C = data_C;
    *data_corig = orig;
    inp->useHugePages = useHugePages;
    inp->fmem = fmem;
    inp->hugeSize = hugeSize;
    
    DBG ( printf("inp->A = %p, B= %p, C = %p, orig = %p\n", data_A, data_B, data_C, orig) );

}
/********************* END OF INIT FUNCTION **********************************/

/********************* BEGIN OF CLEANUP FUNCTION ***************************/

void cleanup_data(input_params *inp, DTYPE *data_corig) 
{
    if ( inp->useHugePages )
    {
        munmap( inp->A - inp->off_a, inp->hugeSize ) ;
        close( inp->fmem ) ;
    }
    else
    {
        _free_align( inp->A - inp->off_a) ;
        _free_align( inp->B - inp->off_b) ;
        _free_align( inp->C - inp->off_c) ;
    }

    _free_align( data_corig );
}

