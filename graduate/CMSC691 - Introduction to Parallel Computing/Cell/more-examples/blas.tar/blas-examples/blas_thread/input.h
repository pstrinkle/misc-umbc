/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __INPUT_H__
#define __INPUT_H__

#define DTYPE float

typedef struct
{
    char transa ;
    char transb ;
    int m ;
    int n ;
    int k ;
    DTYPE alpha ;
    DTYPE *A ; 
    int lda ;
    DTYPE *B ; 
    int ldb ;
    DTYPE beta ;
    DTYPE *C ; 
    int ldc ;
    int off_a ;
    int off_b ;
    int off_c ;
    int useHugePages;
    int hugeSize;
    int fmem;
    char mem_file[100];
    
} input_params ;

typedef struct
{
    DTYPE sa ;
    DTYPE *sx ;
    DTYPE *sy ;
    int incx ;
    int incy ;
    int n ;
    int useHugePages ;
    int hugeSize;
    int fmem;
    char mem_file[100];
    
} input_params1 ;

void get_params( input_params  *inp );
void init_data(input_params *inp, DTYPE **data_corig);
void cleanup_data(input_params *inp, DTYPE *data_corig);
int useHuge();
int getIter();

#define HUGE_PAGE_SIZE (16*1024*1024)

#ifdef DEBUG
#define DBG(stmt) stmt
#else
#define DBG(stmt)
#endif

#endif
