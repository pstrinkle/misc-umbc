/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*
  test_ssyrk.c : Contains functions to test ssyrk routine 
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>

#include "blas.h"
#include "input.h"

#define THRESH ((DTYPE) 0.0001)


static int verify_result_syrk( input_params *inp, DTYPE *data_Corig)
{
    int i, j, k;
    DTYPE diff = 0;
    DTYPE *data_c = inp->C, *data_a = inp->A;
    DTYPE alpha = inp->alpha, beta = inp->beta;
    int lda = inp->lda, ldc = inp->ldc;
    int N = inp->n, K = inp->k; 
    DTYPE result ;


    /* compute the expected result */
    for( j=0; j<N; j++ ) 
    {
        for( i=j; i<N; i++ ) 
        {
            data_Corig[ldc * j + i] *= beta ;
            for (k = 0; k < K; k++) 
            {
                data_Corig[ldc * j + i] += alpha * data_a[lda * k + i] * 
                    data_a[lda * k + j];
            }
        }
    }


    /* verify the computed result from SPU */
    for( j=0; j<N; j++ ) 
    {
        for( i = 0; i < N; i++) 
        {
            result = data_Corig[ldc * j + i] ;
            diff = data_Corig[ldc * j + i] - data_c[ldc * j + i];
            result = (result > 0) ? result : ( (DTYPE)(-1) * result ) ;

            if (diff < (DTYPE) 0.0)
                diff = -diff;

            if ( diff > THRESH *result )  
            {
                printf( "Corig(%d,%d) =%f\n",i, j, data_Corig[ldc * j + i] ) ;
                printf( "C(%d,%d)     =%f\n",i, j, data_c[ldc * j + i] ) ;
                return -1 ;
            }
        }
    }
    return 0 ;
}


int test_syrk(int tid) 
{
    DTYPE  *data_corig ;
    input_params inp;
    char *trans = "N" ;
    int i,  iters = getIter();
    int result = 0;
    char* mem_file = "/huge/blas_app.bin";

    sprintf(inp.mem_file, "%s.%d", mem_file, tid);
    DBG (printf("test_syrk:File name for hugepages = %s\n", inp.mem_file) );

    /* Fetching the input paramaters */

    get_params (&inp) ;

    inp.useHugePages = useHuge();

    for (i = 0 ; i < iters; i++) 
    { 
        
        init_data(&inp, &data_corig); 
        
        ssyrk_( "L", trans, &inp.n, &inp.k, &inp.alpha, inp.A, &inp.lda, 
                &inp.beta, inp.C, &inp.ldc ) ;
        
        
        /* Verification of result for each Matrix */
        if ( (result = verify_result_syrk ( &inp, data_corig)) < 0 ) 
        {
            fprintf(stderr, "test_syrk:FAILED: Verification failed\n") ;
        } 
        else 
        {
#ifdef PRINT_PASS
            printf("test_syrk:PASSED\n") ;
#endif
        }
        
        /*********************** END VERIFICATION **************************/
        
        cleanup_data(&inp, data_corig) ; 
    }
    
    return result;
}





