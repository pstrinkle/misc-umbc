/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/* 
   test_saxpy.c : Contains functions to test saxpy routine
*/

#include <stdlib.h>
#include <stdio.h>
#include <malloc_align.h>
#include <free_align.h>

#include <numa.h>
#include <sys/times.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

#include <blas.h>
#include "input.h"

#define THRESH_DIFF ((DTYPE)0.0001)

/***************** PARAMETER FETCH ROUTINE *****************/
static void get_params1( input_params1  *inp )
{
    inp->n =  10000;
    inp->sa = 0.5;   
    inp->incx = 2 ;
    inp->incy = 1 ;
}

/*************** DATA INITIALIZATION ROUTINE ***************/
static void init_data1( input_params1 *inp )
{
    int i, j ;
	int abs_incx = abs(inp->incx);
	int abs_incy = abs(inp->incy);
    int useHugePages = inp->useHugePages;
    char* mem_file = inp->mem_file;
    int fmem = -1;
    int hugeSize = 0;  
    int entries = inp->n;

    DTYPE *data_ptr_x ;
    DTYPE *data_ptr_y ;

#ifdef USE_NUMA
    if ( numa_available() >= 0 )
    {
        int nodes ;
        nodemask_t mask0 ;

        nodes = numa_max_node() + 1 ;
        if ( nodes > 1 )
        {
            nodemask_zero( &mask0 ) ;
            nodemask_set( &mask0, 0 ) ;
            numa_set_membind( &mask0 ) ;
            numa_bind( &mask0 ) ;
        }
    }
#endif

    if ( useHugePages )
    {
        if ( ( fmem = open( mem_file,  O_CREAT | O_RDWR, 0755 ) ) == -1 )
        {
            printf("Unable to open Huge Pages file\n") ;

            /* Fallback to normal pages */
            useHugePages = 0 ;
        }
        else
        {
            
            hugeSize = ( entries * (abs_incx+abs_incy) * sizeof(DTYPE) + HUGE_PAGE_SIZE-1 ) &
                ~(HUGE_PAGE_SIZE-1) ;
            
            data_ptr_x = mmap( 0, hugeSize, PROT_READ | PROT_WRITE,
                               MAP_PRIVATE, fmem, 0 ) ;

            if ( data_ptr_x == MAP_FAILED )
            {
                printf("ERROR: unable to mmap file. Exiting\n") ;

                close( fmem ) ;
                remove( mem_file ) ;
                useHugePages = 0 ;
            }
            else
            {
                data_ptr_y = (DTYPE *) ( ( (char *) data_ptr_x ) + entries * abs_incx * sizeof(DTYPE) ) ;
                memset(data_ptr_x, 0, hugeSize);
            }
        }
    }
     
    if( ! useHugePages )
    {
        /* Allocate the array and initialize with data */
   		data_ptr_x = (DTYPE *) _malloc_align( entries * abs_incx * sizeof( DTYPE ), 7 ) ; 
        data_ptr_y = (DTYPE *) _malloc_align( entries * abs_incy * sizeof( DTYPE ), 7 ) ;     
    }
   
	if ( data_ptr_x )
	{
        for( i = 0, j=0 ; i < entries * abs_incx ; i+=abs_incx, j++ )
            data_ptr_x[i] = (DTYPE) i ;
    }
    else
    {
        printf( "Failed to allocate %d bytes for input arrayfor x.\n", entries * sizeof( DTYPE ) ) ;
        exit(1) ;
    }
    
    
    if ( data_ptr_y )
    {
        for( i = 0, j = 0 ; i < entries * abs_incy ; i+=abs_incy, j++ )
            data_ptr_y[i] = (DTYPE) i ;
    }
    else
    {
        printf("Failed to allocate %d bytes for input array for y.\n", entries * sizeof(DTYPE));
        exit(1) ;
    }	
    

    inp->sx = data_ptr_x ;
    inp->sy = data_ptr_y ;
    inp->fmem = fmem;
    inp->useHugePages = useHugePages;
    inp->hugeSize = hugeSize;
}

static void cleanup_data1( input_params1 *inp )
{
    if ( inp->useHugePages )
    {
        munmap( inp->sx, inp->hugeSize ) ;
        close( inp->fmem ) ;
        remove( inp->mem_file ) ;
    }
    else
    {
        _free_align( inp->sx ) ;
        _free_align( inp->sy ) ;
    }
}

static int verify_result_axpy( int n, DTYPE *sx, int incx, DTYPE *sy, int incy, DTYPE sa )
{
    int i, j, k ;
    DTYPE diff, diff1 ;
    DTYPE result ;
	DTYPE sum_x;
	int abs_incx = abs(incx);
	int abs_incy = abs(incy);

	if ( incx == 0 && incy == 0 )
	{
		DBG ( printf ("incx=0, incy=0\n"));
		result = sa * sx[0] * n;
        diff =   sy[0] - ( sa * sx[0] * n ) ;
        diff = ( diff > 0 ) ? diff : ( -1 * diff )  ; 
   
		DBG (printf("result = %E, sy[0] = %E",result, sy[0]));

    	if ( diff   > THRESH_DIFF * result)
        {
			DBG (printf("error\n"));
            return -1 ;
        }
	}
	else if (incx !=0 && incy == 0)
	{
		sum_x = 0;
		for (i=0, j=0; i<n; i++, j+=abs_incx)
			sum_x += sx[j];

		result = sa * sum_x;
        diff =   sy[0] - ( sa * sum_x ) ;
        diff = ( diff > 0 ) ? diff : ( -1 * diff )  ; 
		
		if ( diff   > THRESH_DIFF * result)
        {
            DBG (printf("test_saxpy: verification error\n"));
            return -1 ;
        }
	}
	else if ((incx < 0 && incy >0) || (incx > 0 && incy < 0))
	{
    	for( i = 0, j = (n-1)*abs_incy, k=0 ; i < n ; i++, j -= abs_incy, k += abs_incx )
    	{
       	 	result =  ( ( sa * sx[k] ) + j ) ;
        	diff =   sy[j] - ( ( sa * sx[k] ) + j ) ;
        	diff = ( diff > 0 ) ? diff : ( -1 * diff )  ; 
       		
			if ( diff   > THRESH_DIFF * result)
        	{
				DBG (printf("test_saxpy: error\n"));
            	DBG( printf( "sy[%d]=%f\n",j,sy[j] ) ) ;
            	DBG( printf( "sx[%d]=%f\n",k,sx[k] ) ) ;

            	return -1 ;
        	}
    	}
		
	}
	else
	{
    	for( i = 0, j = 0, k=0 ; i < n ; i++, j += abs_incy, k+=abs_incx )
    	{
       	 	result =  ( ( sa * sx[k] ) + j ) ;
        	diff =   sy[j] - ( ( sa * sx[k] ) + j ) ;
        	diff1 = ( diff > 0 ) ? diff : ( -1 * diff )  ; 
       		
			if ( diff1   > THRESH_DIFF * result)
        	{
				DBG (printf("error\n"));
            	DBG( printf( "sy[%d]=%f\n",j,sy[j] ) ) ;
            	DBG( printf( "sx[%d]=%f\n",k,sx[k] ) ) ;
                DBG( printf( "result = %E\n",result));
                DBG( printf( "diff = %E, diff1 = %E \n", diff, diff1));

            	return -1 ;
        	}
    	}
	}
    return 0 ;
} 

/********************** MAIN ROUTINE **********************/
int test_axpy( int tid )
{
    int i ;
    int result = 0;
    int t_n;
    int t_sa;
    int t_incx;
    int t_incy;
    input_params1   inp ;
    char* mem_file = "/huge/blas_app.bin";

    sprintf(inp.mem_file, "%s.%d", mem_file, tid);
    DBG (printf("test_saxpy:File name for hugepages = %s\n", inp.mem_file));
    
    int iters = getIter();
    inp.useHugePages = useHuge();

    get_params1( &inp ) ;
    t_n = inp.n;
    t_sa = inp.sa;
    t_incx = inp.incx;
    t_incy = inp.incy;

    for ( i = 0 ; i < iters ; i++ )
    {
        init_data1( &inp ) ;
    
        saxpy_( &inp.n, &inp.sa, inp.sx, &inp.incx, inp.sy, &inp.incy ) ;
        
        DBG (printf ("test_saxpy: check_equality \n"));	
        result = verify_result_axpy( inp.n, inp.sx, inp.incx, inp.sy, inp.incy, inp.sa );
        
        if ( result < 0 )
        {
            printf("test_saxpy:FAILED: Error in verfication\n");
        }
        else
        {    
#ifdef PRINT_PASS
            printf( "test_saxpy: PASSED\n" );
#endif
        }
        
        cleanup_data1 ( &inp) ;
    }

    return result;
}
