/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */


#define PRECISION_S

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc_align.h>
#include <free_align.h>

#include <input.h>

#include <cblas.h>
#include <blas.h>

#define THRESH_DIFF ((DTYPE)0.0001)

input_params1 inp ;

/***************** PARAMETER FETCH ROUTINE *****************/
static void get_params( int argc, char *argv[] )
{
    if ( argc != 4 )
    {
      LOG_ERROR ( 0, "Syntax:\n\n", 0 ) ;
      LOG_ERROR ( 0, " <N> <incx> <incy> \n\n", 0 ) ;
      LOG_ERROR ( 0, "     N       Number of Entries\n", 0 ) ;
      LOG_ERROR ( 0, "     incx    Stride_x\n", 0 ) ;
      LOG_ERROR ( 0, "     incy    Stride_y\n", 0 ) ;
      exit(1) ;
    }

    inp.n = atoi( argv[1] ) ;
    inp.incx = atoi( argv[2] ) ;
    inp.incy = atoi( argv[3] ) ;
}

/*************** DATA INITIALIZATION ROUTINE ***************/
static void init_data()
{
    int    i,j ;
    int entries_x, entries_y ;
  
    DTYPE *data_ptr_x ;
    DTYPE *data_ptr_y ;

    inp.sa = 2.3 ;
    
    if( inp.incx <  0 )
        inp.incx = -1 * inp.incx ;
    if( inp.incy <  0 )
        inp.incy = -1 * inp.incy ;

    entries_x = inp.n * inp.incx ;
    entries_y = inp.n * inp.incy ;

    /* Allocate array x & y and initialize with data */

    data_ptr_x = (DTYPE *) _malloc_align( entries_x * sizeof( DTYPE ), 7 ) ;

    if ( data_ptr_x )
    {
        for( i = 0 ; i < entries_x ; i++ )
            data_ptr_x[i] = (DTYPE) (i) ;
    }
    else
    {
        LOG_ERROR( 0, "Failed to allocate %d bytes for input arrayfor x.\n",
                 entries_x * sizeof( DTYPE ) ) ;
        exit(1) ;
    }

    data_ptr_y = (DTYPE *) _malloc_align( entries_y * sizeof( DTYPE ), 7 ) ;
    
    j = entries_y - 1 ;
    if ( data_ptr_y )
    {
        for( i = 0 ; i < entries_y ; i++,j-- )
            data_ptr_y[i] = (DTYPE) (j) ;
    }
    else
    {
        LOG_ERROR( 0, "Failed to allocate %d bytes for input array for y.\n",
                 entries_y * sizeof( DTYPE ) ) ;
        exit(1) ;
    }
   
    inp.sx = data_ptr_x ;
    inp.sy = data_ptr_y ;
}

/*************** DATA CLEAN-UP ROUTINE ***************/
static void cleanup_data()
{
    _free_align( inp.sx ) ;
    _free_align( inp.sy ) ;
}

/*************** VERIFY SCOPY ROUTINE ***************/
int verify_result_scopy( int n, DTYPE *sx, int incx, DTYPE *sy, int incy) 
{
    int i, j, k ;

    for( i = 0, j = 0, k = 0 ; i < n ; i++, j += incx, k += incy )
    {
        if (sx[j] != sy[k] )
        {
            printf( "Expected sy[%d]=%f\n",j,sx[j] ) ;
            printf( "Computed sy[%d]=%f\n",k,sy[k] )  ;

            return -1 ;
        }
    }
    return 0 ;
}

/*************** VERIFY SDOT ROUTINE ***************/
int verify_result_sdot( int n, DTYPE *sx, int incx, DTYPE *sy, int incy, double result )
{
    int i, j, k ;
    DTYPE sum = 0.0, diff = 0.0 ;

    for( i = 0, j = 0, k = 0 ; i < n ; i++, j += incx, k += incy )
        sum  += sx[j] * sy[k] ;

    if( result < 0 )
        result = result * (DTYPE)(-1) ;
    if( sum < 0 )
        sum = sum * (DTYPE)(-1) ;

    diff = sum - result ;

    if( diff < 0 )
        diff = diff * (DTYPE)(-1) ;

        if ( diff > THRESH_DIFF * (sum) )
        {
            printf( "Expected SDOT SUM = %f\n", sum ) ;
            printf( "Computed SDOT SUM = %f\n", result ) ;

            return -1 ;
        }
    return 0 ;
}

/*************** VERIFY CBLAS_SDOT ROUTINE ***************/
int verify_result_cblas_sdot( int n, DTYPE *sx, int incx, DTYPE *sy, int incy, DTYPE result )
{
    int i, j, k ;
    DTYPE sum = 0.0, diff = 0.0 ;
    
    for( i = 0, j = 0, k = 0 ; i < n ; i++, j += incx, k += incy )
        sum  += sx[j] * sy[k] ;

    if( result < 0 )
        result = result * (DTYPE)(-1) ;
    if( sum < 0 )
        sum = sum * (DTYPE)(-1) ;

    diff = sum - result ;

    if( diff < 0 )
        diff = diff * (DTYPE)(-1) ;

    if ( diff > THRESH_DIFF * (sum) )
    {
        printf( "Expected SDOT SUM = %f\n", sum ) ;
        printf( "Computed SDOT SUM = %f\n", result ) ;

        return -1 ;
    }
    return 0 ;
}

/*************** VERIFY SSCAL ROUTINE ***************/
int verify_result_sscal( int n, DTYPE sa, DTYPE *sx, int incx )
{
    int i, j ;
    DTYPE diff ;

    for( i = 0, j = 0 ; i < n ; i++, j += incx )
    {
        diff = sx[j] - ( sa * j ) ;
        diff = ( diff > 0 ) ? diff : -1 * diff ;
        if ( diff > THRESH_DIFF * sa * j )
        {
            printf( "Expected sx[%d]=%f\n",j,sa*j ) ;
            printf( "Computed sx[%d]=%f\n",j,sx[j] ) ;

            return -1 ;
        }
    }
    return 0 ;
}

/*************** VERIFY SNRM2 ROUTINE ***************/
int verify_result_snrm2( int n, DTYPE *sx, int incx, double result ) 
{
    int i, j ;
    DTYPE sum_norm = 0.0, norm = 0.0 ;

    for( i = 0, j = 0 ; i < n ; i++, j += incx )
        sum_norm  += sx[j] * sx[j] ;

    norm = (double)sqrt(sum_norm) ;

    if ( abs( norm - result ) > THRESH_DIFF * norm )
    {
        printf( "Expected Norm = %lf\n", norm ) ;
        printf( "Computed Norm = %lf\n", result ) ;

        return -1 ;
    }
    return 0 ;
}

/*************** VERIFY CBLAS_SNRM2 ROUTINE ***************/
int verify_result_cblas_snrm2( int n, DTYPE *sx, int incx, DTYPE result )
{
    int i, j ;
    DTYPE sum_norm = 0.0, norm = 0.0 ;

    for( i = 0, j = 0 ; i < n ; i++, j += incx )
        sum_norm  += sx[j] * sx[j] ;

    norm = (double)sqrt(sum_norm) ;

    if ( abs( norm - result ) > THRESH_DIFF * norm )
    {
        printf( "Expected Norm = %lf\n", norm ) ;
        printf( "Computed Norm = %lf\n", result ) ;

        return -1 ;
    }
    return 0 ;
}

/*************** CALL SCOPY ROUTINE ***************/
int call_scopy( int argc, char *argv[] )
{
    get_params( argc, argv ) ;
    init_data() ;

    scopy_( &inp.n, inp.sx, &inp.incx, inp.sy, &inp.incy ) ;

    if ( verify_result_scopy( inp.n, inp.sx, inp.incx, inp.sy, inp.incy ) < 0 )
    {
        LOG_ERROR( 0, "Error in verification. -> SCOPY \n", 0 ) ;
        exit(1) ;
    }
    else
       printf( "\nsuccess SCOPY \n" )  ;

    cleanup_data () ;

    return 0 ;
}

/*************** CALL CBLAS_SCOPY ROUTINE ***************/
int call_cblas_scopy( int argc, char *argv[] )
{
    get_params( argc, argv ) ;
    init_data() ;

    cblas_scopy( inp.n, inp.sx, inp.incx, inp.sy, inp.incy ) ;

    if ( verify_result_scopy( inp.n, inp.sx, inp.incx, inp.sy, inp.incy ) < 0 )
    {
        LOG_ERROR( 0, "Error in verification. -> SCOPY \n", 0 ) ;
        exit(1) ;
    }
    else
       printf( "\nsuccess CBLAS_SCOPY \n" )  ;

    cleanup_data () ;

    return 0 ;
}

/*************** CALL SDOT ROUTINE ***************/
int call_sdot( int argc, char *argv[] )
{
    double result ;

    get_params( argc, argv ) ;
    init_data() ;

    result = sdot_( &inp.n, inp.sx, &inp.incx, inp.sy, &inp.incy ) ;

    if ( verify_result_sdot( inp.n, inp.sx, inp.incx, inp.sy, inp.incy, result ) < 0 )
    {
        LOG_ERROR( 0, "Error in verification. -> SDOT \n \n", 0 ) ;
        exit(1) ;
    }
    else
      printf( "\nsuccess SDOT \n" ) ;

    cleanup_data () ;

    return 0 ;
}

/*************** CALL CBLAS_SDOT ROUTINE ***************/
int call_cblas_sdot( int argc, char *argv[] )
{
    DTYPE result ;

    get_params( argc, argv ) ;
    init_data() ;

    result = cblas_sdot( inp.n, inp.sx, inp.incx, inp.sy, inp.incy ) ;

    if ( verify_result_cblas_sdot( inp.n, inp.sx, inp.incx, inp.sy, inp.incy, result ) < 0 )
    {
        LOG_ERROR( 0, "Error in verification. -> CBLAS_SDOT \n \n", 0 ) ;
        exit(1) ;
    }
    else
      printf( "\nsuccess CBLAS_SDOT \n" ) ;

    cleanup_data () ;

    return 0 ;
}

/*************** CALL SSCAL ROUTINE ***************/
int call_sscal( int argc, char *argv[] )
{
    get_params( argc, argv ) ;
    init_data() ;

    sscal_( &inp.n, &inp.sa, inp.sx, &inp.incx ) ;

    if ( verify_result_sscal( inp.n, inp.sa, inp.sx, inp.incx ) < 0 )
    {
        LOG_ERROR( 0, "Error in verification. -> SSCAL \n \n", 0 ) ;
        exit(1) ;
    }
    else
      printf( "\nsuccess SSCAL \n" ) ;

    cleanup_data () ;

    return 0 ;
}

/*************** CALL SNRM2 ROUTINE ***************/
int call_snrm2( int argc, char *argv[] )
{
    double norm2 ;

    get_params( argc, argv ) ;
    init_data() ;

    norm2 = snrm2_( &inp.n, inp.sx, &inp.incx ) ;

    if ( verify_result_snrm2( inp.n, inp.sx, inp.incx, norm2 ) < 0 )
    {
        LOG_ERROR( 0, "Error in verification. -> SNRM2 \n \n", 0 ) ;
        exit(1) ;
    }
    else
      printf( "\nsuccess SNRM2 \n" ) ;

    cleanup_data () ;

    return 0 ;
}

/*************** CALL CBLAS_SNRM2 ROUTINE ***************/
int call_cblas_snrm2( int argc, char *argv[] )
{
    DTYPE norm2 ;

    get_params( argc, argv ) ;
    init_data() ;

    norm2 = cblas_snrm2( inp.n, inp.sx, inp.incx ) ;

    if ( verify_result_cblas_snrm2( inp.n, inp.sx, inp.incx, norm2 ) < 0 )
    {
        LOG_ERROR( 0, "Error in verification. -> CBLAS_SNRM2 \n \n", 0 ) ;
        exit(1) ;
    }
    else
      printf( "\nsuccess CBLAS_SNRM2 \n" ) ;

    cleanup_data () ;

    return 0 ;
}

/********************** MAIN ROUTINE **********************/
int main( int argc, char *argv[] )
{
    call_scopy( argc, argv ) ;
    call_sdot( argc, argv ) ;
    call_sscal( argc, argv ) ;
    call_snrm2( argc, argv ) ;
    call_cblas_scopy( argc, argv ) ;
    call_cblas_sdot( argc, argv ) ;
    call_cblas_snrm2( argc, argv ) ;

    return 0;
}

