/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */


#define PRECISION_S

#include <stdio.h>
#include <stdlib.h>
#include <malloc_align.h>
#include <free_align.h>
#include <string.h>

#include <input.h>

#include <blas.h>
#include <cblas.h>

#define THRESH_DIFF ((DTYPE)0.0001)

input_params2   inp ;

/***************** PARAMETER FETCH ROUTINE *****************/
static void get_params( int argc, char *argv[])
{
    if ( argc < 11 )
        {
            LOG_ERROR ( 0, "Syntax:\n\n", 0 ) ;
            LOG_ERROR ( 0, " <uplo> <trans> <diag> <M> <N> <alpha> <lda> <incX> <beta> <incY> \n\n", 0 ) ;
            exit(1) ;
        }

    inp.uplo = atoi( argv[1] ) ;
    inp.trans = atoi( argv[2] ) ;
    inp.diag = atoi( argv[3] ) ;
    inp.m = atoi( argv[4] ) ;
    inp.n = atoi( argv[5] ) ;
    inp.alpha = atof( argv[6] ) ;
    inp.lda = atoi( argv[7] ) ;
    inp.incX = atoi( argv[8] );
    inp.beta = atof( argv[9] ) ;
    inp.incY = atoi( argv[10] );
}

/*************** DATA INITIALIZATION ROUTINE ***************/
static void init_data()
{
 
    DTYPE *data_ptr_x;
    DTYPE *data_ptr_y;
    DTYPE *data_ptr_a;
    DTYPE *data_ptr_aOrig;
    DTYPE *data_ptr_yOrig;
    
    int i;
    
    // Allocate the array and initialize with data 
    fflush(stdout);
    data_ptr_x = (DTYPE *) _malloc_align( (inp.n * inp.incX + 32) * sizeof( DTYPE ), 7 ) ;
   
    if ( !data_ptr_x ) 
    {
        LOG_ERROR( 0, "Failed to allocate %d bytes for input arrayfor x.\n",
                   inp.n * sizeof( DTYPE ) ) ;
        exit(1) ;
    }

    for (i = 0; i < inp.n * inp.incX; i++)
        data_ptr_x[i] = (DTYPE) (i%10 + 1); 


    data_ptr_y = (DTYPE *) _malloc_align( (inp.m) * sizeof( DTYPE ), 7 ) ;

    if ( !data_ptr_y ) 
    {
        LOG_ERROR( 0, "Failed to allocate %d bytes for input array for y.\n",
                   inp.m * sizeof( DTYPE ) ) ;
        exit(1) ;
    }
    
    for (i = 0; i < inp.m; i++)
        data_ptr_y[i] = (DTYPE) (i % 10) + 2; 
   
    // Another Y vector for the purpose of result verification
    data_ptr_yOrig = (DTYPE *) _malloc_align( inp.m * sizeof( DTYPE ), 7 ) ;

    if ( !data_ptr_yOrig ) 
    {
        LOG_ERROR( 0, "Failed to allocate %d bytes for second test array for y.\n",
                   inp.m * sizeof( DTYPE ) ) ;
        exit(1) ;
    }
   
    memcpy(data_ptr_yOrig, data_ptr_y, inp.m * sizeof(DTYPE));

    // Matrix A
    data_ptr_a = (DTYPE *) _malloc_align( (inp.lda * inp.n) * sizeof( DTYPE ), 7 ) ;

    if ( !data_ptr_a ) 
    {
        LOG_ERROR( 0, "Failed to allocate %d bytes for input array for a.\n",
                   inp.m * inp.n * sizeof( DTYPE ) ) ;
        exit(1) ;
    }
   
    for (i = 0; i < inp.lda * inp.n; i++)
        data_ptr_a[i] = (DTYPE)  (i%10 + 3); 
     
    data_ptr_aOrig = (DTYPE *) _malloc_align( (inp.lda * inp.n ) * sizeof( DTYPE ), 7 ) ;

    if ( !data_ptr_aOrig ) 
    {
        LOG_ERROR( 0, "Failed to allocate %d bytes for input array for a.\n",
                   inp.n * inp.n * sizeof( DTYPE ) ) ;
        exit(1) ;
    }
    memcpy(data_ptr_aOrig, data_ptr_a, inp.n * inp.lda * sizeof(DTYPE));


    inp.x  = data_ptr_x;
    inp.y = data_ptr_y;
    inp.a = data_ptr_a;
    inp.yOrig = data_ptr_yOrig;
    inp.aOrig = data_ptr_aOrig ;
}

/*************** DATA CLEAN-UP ROUTINE ***************/
static void cleanup_data()
{
    _free_align( inp.x ) ;
    _free_align( inp.y ) ;
    _free_align( inp.a ) ;
    _free_align( inp.yOrig ) ;
    _free_align( inp.aOrig ) ;
}

/*************** VERIFY SGEMV ROUTINE ***************/
static int verify_result_sgemv()
{
    int i, j, k;
    DTYPE val = 0;
    DTYPE diff = 0;
    int trans = inp.trans ;

    // compute the expected result

    if (!trans)
    {
        printf("Computing expected result for y = alpha.A.x + beta.y \n");
        for (i = 0; i < inp.m; i++) 
        {
            val = 0.0;
            for (j = 0, k = 0; j < inp.n; j++, k += inp.incX) 
                val += inp.a[j * inp.lda + i] * inp.x[k];

            inp.yOrig[i] = inp.alpha * val + inp.beta * inp.yOrig[i];
        }
    }
    else
    {
        printf("Computing expected result for y = alpha.Trans(A).x + beta.y \n");
        for (i = 0; i < inp.m; i++) 
        {
            val = 0.0;
            for (j = 0, k = 0; j < inp.n; j++, k += inp.incX) 
                val += inp.a[i * inp.lda + j] * inp.x[k];

            inp.yOrig[i] = inp.alpha * val + inp.beta * inp.yOrig[i];
        }
    }
 
    for( i = 0; i < inp.m; i++)  
    {
        diff = inp.yOrig[i] - inp.y[i];
        if (diff < 0) 
            diff = -diff;
        if ( diff > THRESH_DIFF )  
        {            
            printf( "Expected sy[%d]=%f\n",i,inp.yOrig[i] ) ;
            printf( "Computed sy[%d]=%f\n",i,inp.y[i] ) ;
            
            return -1 ;
        }
    }
    return 0 ;
} 

/*************** VERIFY SSYR ROUTINE ***************/
static int verify_result_ssyr()
{
    int i, j ;
    DTYPE diff = 0;
    DTYPE *A ;

    A = (DTYPE *) _malloc_align( inp.n * inp.lda * sizeof( DTYPE ), 7 ) ;

    printf("Computing expected result for A = alpha.x.Trans(x) + A \n");

    for( i=0; i<inp.n; i++ )
    {
       for( j=0; j<=i; j++)
       {
            A[i*inp.n + j] = inp.aOrig[i*inp.n + j] + inp.alpha * inp.x[i] * inp.x[j] ;
    
            diff = A[i*inp.n + j] - inp.a[i*inp.n + j] ;
            if (diff < 0)
                diff = -diff;
            if ( diff > THRESH_DIFF * inp.a[i*inp.n + j] )  
            {
                printf(" %d \t Expected A = %f \t Computed A = %f \n",j,A[i*inp.n + j],inp.a[i*inp.n + j]) ;
                return -1 ;
            }
       }
    }
    return 0 ;
}

/*************** CALL SGEMV ROUTINE ***************/
int call_sgemv( int argc, char *argv[] )
{
    char *trans = "N" ;

    get_params( argc, argv) ;

    if (inp.trans)
            trans = "T";

    init_data();

    sgemv_( trans, &inp.m, &inp.n, &inp.alpha, inp.a, &inp.lda,
            inp.x, &inp.incX, &inp.beta, inp.y, &inp.incY) ;

    printf("computation done, verifying result...\n");

    if ( verify_result_sgemv() < 0 ) 
    {
        LOG_ERROR( 0, "Error in verification.. SGEMV \n\n", 0 ) ;
        exit(1) ;
    } 
    else
        printf( "success SGEMV \n\n" );
    
    cleanup_data() ;

    return 0 ;
}

/*************** CALL CBLAS_SGEMV ROUTINE ***************/
int call_cblas_sgemv( int argc, char *argv[] )
{
    int trans = CblasNoTrans ;

    get_params( argc, argv) ;

    if (inp.trans)
            trans = CblasTrans ;

    init_data();

    cblas_sgemv( CblasColMajor, trans, inp.m, inp.n, inp.alpha, inp.a, inp.lda,
                 inp.x, inp.incX, inp.beta, inp.y, inp.incY) ;

    printf("computation done, verifying result...\n");

    if ( verify_result_sgemv() < 0 ) 
    {
        LOG_ERROR( 0, "Error in verification.. CBLAS_SGEMV \n\n", 0 ) ;
        exit(1) ;
    }
    else
        printf( "success CBLAS_SGEMV \n\n" );

    cleanup_data() ;

    return 0 ;
}

/*************** CALL SSYR ROUTINE ***************/
int call_ssyr( int argc, char *argv[] )
{
    get_params( argc, argv) ;
    init_data();

    ssyr_( "U", &inp.n, &inp.alpha, inp.x, &inp.incX, inp.a, &inp.lda ) ;

    printf("computation done, verifying result...\n");

    if ( verify_result_ssyr() < 0 ) 
    {
        LOG_ERROR( 0, "Error in verification.. SSYR \n\n", 0 ) ;
        exit(1) ;
    }
    else
        printf( "success SSYR \n\n" );

    cleanup_data() ;

    return 0 ;
}

/********************** MAIN ROUTINE **********************/
int main( int argc, char *argv[] )
{
    call_sgemv( argc, argv ) ;
    call_cblas_sgemv( argc, argv ) ;
    call_ssyr( argc, argv ) ;

    return 0;
}

