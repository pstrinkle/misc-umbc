#!/bin/bash
# --------------------------------------------------------------  
# (C)Copyright 2007                                               
# International Business Machines Corporation                     
# All Rights Reserved.                                            
#                                                                 
# Redistribution and use in source and binary forms, with or      
# without modification, are permitted provided that the           
# following conditions are met:                                   
#                                                                 
# - Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer. 
#                                                                 
# - Redistributions in binary form must reproduce the above       
#   copyright notice, this list of conditions and the following   
#   disclaimer in the documentation and/or other materials        
#   provided with the distribution.                               
#                                                                 
# - Neither the name of IBM Corporation nor the names of its      
#   contributors may be used to endorse or promote products       
#   derived from this software without specific prior written     
#   permission.                                                   
#                                                                 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
# --------------------------------------------------------------  
# PROLOG END TAG zYx                                              

# Purpose of this file
# --------------------
# This file contains examples to execute blas-simple sample application


# BLAS-LEVEL 1
#<N> <incx> <incy>

#<N>      - INTEGER.
#           N specifies the number of elements in the array
#
#<incx>   - INTEGER
#	    incx specifies the increment of vector x
#
#<incy>   - INTEGER
#	    incy specifies the increment of vector y

# Single Precision
./blas_sblat1 1 1 1
./blas_sblat1 10 1 2
./blas_sblat1 197 7 3
./blas_sblat1 1000 1 6
./blas_sblat1 1539 1 2
./blas_sblat1 10000 1 1

# Double Precision
./blas_dblat1 1 1 1
./blas_dblat1 10 1 2
./blas_dblat1 197 7 3
./blas_dblat1 1000 1 6
./blas_dblat1 1539 1 2
./blas_dblat1 10000 1 1


# BLAS-LEVEL 2
# <uplo> <trans> <diag> <M> <N> <alpha> <lda> <incX> <beta> <incY>

#<uplo>   - INTEGER
#	    uplo specifies whether the upper or lower triangular
#           part of the matrix is to be referenced as follows:
#
#                uplo = 0   Only the upper triangular part of
#                           matrix is to be referenced.
#
#                uplo = 1   Only the lower triangular part of 
#                           matrix is to be referenced.
#
#<trans>  - INTEGER
#	    trans specifies whether the transpose or normal case
#           of the matrix is to be referenced as follows:
#
#                trans = 0   Only the normal(non-transpose) case of 
#                            matrix is to be referenced.
#
#                trans = 1   Only the transpose case of 
#                            matrix is to be referenced.
#
#<diag>   - INTEGER
#           diag specifies whether matrix is unit triangular or not,
#           referenced as follows:
#
#                diag = 0   matrix is assumed to be unit triangular.
#
#                diag = 1   matrix is not a unit triangular.
#
#<M>      - INTEGER
#           M specifies the number of rows of the matrix
#
#<N>      - INTEGER
#           N specifies the number of columns of the matrix
#
#<alpha>  - FLOAT/DOUBLE depending upon the precesion of the code
#           alpha specifies the scalar alpha
#
#<lda>    - INTEGER
#           lda specifies the leading(first) dimension of A as 
#           declared in the calling program.
#
#<incX>   - INTEGER
#	    incX specifies the increment of vector x
#
#<beta>   - FLOAT/DOUBLE depending upon the precesion of the code
#           beta specifies the scalar beta
#
#<incY>   - INTEGER
#	    incY specifies the increment of vector y

# Single Precision
./blas_sblat2 0 0 0 10 10 1 10 1 1 1
./blas_sblat2 0 1 0 100 100 1.7 100 1 0.7 1
./blas_sblat2 0 1 1 1000 1000 1 1000 1 1 1

# Double Precision
./blas_dblat2 0 1 0 10 10 1 10 1 1 1
./blas_dblat2 0 0 1 100 100 1.7 100 1 0.7 1
./blas_dblat2 0 1 1 1000 1000 1 1000 1 1 1


# BLAS-LEVEL 3
# <transa> <transb> <m> <n> <k> <alpha> <lda> <ldb> <beta> <ldc>

#<transa> - INTEGER
#	    transa specifies whether the transpose or normal case
#           of the matrix A is to be referenced as follows:
#
#                transa = 0   Only the normal(non-transpose) case of 
#                             matrix is to be referenced.
#
#                transa = 1   Only the transpose case of 
#                             matrix is to be referenced.
#
#<transb> - INTEGER
#	    transb specifies whether the transpose or normal case
#           of the matrix A is to be referenced as follows:
#
#                transb = 0   Only the normal(non-transpose) case of 
#                             matrix is to be referenced.
#
#                transb = 1   Only the transpose case of 
#                             matrix is to be referenced.
#
#<m>      - INTEGER
#           m specifies the number of rows of the matrix A
#
#<n>      - INTEGER
#           n specifies the number of columns of the matrix B
#
#<k>      - INTEGER
#           k specifies the number of columns of the matrix A
#
#<alpha>  - FLOAT/DOUBLE depending upon the precesion of the code
#           alpha specifies the scalar alpha
#
#<lda>    - INTEGER
#           lda specifies the leading(first) dimension of A as 
#           declared in the calling program.
#
#<ldb>    - INTEGER
#           ldb specifies the leading(first) dimension of B as 
#           declared in the calling program.
#
#<beta>   - FLOAT/DOUBLE depending upon the precesion of the code
#           beta specifies the scalar beta
#
#<ldc>    - INTEGER
#           ldc specifies the leading(first) dimension of B as 
#           declared in the calling program.

# Single Precision
./blas_sblat3 0 0 100 100 100 1 100 100 1 100
./blas_sblat3 0 0 500 250 1000 1 1000 1000 0.1 1000
./blas_sblat3 1 1 167 248 10 0.1 1000 1000 1 1000

# Double Precision
./blas_dblat3 1 0 100 100 100 1 100 100 1 100
./blas_dblat3 1 1 500 250 1000 1.1 1000 1000 0.77 1000
./blas_dblat3 0 0 167 248 10 0.1 1000 1000 1 1000
