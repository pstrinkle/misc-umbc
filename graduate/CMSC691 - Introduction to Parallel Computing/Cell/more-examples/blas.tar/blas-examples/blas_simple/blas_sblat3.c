/* --------------------------------------------------------------  */
/* (C)Copyright 2007                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */


#define PRECISION_S

#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/wait.h>
#include <malloc_align.h>
#include <free_align.h>
#include <sys/times.h>
#include <unistd.h>
#include <numa.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>

#include "input.h"

#include <blas.h>
#include <cblas.h>

#define THRESH ((DTYPE) 0.01)

input_params3 inp;

int nodes;
nodemask_t mask0;
int useHugePages = 1;

#define HUGE_PAGE_SIZE (16*1024*1024)
int hugeSize;
int fmem = -1;
char* mem_file = "/huge/blas_app.bin";

/***************** PARAMETER FETCH ROUTINE *****************/
static void get_params( int argc, char *argv[] )
{
    if ( argc != 11 )
    {
      LOG_ERROR ( 0, "Syntax:\n\n", 0 ) ;
      LOG_ERROR ( 0, " <transa> <transb> <m> <n> <k> <alpha> <lda> <ldb> <beta> <ldc> \n\n", 0 ) ;
      LOG_ERROR ( 0, "     transa  pointer to char for operation\n", 0 ) ;
      LOG_ERROR ( 0, "     transb  pointer to char for operation\n", 0 ) ;
      LOG_ERROR ( 0, "     m       no of rows of a\n", 0 ) ;
      LOG_ERROR ( 0, "     k       no of col of a\n", 0 ) ;
      LOG_ERROR ( 0, "     n       no of col of c\n", 0 ) ;
      LOG_ERROR ( 0, "     alpha   constant\n", 0 ) ;
      LOG_ERROR ( 0, "     lda     LDA\n", 0 ) ;
      LOG_ERROR ( 0, "     ldb     LDB\n", 0 ) ;
      LOG_ERROR ( 0, "     beta    constant\n", 0 ) ;
      LOG_ERROR ( 0, "     ldc      LDC\n", 0 ) ;
      exit(1) ;
    }

    inp.transa = atoi( argv[1] ) ;
    inp.transb = atoi( argv[2] ) ;
    inp.m = atoi( argv[3] ) ;
    inp.n = atoi( argv[4] ) ;
    inp.k = atoi( argv[5] ) ;
    inp.alpha = atof( argv[6] ) ;
    inp.lda = atoi( argv[7] ) ;
    inp.ldb = atoi( argv[8] ) ;
    inp.beta = atof( argv[9] ) ;
    inp.ldc = atoi( argv[10] ) ;
}

/*************** USE HUGE PAGES ROUTINE ***************/
static int useHuge()
{
    int isHuge = 0;
    char* hugeStr = getenv("USE_HUGE_PAGES");
    isHuge = (hugeStr != NULL);

    if (isHuge) 
        printf("useHuge(): Huge Pages Requested\n");

   return isHuge;
}

/*************** DATA CLEAN-UP ROUTINE ***************/
void cleanup_data(DTYPE *data_corig) 
{
    if ( useHugePages )
    {
        munmap( inp.A, hugeSize ) ;
        close( fmem ) ;
        remove( mem_file ) ;
    }
    else
    {
        _free_align( inp.A ) ;
        _free_align( inp.B ) ;
        _free_align( inp.C ) ;
    }

    _free_align( data_corig );
}

/*************** DATA INITIALIZATION ROUTINE ***************/
void init_data(DTYPE **data_corig) 
{
    int i;
    int sizeA, sizeB, sizeC;
    DTYPE *data_A, *data_B, *data_C, *orig;

    if ( numa_available() >= 0 )
    {
        nodes = numa_max_node() + 1 ;
        if ( nodes > 1 )
        {
            nodemask_zero( &mask0 ) ;
            nodemask_set( &mask0, 0 ) ;
            numa_set_membind( &mask0 ) ;
            numa_bind( &mask0 ) ;
        }
    }

    // Calculate the number of elements in input array required for each matrix
   if (inp.transa)
       sizeA = inp.lda * inp.m;
   else
       sizeA = inp.lda * inp.k;

   if (inp.transb)
        sizeB = inp.ldb * inp.k;
   else
        sizeB = inp.ldb * inp.n;

   sizeC = inp.ldc * inp.n;

    if ( useHugePages )
    {
        if ( ( fmem = open( mem_file,  O_CREAT | O_RDWR, 0755 ) ) == -1 )
        {
            printf( "Unable to open Huge Pages file\n") ;
            /* Fallback to normal pages */
            useHugePages = 0 ;
        }
        else
        {
            hugeSize = ( (sizeA+sizeB+sizeC) * sizeof(DTYPE) + HUGE_PAGE_SIZE -1) 
		    	& ~(HUGE_PAGE_SIZE-1);
            
            data_A = mmap(0, hugeSize, PROT_READ | PROT_WRITE, MAP_PRIVATE,
                     fmem, 0);

            if (data_A == MAP_FAILED) 
            {
                close(fmem);
                remove(mem_file);
                useHugePages = 0;
            } 
            else 
            {
                data_B = (DTYPE*) ( (char*) data_A + sizeA * sizeof(DTYPE) );
                data_C = (DTYPE*) ( (char*) data_A + (sizeA + sizeB) * sizeof(DTYPE) );

                memset(data_A, 0, hugeSize);
 
                printf("Using HugePages, hugeSize = %d MB\n", hugeSize/(1024*1024));
            }
        }
    }


    if (!useHugePages) 
    {
        /* Here is the malloc call a data array aligned to a cacheline boundary 
           for efficient transfer. */
        data_A = (DTYPE *)_malloc_align( sizeA * sizeof(DTYPE), 7);
        data_B = (DTYPE *)_malloc_align( sizeB * sizeof(DTYPE), 7);
        data_C = (DTYPE *)_malloc_align( sizeC * sizeof(DTYPE), 7);

        if (!data_A || !data_B || !data_C) 
        {
            fprintf(stderr, "Failed to allocate buffers for input matrices A, B and C\n");
            exit(1);
        }
    }

    // Buffer for matrix C, used for verification
    orig = (DTYPE*) _malloc_align( sizeC * sizeof(DTYPE), 7);

    if ( !orig )
    {
        fprintf(stderr, "Failed to allocate buffer for matrix C for expected result comp\n");
        cleanup_data(orig);
        exit(1);
    }
        
   
   /* Filling up values*/

    // matrix A
    for (i = 0; i < sizeA; i++)
        data_A[i] = i%10;

    // matrix B
    for (i = 0; i < sizeB; i++)
        data_B[i] = i%10 + 1;

    // matrix C, data_corig
    for (i = 0; i < sizeC; i++) 
    {
        data_C[i] = i%10 + 2;
        orig[i] = data_C[i];
    }
    
    inp.A = data_A;
    inp.B = data_B;
    inp.C = data_C;
    *data_corig = orig;
}

/*************** VERIFY SGEMM ROUTINE ***************/
static int verify_result_sgemm( DTYPE *data_Corig )
{
    int i, j, k;
    DTYPE diff = 0;
    DTYPE *data_c = inp.C, *data_a = inp.A, *data_b = inp.B;
    DTYPE alpha = inp.alpha, beta = inp.beta;
    int lda = inp.lda, ldb = inp.ldb, ldc = inp.ldc;
    int M = inp.m, N = inp.n, K = inp.k; 
    int transa = inp.transa, transb = inp.transb;
    
    if (!transa && !transb)
    {   
	printf("Computing expected result for C = alpha.A.B + C \n");
    	// compute the expected result
    	for( j=0; j<N; j++ )
    	{
    	    for( i=0; i<M; i++ )
	    {
            	data_Corig[ldc * j + i] *= beta ;
            	for (k = 0; k < K; k++)
            	{
                    data_Corig[ldc * j + i] += alpha * data_a[lda * k + i] * data_b[ldb * j + k];
            	}
            }
    	}
    } 
    else if (transa && !transb) 
    {   
     	printf("Computing expected result for C = alpha.Trans(A).B + beta.C \n");
	 // compute the expected result
    	for( j=0; j<N; j++ )
    	{
    	    for( i=0; i<M; i++ )
	    {
            	data_Corig[ldc * j + i] *= beta ;
            	for (k = 0; k < K; k++)
            	{
                    data_Corig[ldc * j + i] += alpha * data_a[lda * i + k] * data_b[ldb * j + k];
            	}
            }
    	}   
    }
    else if (!transa && transb)
    {
    	printf("Computing expected result for C = alpha.A.Trans(B) + beta.C \n");
	// compute the expected result
    	for( j=0; j<N; j++ )
    	{
    	    for( i=0; i<M; i++ )
	    {
            	data_Corig[ldc * j + i] *= beta ;
            	for (k = 0; k < K; k++)
            	{
                    data_Corig[ldc * j + i] += alpha * data_a[lda * k + i] * data_b[ldb * k + j];
            	}
            }
    	}   
    } 
    else   // both transa and transb true 
    {
    	printf("Computing expected result for C = alpha.Trans(A).Trans(B) + beta.C \n");
	 // compute the expected result
    	for( j=0; j<N; j++ )
    	{
    	    for( i=0; i<M; i++ )
	    {
            	data_Corig[ldc * j + i] *= beta ;
            	for (k = 0; k < K; k++)
            	{
                    data_Corig[ldc * j + i] += alpha * data_a[lda * i + k] * data_b[ldb * k + j];
            	}
            }
    	}   
    }

    printf("Verifying results...\n");
    // verify the computed result
    for( j=0; j<N; j++ )
    {
	for( i = 0; i < M; i++)
    	{
            diff = data_Corig[ldc * j + i] - data_c[ldc * j + i];

            if (diff < (DTYPE) 0.0)
                diff = -diff;

            if ( diff > THRESH )  
            {
                printf( "Corig(%d,%d) =%f\n",i, j, data_Corig[ldc * j + i] ) ;
                printf( "C(%d,%d)     =%f\n",i, j, data_c[ldc * j + i] ) ;
                return -1 ;
            }
        }

    }
        return 0 ;
}

/*************** CALL SGEMM ROUTINE ***************/
int call_sgemm(int argc, char* argv[]) 
{
    DTYPE  *data_corig ;
    char *transa = "N", *transb = "N";
    struct tms tbuf ;
    clock_t start_tick, end_tick;
    double elapsed;
    
    /* Fetching the input paramaters */
    get_params (argc, argv) ;

    if (inp.transa)
	    transa = "T";
    if (inp.transb)
	    transb = "T";
    
    useHugePages = useHuge();

    init_data(&data_corig); 

    start_tick = times(&tbuf);
    
    sgemm_( transa, transb, &inp.m, &inp.n, &inp.k, &inp.alpha, 
		    inp.A, &inp.lda, inp.B, &inp.ldb, &inp.beta, inp.C, &inp.ldc ) ;

    end_tick = times( &tbuf ) ;
    elapsed = (double) (end_tick - start_tick) / (double) sysconf(_SC_CLK_TCK) ;
   
    printf("execution time     = %.2f seconds\n", elapsed);
    printf("computation done, verifying result...\n");
 
    /* Verification of result for each Matrix */
    if ( verify_result_sgemm (data_corig) < 0 ) 
        fprintf(stderr, "Verification failed SGEMM \n") ;
    else 
        printf("PASSED SGEMM \n\n") ;
  
    cleanup_data(data_corig) ; 
 
    return 0 ;
}

/*************** CALL CBLAS_SGEMM ROUTINE ***************/
int call_cblas_sgemm( int argc, char* argv[] ) 
{
    DTYPE  *data_corig ;
    int transa = CblasNoTrans, transb = CblasNoTrans;
    struct tms tbuf ;
    clock_t start_tick, end_tick;
    double elapsed;

    /* Fetching the input paramaters */
    get_params (argc, argv) ;

    if (inp.transa)
	    transa = CblasTrans ;
    if (inp.transb)
	    transb = CblasTrans ;

    useHugePages = useHuge();

    init_data(&data_corig); 

    start_tick = times(&tbuf);
    
    cblas_sgemm( CblasColMajor, transa, transb, inp.m, inp.n, inp.k, inp.alpha, 
		    inp.A, inp.lda, inp.B, inp.ldb, inp.beta, inp.C, inp.ldc ) ;

    end_tick = times( &tbuf ) ;
    elapsed = (double) (end_tick - start_tick) / (double) sysconf(_SC_CLK_TCK) ;
   
    printf("execution time     = %.2f seconds\n", elapsed);
    printf("computation done, verifying result...\n");

    /* Verification of result for each Matrix */
    if ( verify_result_sgemm (data_corig) < 0 ) 
        fprintf(stderr, "Verification failed CBLAS_SGEMM \n") ;
    else 
        printf("PASSED CBLAS_SGEMM \n\n") ;
  
    cleanup_data( data_corig ) ; 
 
    return 0 ;
}

/********************** MAIN ROUTINE **********************/
int main( int argc, char *argv[] )
{
    call_sgemm( argc, argv ) ;
    call_cblas_sgemm( argc, argv ) ;

    return 0;
}

