/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/* Initial scalar implementation of a heavily simplified particle 
 * system simulation that performs Euler integration.
 *
 * Consider a particle system simulation using numerical integration 
 * techniques to animate a large set of particles. Numerical integration 
 * will compute using Euler's method of itegration which state that at time
 * t, the next value of the function can be calculated by incrementing the
 * current value by the time step times the derivative of the function.
 *
 * 	F(t + dt) = F(t) + dt*F'(t)
 *
 * Our simple particle system will consist of:
 *
 *	1) An array of 3-D positions for each particle (pos[])
 *	2) An array of 3-D velocities for each particle (vel[])
 *	3) An array of masses for each particle (mass[])
 *	4) A force vector that varies over time. (force)
 *
 * This example will not consider how the time variant force function and step
 * in time (dt) is determined (computed) and will treat them as constants. Nor 
 * will we consider particle collisions. Neither of these aspects are germane 
 * to the presentation of the material. In addition, we will assume that 
 * all 3-D vectors (x,y,z) are expressed in homogeneous 4-D coordinates 
 * (x,y,z,1).
 */

#include "euler.h"

vec4D pos[PARTICLES];		// particle positions
vec4D vel[PARTICLES];		// particle velocities
vec4D force;			// current force being applied to the particles
float inv_mass[PARTICLES];	// inverse mass of the particles
float dt = 1.0f;		// step in time

int main()
{
  int i;
  float time;
  float dt_inv_mass;

  // For each step in time
  for (time=0; time<END_OF_TIME; time += dt) {
    // For each particle
    for (i=0; i<PARTICLES; i++) {
      // Compute the new position and velocity as acted upon by the force f.
      pos[i].x = vel[i].x * dt + pos[i].x;
      pos[i].y = vel[i].y * dt + pos[i].y;
      pos[i].z = vel[i].z * dt + pos[i].z;

      dt_inv_mass = dt * inv_mass[i];

      vel[i].x = dt_inv_mass * force.x + vel[i].x;
      vel[i].y = dt_inv_mass * force.y + vel[i].y;
      vel[i].z = dt_inv_mass * force.z + vel[i].z;
    }
  }
  return (0);
}

