/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CBE_MFC_H_
#define _CBE_MFC_H_

#include <libspe2.h>
#include <ppu_intrinsics.h>

/* If _SPE_DEBUG is defined, then the instrumentation is added to the
 * inline direct problem state functions to check for erroneous parameters.
 *
 * Output if control my the _SPE_DEBUG_STREAM define. If not defined 
 * all output information is sent to stderr.
 */
#ifdef _SPE_DEBUG
    #include <stdio.h>
#endif

#ifndef _SPE_DEBUG_STREAM
  #define _SPE_DEBUG_STREAM	stderr
#endif

/* This header file contains various definitions related to the SPE
 * Memory Flow Controller (MFC) problem state accessible by the PPE
 */

/**************************************/
/* MFC DMA Command Opcode Definitions */
/**************************************/

/****************************************************************************/
/* MFC DMA Command flags which identify classes of operations. */
/****************************************************************************/
/* Note: These flags may be used in conjunction with the base command types
 *	 (i.e. MFC_PUT_CMD, MFC_PUTR_CMD, MFC_GET_CMD, and MFC_SNDSIG_CMD)
 *	 to construct the various command permutations.
 */

#define MFC_BARRIER_ENABLE      0x01
#define MFC_FENCE_ENABLE        0x02
#define MFC_START_ENABLE        0x08
#define MFC_RESULT_ENABLE       0x10

/****************************************************************************/
/* MFC DMA Put Commands */
/****************************************************************************/

#define MFC_PUT_CMD             0x20
#define MFC_PUTS_CMD            0x28
#define MFC_PUTR_CMD            0x30
#define MFC_PUTF_CMD            0x22
#define MFC_PUTB_CMD            0x21
#define MFC_PUTFS_CMD           0x2A
#define MFC_PUTBS_CMD           0x29
#define MFC_PUTRF_CMD           0x32
#define MFC_PUTRB_CMD           0x31

/****************************************************************************/
/* MFC DMA Get Commands */
/****************************************************************************/

#define MFC_GET_CMD             0x40
#define MFC_GETS_CMD            0x48
#define MFC_GETF_CMD            0x42
#define MFC_GETB_CMD            0x41
#define MFC_GETFS_CMD           0x4A
#define MFC_GETBS_CMD           0x49


/****************************************************************************/
/* MFC DMA Storage Control Commands */
/****************************************************************************/
/* Note: These are only supported on implementations with a SL1 cache
 *	 They are no-ops on the initial (CBE) implementation.
 */

#define MFC_SDCRT_CMD           0x80
#define MFC_SDCRTST_CMD         0x81
#define MFC_SDCRZ_CMD           0x89
#define MFC_SDCRS_CMD           0x8D
#define MFC_SDCRF_CMD           0x8F

/****************************************************************************/
/* MFC Synchronization Commands */
/****************************************************************************/

#define MFC_SNDSIG_CMD          0xA0
#define MFC_SNDSIGB_CMD         0xA1
#define MFC_SNDSIGF_CMD         0xA2
#define MFC_BARRIER_CMD         0xC0
#define MFC_EIEIO_CMD           0xC8
#define MFC_SYNC_CMD            0xCC


/****************************************************************************/
/* Definitions for constructing a 32-bit command word including the transfer
 * and replacement class id and the command opcode.
 */
/****************************************************************************/
#define MFC_TCLASS(_tid)       ((_tid) << 24)
#define MFC_RCLASS(_rid)       ((_rid) << 16)

#define MFC_CMD_WORD(_tid, _rid, _cmd) (MFC_TCLASS(_tid) | MFC_RCLASS(_rid) | (_cmd))

/****************************************************************************/
/* Definitions for constructing a 64-bit command word including the size, tag,
 * transfer and replacement class id and the command opcode.
 */
/****************************************************************************/
#define MFC_SIZE(_size)        ((unsigned long long)(_size) << 48)
#define MFC_TAG(_tag_id)       ((unsigned long long)(_tag_id) << 32)
#define MFC_TR_CMD(_trcmd)     ((unsigned long long)(_trcmd))

#define MFC_CMD_DWORD(_size, _tag_id, _trcmd)  (MFC_SIZE(_size) | MFC_TAG(_tag_id) | MFC_TR_CMD(_trcmd))

/****************************************************************************/
/* Mask definitions for obtaining DMA commands and class ids from packed words.
 */
/****************************************************************************/
#define MFC_CMD_MASK       0x0000FFFF
#define MFC_CLASS_MASK     0x000000FF

/****************************************************************************/
/* DMA max/min size definitions. */
/****************************************************************************/
#define MFC_MIN_DMA_SIZE_SHIFT	1	/* 1 byte */
#define MFC_MAX_DMA_SIZE_SHIFT	14	/* 16384 bytes */

#define MFC_MIN_DMA_SIZE	(1 << MFC_MIN_DMA_SIZE_SHIFT)
#define MFC_MAX_DMA_SIZE	(1 << MFC_MAX_DMA_SIZE_SHIFT)

#define MFC_MIN_DMA_SIZE_MASK	(MFC_MIN_DMA_SIZE - 1)
#define MFC_MAX_DMA_SIZE_MASK	(MFC_MAX_DMA_SIZE - 1)

/****************************************************************************/
/* Mask definition for checking proper address alignment. 
 *
 * Transfers of 1, 2, 4, and 8 bytes must be naturally aligned with the 
 * same 4 least significant bits in the source and destination addreses.
 *
 * Optimal DMA performance is obtained when the source and destination address
 * is MFC_BEST_ADDR_ALIGNMENT aligned with a transfer size a multiple of 
 * MFC_BEST_ADDR_ALIGNMENT.
 */
/****************************************************************************/
#define MFC_ADDR_MATCH_MASK     0xF	
#define MFC_BEST_ADDR_ALIGNMENT 0x80

/****************************************************************************/
/* Definitions related to the Proxy DMA Command Status register (MFC_CMDStatus).
 */
/****************************************************************************/
#define MFC_PROXY_DMA_CMD_ENQUEUE_SUCCESSFUL     0x00
#define MFC_PROXY_DMA_CMD_SEQUENCE_ERROR         0x01
#define MFC_PROXY_DMA_QUEUE_FULL_ERROR           0x02

/****************************************************************************/
/* Definitions related to the DMA Queue Status register (MFC_QStatus). */
/****************************************************************************/
#define MFC_PROXY_DMA_Q_EMPTY			0x80000000
#define MFC_PROXY_DMA_Q_FREE_SPACE_MASK		0x0000FFFF

/****************************************************************************/
/* Definitions related to the Proxy Tag-Group Query-Type register
 * (Prxy_QueryType). 
 */
/****************************************************************************/
#define MFC_PROXY_DMA_QUERYTYPE_ANY	0x1
#define MFC_PROXY_DMA_QUERYTYPE_ALL	0x2

/****************************************************************************/
/* Definitions related to the Proxy Tag-Group Query-Mask (Prxy_QueryMask)
 * and Proxy Tag-Group Status (Prxy_TagStatus) registers.
 *
 * NOTE: The only use the bottom 5 bits of the tag id value passed to insure
 *       a valid tag id is used.
 */
/****************************************************************************/

#define MFC_TAGID_TO_TAGMASK(tag_id)  (1 << (tag_id & 0x1F))

/****************************************************************************/
/* Definitions related to the Mailbox Status register (SPU_Mbox_Stat) and the 
 * depths of the outbound Mailbox Register (SPU_OutMbox), the outbound 
 * interrupting Mailbox Register (SPU_OutIntrMbox), and the inbound Mailbox
 * Register (SPU_In_Mbox).
 */
/****************************************************************************/
#define MFC_SPU_OUT_MBOX_COUNT_STATUS_MASK	0x000000FF
#define MFC_SPU_OUT_MBOX_COUNT_STATUS_SHIFT	0x0
#define MFC_SPU_IN_MBOX_COUNT_STATUS_MASK	0x0000FF00
#define MFC_SPU_IN_MBOX_COUNT_STATUS_SHIFT	0x8
#define MFC_SPU_OUT_INTR_MBOX_COUNT_STATUS_MASK	0x00FF0000
#define MFC_SPU_OUT_INTR_MBOX_COUNT_STATUS_SHIFT 0x10

/****************************************************************************/
/* Definitions related to the SPC Multi Source Syncronization register
 * (MFC_MSSync). 
 */
/****************************************************************************/
#define MFC_MSS_STATUS_MASK                      0x1
#define MFC_MSS_COMPLETE                         0x0
#define MFC_MSS_NOT_COMPLETE                     0x1

/****************************************************************************/
/* Direct Problem State inline functions
 */
/****************************************************************************/

/* Multi-source sync */

/**
 * _spe_mssync_start
 * 
 * Writes to the MFC_MSSync register to start a synchronization.
 */
static __inline__ void _spe_mssync_start(volatile spe_mssync_area_t *ps_area)
{
    ps_area->MFC_MSSync = 1; /* Any data can be written here */
}

/**
 * _spe_mssync_get_status
 * 
 * Reads the MFC_MSSync register and returns the status.
 */
static __inline__ int _spe_mssync_get_status(volatile spe_mssync_area_t *ps_area)
{
    return ps_area->MFC_MSSync & MFC_MSS_STATUS_MASK;
}

/* Signal notification */

/**
 * _spe_sig_notify_1_read
 * 
 * Reads the SPU_Sig_Notify_1 register and returns the value read.
 */
static __inline__ unsigned int _spe_sig_notify_1_read(volatile spe_sig_notify_1_area_t *ps_area)
{
    return ps_area->SPU_Sig_Notify_1;
}

/**
 * _spe_sig_notify_1_write
 * 
 * Writes data to the SPU_Sig_Notify_1 register.
 */
static __inline__ void _spe_sig_notify_1_write(volatile spe_sig_notify_1_area_t *ps_area, unsigned int data)
{
    ps_area->SPU_Sig_Notify_1 = data;
}

/**
 * _spe_sig_notify_2_read
 * 
 * Reads the SPU_Sig_Notify_2 register and returns the value read.
 */
static __inline__ unsigned int _spe_sig_notify_2_read(volatile spe_sig_notify_2_area_t *ps_area)
{
    return ps_area->SPU_Sig_Notify_2;
}

/**
 * _spe_sig_notify_2_write
 * 
 * Writes data to the SPU_Sig_Notify_2 register.
 */
static __inline__ void _spe_sig_notify_2_write(volatile spe_sig_notify_2_area_t *ps_area, unsigned int data)
{
    ps_area->SPU_Sig_Notify_2 = data;
}

/* Mailboxes */

/**
 * _spe_in_mbox_status
 * 
 * Reads the SPU_Mbox_Stat register and returns the number of entries
 * available for writing to the SPU_In_Mbox register.
 */
static __inline__ int _spe_in_mbox_status(volatile spe_spu_control_area_t *ps_area)
{
    return (ps_area->SPU_Mbox_Stat & MFC_SPU_IN_MBOX_COUNT_STATUS_MASK) >> MFC_SPU_IN_MBOX_COUNT_STATUS_SHIFT;
}

/**
 * _spe_out_mbox_status
 * 
 * Reads the SPU_Mbox_Stat register and returns the number of entries
 * available for reading from the SPU_Out_Mbox register.
 */
static __inline__ int _spe_out_mbox_status(volatile spe_spu_control_area_t *ps_area)
{
    return (ps_area->SPU_Mbox_Stat & MFC_SPU_OUT_MBOX_COUNT_STATUS_MASK) >> MFC_SPU_OUT_MBOX_COUNT_STATUS_SHIFT;
}

/**
 * _spe_out_mbox_read
 * 
 * Reads a value from the SPU_Out_Mbox register and returns the value read.
 * This function will block until an entry is available.
 * To avoid blocking, call _spe_out_mbox_status first to check available
 * entries.
 */
static __inline__ unsigned int _spe_out_mbox_read(volatile spe_spu_control_area_t *ps_area)
{
    /* Wait for a message to be available for reading */
    while (_spe_out_mbox_status(ps_area) == 0) ;
    return ps_area->SPU_Out_Mbox;
}

/**
 * _spe_in_mbox_write
 * 
 * Writes one value to the SPU_In_Mbox register passed in mbox_data.
 * This function will block until an entry is available.
 * To avoid blocking, call _spe_out_mbox_status first to check available
 * entries.
 */
static __inline__ void _spe_in_mbox_write(volatile spe_spu_control_area_t *ps_area, unsigned int mbox_data) 
{
    /* Wait for a slot to be available for writing */
    while (_spe_in_mbox_status(ps_area) == 0) ;
    ps_area->SPU_In_Mbox = mbox_data;
}

/**
 * _spe_out_mbox_read_multi
 * 
 * Reads count values from the SPU_Out_Mbox register and returns the read values
 * in mbox_data.
 * This function will block until enough entries are available.
 * To avoid blocking, call _spe_out_mbox_status first to check available
 * entries.
 */
static __inline__ void _spe_out_mbox_read_multi(volatile spe_spu_control_area_t *ps_area,
                                                unsigned int mbox_data[],
                                                int count)
{
    int i, entries;

    i = 0;
    while (count > 0) {
        entries = (int)_spe_out_mbox_status(ps_area);
	if (entries > count) entries = count;
	count -= entries;
	while (entries--) mbox_data[i++] = ps_area->SPU_Out_Mbox;
    }
}

/**
 * _spe_in_mbox_write_multi
 * 
 * Writes count values to the SPU_In_Mbox register passed in mbox_data.
 * This function will block until enough entries are available.
 * To avoid blocking, call _spe_out_mbox_status first to check available
 * entries.
 */
static __inline__ void _spe_in_mbox_write_multi(volatile spe_spu_control_area_t *ps_area,
                                                unsigned int mbox_data[],
                                                int count)
{
    int i, entries;

    i = 0;
    while (count > 0) {
        entries = (int)_spe_in_mbox_status(ps_area);
	if (entries > count) entries = count;
	count -= entries;
	while (entries--) ps_area->SPU_In_Mbox = mbox_data[i++];
    }
}

/* MFC Proxy Commands */

/**
 * _spe_mfc_dma
 * 
 * Enqueues a DMA request using the values provided.
 * This function will block until the MFC queue has space available.
 * The status of the enqueue attempt is returned.
 */
static __inline__ int _spe_mfc_dma(volatile spe_mfc_command_area_t *ps_area,
                                   unsigned int ls,
                                   unsigned long long ea,
                                   unsigned int size,
                                   unsigned int tag,
                                   unsigned int cmd) 
{
    int status;
#ifdef _SPE_DEBUG
    if (ea == 0) {
        fprintf(_SPE_DEBUG_STREAM, "%s: ea value of 0 passed\n", __PRETTY_FUNCTION__);
    }
    if ((ls & 0x0000000F) != ((unsigned int)ea & 0x0000000F)) {
        fprintf(_SPE_DEBUG_STREAM, "%s: ls and ea value not aligned, last 4 bits should match: ls=%u ea=%u\n", __PRETTY_FUNCTION__, ls, (unsigned int)ea);
    }
    if ((size > 16) && (ls & 0x0000000F) != 0) {
        fprintf(_SPE_DEBUG_STREAM, "%s: ls value not aligned, last 4 bits should be 0 if size > 16: ls=%u\n", __PRETTY_FUNCTION__, ls);
    }
    if (tag > 31) {
        fprintf(_SPE_DEBUG_STREAM, "%s: tag size passed is out of range (0..31): %d\n", __PRETTY_FUNCTION__, tag);
    }
    if (((size != 1) && (size != 2) && (size != 4) && (size != 8) && 
	((size % 16) != 0)) || (size > 16384)) {
        fprintf(_SPE_DEBUG_STREAM, "%s: size passed is incorrect (1, 2, 4, 8, 16 or multiple of 16 bytes up to 16 KB): %d\n", 
		__PRETTY_FUNCTION__, size);
    }
    switch (cmd & 0xFFFF) {
    case MFC_PUT_CMD:
    case MFC_PUTS_CMD:
    case MFC_PUTR_CMD:
    case MFC_PUTF_CMD:
    case MFC_PUTB_CMD:
    case MFC_PUTFS_CMD:
    case MFC_PUTBS_CMD:
    case MFC_PUTRF_CMD:
    case MFC_PUTRB_CMD:
    case MFC_GET_CMD:
    case MFC_GETS_CMD:
    case MFC_GETF_CMD:
    case MFC_GETB_CMD:
    case MFC_GETFS_CMD:
    case MFC_GETBS_CMD:
    case MFC_SDCRT_CMD:
    case MFC_SDCRTST_CMD:
    case MFC_SDCRZ_CMD:
    case MFC_SDCRS_CMD:
    case MFC_SDCRF_CMD:
    case MFC_SNDSIG_CMD:
    case MFC_SNDSIGB_CMD:
    case MFC_SNDSIGF_CMD:
    case MFC_BARRIER_CMD:
    case MFC_EIEIO_CMD:
    case MFC_SYNC_CMD:
        break;
    default:
        fprintf(_SPE_DEBUG_STREAM, "%s: unexpected MFC command encounterd: 0x%x\n", 
		__PRETTY_FUNCTION__, cmd & 0xFFFF);
    }
#endif
    /* Wait for space to be available in the MFC queue */
    while ((ps_area->MFC_QStatus & 0x0000FFFF) == 0) ;
    do {
        ps_area->MFC_LSA = ls;
        ps_area->MFC_EAH = (unsigned int)(ea >> 32);
        ps_area->MFC_EAL = (unsigned int)ea;
        ps_area->MFC_Size_Tag = (size << 16) | tag;
        ps_area->MFC_ClassID_CMD = cmd;
        /* If a sequencing error is returned, we need to try again */
        status = ps_area->MFC_CMDStatus & 0x00000003;
    } while (status == MFC_PROXY_DMA_CMD_SEQUENCE_ERROR);
    return status;
}

/**
 * _spe_mfc_write_tag_mask
 * 
 * Writes the mask value to the Prxy_QueryMask register.
 */
static __inline__ void _spe_mfc_write_tag_mask(volatile spe_mfc_command_area_t *ps_area, unsigned int mask) 
{
#ifdef _SPE_DEBUG
    if (mask == 0) {
        fprintf(_SPE_DEBUG_STREAM, "%s: warning: mask value of 0 passed\n", __PRETTY_FUNCTION__);
    }
#endif
    ps_area->Prxy_QueryMask = mask;
}

/**
 * _spe_mfc_read_tag_status_immediate
 * 
 * Reads the Prxy_TagStatus register and returns the value read.
 * This function does not block.
 * _spe_mfc_write_tag_mask should be called before to set the tag mask.
 */
static __inline__ unsigned int _spe_mfc_read_tag_status_immediate(volatile spe_mfc_command_area_t *ps_area) 
{
    __eieio();
    return ps_area->Prxy_TagStatus;
}

#endif /* _CBE_MFC_H_ */
