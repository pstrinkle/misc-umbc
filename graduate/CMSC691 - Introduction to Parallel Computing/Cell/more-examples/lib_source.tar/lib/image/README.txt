%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Library containing image routines for PPE and SPE.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory builds a library (libimage) that contains the
	following image functions:

	conv3x3_1f
		3x3 convolution for single component float images

	conv3x3_1us
		3x3 convolution for one component unsigned short images

	conv3x3_4ub
		3x3 convolution for four component unsigned byte images

	conv5x5_1f
		5x5 convolution for single component float images

	conv5x5_1us
		5x5 convolution for one component unsigned short images

	conv5x5_4ub
		5x5 convolution for four component unsigned byte images

	conv7x7_1f
		7x7 convolution for single component float images

	conv7x7_1us
		7x7 convolution for one component unsigned short images

	conv7x7_4ub
		7x7 convolution for four component unsigned byte images

	conv9x9_1f
		9x9 convolution for single component float images

	conv9x9_1us
		9x9 convolution for one component unsigned short images

	conv9x9_4ub
		9x9 convolution for four component unsigned byte images

	histogram_ub
		generates a histogram of characters in the data array


	For each, see the appropriate include file for more detailed
	function descriptions.
