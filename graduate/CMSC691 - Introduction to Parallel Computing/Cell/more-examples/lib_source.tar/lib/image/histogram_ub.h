/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 *      void histogram_ub(unsigned int counts[], unsigned char data[], int size)
 * 
 * DESCRIPTION
 *      histogram_ub generates a histogram of characters in the data array.
 *	The number of characters in the array, data, is specified by the <size>
 *	parameter. The counts array consists of 256 32-bit counters. It serves
 *	as both the input and output in that the count is adjusted according
 *	to the byte counts in the data array.
 *
 *	Within the SPU, the count array must be quadword aligned.
 *	No assumptions are made with regard to the data array.
 */

static __inline void _histogram_ub(unsigned int counts[], unsigned char data[], int size)
{
#ifdef __SPU__
  int i;
  vector unsigned char in;
  vector unsigned char *vdata;
  vector unsigned int *vcounts;
  int slot;
  unsigned int idx;
  unsigned int idx_0, idx_1, idx_2, idx_3, idx_4, idx_5, idx_6, idx_7;
  vector unsigned short in_0, in_1;
  vector unsigned short slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7;
  vector unsigned int i0, i1, i2, i3;
  vector unsigned int indx_0, indx_1;
  vector unsigned int add_0, add_1, add_2, add_3, add_4, add_5, add_6, add_7;
  vector unsigned int cnts_0[64];
  vector unsigned int cnts_1[64];
  vector unsigned int cnts_2[64];
  vector unsigned int cnts_3[64];
  vector unsigned int cnts_4[64];
  vector unsigned int cnts_5[64];
  vector unsigned int cnts_6[64];
  vector unsigned int cnts_7[64];

  vector unsigned int zero = (vector unsigned int) { 0, 0, 0, 0};
  vector unsigned int one  = (vector unsigned int) { 1, 0, 0, 0};

  /* Count array is assumed to be quadword aligned.
   */
  // assert(((unsigned int)(counts) & 0xF) == 0);

  vcounts = (vector unsigned int *)(counts);

  /* To reduce instruction dependency, we compute 8 serparate
   * histograms. These are rolled back up into a single one 
   * at the end.
   */

  /* Initialized the local counters
   */
  for (i=0; i<64; i++) {
    cnts_0[i] = vcounts[i];
    cnts_1[i] = zero;
    cnts_2[i] = zero;
    cnts_3[i] = zero;
    cnts_4[i] = zero;
    cnts_5[i] = zero;
    cnts_6[i] = zero;
    cnts_7[i] = zero;
  }

  /* Process any leading misaligned bytes.
   */
  if ((i=((unsigned int)(data) & 0xF))) {
    int leading_size, end;

    in = spu_rlqwbyte(*(vector unsigned char *)(data), i);

    end = i + size;
    if (end > 16) end = 16;

    leading_size = end - i;
    data += leading_size;
    size -= leading_size;

    while (i++ < end) {
      idx = spu_extract(spu_rlmask((vector unsigned int)in, -24), 0);

      slot = (0 - idx) << 2;
      idx >>= 2;
      cnts_0[idx] = spu_add(cnts_0[idx], spu_rlqwbyte(one, slot));

      in = spu_rlqwbyte(in, 1);
    }
  }
  
  /* Process full quadwords of input data
   */
  vdata = (vector unsigned char *)(data);
  for (i=15; i<size; i+=16) {
    in = *vdata++;

    in_0 = spu_and((vector unsigned short)in, 0xFF);
    in_1 = spu_rlmask((vector unsigned short)in, -8);

    indx_0 = (vector unsigned int)spu_rlmask(in_0, -2);
    indx_1 = (vector unsigned int)spu_rlmask(in_1, -2);

    slot_0 = spu_sub(0, spu_sl(in_0, 2));
    slot_1 = spu_sub(0, spu_sl(in_1, 2));

    add_0 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_0), 0));
    add_1 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_0, 16), 0));

    add_2 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_1), 0));
    add_3 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_1, 16), 0));

    slot_2 = spu_rlqwbyte(slot_0, 4);
    slot_3 = spu_rlqwbyte(slot_1, 4);

    add_4 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_2), 0));
    add_5 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_2, 16), 0));

    add_6 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_3), 0));
    add_7 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_3, 16), 0));

    i0 = spu_and(indx_0, 0xFF);
    i1 = spu_rlmask(indx_0, -16);
    i2 = spu_and(indx_1, 0xFF);
    i3 = spu_rlmask(indx_1, -16);

    idx_0 = spu_extract(i0, 0);
    idx_1 = spu_extract(i1, 0);
    idx_2 = spu_extract(i2, 0);
    idx_3 = spu_extract(i3, 0);
    idx_4 = spu_extract(i0, 1);
    idx_5 = spu_extract(i1, 1);
    idx_6 = spu_extract(i2, 1);
    idx_7 = spu_extract(i3, 1);

    cnts_0[idx_0] = spu_add(cnts_0[idx_0], add_0);
    cnts_1[idx_1] = spu_add(cnts_1[idx_1], add_1);
    cnts_2[idx_2] = spu_add(cnts_2[idx_2], add_2);
    cnts_3[idx_3] = spu_add(cnts_3[idx_3], add_3);
    cnts_4[idx_4] = spu_add(cnts_4[idx_4], add_4);
    cnts_5[idx_5] = spu_add(cnts_5[idx_5], add_5);
    cnts_6[idx_6] = spu_add(cnts_6[idx_6], add_6);
    cnts_7[idx_7] = spu_add(cnts_7[idx_7], add_7);

    slot_4 = spu_rlqwbyte(slot_0, 8);
    slot_5 = spu_rlqwbyte(slot_1, 8);

    add_0 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_4), 0));
    add_1 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_4, 16), 0));

    add_2 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_5), 0));
    add_3 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_5, 16), 0));

    slot_6 = spu_rlqwbyte(slot_0, 12);
    slot_7 = spu_rlqwbyte(slot_1, 12);

    add_4 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_6), 0));
    add_5 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_6, 16), 0));

    add_6 = spu_rlqwbyte(one, spu_extract((vector signed int)(slot_7), 0));
    add_7 = spu_rlqwbyte(one, spu_extract(spu_rl((vector signed int)slot_7, 16), 0));

    idx_0 = spu_extract(i0, 2);
    idx_1 = spu_extract(i1, 2);
    idx_2 = spu_extract(i2, 2);
    idx_3 = spu_extract(i3, 2);
    idx_4 = spu_extract(i0, 3);
    idx_5 = spu_extract(i1, 3);
    idx_6 = spu_extract(i2, 3);
    idx_7 = spu_extract(i3, 3);

    cnts_0[idx_0] = spu_add(cnts_0[idx_0], add_0);
    cnts_1[idx_1] = spu_add(cnts_1[idx_1], add_1);
    cnts_2[idx_2] = spu_add(cnts_2[idx_2], add_2);
    cnts_3[idx_3] = spu_add(cnts_3[idx_3], add_3);
    cnts_4[idx_4] = spu_add(cnts_4[idx_4], add_4);
    cnts_5[idx_5] = spu_add(cnts_5[idx_5], add_5);
    cnts_6[idx_6] = spu_add(cnts_6[idx_6], add_6);
    cnts_7[idx_7] = spu_add(cnts_7[idx_7], add_7);
  }

  /* Cleanup any trailing non-complete, quadword data.
   */
  if ((i=size&15)) {
    in = *vdata;
    do {
      idx = spu_extract(spu_rlmask((vector unsigned int)in , -24), 0);

      slot = (0 - idx) << 2;
      idx >>= 2;
      cnts_0[idx] = spu_add(cnts_0[idx], spu_rlqwbyte(one, slot));

      in = spu_rlqwbyte(in, 1);
    } while (--i > 0);
  }

  /* Roll the counters into the overall (external) count array.
   */
  for (i=0; i<64; i+=2) {
    vector unsigned int sum0, sum1, sum2, sum3, sum4, sum5, sum6, sum7;

    sum0 = spu_add(cnts_0[i], cnts_1[i]);
    sum1 = spu_add(cnts_2[i], cnts_3[i]);
    sum2 = spu_add(cnts_4[i], cnts_5[i]);
    sum3 = spu_add(cnts_6[i], cnts_7[i]);

    sum4 = spu_add(cnts_0[i+1], cnts_1[i+1]);
    sum5 = spu_add(cnts_2[i+1], cnts_3[i+1]);
    sum6 = spu_add(cnts_4[i+1], cnts_5[i+1]);
    sum7 = spu_add(cnts_6[i+1], cnts_7[i+1]);

    sum0 = spu_add(sum0, sum1);
    sum2 = spu_add(sum2, sum3);
    sum4 = spu_add(sum4, sum5);
    sum6 = spu_add(sum6, sum7);

    vcounts[i]   = spu_add(sum0, sum2);
    vcounts[i+1] = spu_add(sum4, sum6);
  }
#else /* !__SPU__ */
  int i;

  for (i=0; i<size; i++) counts[*data++]++;

#endif /* __SPU__ */
}
