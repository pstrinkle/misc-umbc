/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _conv7x7_1us_h_
#define _conv7x7_1us_h_

#include <conv_defs.h>
#include <conv_shuf_us.h>

/* 
NAME
 	_conv7x7_1us - 7x7 convolution for one component unsigned short images

SYNOPSIS
	#include <conv7x7_1us.h>

	void _conv7x7_1us (const unsigned short *in[7], 
			   unsigned short *out, 
			   const vec_float4 m[49], int w)

DESCRIPTION
	Compute output pixels as the weighted sum of the input images's 
 	7x7 neighborhood and the filter mask 'm'.

	The image format is one component unsigned short.  The filter mask 
	'm' represents an arbitrary 7x7 kernel, where each entry has been 
	converted to 'float' and replicated to 'vec_float' form.

	Border pixels require a policy for defining values outside the
	image.  Three compile time options are supported.  The default 
	behaviour is to use _BORDER_COLOR_US (pre-defined to 0) for all 
	values beyond the left or right edges of the input image.  For
	values above or below the image, the caller is responsible for
	supplying scanlines cleared to the appropriate value.
	
	When _WRAP_CONV is defined, the input values are periodically 
	repeated --in other words, the input wraps from left to right 
	(and visa-versa).  The caller is responsible for managing the 
	input scanlines to support wrapping from top to bottom.

	When _CLAMP_CONV is defined, the input values are clamped to the 
	border --in other words, the right most value is repeated for 
	values beyond the right edge of the image; the left most value 
	is repeated for values beyond the left edge of the image.  The
	caller is responsible for managing the input scanlines to support
	clamping from top to bottom.

RESTRICTIONS
 	The input and output scanlines must be quad-word aligned.  The 
	scanline width 'w' must be a multiple of 8 pixels.  

 */
static __inline void _conv7x7_1us (const unsigned short *in[7], unsigned short *out, const vec_float4 m[49], int w)
{
  const vec_ushort8 *in0 = (const vec_ushort8 *)in[0];
  const vec_ushort8 *in1 = (const vec_ushort8 *)in[1];
  const vec_ushort8 *in2 = (const vec_ushort8 *)in[2];
  const vec_ushort8 *in3 = (const vec_ushort8 *)in[3];
  const vec_ushort8 *in4 = (const vec_ushort8 *)in[4];
  const vec_ushort8 *in5 = (const vec_ushort8 *)in[5];
  const vec_ushort8 *in6 = (const vec_ushort8 *)in[6];
  vec_ushort8 *vout = (vec_ushort8 *)out;
  vec_ushort8 p0, p1, p2, p3, p4, p5, p6;
  vec_ushort8 prev, curr, next;
  vec_ushort8 prevu, curru, nextu;
  vec_ushort8 left, left2, left3, right, right2, right3;
  vec_ushort8 leftu, left2u, left3u, rightu, right2u, right3u;
  vec_float4 left_hi, left_lo;
  vec_float4 leftu_hi, leftu_lo;
  vec_float4 left2_hi, left2_lo;
  vec_float4 left2u_hi, left2u_lo;
  vec_float4 left3_hi, left3_lo;
  vec_float4 left3u_hi, left3u_lo;
  vec_float4 curr_hi, curr_lo;
  vec_float4 curru_hi, curru_lo;
  vec_float4 right_hi, right_lo;
  vec_float4 rightu_hi, rightu_lo;
  vec_float4 right2_hi, right2_lo;
  vec_float4 right2u_hi, right2u_lo;
  vec_float4 right3_hi, right3_lo;
  vec_float4 right3u_hi, right3u_lo;
  vec_float4 res_hi, res_lo;
  vec_float4 resu_hi, resu_lo;
  vec_ushort8 res_hilo, resu_hilo;
  vec_float4 m00, m01, m02, m03, m04;
  vec_float4 m05, m06;
  int i0, i1, i2;

#ifdef _WRAP_CONV
  p0 = in0[(w>>2)-1];
  p1 = in1[(w>>2)-1];
  p2 = in2[(w>>2)-1];
  p3 = in3[(w>>2)-1];
  p4 = in4[(w>>2)-1];
  p5 = in5[(w>>2)-1];
  p6 = in6[(w>>2)-1];
#elif defined(_CLAMP_CONV)
  p0 = in0[0];
  p1 = in1[0];
  p2 = in2[0];
  p3 = in3[0];
  p4 = in4[0];
  p5 = in5[0];
  p6 = in6[0];
#else
  p0 = _BORDER_COLOR_US;
  p1 = _BORDER_COLOR_US;
  p2 = _BORDER_COLOR_US;
  p3 = _BORDER_COLOR_US;
  p4 = _BORDER_COLOR_US;
  p5 = _BORDER_COLOR_US;
  p6 = _BORDER_COLOR_US;
#endif /* _WRAP_CONV */

#define _CONV7_1us(_i)						\
  m00 = m[_i+0]; m01 = m[_i+1];                 		\
  m02 = m[_i+2]; m03 = m[_i+3];                 		\
  m04 = m[_i+4]; m05 = m[_i+5];                 		\
  m06 = m[_i+6];                                		\
  left3 = (vec_ushort8)vec_perm(prev, curr, left3_shuf_1us);	\
  left3u = (vec_ushort8)vec_perm(prevu, curru, left3_shuf_1us);	\
  left2 = (vec_ushort8)vec_perm(prev, curr, left2_shuf_1us);	\
  left2u = (vec_ushort8)vec_perm(prevu, curru, left2_shuf_1us);	\
  left = (vec_ushort8)vec_perm(prev, curr, left_shuf_1us);	\
  leftu = (vec_ushort8)vec_perm(prevu, curru, left_shuf_1us);	\
  right = (vec_ushort8)vec_perm(curr, next, right_shuf_1us);	\
  rightu = (vec_ushort8)vec_perm(curru, nextu, right_shuf_1us);	\
  right2 = (vec_ushort8)vec_perm(curr, next, right2_shuf_1us);	\
  right2u = (vec_ushort8)vec_perm(curru, nextu, right2_shuf_1us);\
  right3 = (vec_ushort8)vec_perm(curr, next, right3_shuf_1us);	\
  right3u = (vec_ushort8)vec_perm(curru, nextu, right3_shuf_1us);\
  _GET_PIXELS_1us(left3);					\
  _GET_PIXELS_1us(left3u);					\
  _GET_PIXELS_1us(left2);					\
  _GET_PIXELS_1us(left2u);					\
  _GET_PIXELS_1us(left);					\
  _GET_PIXELS_1us(leftu);					\
  _GET_PIXELS_1us(curr);					\
  _GET_PIXELS_1us(curru);					\
  _GET_PIXELS_1us(right);					\
  _GET_PIXELS_1us(rightu);					\
  _GET_PIXELS_1us(right2);					\
  _GET_PIXELS_1us(right2u);					\
  _GET_PIXELS_1us(right3);					\
  _GET_PIXELS_1us(right3u);					\
  _CONVERT_PIXELS_TO_FLOAT(left3);				\
  _CONVERT_PIXELS_TO_FLOAT(left3u);				\
  _CONVERT_PIXELS_TO_FLOAT(left2);				\
  _CONVERT_PIXELS_TO_FLOAT(left2u);				\
  _CONVERT_PIXELS_TO_FLOAT(left);				\
  _CONVERT_PIXELS_TO_FLOAT(leftu);				\
  _CONVERT_PIXELS_TO_FLOAT(curr);				\
  _CONVERT_PIXELS_TO_FLOAT(curru);				\
  _CONVERT_PIXELS_TO_FLOAT(right);				\
  _CONVERT_PIXELS_TO_FLOAT(rightu);				\
  _CONVERT_PIXELS_TO_FLOAT(right2);				\
  _CONVERT_PIXELS_TO_FLOAT(right2u);				\
  _CONVERT_PIXELS_TO_FLOAT(right3);				\
  _CONVERT_PIXELS_TO_FLOAT(right3u);				\
  _CALC_PIXELS_1us(left3, m00, res);				\
  _CALC_PIXELS_1us(left3u, m00, resu);				\
  _CALC_PIXELS_1us(left2, m01, res);				\
  _CALC_PIXELS_1us(left2u, m01, resu);				\
  _CALC_PIXELS_1us(left, m02, res);				\
  _CALC_PIXELS_1us(leftu, m02, resu);				\
  _CALC_PIXELS_1us(curr, m03, res);				\
  _CALC_PIXELS_1us(curru, m03, resu);				\
  _CALC_PIXELS_1us(right, m04, res);				\
  _CALC_PIXELS_1us(rightu, m04, resu);				\
  _CALC_PIXELS_1us(right2, m05, res);				\
  _CALC_PIXELS_1us(right2u, m05, resu);				\
  _CALC_PIXELS_1us(right3, m06, res);				\
  _CALC_PIXELS_1us(right3u, m06, resu)
  
  for (i0=0, i1=1, i2=2; i0<(w>>3)-2; i0+=2, i1+=2, i2+=2)
  {
#ifdef __SPU__
    res_hi = res_lo = spu_splats((float)0.0f);
    resu_hi = resu_lo = spu_splats((float)0.0f);
#else /* !__SPU__ */
    res_hi = res_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
    resu_hi = resu_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
#endif /* __SPU__ */

    _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[i2]);
    _CONV7_1us(0);

    _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[i2]);
    _CONV7_1us(7);

    _GET_SCANLINE_x2(p2, in2[i0], in2[i1], in2[i2]);
    _CONV7_1us(14);

    _GET_SCANLINE_x2(p3, in3[i0], in3[i1], in3[i2]);
    _CONV7_1us(21);

    _GET_SCANLINE_x2(p4, in4[i0], in4[i1], in4[i2]);
    _CONV7_1us(28);

    _GET_SCANLINE_x2(p5, in5[i0], in5[i1], in5[i2]);
    _CONV7_1us(35);

    _GET_SCANLINE_x2(p6, in6[i0], in6[i1], in6[i2]);
    _CONV7_1us(42);

    _CONVERT_PIXELS_TO_USHORT(res);
    _CONVERT_PIXELS_TO_USHORT(resu);
    _PACK_PIXELS_1us(res);
    _PACK_PIXELS_1us(resu);
    vout[i0] = res_hilo;
    vout[i1] = resu_hilo;
  }
#ifdef __SPU__
  res_hi = res_lo = spu_splats((float)0.0f);
  resu_hi = resu_lo = spu_splats((float)0.0f);
#else /* !__SPU__ */
  res_hi = res_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
  resu_hi = resu_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
#endif /* __SPU__ */

#ifdef _WRAP_CONV
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[0]);
  _CONV7_1us(0);                      

  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[0]);
  _CONV7_1us(7);                      

  _GET_SCANLINE_x2(p2, in2[i0], in2[i1], in2[0]);
  _CONV7_1us(14);                     

  _GET_SCANLINE_x2(p3, in3[i0], in3[i1], in3[0]);
  _CONV7_1us(21);                     

  _GET_SCANLINE_x2(p4, in4[i0], in4[i1], in4[0]);
  _CONV7_1us(28);

  _GET_SCANLINE_x2(p5, in5[i0], in5[i1], in5[0]);
  _CONV7_1us(35);                     

  _GET_SCANLINE_x2(p6, in6[i0], in6[i1], in6[0]);
  _CONV7_1us(42);

#elif defined(_CLAMP_CONV)
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[i1]);   
  _CONV7_1us(0);  

  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[i1]);   
  _CONV7_1us(7);  

  _GET_SCANLINE_x2(p2, in2[i0], in2[i1], in2[i1]);   
  _CONV7_1us(14);  

  _GET_SCANLINE_x2(p3, in3[i0], in3[i1], in3[i1]);   
  _CONV7_1us(21);  

  _GET_SCANLINE_x2(p4, in4[i0], in4[i1], in4[i1]);   
  _CONV7_1us(28);  

  _GET_SCANLINE_x2(p5, in5[i0], in5[i1], in5[i1]);   
  _CONV7_1us(35);  

  _GET_SCANLINE_x2(p6, in6[i0], in6[i1], in6[i1]);   
  _CONV7_1us(42);

#else
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], _BORDER_COLOR_US);   
  _CONV7_1us(0);  

  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], _BORDER_COLOR_US);   
  _CONV7_1us(7);  

  _GET_SCANLINE_x2(p2, in2[i0], in2[i1], _BORDER_COLOR_US);   
  _CONV7_1us(14);  

  _GET_SCANLINE_x2(p3, in3[i0], in3[i1], _BORDER_COLOR_US);   
  _CONV7_1us(21);  

  _GET_SCANLINE_x2(p4, in4[i0], in4[i1], _BORDER_COLOR_US);   
  _CONV7_1us(28);  

  _GET_SCANLINE_x2(p5, in5[i0], in5[i1], _BORDER_COLOR_US);   
  _CONV7_1us(35);  

  _GET_SCANLINE_x2(p6, in6[i0], in6[i1], _BORDER_COLOR_US);   
  _CONV7_1us(42);

#endif /* _WRAP_CONV */

  _CONVERT_PIXELS_TO_USHORT(res);
  _CONVERT_PIXELS_TO_USHORT(resu);
  _PACK_PIXELS_1us(res);
  _PACK_PIXELS_1us(resu);
  vout[i0] = res_hilo;
  vout[i1] = resu_hilo;
}

#endif /* _con7x7_1us_h_ */
