/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _conv_defs_h_
#define _conv_defs_h_

#include <vec_types.h>

/* The following macros replicate a scalar (either a short, int, or float)
 * across all elements of a vector.
 */
#ifdef __SPU__
#define _splat_short(in)	spu_splats((short)in)
#define _splat_int(in)		spu_splats((int)in)
#define _splat_float(in)	spu_splats((float)in)
#else /* not __SPU__ */
#include <altivec.h>
static __inline vec_short8 _splat_short(short a)
{
  union {
    vec_short8 v;
    short s[8];
  } in;

  in.s[0] = a;
  return (vec_splat(in.v, 0));
}

static __inline vec_int4 _splat_int(int a)
{
  union {
    vec_int4 v;
    int i[4];
  } in;

  in.i[0] = a;
  return (vec_splat(in.v, 0));
}

static __inline vec_float4 _splat_float(float a)
{
  union {
    vec_float4 v;
    float f[4];
  } in;

  in.f[0] = a;
  return (vec_splat(in.v, 0));
}

#endif /* __SPU__ */



#ifdef __SPU__
  #define _SIGNBIT_SHIFT 	spu_splats((signed int)-31)
#else
  #define _SIGNBIT_SHIFT 	((vector unsigned int) {31,31,31,31})
#endif /* __SPU__ */

#ifndef _BORDER_COLOR_F
 #ifdef __SPU__
  #define _BORDER_COLOR_F	spu_splats((float)0.0f)
 #else
  #define _BORDER_COLOR_F	((vector float) {0.0f,0.0f,0.0f,0.0f})
 #endif /* __SPU__ */
#endif /* _BORDER_COLOR_F */

#ifndef _BORDER_COLOR_UB
 #ifdef __SPU__
  #define _BORDER_COLOR_UB	spu_splats((unsigned int)0)
 #else
  #define _BORDER_COLOR_UB	((vector unsigned int) {0,0,0,0})
 #endif /* __SPU__ */
#endif /* _BORDER_COLOR_UB */

#ifndef _BORDER_COLOR_US
 #ifdef __SPU__
  #define _BORDER_COLOR_US	spu_splats((unsigned short)0)
 #else
  #define _BORDER_COLOR_US	((vector unsigned short) {0,0,0,0})
 #endif /* __SPU__ */
#endif /* _BORDER_COLOR_US */

#ifdef __SPU__
  #define vec_add               spu_add
  #define vec_andc      	spu_andc
  #define vec_cmpgt             spu_cmpgt 
  #define vec_ctf               spu_convtf
  #define vec_ctu               spu_convtu
  #define vec_mhhadd		spu_mhhadd
  #define vec_madd              spu_madd
  #define vec_mul               spu_mul
  #define vec_mulo      	spu_mulo
  #define vec_or      		spu_or
  #define vec_perm              spu_shuffle
  #define vec_sel(_a, _b, _c)   spu_sel(_a, _b, (vec_uchar16)_c) 
  #define vec_sr        	spu_rlmask
  #define vec_sra       	spu_rlmaska

  #define vec_mlladd(_a, _b, _c)        \
          (vec_int4)vec_madd((vec_short8)_a, (vec_short8)_b, (vec_int4)_c)

#else /* !__SPU__ */
  #define vec_mul(_a, _b)		\
	  vec_madd(_a, _b, (vec_float4)(0.0f))

  #define vec_mhhadd(_a, _b, _c)	\
	  vec_add((vec_int4)vec_mule((vec_short8)_a, (vec_short8)_b), (vec_int4)_c)

  #define vec_mlladd(_a, _b, _c)        \
          vec_msum((vec_short8)_a, (vec_short8)_b, (vec_int4)_c)

#endif /* __SPU__ */

///////////////////////////////////////////////////////////////////////////////

#define _GET_SCANLINE(_p, _a, _b)            		\
  prev = _p;                                    	\
  curr = _p = _a;                               	\
  next = _b

#define _GET_SCANLINE_x2(_p, _a, _b, _c)            	\
  prev = _p;                                    	\
  curr = prevu = _a;                               	\
  next = curru = _p = _b;				\
  nextu = _c

#define _GET_SCANLINE_x4(_p, _a, _b, _c, _d, _e)        \
  prev = _p;                                            \
  curr = prevu = _a;                                    \
  next = curru = prevuu = _b;                           \
  nextu = curruu = prevuuu = _c;                        \
  nextuu = curruuu = _p = _d;                           \
  nextuuu = _e

#define _GET_x4(_a, _b, _c, _shuf)                      \
  _c = vec_perm(_a, _b, _shuf);                         \
  _c##u = vec_perm(_a##u, _b##u, _shuf);                \
  _c##uu = vec_perm(_a##uu, _b##uu, _shuf);             \
  _c##uuu = vec_perm(_a##uuu, _b##uuu, _shuf)

///////////////////////////////////////////////////////////////////////////////

#define _CALC_PIXELS_1f_x4(_a, _b, _c)                  \
  _c = vec_madd(_a, _b, _c);                            \
  _c##u = vec_madd(_a##u, _b, _c##u);                   \
  _c##uu = vec_madd(_a##uu, _b, _c##uu);                \
  _c##uuu = vec_madd(_a##uuu, _b, _c##uuu)

///////////////////////////////////////////////////////////////////////////////

#ifdef __SPU__
 #define _GET_PIXELS_4ub(_s)                                 			\
  _s##_p0 = (vec_int4)vec_perm(_s, spu_splats((unsigned int)0), p0_shuf);	\
  _s##_p1 = (vec_int4)vec_perm(_s, spu_splats((unsigned int)0), p1_shuf);	\
  _s##_p2 = (vec_int4)vec_perm(_s, spu_splats((unsigned int)0), p2_shuf);	\
  _s##_p3 = (vec_int4)vec_perm(_s, spu_splats((unsigned int)0), p3_shuf)
#else /* !__SPU__ */
 #define _GET_PIXELS_4ub(_s)                                 			\
  _s##_p0 = (vec_int4)vec_perm(_s, ((vector unsigned int) {0,0,0,0}), p0_shuf);	\
  _s##_p1 = (vec_int4)vec_perm(_s, ((vector unsigned int) {0,0,0,0}), p1_shuf);	\
  _s##_p2 = (vec_int4)vec_perm(_s, ((vector unsigned int) {0,0,0,0}), p2_shuf);	\
  _s##_p3 = (vec_int4)vec_perm(_s, ((vector unsigned int) {0,0,0,0}), p3_shuf)
#endif /* __SPU__ */

#define _CALC_PIXELS_4ub(_a, _b, _c)              		\
  _c##_p0 = vec_mlladd(_a##_p0, _b, _c##_p0);    		\
  _c##_p1 = vec_mlladd(_a##_p1, _b, _c##_p1);    		\
  _c##_p2 = vec_mlladd(_a##_p2, _b, _c##_p2);    		\
  _c##_p3 = vec_mlladd(_a##_p3, _b, _c##_p3)

#ifdef __SPU__
 #define _CLAMP_PIXELS_4ub(_s)						\
  _s##_sign_p0 = (vec_uint4)vec_sra((vec_uint4)_s##_p0, _SIGNBIT_SHIFT);\
  _s##_sign_p1 = (vec_uint4)vec_sra((vec_uint4)_s##_p1, _SIGNBIT_SHIFT);\
  _s##_sign_p2 = (vec_uint4)vec_sra((vec_uint4)_s##_p2, _SIGNBIT_SHIFT);\
  _s##_sign_p3 = (vec_uint4)vec_sra((vec_uint4)_s##_p3, _SIGNBIT_SHIFT);\
  _s##_p0 = (vec_int4)vec_andc((vec_uint4)_s##_p0, _s##_sign_p0);	\
  _s##_p1 = (vec_int4)vec_andc((vec_uint4)_s##_p1, _s##_sign_p1);	\
  _s##_p2 = (vec_int4)vec_andc((vec_uint4)_s##_p2, _s##_sign_p2);	\
  _s##_p3 = (vec_int4)vec_andc((vec_uint4)_s##_p3, _s##_sign_p3);	\
  _s##_p0 = (vec_int4)vec_mulo((vec_ushort8)_s##_p0, vscale);		\
  _s##_p1 = (vec_int4)vec_mulo((vec_ushort8)_s##_p1, vscale);		\
  _s##_p2 = (vec_int4)vec_mulo((vec_ushort8)_s##_p2, vscale);		\
  _s##_p3 = (vec_int4)vec_mulo((vec_ushort8)_s##_p3, vscale);		\
  _s##_p0 = vec_sr(_s##_p0, vshift);					\
  _s##_p1 = vec_sr(_s##_p1, vshift);					\
  _s##_p2 = vec_sr(_s##_p2, vshift);					\
  _s##_p3 = vec_sr(_s##_p3, vshift);					\
  _s##_p0 = vec_or(_s##_p0, (vec_int4)vec_cmpgt(_s##_p0, spu_splats((signed int)255))); \
  _s##_p1 = vec_or(_s##_p1, (vec_int4)vec_cmpgt(_s##_p1, spu_splats((signed int)255))); \
  _s##_p2 = vec_or(_s##_p2, (vec_int4)vec_cmpgt(_s##_p2, spu_splats((signed int)255))); \
  _s##_p3 = vec_or(_s##_p3, (vec_int4)vec_cmpgt(_s##_p3, spu_splats((signed int)255)))
#else /* !__SPU__ */
 #define _CLAMP_PIXELS_4ub(_s)						\
  _s##_sign_p0 = (vec_uint4)vec_sra((vec_uint4)_s##_p0, _SIGNBIT_SHIFT);\
  _s##_sign_p1 = (vec_uint4)vec_sra((vec_uint4)_s##_p1, _SIGNBIT_SHIFT);\
  _s##_sign_p2 = (vec_uint4)vec_sra((vec_uint4)_s##_p2, _SIGNBIT_SHIFT);\
  _s##_sign_p3 = (vec_uint4)vec_sra((vec_uint4)_s##_p3, _SIGNBIT_SHIFT);\
  _s##_p0 = (vec_int4)vec_andc((vec_uint4)_s##_p0, _s##_sign_p0);	\
  _s##_p1 = (vec_int4)vec_andc((vec_uint4)_s##_p1, _s##_sign_p1);	\
  _s##_p2 = (vec_int4)vec_andc((vec_uint4)_s##_p2, _s##_sign_p2);	\
  _s##_p3 = (vec_int4)vec_andc((vec_uint4)_s##_p3, _s##_sign_p3);	\
  _s##_p0 = (vec_int4)vec_mulo((vec_ushort8)_s##_p0, vscale);		\
  _s##_p1 = (vec_int4)vec_mulo((vec_ushort8)_s##_p1, vscale);		\
  _s##_p2 = (vec_int4)vec_mulo((vec_ushort8)_s##_p2, vscale);		\
  _s##_p3 = (vec_int4)vec_mulo((vec_ushort8)_s##_p3, vscale);		\
  _s##_p0 = vec_sr(_s##_p0, vshift);					\
  _s##_p1 = vec_sr(_s##_p1, vshift);					\
  _s##_p2 = vec_sr(_s##_p2, vshift);					\
  _s##_p3 = vec_sr(_s##_p3, vshift);					\
  _s##_p0 = vec_or(_s##_p0, (vec_int4)vec_cmpgt(_s##_p0, ((vector signed int) {255,255,255,255}))); \
  _s##_p1 = vec_or(_s##_p1, (vec_int4)vec_cmpgt(_s##_p1, ((vector signed int) {255,255,255,255}))); \
  _s##_p2 = vec_or(_s##_p2, (vec_int4)vec_cmpgt(_s##_p2, ((vector signed int) {255,255,255,255}))); \
  _s##_p3 = vec_or(_s##_p3, (vec_int4)vec_cmpgt(_s##_p3, ((vector signed int) {255,255,255,255})))
#endif /* __SPU__ */

#define _PACK_PIXELS_4ub(_s)						\
  _s##_p01   = (vec_uint4)vec_perm(_s##_p0, _s##_p1, shuf_p2);  	\
  _s##_p23   = (vec_uint4)vec_perm(_s##_p2, _s##_p3, shuf_p2);  	\
  _s##_p0123 = (vec_uint4)vec_perm(_s##_p01, _s##_p23, shuf_p4)

///////////////////////////////////////////////////////////////////////////////

#ifdef __SPU__
 #define _GET_PIXELS_1us(_s)                           		\
  _s##_hi = (vec_float4)vec_perm(_s, spu_splats((unsigned short)0), hi_shuf);\
  _s##_lo = (vec_float4)vec_perm(_s, spu_splats((unsigned short)0), lo_shuf)
#else /* !__SPU__ */
 #define _GET_PIXELS_1us(_s)                           		\
  _s##_hi = (vec_float4)vec_perm(_s, ((vector unsigned short) {0,0,0,0}), hi_shuf);\
  _s##_lo = (vec_float4)vec_perm(_s, ((vector unsigned short) {0,0,0,0}), lo_shuf)
#endif /* __SPU__ */

#define _CONVERT_PIXELS_TO_FLOAT(_s)                    	\
  _s##_hi = vec_ctf((vec_uint4)_s##_hi, 0);             	\
  _s##_lo = vec_ctf((vec_uint4)_s##_lo, 0)

#define _CALC_PIXELS_1us(_a, _b, _c)				\
  _c##_hi = vec_madd((vec_float4)_a##_hi, _b, _c##_hi);		\
  _c##_lo = vec_madd((vec_float4)_a##_lo, _b, _c##_lo)

#define _CONVERT_PIXELS_TO_USHORT(_s)                   	\
  _s##_hi = (vec_float4)vec_ctu(_s##_hi, 16);           	\
  _s##_lo = (vec_float4)vec_ctu(_s##_lo, 16)

#define _PACK_PIXELS_1us(_s)					\
  _s##_hilo = (vec_ushort8)vec_perm(_s##_hi, _s##_lo, shuf_hilo)

#endif /* _conv_defs_h_ */

