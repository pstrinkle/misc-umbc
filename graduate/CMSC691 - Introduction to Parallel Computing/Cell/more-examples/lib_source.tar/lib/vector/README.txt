%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Library containing vector routines for PPE and SPE.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory builds a library (libvector) that contains the
	following vector functions:

	clipcode_ndc
		generates a clip code for the normalized device coordinate

	clipcode_ndc_v
		generates a vector of 4 clip codes for the 4 normalized,
		device coordinates specified as parallel arrays by the inputs

	clip_ray
		computes the linear interpolation factor for the ray passing
		through vertices v1 and v2 intersecting the plane specified
		by the plane parameter

	cross_product3
		computes the cross product of the two 3 component input vectors

	cross_product3_v
		simultaneously computes 4 cross products of the two 3
		component input vectors

	cross_product4
		computes the cross product of the two 4-component input vectors

	dot_product3
		computes the dot product of the two input vectors
		
	dot_product3_v
		computes 4 simultaneous dot products of the two SIMD input
		vectors

	dot_product4
		computes the 4 component dot product of the two input vectors

	dot_product4_v
		computes 4 simultaneous dot products of the two SIMD input
		vectors

	intersect_ray1_triangle8_v
		determine if a ray intersects a set of 8 triangles. If so,
		return each triangle's parameterized (u, v) intersection
		coordinates

	intersect_ray8_triangle1_v
		determine if a set of 8 rays intersect the given triangle.
		If so, return the parameterized (u, v) intersection
		coordinates, and accumulate nearest triangle intercept point,
		assuming that more than 1 triangle will eventually be
		intersected with each ray

	intersect_ray_triangle
		determine if a ray intersects a given triangle.  If so, return
		the triangle's parameterized (u, v) intersection coordinates

	intersect_ray_triangle_v
		use SoA form to determine if ray(s) intersect with triangle(s).
		If so, return the triangle's parameterized (u, v) intersection
		coordinates in the accumulated hit record

	inv_length_vec3
		computes the reciprocal of the magnitude of the 3-D vector
		specified by the input parameter

	inv_length_vec3_v
		computes the reciprocal of the magnitude of 4 3-D vectors
		specified by the parallel array input parameters

	length_vec3
		computes the magnitude of the 3-D vector specified by the
		input parameter

	length_vec3_v
		computes the magnitude of 4 3-D vectors specified by the
		parallel array input parameters

	lerp_vec1_v

	lerp_vec2_v
		computes 4 2-D vertices of the linear interpolation between
		4 2-D vertex pairs for 4 interpolation factors
		
	lerp_vec3_v
		computes 4 3-D vertices of the linear interpolation between
		4 3-D vertex pairs for 4 interpolation factors

	lerp_vec4
		computes the vertex of the linear interpolation between
		vertices v1 and v2 for a linear interpolation factor

	lerp_vec4_v
		computes 4 4-D vertices of the linear interpolation between
		4 4-D vertex pairs for 4 interpolation factors

	load_vec_float4
		loads 4 independent floating-point values into a 128-bit
		floating point vector and returns the vector

	load_vec_int4
		loads 4 independent integer values into a 128-bit integer
		vector and returns the vector

	normalize3
		normalizes the input vector specified by the parameter in
		and return the result

	normalize3_v
		normalizes 4 3-component input vectors specified as parallel
		arrays by the input parameters. The resulting 4 normalized
		vectors are returned in parallel array format into the memory
		pointed to by the input parameters

	normalize4
		normalizes the input vector specified by the parameter in
		and return the result

	reflect_vec3
		computes the reflection vector for light direction v
		reflecting off a surface whose normal is n and returns the
		reflection vector

	reflect_vec3_v
		computes 4 reflection vectors for normalized light directions
		specified by vx, vy, vz reflecting off surfaces whose
		normalized normals

	splat_dot_product3
		computes the dot product of the two input vectors, v1 dot v2,
		and results the result replicated (splated) across a
		128-bit floating-point vector

	sum_across_float3
		sums the 3 most significant components of a 4 component
		128-bit SIMD vector and returns the result

	sum_across_float4
		sums the 4 components of a 128-bit SIMD vector and returns
		the result

	xform_norm3
		transforms a 3-D normal vector by the upper left 3x4 matrix
		of a 4x4 matrix producing a reoriented 3-D normal vector

	xform_norm3_v
		transforms 4  3-D vectors by the upper left of a replicated
		4x4 matrix producing 4 transformed 3-D vector

	xform_vec3
		transforms a 3-D vector by a 4x4 matrix producing a
		transformed 4-D vector

	xform_vec3_v
		transforms 4  3-D vectors by a replicated 4x4 matrix producing
		4 transformed 4-D vector. The W (4th) component of the input
		vector is assumed to equal 1.0

	xform_vec4
		transforms a 4-D vector by a 4x4 matrix producing a
		transformed vector

	xform_vec4_v
		transforms 4  4-D vectors by a replicated 4x4 matrix producing
		4 transformed 4-D vector

