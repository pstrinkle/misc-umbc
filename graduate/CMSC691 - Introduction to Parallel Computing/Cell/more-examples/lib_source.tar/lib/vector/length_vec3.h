/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _LENGTH_VEC3_H_
#define _LENGTH_VEC3_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include <simdmath/sqrtf4.h>
#include "sum_across_float3.h"

/*
 * FUNCTION
 * 	float _length_vec3(vector float v)
 * 
 * DESCRIPTION
 * 	_length_vec3 computes the magnitude of the 3-D vector specified
 *	by the input parameter v. The 3 components of the vector are
 *	contained in the most significant components of the 128-bit 
 *	SIMD floating-point vector v.
 *           _______________________________
 *          |___X___|___Y___|___Z___|_______|
 *          msb                           lsb
 *
 *	result = sqrtf(x*x + y*y + z*z);
 */

static __inline float _length_vec3(vector float v)
{
  vector float v2;

#ifdef __SPU__
  float sum;
  v2 = spu_mul(v, v);
  sum = _sum_across_float3(v2);

  return (spu_extract(_sqrtf4(spu_promote(sum, 0)), 0));
#else
  union {
    vector float v;
    float f[4];
  } sum, result;


  v2 = vec_madd(v, v, ((vector float) {0.0f,0.0f,0.0f,0.0f}));
  sum.f[0] = _sum_across_float3(v2);
  result.v = _sqrtf4(sum.v);
  
  return (result.f[0]);
#endif
}

#endif /* _LENGTH_VEC3_H_ */
