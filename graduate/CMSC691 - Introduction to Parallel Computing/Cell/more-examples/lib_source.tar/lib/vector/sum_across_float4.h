/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SUM_ACROSS_FLOAT4_H_
#define _SUM_ACROSS_FLOAT4_H_		1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	float _sum_across4(vector float v)
 * 
 * DESCRIPTION
 * 	_sum_across4 sums the 4 components of a 128-bit SIMD vector 
 *	and returns the result.
 *           __________________________________
 *          |___c1___|___c2___|___c3___|___c4__|
 *          msb                              lsb
 *
 *	result = c1 + c2 + c3 + c4;
 */

static __inline float _sum_across_float4(vector float v)
{
  vector float c12, c2, c3, c4, c34;
  
#ifdef __SPU__
  vector float result;

  c2 = spu_rlqwbyte(v, 4);
  c3 = spu_rlqwbyte(v, 8);
  c4 = spu_rlqwbyte(v, 12);
  c12 = spu_add(v,  c2);
  c34 = spu_add(c3, c4);

  result = spu_add(c12, c34);
  return (spu_extract(result, 0));
#else
  union {
    vector float fv;
    float f[4];
  } result;

  c2 = vec_splat(v, 1);
  c3 = vec_splat(v, 2);
  c4 = vec_splat(v, 3);
  c12 = vec_add(v,  c2);
  c34 = vec_add(c3, c4);

  result.fv = vec_add(c12, c34);
  return (result.f[0]);
#endif

}

#endif /* _SUM_ACROSS_FLOAT4_H_ */
