/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CLIP_RAY_H_
#define _CLIP_RAY_H_	1

#include <simdmath/divf4.h>

/*
 * FUNCTION
 * 	vector float _clip_ray(vector float v1, vector float v2, vector float plane)
 * 
 * DESCRIPTION
 * 	_clip_ray computes the linear interpolation factor for the ray
 *	passing through vertices v1 and v2 intersecting the plane specified
 *	by the plane parameter. Input vertices, v1 and v2, are homogenious
 *	3-D coordinates packed in a 128-bit floating-point vector.
 *           _______________________________
 *          |___X___|___Y___|___Z___|___W___|
 *        
 *	The plane is also defined by a 4-component 128-bit floating-point
 *	vector satisfying the equation:
 *
 *	    plane.x*x + plane.y*y + plane.z* + plane.w*w = 0
 *
 *	The output is a scalar describing the position along the ray
 *	in which the ray intersects the plane. A value of 0.0 corresponds
 *	to the ray intersecting at v1. A value of 1.0 corresponds to
 *	the ray intersecting at v2. The resulting scalar replicated across
 *	a 4 component, 128-bit, floating point vectors to be suitable
 *	for computing the intersecting vertex using a lerp_* (linear 
 *	interpolayion) subroutines
 *
 *	Correct results are produced only if the ray is uniquely defined
 *	(ie, v1 != v2) and it intersects the plane.
 */

static __inline vector float _clip_ray(vector float v1, vector float v2, vector float plane)
{
  vector float t;
  vector float d1, d2;
  vector float xyzw1, yzwx1, zwxy1, wxyz1;
  vector float xyzw2, yzwx2, zwxy2, wxyz2;

#ifdef __SPU__
  xyzw1 = spu_mul(v1, plane);
  xyzw2 = spu_mul(v2, plane);

  yzwx1 = spu_rlqwbyte(xyzw1, 4);
  zwxy1 = spu_rlqwbyte(xyzw1, 8);
  wxyz1 = spu_rlqwbyte(xyzw1, 12);

  yzwx2 = spu_rlqwbyte(xyzw2, 4);
  zwxy2 = spu_rlqwbyte(xyzw2, 8);
  wxyz2 = spu_rlqwbyte(xyzw2, 12);

  d1 = spu_add(spu_add(xyzw1, yzwx1), spu_add(zwxy1, wxyz1));
  d2 = spu_add(spu_add(xyzw2, yzwx2), spu_add(zwxy2, wxyz2));

  t = _divf4(d1, spu_sub(d1, d2));
#else
  vector float vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});

  xyzw1 = vec_madd(v1, plane, vzero);
  xyzw2 = vec_madd(v2, plane, vzero);

  yzwx1 = vec_sld(xyzw1, xyzw1, 4);
  zwxy1 = vec_sld(xyzw1, xyzw1, 8);
  wxyz1 = vec_sld(xyzw1, xyzw1, 12);

  yzwx2 = vec_sld(xyzw2, xyzw2, 4);
  zwxy2 = vec_sld(xyzw2, xyzw2, 8);
  wxyz2 = vec_sld(xyzw2, xyzw2, 12);

  d1 = vec_add(vec_add(xyzw1, yzwx1), vec_add(zwxy1, wxyz1));
  d2 = vec_add(vec_add(xyzw2, yzwx2), vec_add(zwxy2, wxyz2));

  t = _divf4(d1, vec_sub(d1, d2));
#endif

  return (t);
}
#endif /* _CLIP_RAY_H_ */
