/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CROSS_PRODUCT3_V_H_
#define _CROSS_PRODUCT3_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	_cross_product3(vector float *xOut, vector float *yOut, vector float *zOut,
 *                      vector float x1, vector float y1, vector float z1,
 *                      vector float x2, vector float y2, vector float z2)
 * 
 * DESCRIPTION
 * 	_cross_product3_v simultaneously computes 4 cross products of 
 *	the two 3 component input vectors. The input and output vectors
 *	are maintained in parallel arrays (ie, each component of 4
 *	input vectors resides in a single floating vector). In this form,
 *	then SIMD processing is encoded as if it were scalar code.
 *        
 *		*xOut = (y1 * z2) - (z1 * y2)
 *		*yOut = (z1 * x2) - (x1 * z2)
 *		*zOut = (x1 * y2) - (y1 * x2)
 */

static __inline void _cross_product3_v(vector float *xOut, vector float *yOut, vector float *zOut, vector float x1, vector float y1, vector float z1, vector float x2, vector float y2, vector float z2)
{
  vector float x, y, z;
#ifdef __SPU__
  x = spu_mul(y1, z2);
  y = spu_mul(z1, x2);
  z = spu_mul(x1, y2);

  *xOut = spu_nmsub(z1, y2, x);
  *yOut = spu_nmsub(x1, z2, y);
  *zOut = spu_nmsub(y1, x2, z);
#else
  vector float vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});

  x = vec_madd(y1, z2, vzero);
  y = vec_madd(z1, x2, vzero);
  z = vec_madd(x1, y2, vzero);

  *xOut = vec_nmsub(z1, y2, x);
  *yOut = vec_nmsub(x1, z2, y);
  *zOut = vec_nmsub(y1, x2, z);
#endif
}

#endif /* _CROSS_PRODUCT3_V_H_ */
