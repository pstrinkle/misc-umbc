/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _XFORM_NORM3_H
#define _XFORM_NORM3_H	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	vector float _xform_norm3(vector float vec, const vector float *m)
 * 
 * DESCRIPTION
 *	_xform_norm3 transforms a 3-D normal vector by the upper left 3x4
 *	matrix of a 4x4 matrix producing a reoriented 3-D normal vector. 
 *
 *	[result] = [vec] * [  *(m+0)  ]
 *                         [  *(m+1)  ]
 *			   [  *(m+2)  ]
 *
 *	The 4 component of the output vector is undefined.
 */

static __inline vector float _xform_norm3 (vector float vec, const vector float *m)
{
  vector float m0, m1, m2;
  vector float x, y, z;
  vector float result;
#ifdef __SPU__
  vector unsigned char splat0 = ((vector unsigned char) {
					    0, 1, 2, 3, 0, 1, 2, 3,
					    0, 1, 2, 3, 0, 1, 2, 3});
  vector unsigned char splat1, splat2;

  m0 = *(m+0);
  m1 = *(m+1);
  m2 = *(m+2);

  splat1 = spu_or(splat0, 0x04);
  splat2 = spu_or(splat0, 0x08);

  x = spu_shuffle(vec, vec, splat0);
  y = spu_shuffle(vec, vec, splat1);
  z = spu_shuffle(vec, vec, splat2);

  result = spu_mul(x, m0);
  result = spu_madd(y, m1, result);
  result = spu_madd(z, m2, result);

#else /* !__SPU__ */
  vector float vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});

  m0 = *(m+0);
  m1 = *(m+1);
  m2 = *(m+2);

  x = vec_splat(vec, 0);
  y = vec_splat(vec, 1);
  z = vec_splat(vec, 2);

  result = vec_madd(x, m0, vzero);
  result = vec_madd(y, m1, result);
  result = vec_madd(z, m2, result);
#endif /* __SPU__ */

  return(result);
}

#endif /* _XFORM_NORM3_H */
