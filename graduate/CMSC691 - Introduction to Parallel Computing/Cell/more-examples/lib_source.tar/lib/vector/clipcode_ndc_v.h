/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CLIPCODE_NDC_V_H_
#define _CLIPCODE_NDC_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	vector unsigned int _clipcode_ndc(vector float x, vector float y,
 *					  vector float z, vector float w)
 * 
 * DESCRIPTION
 *	_clipcode_ndc generates a vector of 4 clip codes for the
 *	4 normalized, device coordinates specified as parrallel arrays
 *	by the inputs x,y,z,w.
 *
 *	Each of clipcode is a set of bit flags indicating if the vertex
 *	is outside the half-space defined by the -1.0 to 1.0 volume.
 *	Defines for each of the 6 bit-flags are defined in libvertex.h
 *
 *	The clipcodes are logically computed with the folowing pseduo-code:
 *
 *	  code = 0;
 *	  if (x < -w) code |= CLIP_CODE_LEFT;
 *	  if (x >  w) code |= CLIP_CODE_RIGHT;
 *	  if (y < -w) code |= CLIP_CODE_BOTTOM;
 *	  if (y >  w) code |= CLIP_CODE_TOP;
 *	  if (z < -w) code |= CLIP_CODE_NEAR;
 *	  if (z >  w) code |= CLIP_CODE_FAR;
 */


static __inline vector unsigned int _clipcode_ndc_v(vector float x, vector float y, vector float z, vector float w)
{
  vector unsigned int code;

#ifdef __SPU__
  vector float minus_w;
  vector unsigned int left, right, top, bottom, near, far;
  vector unsigned int lr, bt, nf;

  minus_w = (vector float)spu_xor((vector unsigned int)w, spu_splats((unsigned int)0x80000000));

  left   = spu_cmpgt(minus_w, x);
  bottom = spu_cmpgt(minus_w, y);
  near   = spu_cmpgt(minus_w, z);

  right  = spu_cmpgt(x, w);
  top    = spu_cmpgt(y, w);
  far    = spu_cmpgt(z, w);

  lr     = spu_sel(right, left, spu_splats((unsigned int)0x55));
  bt     = spu_sel(top, bottom, spu_splats((unsigned int)0x55));
  nf     = spu_sel(far, near,   spu_splats((unsigned int)0x55));
  
  lr     = (vector unsigned int)spu_and((vector unsigned char)(lr), 0xC0);
  bt     = (vector unsigned int)spu_and((vector unsigned char)(bt), 0x30);
  nf     = (vector unsigned int)spu_and((vector unsigned char)(nf), 0x0C);

  code   = spu_and(spu_or(spu_or(lr, bt), nf), spu_splats((unsigned int)0xFF));
#else
  vector unsigned int cmp_x, cmp_y, cmp_z;

  cmp_x = vec_sr((vector unsigned int)vec_cmpb(x, w), ((vector unsigned int) {24,24,24,24}));
  cmp_y = vec_sr((vector unsigned int)vec_cmpb(y, w), ((vector unsigned int) {26,26,26,26}));
  cmp_z = vec_sr((vector unsigned int)vec_cmpb(z, w), ((vector unsigned int) {28,28,28,28}));

  code  = vec_or(vec_or(cmp_x, cmp_y), cmp_z);
#endif

  return (code);
}

#endif /* _CLIPCODE_NDC_V_H_ */



