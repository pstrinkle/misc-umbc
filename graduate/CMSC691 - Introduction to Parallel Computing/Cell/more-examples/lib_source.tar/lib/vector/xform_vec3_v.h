/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _XFORM_VEC3_V_H
#define _XFORM_VEC3_V_H		1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include "xform_vec_macros.h"

/*
 * FUNCTION:
 *   void _xform_vec3_v (vector float *xout, vector float *yout, vector float *zout, 
 *                       vector float *wout, vector float xin, vector float yin, 
 *			 vector float zin, const vector float *m)
 * 
 * DESCRIPTION:
 *	_xform_vec3 transforms 4  3-D vectors by a replicated 4x4 matrix producing 4 
 *	transformed 4-D vector. The W (4th) component of the input vector is assumed
 *	to equal 1.0.
 *
 *	[out] = [in] * [ m ]
 *
 *	The input (xin, yin, zin) and output vectors (xout, yout, zout, wout) are 
 *	specified in parallel array format (ie, each vector component, x, y, z & w,
 *	are maintained in seperate arrays. For this routine, the arrays are 128-bit
 *	floating-point vectors and thus contain 4 entries.
 *
 *	The input matrix is a 4x4 array of 128-bit, floating-point vectors. Typically,
 *	this is a replicated matric created by splat_matrix4x4. However, the matrix
 *	need not be replicated. Each component of the matrix entries is used to transform
 *	the corresponding component of the inputs.
 */



static __inline void _xform_vec3_v(vector float *xout, vector float *yout, vector float *zout, vector float *wout, vector float xin, vector float yin, vector float zin, const vector float *m) 
{
  _DECLARE_MATRIX_4X4_V(m);
  _LOAD_MATRIX_4X4_V(m);

  _XFORM_VEC3_V(xout, yout, zout, wout, xin, yin, zin, m);
}

#endif /* XFORM_VEC3_V_H */
