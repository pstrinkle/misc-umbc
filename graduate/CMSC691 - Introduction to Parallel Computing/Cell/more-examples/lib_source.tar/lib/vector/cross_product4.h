/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CROSS_PRODUCT4_H_
#define _CROSS_PRODUCT4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	vector float _cross_product4(vector float v1, vector float v2)
 * 
 * DESCRIPTION
 * 	_cross_product4 computes the cross product of the two 4-component
 *	input vectors -	v1 cross v2. Traditional, the cross product 
 *	is performed in 3-component vectors. This routine treats the 
 *	input vectors a 3-d vectors with a 4th component scalar - w. The
 *	resulting 4th component is the scalar product of the input
 *	4th components.
 *           _______________________________
 *          |___X___|___Y___|___Z___|___W___|
 *        
 *	out.x = (v1.y * v2.z) - (v1.z * v2.y)
 *	out.y = (v1.z * v2.x) - (v1.x * v2.z)
 *	out.z = (v1.x * v2.y) - (v1.y * v2.x)
 *	out.w = (v1.w * v2*w)
 */

static __inline vector float _cross_product4(vector float v1, vector float v2)
{
  vector float yzx01, yzxw2;
  vector float result;
  vector unsigned char shuffle_yzxw = ((vector unsigned char) {
						  0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B,
						  0x00, 0x01, 0x02, 0x03, 0x1C, 0x1D, 0x1E, 0x1F});
							    
#ifdef __SPU__
  vector float vzero = spu_splats((float)0.0f);

  yzx01  = spu_shuffle(v1, vzero, shuffle_yzxw);
  yzxw2  = spu_shuffle(v2, v2, shuffle_yzxw);
  result = spu_mul(v1, yzxw2);
  result = spu_nmsub(v2, yzx01, result);
  result = spu_shuffle(result, result, shuffle_yzxw);
#else
  vector float vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});

  yzx01  = vec_perm(v1, vzero, shuffle_yzxw);
  yzxw2  = vec_perm(v2, v2, shuffle_yzxw);
  result = vec_madd(v1, yzxw2, vzero);
  result = vec_nmsub(v2, yzx01, result);
  result = vec_perm(result, result, shuffle_yzxw);
#endif
  return (result);
}


#endif /* _CROSS_PRODUCT4_H_ */
