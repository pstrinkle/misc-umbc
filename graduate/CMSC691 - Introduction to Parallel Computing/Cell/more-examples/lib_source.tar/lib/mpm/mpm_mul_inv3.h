/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MPM_MUL_INV3_H_
#define _MPM_MUL_INV3_H_	1

#include <spu_intrinsics.h>
#include "mpm_defines.h"
#include "mpm_macros.h"
#include "mpm_cmpge.h"
#include "mpm_cmpgt.h"
#include "mpm_div.h"
#include "mpm_sub.h"
#include "mpm_sizeof.h"
#include "mpm_div2.h"
#include "mpm_add3.h"
#include "mpm_mul.h"
#include "mpm_mod.h"

/* mpm_mul_inv3
 * ------------
 * Routine that computes the multiplicative inverse of large numbers 
 * <a> and <b> of size <asize> and <bsize> quadwords respectively. The multiplicative 
 * inverse is the value <mi> of <asize> quadwords such that
 *
 *	(mi * b) % a = 1
 *
 * If the multiplicative inverse does not exit than 0 is returned. Otherwise,
 * 1 is returns and the large number pointed to by <mi> is filled with the
 * result.
 *
 * This function assumes that a > b > 0.
 *
 * The basic algorithn is:
 *
 * 1. If the lsb of both a and b are 0, then return 0.
 * 2. c = a / b
 *    d = a % b
 * 3. if (d == 0) then 
 *    3.1  if (b == 1) then mi = 1
 *         3.1.1   mi = 1
 *         3.1.2   return 1
 *         else
 *         3.1.3   return 0   "does not exist"
 *    else if (d == 1) then
 *    3.2  mi = a - c
 *    3.3  return 1
 *    endif
 * 4. u = d
 * 5. v = b
 * 6. q = 1
 * 7. r = 0
 * 8. s = 0
 * 9. t = 1
 * 10. do
 *     10.1  while the lsb of u is 0
 *           10.1.1  u >>= 1
 *           10.1.2  if lsb of q or r is 1 then
 *                   10.1.2.1  q += b
 *                   10.1.2.2  r -= d
 *           10.1.3  q >>= 1
 *           10.1.4  r >>= 1
 *     10.2  while the lsb of v is 0
 *           10.2.1  v >>= 1
 *           10.2.2  if lsb of s or t is 1 then
 *                   10.2.2.1  s += b
 *                   10.2.2.2  t -= d
 *           10.2.3  s >>= 1
 *           10.2.4  t >>= 1
 *     10.3  if (u >= v) then
 *           10.3.1  u -= v
 *           10.3.2  q -= s
 *           10.3.3  r -= t
 *           else
 *           10.3.4  v -= u
 *           10.3.5  s -= q
 *           10.3.6  t -= r
 *     while (u != 0);
 * 11. if (v == 1) then
 *     11.1  if (t < 0) then
 *           11.1.1  t = |t|
 *           11.1.2  if (t > d) then
 *                   11.1.2.1  t = t % d
 *           11.1.3  t = d - t
 *     11.2  h = (b*t)/d
 *     11.3  mi = t + c*h
 *     11.5  return 1
 *     else
 *     11.6  return 0 	"does not exist"
 *     endif
 */

static __inline int _mpm_mul_inv3(vector unsigned int *mi, const vector unsigned int *a, int asize, const vector unsigned int *b, int bsize)
{
  int i, delta;
  int uvsize, tsize, hsize, csize, size;
  vector unsigned int or, or_u;
  vector unsigned int zero = spu_splats((unsigned int)0);
  vector unsigned int one  = spu_splats((unsigned int)1);
  vector unsigned int msb  = ((vector unsigned int) { 0x80000000, 0, 0, 0});
  vector unsigned int lsb  = ((vector unsigned int) { 0, 0, 0, 1});
  vector unsigned int no_carry, addend;
  vector unsigned int borrow, b0, b1, b2, carry;
  vector unsigned int d0;
  vector unsigned int u0, v0, q0, r0, s0, t0;
  vector unsigned int u1, v1, q1, r1, s1, t1;
  vector unsigned int q_msw, r_msw, s_msw, t_msw;
  vector unsigned int h[2*MPM_MAX_SIZE];
  vector unsigned int c[MPM_MAX_SIZE];
  vector unsigned int d[MPM_MAX_SIZE];
  vector unsigned int u[MPM_MAX_SIZE];
  vector unsigned int v[MPM_MAX_SIZE];
  vector unsigned int q[MPM_MAX_SIZE];
  vector unsigned int r[MPM_MAX_SIZE];
  vector unsigned int s[MPM_MAX_SIZE];
  vector unsigned int t[MPM_MAX_SIZE];
  vector unsigned int *pu, *pv;
  vector unsigned int *pc, *ph, *pt;

  /* 1. If the least significant bits of both a and b are 0, then return 0
   * indicating that the multiplication inverse does not exist.
   */
  if (spu_extract(spu_and(spu_or(a[asize-1], b[bsize-1]), 1), 3) == 0) {
    return 0;
  }

  /* 2. c = a / b
   *    d = a % b
   */
  _mpm_div(c, d, a, asize, b, bsize);

  /* 3. if (d <= 0) then
   */
  d0 = d[bsize-1];
  or = spu_andc(d0, lsb);
  for (i=bsize-2; i>=0; i--) or = spu_or(or, d[i]);

  if (__builtin_expect((spu_extract(spu_gather(spu_cmpeq(or, 0)), 0) == 15), 0)) {
    if (spu_extract(d0, 3)) {
      /* 3.2  {d == 1}
       *      mi = a - c
       * 3.3  return 1
       */
      _mpm_sub(mi, a, c, asize);
      return (1);
    } else {
      /* 3.1 if (b == 1) 
       */
      or = spu_splats((unsigned int)0);
      for (i=0; i<bsize-1; i++) or = spu_or(or, b[i]);
      or = spu_or(or, spu_xor(b[i], lsb));
      if (spu_extract(spu_gather(spu_cmpeq(or, 0)), 0) == 15) {
	/* 3.1.1  mi = 1
	 *        return 1
	 */
	for (i=0; i<asize-1; i++) mi[i] = spu_splats((unsigned int)0);
	mi[i] = lsb;
	return (1);
      } else {
	/* 3.1.2 return 0   "does not exist"
	 */
	return (0);
      }
    }
  }

  /* 4. u = d
   * 5. v = b
   * 6. q = 1
   * 7. r = 0
   * 8. s = 0
   * 9. t = 1
   *
   * q, r, s, and t can be up to 1 word larger than a. The extra word will be 
   * stored in element 3 of the vectors q_msw, r_msw, s_msw, t_msw.
   */
  for (i=0; i<bsize-1; i++) {
    u[i] = d[i];
    v[i] = b[i];
    q[i] = r[i]  = s[i] = t[i] = zero;
  }
  u[i] = d[i];
  v[i] = b[i];
  r[i] = s[i]  = zero;
  q[i] = t[i]  = lsb;

  or_u  = lsb;
  q_msw = r_msw = s_msw = t_msw = zero;

  uvsize = bsize;
  pu = u;
  pv = v;

  /* 10. do
   */
  do {
    /* 10.1 while the lsb of u is 0
     */
    while ((spu_extract(u[bsize-1], 3) & 1) == 0) {
      /* 10.1.2 if lsb of q or r is 1
       */
      or_u = zero;

      if (__builtin_expect(spu_extract(spu_or(q[bsize-1], r[bsize-1]), 3) & 1, 1)) {
	/* 10.1.2.1/10.1.3  q = (q+b) >> 1
	 * 10.1.2.2/10.1.4  r = (r-d) >> 1
	 * 10.1.1           u >>= 1
	 */
	MPM_ADD_FULL(q1, carry, q[bsize-1],  b[bsize-1], zero)
	carry = spu_rlmaskqwbyte(carry, -12);
	MPM_SUB_FULL(r1, borrow, r[bsize-1], d[bsize-1], one)

	u1 = spu_rlqw(spu_rlqwbyte(u[bsize-1], 15), 7);
	q1 = spu_rlqw(spu_rlqwbyte(q1, 15), 7);
	r1 = spu_rlqw(spu_rlqwbyte(r1, 15), 7);

	for (i=bsize-2; i>=0; i--) {
	  MPM_ADD_FULL(q0, carry, q[i],  b[i], carry)
	  carry = spu_rlmaskqwbyte(carry, -12);
	  MPM_SUB_FULL(r0, borrow, r[i], d[i], borrow)

	  u0 = spu_rlqw(spu_rlqwbyte(u[i], 15), 7);
	  q0 = spu_rlqw(spu_rlqwbyte(q0, 15), 7);
	  r0 = spu_rlqw(spu_rlqwbyte(r0, 15), 7);

	  u1 = spu_sel(u1, u0, msb);

	  u[i+1] = u1;
	  q[i+1] = spu_sel(q1, q0, msb);
	  r[i+1] = spu_sel(r1, r0, msb);

	  or_u = spu_or(or_u, u1);

	  u1 = u0;
	  q1 = q0;
	  r1 = r0;
	}
	q0 = spu_add(q_msw, carry);
	r0 = spu_subx(r_msw, zero, borrow);

	u0 = spu_sel(u1, zero, msb);
	u[0] = u0;
	q[0] = spu_sel(q1, spu_rlqwbyte(spu_rl(q0, -1), 12), msb);
	r[0] = spu_sel(r1, spu_rlqwbyte(spu_rl(r0, -1), 12), msb);
	
	or_u = spu_or(u0, or_u);

	q_msw = spu_rlmaska(q0, -1);
	r_msw = spu_rlmaska(r0, -1);

      } else {
	/* 10.1.1  u >>= 1
	 * 10.1.3  q >>= 1
	 * 10.1.4  r >>= 1
	 */
	u0 = spu_splats((unsigned int)0);
	q0 = spu_rlqwbyte(spu_rl(q_msw, -1), 12);
	r0 = spu_rlqwbyte(spu_rl(r_msw, -1), 12);
	q_msw = spu_rlmaska(q_msw, -1);
	r_msw = spu_rlmaska(r_msw, -1);
	for (i=0; i<bsize; i++) {
	  u1 = spu_rlqw(spu_rlqwbyte(u[i], 15), 7);
	  q1 = spu_rlqw(spu_rlqwbyte(q[i], 15), 7);
	  r1 = spu_rlqw(spu_rlqwbyte(r[i], 15), 7);

	  u0 = spu_sel(u1, u0, msb);

	  u[i] = u0;
	  q[i] = spu_sel(q1, q0, msb);
	  r[i] = spu_sel(r1, r0, msb);

	  or_u = spu_or(u0, or_u);

	  u0 = u1;
	  q0 = q1;
	  r0 = r1;
	}
      }
    }

    /* 10.2 while the lsb of v is 0
     */
    while ((spu_extract(v[bsize-1], 3) & 1) == 0) {
      /* 10.2.2 if lsb of s or t is 1
       */
      if (__builtin_expect(spu_extract(spu_or(s[bsize-1], t[bsize-1]), 3) & 1, 1)) {
	/* 10.2.2.1/10.2.3  s = (s+b) >> 1
	 * 10.2.2.2/10.2.4  t = (t-d) >> 1
	 * 10.2.1           v >>= 1
	 */
	MPM_ADD_FULL(s1, carry, s[bsize-1],  b[bsize-1], zero)
	carry = spu_rlmaskqwbyte(carry, -12);
	MPM_SUB_FULL(t1, borrow, t[bsize-1], d[bsize-1], one)

	v1 = spu_rlqw(spu_rlqwbyte(v[bsize-1], 15), 7);
	s1 = spu_rlqw(spu_rlqwbyte(s1, 15), 7);
	t1 = spu_rlqw(spu_rlqwbyte(t1, 15), 7);

	for (i=bsize-2; i>=0; i--) {
	  MPM_ADD_FULL(s0, carry, s[i],  b[i], carry);
	  carry = spu_rlmaskqwbyte(carry, -12);
	  MPM_SUB_FULL(t0, borrow, t[i], d[i], borrow);

	  v0 = spu_rlqw(spu_rlqwbyte(v[i], 15), 7);
	  s0 = spu_rlqw(spu_rlqwbyte(s0, 15), 7);
	  t0 = spu_rlqw(spu_rlqwbyte(t0, 15), 7);

	  v[i+1] = spu_sel(v1, v0, msb);
	  s[i+1] = spu_sel(s1, s0, msb);
	  t[i+1] = spu_sel(t1, t0, msb);

	  v1 = v0;
	  s1 = s0;
	  t1 = t0;
	}
	s0 = spu_add(s_msw, carry);
	t0 = spu_subx(t_msw, zero, borrow);

	v[0] = spu_sel(v1, zero, msb);
	s[0] = spu_sel(s1, spu_rlqwbyte(spu_rl(s0, -1), 12), msb);
	t[0] = spu_sel(t1, spu_rlqwbyte(spu_rl(t0, -1), 12), msb);
	
	s_msw = spu_rlmaska(s0, -1);
	t_msw = spu_rlmaska(t0, -1);

      } else {
	/* 10.1.1  v >>= 1
	 * 10.1.3  s >>= 1
	 * 10.1.4  t >>= 1
	 */
	v0 = spu_splats((unsigned int)0);
	s0 = spu_rlqwbyte(spu_rl(s_msw, -1), 12);
	t0 = spu_rlqwbyte(spu_rl(t_msw, -1), 12);
	s_msw = spu_rlmaska(s_msw, -1);
	t_msw = spu_rlmaska(t_msw, -1);
	for (i=0; i<bsize; i++) {
	  v1 = spu_rlqw(spu_rlqwbyte(v[i], 15), 7);
	  s1 = spu_rlqw(spu_rlqwbyte(s[i], 15), 7);
	  t1 = spu_rlqw(spu_rlqwbyte(t[i], 15), 7);

	  v[i] = spu_sel(v1, v0, msb);
	  s[i] = spu_sel(s1, s0, msb);
	  t[i] = spu_sel(t1, t0, msb);

	  v0 = v1;
	  s0 = s1;
	  t0 = t1;
	}
      }
    }


    /* 10.3 if (u >= v) 
     */
    if (_mpm_cmpge(pu, pv, uvsize)) {
      /* 10.3.1  u -= v
       * 10.3.2  q -= s
       * 10.3.3  r -= t
       */
      or_u = zero;

      b0 = b1 = b2 = one;
      for (i=bsize-1; i>=0; i--) {
	u0 = u[i]; v0 = v[i];
	q0 = q[i]; s0 = s[i];
	r0 = r[i]; t0 = t[i];

	MPM_SUB_FULL(u0,   b0, u0, v0, b0)
	MPM_SUB_FULL(q[i], b1, q0, s0, b1)
	MPM_SUB_FULL(r[i], b2, r0, t0, b2)

	or_u = spu_or(u0, or_u);
	u[i] = u0;
      }
      q_msw = spu_subx(q_msw, s_msw, b1);
      r_msw = spu_subx(r_msw, t_msw, b2);

    } else {
      /* 10.3.4  v -= u
       * 10.3.5  s -= q
       * 10.3.6  t -= r
       */
      b0 = b1 = b2 = one;
      for (i=bsize-1; i>=0; i--) {
	u0 = u[i]; v0 = v[i];
	q0 = q[i]; s0 = s[i];
	r0 = r[i]; t0 = t[i];
	MPM_SUB_FULL(v[i], b0, v0, u0, b0)
	MPM_SUB_FULL(s[i], b1, s0, q0, b1)
	MPM_SUB_FULL(t[i], b2, t0, r0, b2)
      }
      s_msw = spu_subx(s_msw, q_msw, b1);
      t_msw = spu_subx(t_msw, r_msw, b2);
    }

    /* Skip leading quadwords as u and v get smaller.
     */
    delta = (int)spu_extract(spu_cmpeq(spu_gather(spu_cmpeq(spu_or(*pu, *pv), 0)), 15), 0);
    pu -= delta;
    pv -= delta;
    uvsize += delta;

    /* while (u != 0) 
     */
  } while (spu_extract(spu_gather(spu_cmpeq(or_u, 0)), 0) != 15);


  /* 11. if (v == 1) then
   */
  for (i=uvsize-2, or=spu_xor(pv[uvsize-1], lsb); i>=0; i--) or = spu_or(or, pv[i]);

  if (spu_extract(spu_gather(spu_cmpeq(or, 0)), 0) != 15) {
    /* 11.6  multiplicative inverse does not exist.
     */
    return (0);
  }

  /* 11.1 if (t < 0)
   */
  pt = t;

  if ((signed int)spu_extract(t_msw, 3) < 0) {

    /* 11.1.1  t = |t|
     *         At this point t is expanded to a full bsize+1 quadwords
     */
    for (i=bsize-1; i>=0; i--) {
      t0 = t[i];
      t1 = spu_xor(t0, -1);
      no_carry = spu_xor(spu_cmpeq(t0, 0), -1);

      addend = spu_xor(spu_or(spu_slqwbyte(no_carry, 12), 
			      spu_or(spu_slqwbyte(no_carry, 8),
				     spu_slqwbyte(no_carry, 4))), -1);

      t[i+1] = spu_sub(t1, addend);

      if (spu_extract(spu_gather(no_carry), 0)) break;
    }
    
    if (i >= 0) {
      for (i--; i>=0; i--) t[i+1] = spu_xor(t[i], -1);
      t0 = spu_xor(t_msw, -1);
    } else {
      t0 = spu_sub(0, t_msw);
    }
    t0 = spu_and(t0, ((vector unsigned int) { 0, 0, 0, -1}));
    t[0] = t0;

    /* 11.1.2  if (t > d) 
     */
    if ((spu_extract(t0, 3)) | _mpm_cmpgt(&t[1], d, bsize)) {
      /* 11.1.2.1  t = t % d
       */
      _mpm_mod(&t[1], t, bsize+1, d, bsize);
      t[0] = spu_splats((unsigned int)0);
    }
    /* 11.1.3  t = d - t
     */
    _mpm_sub(&t[1], d, &t[1], bsize);

    pt++;
  } 
  /* 11.2   h = b*t/d
   */
  tsize = _mpm_sizeof(pt, bsize);
  pt += bsize - tsize;

  _mpm_mul(h, b, bsize, pt, tsize);
  hsize = bsize + tsize;

  _mpm_div2(h, h, hsize, d, bsize);

  /* 11.3  h *= c
   *       mi = t + h
   */
  csize = _mpm_sizeof(c, asize);
  pc = c + (asize - csize);
  size = _mpm_sizeof(h, hsize);
  ph = h + (hsize - size);
  hsize = size;

  _mpm_mul(h, pc, csize, ph, hsize);
  hsize += csize;

  _mpm_add3(mi, asize, pt, tsize, h, hsize);
  
  /* 11.4 if (mi > a) mi -= a;
   *
   * Note: This step is only needed if mi is required to
   *       be less than a.
   */
  if (_mpm_cmpgt(mi, a, asize)) {
    _mpm_sub(mi, mi, a, asize);
  }

  return (1);
}

#endif /* _MPM_MUL_INV3_H_ */
