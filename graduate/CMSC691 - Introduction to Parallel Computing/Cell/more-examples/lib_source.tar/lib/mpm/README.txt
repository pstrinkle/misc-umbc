%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Library containing multi-precision math routines.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory contains a collection of functions that perform
	math on multi-precision large numbers on the SPE.
	
	Functions included are:

	mpm_abs
		takes the absolute value of a large number

	mpm_add
	mpm_add2
	mpm_add3
	mpm_add_partial
		adds two large numbers
		
	mpm_cmpeq
	mpm_cmpeq2
		compares two large numbers; if the two numbers are equal,
		then all 1's is returned, else 0 is returned.

	mpm_cmpge
	mpm_cmpge2
		compares two unsigned large numbers; if the first is greater
		than or equal to the second, then all 1's is returned, else
		0 is returned.

	mpm_cmpgt
	mpm_cmpgt2
		compares two unsigned large numbers; if the first is greater
		than the second, then all 1's is returned, else 0 is returned

	mpm_div
	mpm_div2
		divides two large unsigned numbers

	mpm_fixed_mod_reduction
		computes a mod m

	mpm_gcd
		computes the greatest common divisor of two large unsigned
		numbers

	mpm_madd
		multiplies two large unsigned numbers and adds that result
		to a third large number

	mpm_mod
		computes the modulo of 2 large unsigned numbers
		
	mpm_mod_exp
	mpm_mod_exp2
	mpm_mod_exp3
		computes modular exponentiation (b ^ e) % m
		
	mpm_mont_mod_exp
	mpm_mont_mod_exp2
	mpm_mont_mod_exp3
		computes modular exponentiation (b ^ e) % m using Montgomery
		Multiplication

	mpm_mont_mod_mul
		performs Montgomery Modular multiplication of multi-precision
		numbers

	mpm_mul
		multiplies two large unsigned numbers

	mpm_mul_inv
	mpm_mul_inv2
	mpm_mul_inv3
		computes the multiplicative inverse of two large numbers

	mpm_neg
		negates a large number

	mpm_sizeof
		returns the true size of a large number - the highest order
		quadword that contain a non-zero value

	mpm_square
		squares a multi-precision unsigned number

	mpm_sub
	mpm_sub2
		subtracts two large numbers

	mpm_swap_endian
		swap the endian-ness (ie. byte ordering) of a large number

