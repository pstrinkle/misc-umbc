/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */


#ifndef _MPM_MONT_MOD_EXP2_H_
#define _MPM_MONT_MOD_EXP2_H_		1

#include <spu_intrinsics.h>
#include "mpm_mont_mod_mul.h"

/* mpm_mont_mod_exp2
 * -----------------
 * Generic routine that computes modular exponentiation using Montgomery 
 * Multiplication. This routine computes:
 *
 *	c = (b ^ e) % m
 *
 * where b, e, and m are large multi-precision numbers of msize, esize, 
 * and msize quadwords, respectively. The result, c, is of msize quadwords.
 *
 * The modulus m must be odd and b must be less than m.
 *
 * The input p is the word inverse factor as prescribed by the Montgomery
 * multiplication routine. It equals (2^128 - g) such that:
 *    (g * (m % 2^128)) % 2^128 = 1
 * 
 * The inputs a and u are pre-computed multiple precision numbers where:
 *    a = 2^(128*msize) % m 
 *    u = 2^(2*128*msize) % m
 *
 * This implementation uses a window-based modular exponentiation algorithm.
 * The maximum window size is specified by the input parameter k. 
 *
 * The basic algorithn is:
 *
 * 1.  s = b * u
 * 2.  T[1] = s
 * 3.  s = s * s
 * 4.  for i=1 to 2**(k-1) - 1 do
 *     4.1  T[2*i+1] = s * T[2*i-1]
 *     endfor
 * 5.  c = a
 * 6.  h = most significant non-zero bit of e
 * 7.  while h >= 0
 *     7.1  if bit h of e is 0 then
 *          7.1.1  c = c * c
 *          7.1.2  h -= 1
 *          else
 *          7.1.3  find longest bitstring z up to k bits whose lsb is 1
 *          7.1.4  for i = 1 to z do
 *                 7.1.4.1  c = c*c
 *                 endfor
 *          7.1.5  c = c * T[bitstring]
 *          7.1.6  h -= z
 *          endif
 * 8.  c = c * 1
 * 9.  return c
 *
 * Note: The operator "*" above corresponds to Montgomery modular (modulo m) 
 *       multiplication.
 *       
 *
 *       The T array has been compressed to contain only the odd values since 
 *       the window must have both the msb and lsb equal to 1.
 *
 *	 The parameter k specifies the window size to be applied. This number 
 *       must be 1 to MPM_MOD_EXP_MAX_K.
 */


static vector unsigned int _one_mpm_mont_mod_exp2[MPM_MAX_SIZE];

static __inline void _mpm_mont_mod_exp2(vector unsigned int *c, const vector unsigned int *b, const vector unsigned int *e, int esize, const vector unsigned int *m, int msize, int k, vector unsigned int p, vector unsigned int *a, vector unsigned int *u)
{
  int i;
  int h, T_idx, idx, window, bits_left;
  unsigned int shift;

  vector unsigned int window_size0, window_size1, selector, window_lsb;
  vector unsigned int qw0, qw1, qw;
  vector unsigned int *ptr, *next;
  vector unsigned int s[MPM_MAX_SIZE];
  vector unsigned int T[1 << (MPM_MOD_EXP_MAX_K-1)][MPM_MAX_SIZE]; 

  window_lsb = spu_rlmask(spu_splats((unsigned int)0x80000000), 1-k);

  ptr = &T[0][0];

  /* 1.  s = b * u
   * 2.  T[1] = s
   */
  _mpm_mont_mod_mul(ptr, b, u, m, msize, p);

  /* 3.  s = s * s
   */
  _mpm_mont_mod_mul(s, ptr, ptr, m, msize, p);
  
  /* 4.  for i=1 to 2**(k-1) - 1 do
   *     4.1  T[2*i+1] = s * T[2*i-1] % m
   *     endfor
   */
  for (i=1; i<(1<<(k-1)); i++) {
    next = ptr + MPM_MAX_SIZE;
    _mpm_mont_mod_mul(next, s, ptr, m, msize, p);
    ptr = next;
  }

  /* 5. c = a
   */
  for (i=0; i<msize; i++) c[i] = a[i];

  /* 6. Locate the most significant exponent bit
   */
  MPM_COUNT_LEADING_ZEROS(h, e, esize);

  /* 7.  while h >= 0
   *
   * Repeat until all the exponent bits are consumed
   */
  idx = h >> 7;
  h &= 127;
  bits_left = ((esize-idx) << 7) - h;

  qw0 = e[idx];
  qw1 = spu_and(e[idx+1], spu_maskw(spu_extract(spu_cmpgt(spu_promote(bits_left, 0), 128), 0)));


  while (bits_left) {
    /* Move the MPM_MOD_EXP_MAX_K (k) bits starting at bit h into the least 
     * significant bits of the preferred word slot.
     */
    shift = (unsigned int)(h) >> 3;

    qw = spu_slqw(spu_or(spu_slqwbyte(qw0, shift), 
		       spu_rlmaskqwbyte(qw1, (signed int)(shift-16))),
		(h & 7));

    /* Determine the window size. window_size0 is the window size if 
     * the bit at position h is a 0. window_size1 is the window size
     * if the bit a position h is a 1.
     */
    
    window_size0 = spu_cntlz(qw);
    window_size1 = spu_add(spu_cntlz(spu_xor(spu_sub(qw, window_lsb), qw)), 1);

    selector = spu_rlmaska(qw, -31);

    window = spu_extract(spu_sel(window_size0, window_size1, selector), 0);

    h += window;

    /* Don't let the window extend beyond the end of the exponent.
     */
    if (window > bits_left) window = bits_left;
    bits_left -= window;
    
    /* Handle all the squaring terms for the window.
     *
     * 7.1.1 and 7.1.5    c = c * c
     */
    for (i=0; i<window; i++) {
      _mpm_mont_mod_mul(c, c, c, m, msize, p);
    }

    /* The most significant bit of the window is a one. Multiply by
     * the pre-computed T array value.
     *
     * 7.1.5  c = c * T[bitstring]
     */
    if (spu_extract(selector, 0)) {
      T_idx = spu_extract(spu_rlmask(qw, window-33), 0);
      _mpm_mont_mod_mul(c, c, &T[T_idx][0], m, msize, p);
    }

    /* Advance to next quadword if it has been fully consumed.
     */
    if (h >> 7) {
      h &= 127;
      idx++;
      qw0 = qw1;
      qw1 = spu_and(e[idx+1], spu_maskw(spu_extract(spu_cmpgt(spu_promote(bits_left, 0), 128), 0)));
    }
  }
  /* 8.  c = c * 1
   */
  ptr = &_one_mpm_mont_mod_exp2[MPM_MAX_SIZE-msize];
  _one_mpm_mont_mod_exp2[MPM_MAX_SIZE-1] = ((vector unsigned int) { 0,0,0,1});
  _mpm_mont_mod_mul(c, c, ptr, m, msize, p);
}

#endif /* _MPM_MONT_MOD_EXP2_H_ */
