/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <spu_intrinsics.h>
#include "mpm_defines.h"
#include "mpm_macros.h"
#include "mpm_sub.h"

#ifndef _MPM_MONT_MOD_MUL_H_
#define _MPM_MONT_MOD_MUL_H_		1

/* mpm_mont_mod_mul
 * ----------------
 * The mpm_mont_mod_mul routine performs Montgomery Modular multiplication
 * of multi-precision numbers <a> and <b>, for the modulus <m>. The 
 * parameters <a>, <b>, and <m> are <size> quadwords in length. The result <c>
 * is also <size> quadwords in length.
 *
 * Inputs:
 *  a : multiplier of <size> quadwords. 0 <= a < m
 *  b : multiplier of <size> quadwords. 0 <= b < m
 *  m : modulus of <size> quadwords. m must be odd with a most significant 
 *      non-zero quadword.
 *  size : number of quadwords in a, b, c, and m.
 *  p : quadword inverse factor, where p = 2^128 - g, 1 <= p <= 2^128 - 1, 
 *      such that (g * (m % 2^128)) % 2^128 = 1
 *  
 * Output:
 *  c : result of <size> quadwords. Equals (a * b * y) % m, where y is
 *      the product inverse factor such that 0 < y < m. That is, 
 *      (y * (2^(128*size) % m)) % m = 1.
 *
 * This implementation attempts to reduce (as much as possible), dealing
 * with carry propogation. As such, carries are maintained in a seperate
 * array (d_carry), and only when a single quadword or the final result
 * is needed, then we add the accumulated carries to the products.
 *
 * Carry array:
 *                ------------ ------------ ------------   ------------
 *               |             : d_carry   :            | |  carry_lsq |
 *                ------------ ------------ ------------   ------------
 *
 * Produc array:
 *                ------------ ------------ ------------
 *               |            :     c      :            |
 *                ------------ ------------ ------------ 
 *
 *
 * Note: The multi-precision number "c" must not be "m".
 */
static vector unsigned int _zero_mpm_mont_mod_mul[MPM_MAX_SIZE];

static __inline void _mpm_mont_mod_mul(vector unsigned int *c, const vector unsigned int *a, const vector unsigned int *b, const vector unsigned int *m, int size, vector unsigned int p)
{
  int i, j;
  unsigned int too_large;
  vector unsigned short b0, b1;
  vector unsigned short u0, u1, u10, u32, u54, u76;
  vector unsigned short     p10, p32, p54, p76;
  vector unsigned short ai, a10, a32, a54, a76;
  vector unsigned short b0j, b1j, m0j, m1j;
  vector unsigned int u;
  vector unsigned int d[MPM_MAX_SIZE], *d_ptr;
  vector unsigned int d_carry[MPM_MAX_SIZE], *d_carry_ptr, carry_lsq, dj, dj_carry;
  vector unsigned int prod, carry, addend, sum;
  vector unsigned int ab0_0, ab1_0, ab0_1, ab1_1, ab0_2, ab1_2, ab0_3, ab1_3;
  vector unsigned int ab0_4, ab1_4, ab0_5, ab1_5, ab0_6, ab1_6, ab0_7, ab1_7;
  vector unsigned int um0_0, um1_0, um0_1, um1_1, um0_2, um1_2, um0_3, um1_3;
  vector unsigned int um0_4, um1_4, um0_5, um1_5, um0_6, um1_6, um0_7, um1_7;
  vector unsigned int ab_c1, ab_c2, ab_c3, ab_c4, ab_c5, ab_c6, ab_c7;
  vector unsigned int ab_s1, ab_s2, ab_s3, ab_s4, ab_s5, ab_s6, ab_s7;
  vector unsigned int um_c1, um_c2, um_c3, um_c4, um_c5, um_c6, um_c7;
  vector unsigned int um_s1, um_s2, um_s3, um_s4, um_s5, um_s6, um_s7;
  vector unsigned int prev_c0, prev_c1, prev_c2, prev_c3, prev_c4, prev_c5, prev_c6, prev_c7, prev_c8;
  vector unsigned int prev_s0, prev_s1, prev_s2, prev_s3, prev_s4, prev_s5, prev_s6, prev_s7, prev_s8;
  vector unsigned int s0, s1, s2, s3, s4, s5, s6, s7;
  vector unsigned int c0, c1, c2, c3, c4, c5, c6, c7;
  vector unsigned int ms1, ms2, ms3, ms4, ms5, ms6, ms7;
  vector unsigned int mc1, mc2, mc3, mc4, mc5, mc6, mc7;
  vector unsigned int mc01, mc23, mc45, mc67, mc0123, mc4567, mc01234567;
  vector unsigned int p01, p23, p45, p67;
  vector unsigned int c01, c23, c45, c67;
  vector unsigned int mi, gt, lt, gt_bigger, lt_bigger;
  vector unsigned char splat_short10 = (vector unsigned char)(spu_splats((unsigned int)0x0C0D0E0F));
  vector unsigned char splat_short32 = (vector unsigned char)(spu_splats((unsigned int)0x08090A0B));
  vector unsigned char splat_short54 = (vector unsigned char)(spu_splats((unsigned int)0x04050607));
  vector unsigned char splat_short76 = (vector unsigned char)(spu_splats((unsigned int)0x00010203));
  vector unsigned char dbl_qw_shl_2  = ((vector unsigned char) {
						   0x02, 0x03, 0x04, 0x05, 
						   0x06, 0x07, 0x08, 0x09,
						   0x0A, 0x0B, 0x0C, 0x0D,
						   0x0E, 0x0F, 0x10, 0x11});
  vector unsigned char dbl_qw_shl_4  = ((vector unsigned char) {
						   0x04, 0x05, 0x06, 0x07, 
						   0x08, 0x09, 0x0A, 0x0B,
						   0x0C, 0x0D, 0x0E, 0x0F,
						   0x10, 0x11, 0x12, 0x13});
  vector unsigned char dbl_qw_shl_6  = ((vector unsigned char) {
						   0x06, 0x07, 0x08, 0x09, 
						   0x0A, 0x0B, 0x0C, 0x0D,
						   0x0E, 0x0F, 0x10, 0x11,
						   0x12, 0x13, 0x14, 0x15});
  vector unsigned char dbl_qw_shl_8  = ((vector unsigned char) {
						   0x08, 0x09, 0x0A, 0x0B, 
						   0x0C, 0x0D, 0x0E, 0x0F,
						   0x10, 0x11, 0x12, 0x13,
						   0x14, 0x15, 0x16, 0x17});
  vector unsigned char dbl_qw_shl_10 = ((vector unsigned char) {
						   0x0A, 0x0B, 0x0C, 0x0D,
						   0x0E, 0x0F, 0x10, 0x11,
						   0x12, 0x13, 0x14, 0x15, 
						   0x16, 0x17, 0x18, 0x19});
  vector unsigned char dbl_qw_shl_12 = ((vector unsigned char) {
						   0x0C, 0x0D, 0x0E, 0x0F,
						   0x10, 0x11, 0x12, 0x13,
						   0x14, 0x15, 0x16, 0x17,
						   0x18, 0x19, 0x1A, 0x1B});
  vector unsigned char dbl_qw_shl_14 = ((vector unsigned char) {
						   0x0E, 0x0F, 0x10, 0x11,
						   0x12, 0x13, 0x14, 0x15, 
						   0x16, 0x17, 0x18, 0x19,
						   0x1A, 0x1B, 0x1C, 0x1D});

  /* 1)  d = 0
   */
  carry_lsq = spu_splats((unsigned int)0);
  d_ptr = d_carry_ptr = _zero_mpm_mont_mod_mul;

  ai = (vector unsigned short)(a[size-1]);

  b0 = (vector unsigned short)(b[size-1]);
  b1 = (vector unsigned short)(spu_rl((vector unsigned int)(b0), 16));

  p10 = (vector unsigned short)spu_shuffle(p, p, splat_short10);
  p32 = (vector unsigned short)spu_shuffle(p, p, splat_short32);
  p54 = (vector unsigned short)spu_shuffle(p, p, splat_short54);
  p76 = (vector unsigned short)spu_shuffle(p, p, splat_short76);

  /* 2)  for i = size - 1 to 0 
   */
  for (i=size-1; i>=0; ) {
    j = size-1;

    /* 2.1)  u = (c[j] + a[i] * b[j]) * p
     */
    a10 = spu_shuffle(ai, ai, splat_short10);
    a32 = spu_shuffle(ai, ai, splat_short32);
    a54 = spu_shuffle(ai, ai, splat_short54);
    a76 = spu_shuffle(ai, ai, splat_short76);

    /*		Compute d[j] + a[i] * b[j].
     */
    dj = d_ptr[j];
    dj_carry = d_carry_ptr[j];

    ab0_0 = spu_mulo(b0, a10);	/* A6*B0 A4*B0 A2*B0 A0*B0 */
    ab1_0 = spu_mulo(b1, a10);	/* A7*B0 A5*B0 A3*B0 A1*B0 */
    ab0_1 = spu_mule(b1, a10);	/* A6*B1 A4*B1 A2*B1 A0*B1 */
    ab1_1 = spu_mule(b0, a10);	/* A7*B1 A5*B1 A3*B1 A1*B1 */

    ab0_2 = spu_mulo(b0, a32);	/* A6*B2 A4*B2 A2*B2 A0*B2 */
    ab1_2 = spu_mulo(b1, a32);	/* A7*B2 A5*B2 A3*B2 A1*B2 */
    ab0_3 = spu_mule(b1, a32);	/* A6*B3 A4*B3 A2*B3 A0*B3 */
    ab1_3 = spu_mule(b0, a32);	/* A7*B3 A5*B3 A3*B3 A1*B3 */

    ab0_4 = spu_mulo(b0, a54);	/* A6*B4 A4*B4 A2*B4 A0*B4 */
    ab1_4 = spu_mulo(b1, a54);	/* A7*B4 A5*B4 A3*B4 A1*B4 */
    ab0_5 = spu_mule(b1, a54);	/* A6*B5 A4*B5 A2*B5 A0*B5 */
    ab1_5 = spu_mule(b0, a54);	/* A7*B5 A5*B5 A3*B5 A1*B5 */

    ab0_6 = spu_mulo(b0, a76);	/* A6*B6 A4*B6 A2*B6 A0*B6 */
    ab1_6 = spu_mulo(b1, a76);	/* A7*B6 A5*B6 A3*B6 A1*B6 */
    ab0_7 = spu_mule(b1, a76);	/* A6*B7 A4*B7 A2*B7 A0*B7 */

    ab1_7 = spu_mule(b0, a76);

    ab_c1 = spu_genc(ab1_0, ab0_1);
    ab_s1 = spu_add(ab1_0, ab0_1);

    ab_c2 = spu_genc(ab1_1, ab0_2);
    ab_s2 = spu_add(ab1_1, ab0_2);

    ab_c3 = spu_genc(ab1_2, ab0_3);
    ab_s3 = spu_add(ab1_2, ab0_3);

    ab_c4 = spu_genc(ab1_3, ab0_4);
    ab_s4 = spu_add(ab1_3, ab0_4);

    ab_c5 = spu_genc(ab1_4, ab0_5);
    ab_s5 = spu_add(ab1_4, ab0_5);

    ab_c6 = spu_genc(ab1_5, ab0_6);
    ab_s6 = spu_add(ab1_5, ab0_6);

    ab_c7 = spu_genc(ab1_6, ab0_7);
    ab_s7 = spu_add(ab1_6, ab0_7);

    mc1   = spu_slqwbyte(ab_c1, 2);
    ms1   = spu_slqwbyte(ab_s1, 2);

    mc2   = spu_slqwbyte(ab_c2, 4);
    ms2   = spu_slqwbyte(ab_s2, 4);

    mc3   = spu_slqwbyte(ab_c3, 6);
    ms3   = spu_slqwbyte(ab_s3, 6);

    mc4   = spu_slqwbyte(ab_c4, 8);
    ms4   = spu_slqwbyte(ab_s4, 8);

    mc5   = spu_slqwbyte(ab_c5, 10);
    ms5   = spu_slqwbyte(ab_s5, 10);

    mc6   = spu_slqwbyte(ab_c6, 12);
    ms6   = spu_slqwbyte(ab_s6, 12);

    mc7   = spu_slqwbyte(ab_c7, 14);
    ms7   = spu_slqwbyte(ab_s7, 14);

    /* 		Accumulate the product terms and c, keep the carry in
     * 		a seperate word. Carry propagation is not deferred until
     *		the end. Instead, we propogate as we quit introducing 
     *		additional carry conditions.
     */
    carry_lsq = spu_rlmaskqwbyte(carry_lsq, -12);      

    c01 = spu_add(dj_carry, mc1);
    MPM_ADD_PARTIAL(p01, c01,  dj, ab0_0, c01);
    MPM_ADD_PARTIAL(p01, c01, p01, ms1, c01);
    MPM_ADD_PARTIAL(p01, c01, p01, carry_lsq, c01);


    c01 = spu_slqwbyte(c01, 4);
    c23 = spu_add(mc2, mc3);
    MPM_ADD_PARTIAL(p23, c23, ms2, ms3, c23);
    MPM_ADD_PARTIAL(p23, c23, p23, p01, c23);
    MPM_ADD_PARTIAL(p23, c23, p23, c01, c23);

    c23 = spu_slqwbyte(c23, 4);
    c45 = spu_add(mc4, mc5);
    MPM_ADD_PARTIAL(p45, c45, ms4, ms5, c45);
    MPM_ADD_PARTIAL(p45, c45, p45, p23, c45);
    MPM_ADD_PARTIAL(p45, c45, p45, c23, c45);

    c45 = spu_slqwbyte(c45, 4);
    p67 = spu_add(ms6, ms7);
    p67 = spu_add(p67, p45);
    u = spu_add(p67, c45);

    u0 = (vector unsigned short)(u);
    u1 = (vector unsigned short)(spu_rl(u, 16));
    MPM_MUL_4_4_LOW(u, u0, u1, p10, p32, p54, p76);

    /* 2.2)  d = (d + (a[i] * b) + (u * m)) >> 128;
     */
    u0  = (vector unsigned short)(u);
    u10 = spu_shuffle(u0, u0, splat_short10);
    u32 = spu_shuffle(u0, u0, splat_short32);
    u54 = spu_shuffle(u0, u0, splat_short54);
    u76 = spu_shuffle(u0, u0, splat_short76);

    m0j = (vector unsigned short)(m[j]);
    m1j = (vector unsigned short)(spu_rl((vector unsigned int)(m0j), 16));
      
    /* Compute the partial products for
     *   a[i] * b[j]   and 
     *      u * m[j]
     *
     * Note: partial products a[i]*b[j] were computed when
     *       generating u.
     */
    um0_0 = spu_mulo(m0j, u10);
    um1_0 = spu_mulo(m1j, u10);
    um0_1 = spu_mule(m1j, u10);
    um1_1 = spu_mule(m0j, u10);

    um0_2 = spu_mulo(m0j, u32);
    um1_2 = spu_mulo(m1j, u32);
    um0_3 = spu_mule(m1j, u32);
    um1_3 = spu_mule(m0j, u32);

    um0_4 = spu_mulo(m0j, u54);
    um1_4 = spu_mulo(m1j, u54);
    um0_5 = spu_mule(m1j, u54);
    um1_5 = spu_mule(m0j, u54);

    um0_6 = spu_mulo(m0j, u76);
    um1_6 = spu_mulo(m1j, u76);
    um0_7 = spu_mule(m1j, u76);
    um1_7 = spu_mule(m0j, u76);

    /* Combine product terms that have the same alignment. The
     * combined product terms consist of sums (s#) and carrys (c#).
     */
    prev_c0 = spu_genc(ab0_0, um0_0);
    prev_s0 = spu_add(ab0_0, um0_0);

    um_c1 = spu_genc(um1_0, um0_1);
    um_s1 = spu_add(um1_0, um0_1);
    prev_c1 = spu_add(spu_add(ab_c1, um_c1), spu_genc(ab_s1, um_s1));
    prev_s1 = spu_add(ab_s1, um_s1);

    um_c2 = spu_genc(um1_1, um0_2);
    um_s2 = spu_add(um1_1, um0_2);
    prev_c2 = spu_add(spu_add(ab_c2, um_c2), spu_genc(ab_s2, um_s2));
    prev_s2 = spu_add(ab_s2, um_s2);

    um_c3 = spu_genc(um1_2, um0_3);
    um_s3 = spu_add(um1_2, um0_3);
    prev_c3 = spu_add(spu_add(ab_c3, um_c3), spu_genc(ab_s3, um_s3));
    prev_s3 = spu_add(ab_s3, um_s3);

    um_c4 = spu_genc(um1_3, um0_4);
    um_s4 = spu_add(um1_3, um0_4);
    prev_c4 = spu_add(spu_add(ab_c4, um_c4), spu_genc(ab_s4, um_s4));
    prev_s4 = spu_add(ab_s4, um_s4);

    um_c5 = spu_genc(um1_4, um0_5);
    um_s5 = spu_add(um1_4, um0_5);
    prev_c5 = spu_add(spu_add(ab_c5, um_c5), spu_genc(ab_s5, um_s5));
    prev_s5 = spu_add(ab_s5, um_s5);

    um_c6 = spu_genc(um1_5, um0_6);
    um_s6 = spu_add(um1_5, um0_6);
    prev_c6 = spu_add(spu_add(ab_c6, um_c6), spu_genc(ab_s6, um_s6));
    prev_s6 = spu_add(ab_s6, um_s6);

    um_c7 = spu_genc(um1_6, um0_7);
    um_s7 = spu_add(um1_6, um0_7);
    prev_c7 = spu_add(spu_add(ab_c7, um_c7), spu_genc(ab_s7, um_s7));
    prev_s7 = spu_add(ab_s7, um_s7);

    prev_c8 = spu_genc(ab1_7, um1_7);
    prev_s8 = spu_add(ab1_7, um1_7);

    /* Align the partial products with results from previous
     * iteration.
     */
    ms1 = spu_slqwbyte(prev_s1, 2);
    mc1 = spu_slqwbyte(prev_c1, 2);
    ms2 = spu_slqwbyte(prev_s2, 4);
    mc2 = spu_slqwbyte(prev_c2, 4);
    ms3 = spu_slqwbyte(prev_s3, 6);
    mc3 = spu_slqwbyte(prev_c3, 6);
    ms4 = spu_slqwbyte(prev_s4, 8);
    mc4 = spu_slqwbyte(prev_c4, 8);
    ms5 = spu_slqwbyte(prev_s5, 10);
    mc5 = spu_slqwbyte(prev_c5, 10);
    ms6 = spu_slqwbyte(prev_s6, 12);
    mc6 = spu_slqwbyte(prev_c6, 12);
    ms7 = spu_slqwbyte(prev_s7, 14);
    mc7 = spu_slqwbyte(prev_c7, 14);

    /* Accumulate the product terms and c, keep the carry in
     * a seperate word. Carry propagation is not deferred until
     * the end. Instead, we propogate as we quit introducing 
     * additional carry conditions.
     */
    c01 = spu_add(dj_carry, prev_c0);
    c01 = spu_add(c01, mc1);
    MPM_ADD_PARTIAL(p01, c01,  dj, prev_s0, c01);
    MPM_ADD_PARTIAL(p01, c01, p01, ms1, c01);
    MPM_ADD_PARTIAL(p01, c01, p01, carry_lsq, c01);

    addend = spu_slqwbyte(c01, 4);
    c23 = spu_add(mc2, mc3);
    MPM_ADD_PARTIAL(p23, c23, ms2, ms3, c23)
    MPM_ADD_PARTIAL(p23, c23, p23, p01, c23)
    MPM_ADD_PARTIAL(p23, c23, p23, addend, c23)

    carry_lsq = spu_add(c01, c23);
    addend = spu_slqwbyte(c23, 4);
    c45 = spu_add(mc4, mc5);
    MPM_ADD_PARTIAL(p45, c45, ms4, ms5, c45)
    MPM_ADD_PARTIAL(p45, c45, p45, p23, c45)
    MPM_ADD_PARTIAL(p45, c45, p45, addend, c45)

    carry_lsq = spu_add(carry_lsq, c45);
    addend = spu_slqwbyte(c45, 4);
    c67 = spu_add(mc6, mc7);
    MPM_ADD_PARTIAL(p67,  c67, ms6, ms7, c67)
    MPM_ADD_PARTIAL(p67,  c67, p67, p45, c67)
    c67 = spu_add(c67, spu_genc(p67, addend));

    carry_lsq = spu_add(carry_lsq, c67);

    j--;
    
    b0j = (vector unsigned short)(b[j]);
    m0j = (vector unsigned short)(m[j]);
    
    b1j = (vector unsigned short)(spu_rl((vector unsigned int)(b0j), 16));
    m1j = (vector unsigned short)(spu_rl((vector unsigned int)(m0j), 16));
    
    while (j >= 0) {
      /* Compute the partial products for
       *   a[i] * b[j]   and 
       *      u * m[j]
       */
      ab0_0 = spu_mulo(b0j, a10);
      ab1_0 = spu_mulo(b1j, a10);
      ab0_1 = spu_mule(b1j, a10);
      ab1_1 = spu_mule(b0j, a10);

      ab0_2 = spu_mulo(b0j, a32);
      ab1_2 = spu_mulo(b1j, a32);
      ab0_3 = spu_mule(b1j, a32);
      ab1_3 = spu_mule(b0j, a32);

      ab0_4 = spu_mulo(b0j, a54);
      ab1_4 = spu_mulo(b1j, a54);
      ab0_5 = spu_mule(b1j, a54);
      ab1_5 = spu_mule(b0j, a54);

      ab0_6 = spu_mulo(b0j, a76);
      ab1_6 = spu_mulo(b1j, a76);
      ab0_7 = spu_mule(b1j, a76);
      ab1_7 = spu_mule(b0j, a76);


      um0_0 = spu_mulo(m0j, u10);
      um1_0 = spu_mulo(m1j, u10);
      um0_1 = spu_mule(m1j, u10);
      um1_1 = spu_mule(m0j, u10);

      um0_2 = spu_mulo(m0j, u32);
      um1_2 = spu_mulo(m1j, u32);
      um0_3 = spu_mule(m1j, u32);
      um1_3 = spu_mule(m0j, u32);

      um0_4 = spu_mulo(m0j, u54);
      um1_4 = spu_mulo(m1j, u54);
      um0_5 = spu_mule(m1j, u54);
      um1_5 = spu_mule(m0j, u54);

      um0_6 = spu_mulo(m0j, u76);
      um1_6 = spu_mulo(m1j, u76);
      um0_7 = spu_mule(m1j, u76);
      um1_7 = spu_mule(m0j, u76);

      
      /* Combine product terms that have the same alignment. The
       * combined product terms consist of sums (s#) and carrys (c#).
       */
      c0 = spu_genc(ab0_0, um0_0);
      s0 = spu_add(ab0_0, um0_0);
      
      ab_c1 = spu_genc(ab1_0, ab0_1); 
      ab_s1 = spu_add(ab1_0, ab0_1);  
      um_c1 = spu_genc(um1_0, um0_1);
      um_s1 = spu_add(um1_0, um0_1);
      c1 = spu_add(spu_add(ab_c1, um_c1), spu_genc(ab_s1, um_s1));
      s1 = spu_add(ab_s1, um_s1);

      ab_c2 = spu_genc(ab1_1, ab0_2); 
      ab_s2 = spu_add(ab1_1, ab0_2);  
      um_c2 = spu_genc(um1_1, um0_2);
      um_s2 = spu_add(um1_1, um0_2);
      c2 = spu_add(spu_add(ab_c2, um_c2), spu_genc(ab_s2, um_s2));
      s2 = spu_add(ab_s2, um_s2);

      ab_c3 = spu_genc(ab1_2, ab0_3); 
      ab_s3 = spu_add(ab1_2, ab0_3);  
      um_c3 = spu_genc(um1_2, um0_3);
      um_s3 = spu_add(um1_2, um0_3);
      c3 = spu_add(spu_add(ab_c3, um_c3), spu_genc(ab_s3, um_s3));
      s3 = spu_add(ab_s3, um_s3);

      ab_c4 = spu_genc(ab1_3, ab0_4); 
      ab_s4 = spu_add(ab1_3, ab0_4);  
      um_c4 = spu_genc(um1_3, um0_4);
      um_s4 = spu_add(um1_3, um0_4);
      c4 = spu_add(spu_add(ab_c4, um_c4), spu_genc(ab_s4, um_s4));
      s4 = spu_add(ab_s4, um_s4);

      ab_c5 = spu_genc(ab1_4, ab0_5); 
      ab_s5 = spu_add(ab1_4, ab0_5);
      um_c5 = spu_genc(um1_4, um0_5);
      um_s5 = spu_add(um1_4, um0_5);
      c5 = spu_add(spu_add(ab_c5, um_c5), spu_genc(ab_s5, um_s5));
      s5 = spu_add(ab_s5, um_s5);

      ab_c6 = spu_genc(ab1_5, ab0_6);
      ab_s6 = spu_add(ab1_5, ab0_6);
      um_c6 = spu_genc(um1_5, um0_6);
      um_s6 = spu_add(um1_5, um0_6);
      c6 = spu_add(spu_add(ab_c6, um_c6), spu_genc(ab_s6, um_s6));
      s6 = spu_add(ab_s6, um_s6);

      ab_c7   = spu_genc(ab1_6, ab0_7);
      ab_s7   = spu_add(ab1_6, ab0_7);
      um_c7   = spu_genc(um1_6, um0_7);
      um_s7   = spu_add(um1_6, um0_7);
      c7 = spu_add(spu_add(ab_c7, um_c7), spu_genc(ab_s7, um_s7));
      s7 = spu_add(ab_s7, um_s7);


      /* Align and merge partial products with results from previous
       * iteration.
       */
      ms1 = spu_shuffle(s1, prev_s1, dbl_qw_shl_2);
      mc1 = spu_shuffle(c1, prev_c1, dbl_qw_shl_2);
      ms2 = spu_shuffle(s2, prev_s2, dbl_qw_shl_4);
      mc2 = spu_shuffle(c2, prev_c2, dbl_qw_shl_4);
      ms3 = spu_shuffle(s3, prev_s3, dbl_qw_shl_6);
      mc3 = spu_shuffle(c3, prev_c3, dbl_qw_shl_6);
      ms4 = spu_shuffle(s4, prev_s4, dbl_qw_shl_8);
      mc4 = spu_shuffle(c4, prev_c4, dbl_qw_shl_8);
      ms5 = spu_shuffle(s5, prev_s5, dbl_qw_shl_10);
      mc5 = spu_shuffle(c5, prev_c5, dbl_qw_shl_10);
      ms6 = spu_shuffle(s6, prev_s6, dbl_qw_shl_12);
      mc6 = spu_shuffle(c6, prev_c6, dbl_qw_shl_12);
      ms7 = spu_shuffle(s7, prev_s7, dbl_qw_shl_14);
      mc7 = spu_shuffle(c7, prev_c7, dbl_qw_shl_14);


      /* Accumulate all the terms into the final product
       * and carry word.
       */
      carry = spu_add(prev_c8, d_carry_ptr[j]);
      MPM_ADD_PARTIAL(prod, carry, prev_s8, d_ptr[j], carry);
      MPM_ADD_PARTIAL(prod, carry, prod, s0,  carry);
      MPM_ADD_PARTIAL(prod, carry, prod, ms1, carry);
      MPM_ADD_PARTIAL(prod, carry, prod, ms2, carry);
      MPM_ADD_PARTIAL(prod, carry, prod, ms3, carry);
      MPM_ADD_PARTIAL(prod, carry, prod, ms4, carry);
      MPM_ADD_PARTIAL(prod, carry, prod, ms5, carry);
      MPM_ADD_PARTIAL(prod, carry, prod, ms6, carry);
      MPM_ADD_PARTIAL(prod, carry, prod, ms7, carry);

      mc01 = spu_add(c0,  mc1);
      mc23 = spu_add(mc2, mc3);
      mc45 = spu_add(mc4, mc5);
      mc67 = spu_add(mc6, mc7);

      mc0123 = spu_add(mc01, mc23);
      mc4567 = spu_add(mc45, mc67);

      mc01234567 = spu_add(mc0123, mc4567);

      carry = spu_add(carry, mc01234567);

      /* Fetch inputs for next loop iteration
       */
      j--;
    
      b0j = (vector unsigned short)(b[j]);
      m0j = (vector unsigned short)(m[j]);
    
      b1j = (vector unsigned short)(spu_rl((vector unsigned int)(b0j), 16));
      m1j = (vector unsigned short)(spu_rl((vector unsigned int)(m0j), 16));


      /* Copy the product terms computed in this loop 
       * for use in the next loop. 
       */
      prev_c1 = c1;
      prev_s1 = s1;
      prev_c2 = c2;
      prev_s2 = s2;
      prev_c3 = c3;
      prev_s3 = s3;
      prev_c4 = c4;
      prev_s4 = s4;
      prev_c5 = c5;
      prev_s5 = s5;
      prev_c6 = c6;
      prev_s6 = s6;
      prev_c7 = c7;
      prev_s7 = s7;

      prev_c8 = spu_genc(ab1_7, um1_7);
      prev_s8 = spu_add(ab1_7, um1_7);

      /* Store the result from the previous loop iteration.
       */
      d_carry[j+2] = carry;
      d[j+2] = prod; 

    }

    /* Complete the final resulting quadword.
     */

    /* Align the previous partial products.
     */
    ms1 = spu_rlmaskqwbyte(prev_s1, 2-16);
    mc1 = spu_rlmaskqwbyte(prev_c1, 2-16);
    ms2 = spu_rlmaskqwbyte(prev_s2, 4-16);
    mc2 = spu_rlmaskqwbyte(prev_c2, 4-16);
    ms3 = spu_rlmaskqwbyte(prev_s3, 6-16);
    mc3 = spu_rlmaskqwbyte(prev_c3, 6-16);
    ms4 = spu_rlmaskqwbyte(prev_s4, 8-16);
    mc4 = spu_rlmaskqwbyte(prev_c4, 8-16);
    ms5 = spu_rlmaskqwbyte(prev_s5, 10-16);
    mc5 = spu_rlmaskqwbyte(prev_c5, 10-16);
    ms6 = spu_rlmaskqwbyte(prev_s6, 12-16);
    mc6 = spu_rlmaskqwbyte(prev_c6, 12-16);
    ms7 = spu_rlmaskqwbyte(prev_s7, 14-16);
    mc7 = spu_rlmaskqwbyte(prev_c7, 14-16);

    /* Accumulate all the terms into the final product
     * and carry word.
     */
    MPM_ADD_PARTIAL(prod, carry, prev_s8, ms1, prev_c8);
    MPM_ADD_PARTIAL(prod, carry, prod, ms2, carry);
    MPM_ADD_PARTIAL(prod, carry, prod, ms3, carry);
    MPM_ADD_PARTIAL(prod, carry, prod, ms4, carry);
    MPM_ADD_PARTIAL(prod, carry, prod, ms5, carry);
    MPM_ADD_PARTIAL(prod, carry, prod, ms6, carry);
    MPM_ADD_PARTIAL(prod, carry, prod, ms7, carry);

    mc01 = mc1;
    mc23 = spu_add(mc2, mc3);
    mc45 = spu_add(mc4, mc5);
    mc67 = spu_add(mc6, mc7);

    mc0123 = spu_add(mc01, mc23);
    mc4567 = spu_add(mc45, mc67);

    mc01234567 = spu_add(mc0123, mc4567);
    carry = spu_add(carry, mc01234567);

    d_ptr = d;
    d_carry_ptr = d_carry;

    /* Store the result from the previous loop iteration.
     */
    d_carry[0] = carry;
    d[0] = prod; 

    ai = (vector unsigned short)(a[--i]);
  }

  /* Add all the accumlated carries. At the completion of this
   * loop, the most significant word of carry_lsq contain a carry
   * out (a 1 or a 0) and sum contains the most signficant word
   * of c.
   */
  for (j=size-1; j>=0; j--) {
    vector unsigned int t0, t1, t2;

    dj = d[j];
    dj_carry = d_carry[j];

    carry = spu_shuffle(dj_carry, carry_lsq, dbl_qw_shl_4);

    c0  = spu_genc(dj, carry);
    sum = spu_add(dj, carry);
    
    carry_lsq = spu_add(dj_carry, c0);
    t0  = spu_slqwbyte(c0, 4);
    c1  = spu_genc(sum, t0);
    sum = spu_add(sum, t0);

    carry_lsq = spu_add(carry_lsq, c1);
    t1  = spu_slqwbyte(c1, 4);
    c2  = spu_genc(sum, t1);
    sum = spu_add(sum, t1);

    carry_lsq = spu_add(carry_lsq, c2);
    t2  = spu_slqwbyte(c2, 4);
    c3  = spu_genc(sum, t2);
    sum = spu_add(sum, t2);

    carry_lsq = spu_add(carry_lsq, c3);
    c[j] = sum;
  }
  

  /* 3)  if (c > m) c -= m;
   */
  mi = m[0];
  for (i=0; i<size;) {
    gt = spu_gather(spu_cmpgt(mi, sum));
    lt = spu_gather(spu_cmpgt(sum, mi));
     
    gt_bigger = spu_cmpgt(gt, lt);
    lt_bigger = spu_cmpgt(lt, gt);
     
    i++;
    mi = m[i];
    sum = c[i];
     
    if (spu_extract(spu_or(gt_bigger, lt_bigger), 0)) break;
  }

  too_large = spu_extract(spu_orc(carry_lsq, gt_bigger), 0);

  if (too_large) {
    _mpm_sub(c, c, m, size);
  }
}

#endif /* _MPM_MONT_MOD_MUL_H_ */
