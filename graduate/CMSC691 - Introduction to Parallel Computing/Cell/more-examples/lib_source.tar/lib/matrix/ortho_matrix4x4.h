/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ORTHO_MATRIX_4X4_H_
#define _ORTHO_MATRIX_4X4_H_	1


#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include <simdmath/recipf4.h>

/*
 * FUNCTION
 * 	void  _ortho_matrix4x4(vector float *mOut,
 *			       float left, float right, 
 *			       float bottom, float top,
 *			       float near, float far)
 * 
 * DESCRIPTION
 *	The _ortho_matrix4x4 constructs a orthographic parallel view
 *	volume matrix. The ortho matrix matches that of OpenGL's 
 *	ortho function. The matrix is computed as follows:
 *
 *       2/(right-left)        0             0        (right+left)/(right-left)
 *            0         2/(top-bottom)       0        (top+bottom)/(top-bottom)
 *	      0                0       -2/(far-near)   -(far+near)/(far-near)
 *            0                0             0                    1
 *
 *	The resulting matrix is returned in mOut.
 */

static __inline void _ortho_matrix4x4(vector float *mOut, float left, float right, float bottom, float top, float near, float far)
{
#ifdef __SPU__
  vector float l, r, b, t, f, n;
  vector float lbf, rtn;
  vector float diff, sum, inv_diff;
  vector float diagonal, column;

  l = spu_promote(left, 0);
  r = spu_promote(right, 0);
  b = spu_promote(bottom, 0);
  t = spu_promote(top, 0);
  n = spu_promote(near, 0);
  f = spu_promote(far, 0);

  /* Construct lbf and rtn vectors as follows:
   *          __________________________________
   *   lbf   |__left__|_bottom_|___far__|___-___|
   *          __________________________________
   *   rtn   |__right_|__top___|__near__|___-___|
   *
   */
  lbf = spu_shuffle(l, b, ((vector unsigned char) {
				      0x00, 0x01, 0x02, 0x03, 
				      0x10, 0x11, 0x12, 0x13,
				      0x00, 0x00, 0x00, 0x00, 
				      0x00, 0x00, 0x00, 0x00}));
  rtn = spu_shuffle(r, t, ((vector unsigned char) {
				      0x00, 0x01, 0x02, 0x03, 
				      0x10, 0x11, 0x12, 0x13,
				      0x00, 0x00, 0x00, 0x00, 
				      0x00, 0x00, 0x00, 0x00}));
  lbf = spu_shuffle(lbf, f, ((vector unsigned char) {
					0x00, 0x01, 0x02, 0x03, 
					0x04, 0x05, 0x06, 0x07,
					0x10, 0x11, 0x12, 0x13, 
					0x00, 0x00, 0x00, 0x00}));
  rtn = spu_shuffle(rtn, n, ((vector unsigned char) {
					0x00, 0x01, 0x02, 0x03, 
					0x04, 0x05, 0x06, 0x07,
					0x10, 0x11, 0x12, 0x13, 
					0x00, 0x00, 0x00, 0x00}));

  diff = spu_sub(rtn, lbf);
  sum  = spu_add(rtn, lbf);

  inv_diff = _recipf4(diff);

  
  /* Compute the matrix diagonal value and last column values
   */
  diagonal = spu_mul(spu_splats((float)2.0), inv_diff);
  column  = spu_mul(sum, inv_diff);

  *(mOut+0) = spu_shuffle(diagonal, column, ((vector unsigned char) {
							0x00, 0x01, 0x02, 0x03,
							0x80, 0x80, 0x80, 0x80,
							0x80, 0x80, 0x80, 0x80,
							0x10, 0x11, 0x12, 0x13}));
  *(mOut+1) = spu_shuffle(diagonal, column, ((vector unsigned char) {
							0x80, 0x80, 0x80, 0x80,
							0x04, 0x05, 0x06, 0x07,
							0x80, 0x80, 0x80, 0x80,
							0x14, 0x15, 0x16, 0x17}));
  *(mOut+2) = spu_shuffle(diagonal, column, ((vector unsigned char) {
							0x80, 0x80, 0x80, 0x80,
							0x80, 0x80, 0x80, 0x80,
							0x08, 0x09, 0x0A, 0x0B,
							0x18, 0x19, 0x1A, 0x1B}));
  *(mOut+3) = ((vector float) { 0.0, 0.0, 0.0, 1.0});

#else /* !__SPU__ */
  static union {
    vector float fv;
    float f[4];
  } l, r, b, t, f, n;
  vector float lbf, rtn;
  vector float diff, sum, inv_diff;
  vector float diagonal, column;
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});

  l.f[0] = left;
  r.f[0] = right;
  b.f[0] = bottom;
  t.f[0] = top;
  n.f[0] = near;
  f.f[0] = far;

  /* Construct lbf and rtn vectors as follows:
   *          __________________________________
   *   lbf   |__left__|_bottom_|___far__|___-___|
   *          __________________________________
   *   rtn   |__right_|__top___|__near__|___-___|
   *
   */
  lbf  = vec_mergeh(l.fv, f.fv);
  rtn  = vec_mergeh(r.fv, n.fv);
  lbf  = vec_mergeh(lbf, b.fv);
  rtn  = vec_mergeh(rtn, t.fv);

  diff = vec_sub(rtn, lbf);
  sum  = vec_add(rtn, lbf);

  inv_diff = _recipf4(diff);

  /* Compute the matrix diagonal value and last column values
   */
  column  = vec_madd(sum, inv_diff, vzero);
  column   = (vector float)vec_andc((vector unsigned int)(column), ((vector unsigned int) { 0x0, 0x0, 0x0, 0xFFFFFFFF}));
  diagonal = vec_madd(((vector float) {2.0,2.0,2.0,2.0}), inv_diff, vzero);

  *(mOut+0) = vec_perm(diagonal, column, ((vector unsigned char) {
						     0x00, 0x01, 0x02, 0x03,
						     0x1C, 0x1D, 0x1E, 0x1F,
						     0x1C, 0x1D, 0x1E, 0x1F,
						     0x10, 0x11, 0x12, 0x13}));
  *(mOut+1) = vec_perm(diagonal, column, ((vector unsigned char) {
						     0x1C, 0x1D, 0x1E, 0x1F,
						     0x04, 0x05, 0x06, 0x07,
						     0x1C, 0x1D, 0x1E, 0x1F,
						     0x14, 0x15, 0x16, 0x17}));
  *(mOut+2) = vec_perm(diagonal, column, ((vector unsigned char) {
						     0x1C, 0x1D, 0x1E, 0x1F,
						     0x1C, 0x1D, 0x1E, 0x1F,
						     0x08, 0x09, 0x0A, 0x0B,
						     0x18, 0x19, 0x1A, 0x1B}));
  *(mOut+3) = ((vector float) { 0.0, 0.0, 0.0, 1.0});

#endif /* __SPU__ */
}

#endif /* _ORTHO_MATRIX_4X4_H_ */

