/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MULT_QUAT_H_
#define _MULT_QUAT_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 *      vector float _mult_quat(vector float q1, vector float q2)
 * 
 * DESCRIPTION
 *	_mult_quat multiplies unit length input quaternions q1 and q2. 
 *	The resulting quaterion (returned) decribes a composite of the 
 *	rotations described by q1 followed by q2.
 *
 *	q1*q2 = [v1 x v2 + w1*v2 + w2*v1, w1*w2 - v1 dot v2]
 *
 *	where: q1 = [v1, w1]
 *	       q2 = [v2, w2]
 */

static __inline vector float _mult_quat(vector float q1, vector float q2)
{
  vector float yzxw1, yzxw2, zxyw1, zxyw2; 
  vector float xyzw_2, x_2, y_2, z_2;
  vector float w1, w2;
  vector float w_wx, w_yz, w, cross, result;
  vector unsigned char shuffle_yzxw = ((vector unsigned char) {
						  0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B,
						  0x00, 0x01, 0x02, 0x03, 0x1C, 0x1D, 0x1E, 0x1F});

#if __SPU__
  vector unsigned char shuffle_splat_w = ((vector unsigned char) {
						     12, 13, 14, 15, 12, 13, 14, 15,
						     12, 13, 14, 15, 12, 13, 14, 15});


  xyzw_2 = spu_mul(q1, q2);
  x_2    = spu_rlqwbyte(xyzw_2, 4);
  y_2    = spu_rlqwbyte(xyzw_2, 8);
  z_2    = spu_rlqwbyte(xyzw_2, 12);

  w_wx   = spu_sub(xyzw_2, x_2);
  w_yz   = spu_add(y_2, z_2);
  w      = spu_sub(w_wx, w_yz);

  w1     = spu_shuffle(q1, q1, shuffle_splat_w);
  w2     = spu_shuffle(q2, q2, shuffle_splat_w);

  yzxw1  = spu_shuffle(q1, q1, shuffle_yzxw);
  yzxw2  = spu_shuffle(q2, q2, shuffle_yzxw);

  zxyw1  = spu_shuffle(yzxw1, yzxw1, shuffle_yzxw);
  zxyw2  = spu_shuffle(yzxw2, yzxw2, shuffle_yzxw);

  cross  = spu_mul(q1, yzxw2);
  cross  = spu_nmsub(q2, yzxw1, cross);

  result = spu_madd(zxyw1, w2, cross);
  result = spu_madd(zxyw2, w1, result);

  result = spu_shuffle(result, w, shuffle_yzxw);
#else
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});

  xyzw_2 = vec_madd(q1, q2, vzero);
  x_2    = vec_splat(xyzw_2, 0);
  y_2    = vec_splat(xyzw_2, 1);
  z_2    = vec_splat(xyzw_2, 2);

  w_wx   = vec_sub(xyzw_2, x_2);
  w_yz   = vec_add(y_2, z_2);
  w      = vec_sub(w_wx, w_yz);

  w1     = vec_splat(q1, 3);
  w2     = vec_splat(q2, 3);

  yzxw1  = vec_perm(q1, q1, shuffle_yzxw);
  yzxw2  = vec_perm(q2, q2, shuffle_yzxw);

  zxyw1  = vec_perm(yzxw1, yzxw1, shuffle_yzxw);
  zxyw2  = vec_perm(yzxw2, yzxw2, shuffle_yzxw);

  cross  = vec_madd(q1, yzxw2, vzero);
  cross  = vec_nmsub(q2, yzxw1, cross);

  result = vec_madd(zxyw1, w2, cross);
  result = vec_madd(zxyw2, w1, result);
  result = vec_perm(result, w, shuffle_yzxw);
#endif 

  return (result);
}

#endif /* _MULT_QUAT_H_ */
