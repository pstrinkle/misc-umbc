/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MULT_MATRIX_4X4_D_H_
#define _MULT_MATRIX_4X4_D_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void _mult_matrix4x4_d(vector double *mOut, vector double *m1, vector double *m2)
 * 
 * DESCRIPTION
 *	_mult_matrix4x4_d multiplies double precision input 4x4 matrices m1 
 *	and m2 and places the result in mOut.
 *
 *		mOut = m1 x m2
 *
 *	All matrices are 128-bit aligned linearly address and row ordered.
 */
#ifdef __SPU__

static __inline void _mult_matrix4x4_d(vector double *mOut, const vector double *m1, const vector double *m2)
{
  vector double m1_0a, m1_1a, m1_2a, m1_3a;
  vector double m1_0b, m1_1b, m1_2b, m1_3b;
  vector double m2_0a, m2_1a, m2_2a, m2_3a;
  vector double m2_0b, m2_1b, m2_2b, m2_3b;
  vector double mOut_0a, mOut_1a, mOut_2a, mOut_3a;
  vector double mOut_0b, mOut_1b, mOut_2b, mOut_3b;
  vector double m1_00, m1_01, m1_02, m1_03;
  vector double m1_10, m1_11, m1_12, m1_13;
  vector double m1_20, m1_21, m1_22, m1_23;
  vector double m1_30, m1_31, m1_32, m1_33;
  vector unsigned char splat0;
  vector unsigned char splat1;

  splat0 = ((vector unsigned char) { 0,1,2,3, 4,5,6,7, 0,1,2,3, 4,5,6,7});
  splat1 = spu_or(splat0, 0x8);
  
  m1_0a = *(m1 + 0);
  m1_0b = *(m1 + 1);
  m1_1a = *(m1 + 2);
  m1_1b = *(m1 + 3);
  m1_2a = *(m1 + 4);
  m1_2b = *(m1 + 5);
  m1_3a = *(m1 + 6);
  m1_3b = *(m1 + 7);

  m1_00 = spu_shuffle(m1_0a, m1_0a, splat0);
  m1_10 = spu_shuffle(m1_1a, m1_1a, splat0);
  m1_20 = spu_shuffle(m1_2a, m1_2a, splat0);
  m1_30 = spu_shuffle(m1_3a, m1_3a, splat0);

  m2_0a = *(m2 + 0);
  m2_0b = *(m2 + 1);
  mOut_0a = spu_mul(m1_00, m2_0a);
  mOut_0b = spu_mul(m1_00, m2_0b);
  mOut_1a = spu_mul(m1_10, m2_0a);
  mOut_1b = spu_mul(m1_10, m2_0b);
  mOut_2a = spu_mul(m1_20, m2_0a);
  mOut_2b = spu_mul(m1_20, m2_0b);
  mOut_3a = spu_mul(m1_30, m2_0a);
  mOut_3b = spu_mul(m1_30, m2_0b);

  m1_01 = spu_shuffle(m1_0a, m1_0a, splat1);
  m1_11 = spu_shuffle(m1_1a, m1_1a, splat1);
  m1_21 = spu_shuffle(m1_2a, m1_2a, splat1);
  m1_31 = spu_shuffle(m1_3a, m1_3a, splat1);

  m2_1a = *(m2 + 2);
  m2_1b = *(m2 + 3);
  mOut_0a = spu_madd(m1_01, m2_1a, mOut_0a);
  mOut_0b = spu_madd(m1_01, m2_1b, mOut_0b);
  mOut_1a = spu_madd(m1_11, m2_1a, mOut_1a); 
  mOut_1b = spu_madd(m1_11, m2_1b, mOut_1b); 
  mOut_2a = spu_madd(m1_21, m2_1a, mOut_2a);
  mOut_2b = spu_madd(m1_21, m2_1b, mOut_2b);
  mOut_3a = spu_madd(m1_31, m2_1a, mOut_3a);
  mOut_3b = spu_madd(m1_31, m2_1b, mOut_3b);

  m1_02 = spu_shuffle(m1_0b, m1_0b, splat0);
  m1_12 = spu_shuffle(m1_1b, m1_1b, splat0);
  m1_22 = spu_shuffle(m1_2b, m1_2b, splat0);
  m1_32 = spu_shuffle(m1_3b, m1_3b, splat0);

  m2_2a = *(m2 + 4);
  m2_2b = *(m2 + 5);
  mOut_0a = spu_madd(m1_02, m2_2a, mOut_0a);
  mOut_0b = spu_madd(m1_02, m2_2b, mOut_0b);
  mOut_1a = spu_madd(m1_12, m2_2a, mOut_1a);
  mOut_1b = spu_madd(m1_12, m2_2b, mOut_1b);
  mOut_2a = spu_madd(m1_22, m2_2a, mOut_2a);
  mOut_2b = spu_madd(m1_22, m2_2b, mOut_2b);
  mOut_3a = spu_madd(m1_32, m2_2a, mOut_3a);
  mOut_3b = spu_madd(m1_32, m2_2b, mOut_3b);

  m1_03 = spu_shuffle(m1_0b, m1_0b, splat1);
  m1_13 = spu_shuffle(m1_1b, m1_1b, splat1);
  m1_23 = spu_shuffle(m1_2b, m1_2b, splat1);
  m1_33 = spu_shuffle(m1_3b, m1_3b, splat1);
  
  m2_3a = *(m2 + 6);
  m2_3b = *(m2 + 7);
  mOut_0a = spu_madd(m1_03, m2_3a, mOut_0a);
  mOut_0b = spu_madd(m1_03, m2_3b, mOut_0b);
  mOut_1a = spu_madd(m1_13, m2_3a, mOut_1a);
  mOut_1b = spu_madd(m1_13, m2_3b, mOut_1b);
  mOut_2a = spu_madd(m1_23, m2_3a, mOut_2a);
  mOut_2b = spu_madd(m1_23, m2_3b, mOut_2b);
  mOut_3a = spu_madd(m1_33, m2_3a, mOut_3a);
  mOut_3b = spu_madd(m1_33, m2_3b, mOut_3b);

  *(mOut + 0) = mOut_0a;
  *(mOut + 1) = mOut_0b;
  *(mOut + 2) = mOut_1a;
  *(mOut + 3) = mOut_1b;
  *(mOut + 4) = mOut_2a;
  *(mOut + 5) = mOut_2b;
  *(mOut + 6) = mOut_3a;
  *(mOut + 7) = mOut_3b;
}

#endif /* __SPU__ */
#endif /* _MULT_MATRIX_4X4_H_ */
