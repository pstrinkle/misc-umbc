/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ROTATE_MATRIX_4X4_H_
#define _ROTATE_MATRIX_4X4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include <simdmath/cosf4.h>
#include <math.h>

/*
 * FUNCTION
 * 	void  _rotate_matrix4x4(vector float *mOut, vector float vec, float angle)
 * 
 * DESCRIPTION
 *	_rotate_matrxi4x4 constructs a matrix that performs a rotation
 *	of "angle" radians about the pre-normalized (unit length) vector 
 *	"vec". The resulting matrix is saved in mOut. The rotation matrix
 *	generated is:
 *
 *	    | x*x*(1-c)+  c  x*y*(1-c)-z*s   x*z*(1-c)+y*s        0  |
 *	    | y*x*(1-c)+z*s  y*y*(1-c)+  c   y*z*(1-c)-x*s        0  |
 *          | z*x*(1-c)-y*s  z*y*(1-c)+x*s   z*z*(1-c)+  c        0  |
 *	    |       0              0              0               1  |
 *
 *	where: x,y,z are the components of the input vector, and
 *	       c,s are cosine and sine of the input angle respectively.
 */

static __inline void _rotate_matrix4x4(vector float *mOut, vector float vec, float angle)
{
#ifdef __SPU__
  vector float vangle;
  vector float ccc0, sss0, css0, ___c;
  vector float row0, row1, row2;
  vector float minus_vec;
  vector float xxx0, yyy0, zzz0;
  vector float Ozy0, z0x0, yx00;
  vector unsigned char shuffle0000 = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x00, 0x01, 0x02, 0x03,
						 0x00, 0x01, 0x02, 0x03,
						 0x80, 0x80, 0x80, 0x80});

  /* Generate a vector of floats  cos(angle), sin(angle), sin(angle), 0.0
   */
  vangle = spu_promote(angle, 0);
  vangle = spu_sub(spu_shuffle(vangle, vangle, shuffle0000),
		   ((vector float) { 0.0f, (float)M_PI_2, (float)M_PI_2, 0.0f}));

  css0 = _cosf4(vangle);

  minus_vec = spu_sub(spu_splats((float)0.0), vec);

  yyy0 = spu_rlqwbyte(vec, 4);
  zzz0 = spu_rlqwbyte(vec, 8);

  xxx0 = spu_shuffle(vec,  vec,  shuffle0000);
  yyy0 = spu_shuffle(yyy0, yyy0, shuffle0000);
  zzz0 = spu_shuffle(zzz0, zzz0, shuffle0000);

  row0 = spu_mul(vec, xxx0);
  row1 = spu_mul(vec, yyy0);
  row2 = spu_mul(vec, zzz0);

  ccc0 = spu_shuffle(css0, css0, shuffle0000);
  ___c = spu_rlmaskqwbyte(css0, -12);
  ccc0 = spu_sub(((vector float) { 1.0, 1.0, 1.0, 0.0}), ccc0);

  sss0 = spu_shuffle(spu_slqwbyte(css0, 4), css0, shuffle0000);

  row0 = spu_madd(row0, ccc0, spu_slqwbyte(___c, 12));
  row1 = spu_madd(row1, ccc0, spu_slqwbyte(___c, 8));
  row2 = spu_madd(row2, ccc0, spu_slqwbyte(___c, 4));

  /* Ozy0 = 0.0  -z    y   0.0 
   * z0x0 =  z   0.0  -x   0.0
   * yx00 = -y    x   0.0  0.0
   */
  Ozy0 = spu_shuffle(vec, minus_vec, ((vector unsigned char) {
						 0x80, 0x80, 0x80, 0x80, 0x18, 0x19, 0x1A, 0x1B,
						 0x04, 0x05, 0x06, 0x07, 0x80, 0x80, 0x80, 0x80}));	
  z0x0 = spu_shuffle(vec, minus_vec, ((vector unsigned char) {
						 0x08, 0x09, 0x0A, 0x0B, 0x80, 0x80, 0x80, 0x80,
						 0x10, 0x11, 0x12, 0x13, 0x80, 0x80, 0x80, 0x80}));	
  yx00 = spu_shuffle(vec, minus_vec, ((vector unsigned char) {
						 0x14, 0x15, 0x16, 0x17, 0x00, 0x01, 0x02, 0x03,
						 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80}));	

  row0 = spu_madd(sss0, Ozy0, row0);
  row1 = spu_madd(sss0, z0x0, row1);
  row2 = spu_madd(sss0, yx00, row2);

#else /* !__SPU__ */

  union {
    float f[4];
    vector float fv;
  } vangle;
  vector unsigned int mask = ((vector unsigned int) { 0x0, 0x0, 0x0, 0xFFFFFFFF});
  vector float cccc, ssss, csss, ___c;
  vector float row0, row1, row2;
  vector float minus_vec;
  vector float xxxx, yyyy, zzzz;
  vector float Oxyz, Ozy0, z0x0, yx00;
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});

  /* Generate a vector of floats  cos(angle), sin(angle), sin(angle), sin(angle)
   */
  vangle.f[0] = angle;
  vangle.fv = vec_splat(vangle.fv, 0);
  vangle.fv = vec_sub(vangle.fv, ((vector float) { 0.0f, (float)M_PI_2, (float)M_PI_2, (float)M_PI_2})); 

  csss = _cosf4(vangle.fv);

  minus_vec = vec_sub(vzero, vec);

  xxxx = vec_splat(vec, 0);
  yyyy = vec_splat(vec, 1);
  zzzz = vec_splat(vec, 2);

  row0 = vec_madd(vec, xxxx, vzero);
  row1 = vec_madd(vec, yyyy, vzero);
  row2 = vec_madd(vec, zzzz, vzero);

  cccc = vec_splat(csss, 0);
  cccc = vec_sub(((vector float) { 1.0, 1.0, 1.0, 1.0}), cccc);
  ___c = vec_sld(vzero, csss, 4);
  ssss = vec_splat(csss, 1);

  row0 = vec_madd(row0, cccc, vec_sld(___c, vzero, 12));
  row1 = vec_madd(row1, cccc, vec_sld(___c, vzero, 8));
  row2 = vec_madd(row2, cccc, vec_sld(___c, vzero, 4));

  /* Ozy0 = 0.0  -z    y   0.0 
   * z0x0 =  z   0.0  -x   0.0
   * yx00 = -y    x   0.0  0.0
   */
  Oxyz = vec_sld(vzero, vec, 12);
  Ozy0 = vec_perm(Oxyz, minus_vec, ((vector unsigned char) { 
					       0x00, 0x01, 0x02, 0x03, 0x18, 0x19, 0x1A, 0x1B,
					       0x08, 0x09, 0x0A, 0x0B, 0x00, 0x01, 0x02, 0x03}));	
  z0x0 = vec_perm(Oxyz, minus_vec, ((vector unsigned char) {
					       0x0C, 0x0D, 0x0E, 0x0F, 0x00, 0x01, 0x02, 0x03,
					       0x10, 0x11, 0x12, 0x13, 0x00, 0x01, 0x02, 0x03}));	
  yx00 = vec_perm(Oxyz, minus_vec, ((vector unsigned char) {
					       0x14, 0x15, 0x16, 0x17, 0x04, 0x05, 0x06, 0x07,
					       0x00, 0x01, 0x02, 0x03, 0x00, 0x01, 0x02, 0x03}));	

  row0 = vec_madd(ssss, Ozy0, row0);
  row1 = vec_madd(ssss, z0x0, row1);
  row2 = vec_madd(ssss, yx00, row2);

  row0 = (vector float)vec_andc((vector unsigned int)row0, mask);
  row1 = (vector float)vec_andc((vector unsigned int)row1, mask);
  row2 = (vector float)vec_andc((vector unsigned int)row2, mask);

#endif /* __SPU__ */

  *(mOut+0) = row0;
  *(mOut+1) = row1;
  *(mOut+2) = row2;
  *(mOut+3) = ((vector float) { 0.0, 0.0, 0.0, 1.0});
}

#endif /* _ROTATE_MATRIX_4X4_H_ */
