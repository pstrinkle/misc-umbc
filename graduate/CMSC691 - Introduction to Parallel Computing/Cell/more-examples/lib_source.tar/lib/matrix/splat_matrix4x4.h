/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SPLAT_MATRIX_4X4_H_
#define _SPLAT_MATRIX_4X4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION 
 * 	void  _splat_matrix4x4(vector float *mOut, const vector float *mIn)
 * 
 * DESCRIPTION
 * 	_splat_matrix4x4 converts a 4x4 floating-point matrix into a vector
 *	replicated matrix suitable for simultaneously transforming 4
 *	independent vectors using SIMD vector operations. The input matrix,
 *	mIn, is a 4x4 matrix encoded as 4 128-bit vectors. This is equivalent
 *	to an 8-bit aligned 16 entry floating-point array. _splatMatrix4x4 
 *	takes each of the 16 32-bit entries and replicates is across a
 *	128-bit floating-point vector and store the result into the output
 *	array, mOut.
 */


static __inline void _splat_matrix4x4(vector float *mOut, const vector float *mIn)
{
  vector float in0, in1, in2, in3;
#ifdef __SPU__
  vector unsigned char splat0;
  vector unsigned char splat1;
  vector unsigned char splat2;
  vector unsigned char splat3;

  in0 = *(mIn+0);
  in1 = *(mIn+1);
  in2 = *(mIn+2);
  in3 = *(mIn+3);

  splat0 = (vector unsigned char)(spu_splats((unsigned int)0x10203));
  splat1 = spu_or(splat0, 0x4);
  splat2 = spu_or(splat0, 0x8);
  splat3 = spu_or(splat0, 0xC);

  *(mOut+0)  = spu_shuffle(in0, in0, splat0);
  *(mOut+1)  = spu_shuffle(in0, in0, splat1);
  *(mOut+2)  = spu_shuffle(in0, in0, splat2);
  *(mOut+3)  = spu_shuffle(in0, in0, splat3);

  *(mOut+4)  = spu_shuffle(in1, in1, splat0);
  *(mOut+5)  = spu_shuffle(in1, in1, splat1);
  *(mOut+6)  = spu_shuffle(in1, in1, splat2);
  *(mOut+7)  = spu_shuffle(in1, in1, splat3);

  *(mOut+8)  = spu_shuffle(in2, in2, splat0);
  *(mOut+9)  = spu_shuffle(in2, in2, splat1);
  *(mOut+10) = spu_shuffle(in2, in2, splat2);
  *(mOut+11) = spu_shuffle(in2, in2, splat3);

  *(mOut+12) = spu_shuffle(in3, in3, splat0);
  *(mOut+13) = spu_shuffle(in3, in3, splat1);
  *(mOut+14) = spu_shuffle(in3, in3, splat2);
  *(mOut+15) = spu_shuffle(in3, in3, splat3);
#else
  in0 = *(mIn+0);
  in1 = *(mIn+1);
  in2 = *(mIn+2);
  in3 = *(mIn+3);

  *(mOut+0)  = vec_splat(in0, 0);
  *(mOut+1)  = vec_splat(in0, 1);
  *(mOut+2)  = vec_splat(in0, 2);
  *(mOut+3)  = vec_splat(in0, 3);

  *(mOut+4)  = vec_splat(in1, 0);
  *(mOut+5)  = vec_splat(in1, 1);
  *(mOut+6)  = vec_splat(in1, 2);
  *(mOut+7)  = vec_splat(in1, 3);

  *(mOut+8)  = vec_splat(in2, 0);
  *(mOut+9)  = vec_splat(in2, 1);
  *(mOut+10) = vec_splat(in2, 2);
  *(mOut+11) = vec_splat(in2, 3);

  *(mOut+12) = vec_splat(in3, 0);
  *(mOut+13) = vec_splat(in3, 1);
  *(mOut+14) = vec_splat(in3, 2);
  *(mOut+15) = vec_splat(in3, 3);
#endif
}

#endif /* _SPLAT_MATRIX_4X4_H_ */
