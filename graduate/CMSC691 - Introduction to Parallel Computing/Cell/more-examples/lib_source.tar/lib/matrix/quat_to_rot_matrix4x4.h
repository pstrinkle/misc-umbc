/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _QUAT_TO_ROT_MATRIX_4X4_H_
#define _QUAT_TO_ROT_MATRIX_4X4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void  _quat_to_rot_matrix4x4(vector float *mOut, vector float quaternion)
 * 
 * DESCRIPTION
 *
 * The rotation matrix for a given quaternion  (x, y, z, w) is the
 * following:
 *
 *  | 1-2*Y*Y-2*Z*Z     2*X*Y-2*Z*W     2*X*Z+2*Y*W    0  |
 *  |   2*X*Y+2*Z*W   1-2*X*X-2*Z*Z     2*Y*Z-2*X*W    0  |   
 *  |   2*X*Z-2*Y*W     2*Y*Z+2*X*W   1-2*X*X-2*Y*Y    0  |
 *  |        0               0               0         1  |
 *
 */

static __inline void _quat_to_rot_matrix4x4(vector float *mOut, vector float quaternion)
{
#ifdef __SPU__
  vector unsigned char shuffle1032 = ((vector unsigned char) {
						 0x4, 0x5, 0x6, 0x7,
						 0x0, 0x1, 0x2, 0x3,
						 0xC, 0xD, 0xE, 0xF,
						 0x8, 0x9, 0xA, 0xB});
  vector unsigned char shuffle0000 = (vector unsigned char)spu_splats((unsigned int)0x10203);
  vector unsigned char shuffle1111;
  vector unsigned char shuffle2222;
  vector unsigned int nnnp = ((vector unsigned int) { 0x80000000, 0x80000000, 0x80000000, 0x00000000});
  vector unsigned int nnpp;
  vector unsigned int nppp;
  vector unsigned int xxx0;
  vector float v1000 = ((vector float) { 1.0f, 0.0f, 0.0f, 0.0f});
  vector float xyzw2;
  vector float yxwz, zyxw, zwxy, xyzw, xwzy;
  vector float row0, row1, row2;

  vector float x2, y2, z2;
  vector float x2_nppp, x2_nnpp;
  vector float y2_nppp, y2_nnnp;
  vector float z2_nppp, z2_nnpp;
  
  /* Compute the square of the quaternion components
   */
  xyzw2 = spu_mul(quaternion, spu_splats((float)2.0f));

  /* Generate all the combination of row multipliers 
   */
  yxwz = spu_shuffle(quaternion, quaternion, shuffle1032);
  xyzw = quaternion;
  zwxy = spu_rlqwbyte(quaternion, 8);
  xwzy = spu_rlqwbyte(yxwz, 4);
  zyxw = spu_rlqwbyte(yxwz, 12);

  shuffle1111 = spu_or(shuffle0000, 4);
  shuffle2222 = spu_or(shuffle0000, 8);

  /* Splat each of the squared components.
   */
  x2 = spu_shuffle(xyzw2, xyzw2, shuffle0000);
  y2 = spu_shuffle(xyzw2, xyzw2, shuffle1111);
  z2 = spu_shuffle(xyzw2, xyzw2, shuffle2222);
  
  /* Correct the signs of the square components.
   */
  nnpp = spu_slqwbyte(nnnp, 4);
  nppp = spu_slqwbyte(nnnp, 8);

  x2_nppp = (vector float)spu_xor((vector unsigned int)(x2), nppp);
  x2_nnpp = (vector float)spu_xor((vector unsigned int)(x2), nnpp);

  y2_nppp = (vector float)spu_xor((vector unsigned int)(y2), nppp);
  y2_nnnp = (vector float)spu_xor((vector unsigned int)(y2), nnnp);

  z2_nppp = (vector float)spu_xor((vector unsigned int)(z2), nppp);
  z2_nnpp = (vector float)spu_xor((vector unsigned int)(z2), nnpp);

  /* Compute the rotation matrix rows.
   */
  row0 = spu_madd(y2_nppp, yxwz, v1000);
  row1 = spu_madd(z2_nppp, zyxw, v1000);
  row2 = spu_madd(x2_nppp, xyzw, v1000);

  row0 = spu_madd(z2_nnpp, zwxy, row0);
  row1 = spu_madd(x2_nnpp, xwzy, row1);
  row2 = spu_madd(y2_nnnp, yxwz, row2);

  /* Align the row to their correct column 
   */
  row1 = spu_rlqwbyte(row1, 12);
  row2 = spu_rlqwbyte(row2, 8);

  /* Zero the 4th matrix column 
   */
  xxx0 = spu_rlmaska(nnnp, -31);
  row0 = (vector float)spu_and((vector unsigned int)row0, xxx0);
  row1 = (vector float)spu_and((vector unsigned int)row1, xxx0);
  row2 = (vector float)spu_and((vector unsigned int)row2, xxx0);

  /* Store the resulting row matrix.
   */
  *(mOut + 0) = row0;
  *(mOut + 1) = row1;
  *(mOut + 2) = row2;
  *(mOut + 3) = (vector float)spu_rlqwbyte((vector unsigned int)v1000, 4);

#else /* !__SPU__ */

  vector unsigned char shuffle1032 = ((vector unsigned char) {
						 0x4, 0x5, 0x6, 0x7,
						 0x0, 0x1, 0x2, 0x3,
						 0xC, 0xD, 0xE, 0xF,
						 0x8, 0x9, 0xA, 0xB});

  vector unsigned int nnnp = ((vector unsigned int) { 0x80000000, 0x80000000, 0x80000000, 0x00000000});
  vector unsigned int nnpp;
  vector unsigned int nppp;
  vector unsigned int xxx0;
  vector float v1000 = ((vector float) { 1.0f, 0.0f, 0.0f, 0.0f});
  vector float xyzw2;
  vector float yxwz, zyxw, zwxy, xyzw, xwzy;
  vector float row0, row1, row2;

  vector float x2, y2, z2;
  vector float x2_nppp, x2_nnpp;
  vector float y2_nppp, y2_nnnp;
  vector float z2_nppp, z2_nnpp;
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});
  
  /* Compute the square of the quaternion components
   */
  xyzw2 = vec_madd(quaternion, ((vector float) {2.0f,2.0f,2.0f,2.0f}), vzero);

  /* Generate all the combination of row multipliers 
   */
  yxwz = vec_perm(quaternion, quaternion, shuffle1032);
  xyzw = quaternion;
  zwxy = vec_sld(quaternion, quaternion, 8);
  xwzy = vec_sld(yxwz, yxwz, 4);
  zyxw = vec_sld(yxwz, yxwz, 12);

  /* Splat each of the squared components.
   */
  x2 = vec_splat(xyzw2, 0);
  y2 = vec_splat(xyzw2, 1);
  z2 = vec_splat(xyzw2, 2);
  
  /* Correct the signs of the square components.
   */
  nnpp = vec_sld(nnnp, (vector unsigned int)(vzero), 4);
  nppp = vec_sld(nnnp, (vector unsigned int)(vzero), 8);

  x2_nppp = (vector float)vec_xor((vector unsigned int)(x2), nppp);
  x2_nnpp = (vector float)vec_xor((vector unsigned int)(x2), nnpp);

  y2_nppp = (vector float)vec_xor((vector unsigned int)(y2), nppp);
  y2_nnnp = (vector float)vec_xor((vector unsigned int)(y2), nnnp);

  z2_nppp = (vector float)vec_xor((vector unsigned int)(z2), nppp);
  z2_nnpp = (vector float)vec_xor((vector unsigned int)(z2), nnpp);

  /* Compute the rotation matrix rows.
   */
  row0 = vec_madd(y2_nppp, yxwz, v1000);
  row1 = vec_madd(z2_nppp, zyxw, v1000);
  row2 = vec_madd(x2_nppp, xyzw, v1000);

  row0 = vec_madd(z2_nnpp, zwxy, row0);
  row1 = vec_madd(x2_nnpp, xwzy, row1);
  row2 = vec_madd(y2_nnnp, yxwz, row2);

  /* Align the row to their correct column 
   */
  row1 = vec_sld(row1, row1, 12);
  row2 = vec_sld(row2, row2, 8);

  /* Zero the 4th matrix column 
   */
  xxx0 = ((vector unsigned int) { 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x0});
  row0 = (vector float)vec_and((vector unsigned int)row0, xxx0);
  row1 = (vector float)vec_and((vector unsigned int)row1, xxx0);
  row2 = (vector float)vec_and((vector unsigned int)row2, xxx0);

  /* Store the resulting row matrix.
   */
  *(mOut + 0) = row0;
  *(mOut + 1) = row1;
  *(mOut + 2) = row2;
  *(mOut + 3) = vec_sld(v1000, v1000, 4);
#endif /* __SPU__ */
}

#endif /* _QUAT_TO_ROT_MATRIX_4X4_H_ */

