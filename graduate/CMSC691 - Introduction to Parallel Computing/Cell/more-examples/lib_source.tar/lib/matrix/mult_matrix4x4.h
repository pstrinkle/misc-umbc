/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MULT_MATRIX_4X4_H_
#define _MULT_MATRIX_4X4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void _mult_matrix4x4(vector float *mOut, vector float *m1, vector float *m2)
 * 
 * DESCRIPTION
 *	_mult_matrix4x4 multiplies input 4x4 matrices m1 and m2 and places the
 *	result in mOut.
 *
 *		mOut = m1 x m2
 *
 *	All matrices are 128-bit aligned linearly address and row ordered.
 *
 *	      | m[0]  m[1]  m[2]  m[3]  |
 *	      | m[4]  m[5]  m[6]  m[7]  |
 *	      | m[8]  m[9]  m[10] m[11] |
 *	      | m[12] m[13] m[14] m[15] |
 */

static __inline void _mult_matrix4x4(vector float *mOut, const vector float *m1, const vector float *m2)
{
  vector float m1_0, m1_1, m1_2, m1_3;
  vector float m2_0, m2_1, m2_2, m2_3;
  vector float mOut_0, mOut_1, mOut_2, mOut_3;
  vector float m1_00, m1_01, m1_02, m1_03;
  vector float m1_10, m1_11, m1_12, m1_13;
  vector float m1_20, m1_21, m1_22, m1_23;
  vector float m1_30, m1_31, m1_32, m1_33;
#ifdef __SPU__
  vector unsigned char splat0;
  vector unsigned char splat1;
  vector unsigned char splat2;
  vector unsigned char splat3;

  splat0 = (vector unsigned char)(spu_splats((unsigned int)0x10203));
  splat1 = spu_or(splat0, 0x4);
  splat2 = spu_or(splat0, 0x8);
  splat3 = spu_or(splat0, 0xC);
  
  m1_0 = *(m1 + 0);
  m1_1 = *(m1 + 1);
  m1_2 = *(m1 + 2);
  m1_3 = *(m1 + 3);

  m1_00 = spu_shuffle(m1_0, m1_0, splat0);
  m1_10 = spu_shuffle(m1_1, m1_1, splat0);
  m1_20 = spu_shuffle(m1_2, m1_2, splat0);
  m1_30 = spu_shuffle(m1_3, m1_3, splat0);

  m2_0 = *(m2 + 0);
  mOut_0 = spu_mul(m1_00, m2_0);
  mOut_1 = spu_mul(m1_10, m2_0);
  mOut_2 = spu_mul(m1_20, m2_0);
  mOut_3 = spu_mul(m1_30, m2_0);

  m1_01 = spu_shuffle(m1_0, m1_0, splat1);
  m1_11 = spu_shuffle(m1_1, m1_1, splat1);
  m1_21 = spu_shuffle(m1_2, m1_2, splat1);
  m1_31 = spu_shuffle(m1_3, m1_3, splat1);

  m2_1 = *(m2 + 1);
  mOut_0 = spu_madd(m1_01, m2_1, mOut_0);
  mOut_1 = spu_madd(m1_11, m2_1, mOut_1); 
  mOut_2 = spu_madd(m1_21, m2_1, mOut_2);
  mOut_3 = spu_madd(m1_31, m2_1, mOut_3);

  m1_02 = spu_shuffle(m1_0, m1_0, splat2);
  m1_12 = spu_shuffle(m1_1, m1_1, splat2);
  m1_22 = spu_shuffle(m1_2, m1_2, splat2);
  m1_32 = spu_shuffle(m1_3, m1_3, splat2);

  m2_2 = *(m2 + 2);
  mOut_0 = spu_madd(m1_02, m2_2, mOut_0);
  mOut_1 = spu_madd(m1_12, m2_2, mOut_1);
  mOut_2 = spu_madd(m1_22, m2_2, mOut_2);
  mOut_3 = spu_madd(m1_32, m2_2, mOut_3);

  m1_03 = spu_shuffle(m1_0, m1_0, splat3);
  m1_13 = spu_shuffle(m1_1, m1_1, splat3);
  m1_23 = spu_shuffle(m1_2, m1_2, splat3);
  m1_33 = spu_shuffle(m1_3, m1_3, splat3);
  
  m2_3 = *(m2 + 3);
  mOut_0 = spu_madd(m1_03, m2_3, mOut_0);
  mOut_1 = spu_madd(m1_13, m2_3, mOut_1);
  mOut_2 = spu_madd(m1_23, m2_3, mOut_2);
  mOut_3 = spu_madd(m1_33, m2_3, mOut_3);

#else /* !__SPU__ */
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});

  m1_0 = *(m1 + 0);
  m1_1 = *(m1 + 1);
  m1_2 = *(m1 + 2);
  m1_3 = *(m1 + 3);

  m1_00 = vec_splat(m1_0, 0);
  m1_10 = vec_splat(m1_1, 0);
  m1_20 = vec_splat(m1_2, 0);
  m1_30 = vec_splat(m1_3, 0);

  m2_0 = *(m2 + 0);
  mOut_0 = vec_madd(m1_00, m2_0, vzero);
  mOut_1 = vec_madd(m1_10, m2_0, vzero);
  mOut_2 = vec_madd(m1_20, m2_0, vzero);
  mOut_3 = vec_madd(m1_30, m2_0, vzero);

  m1_01 = vec_splat(m1_0, 1);
  m1_11 = vec_splat(m1_1, 1);
  m1_21 = vec_splat(m1_2, 1);
  m1_31 = vec_splat(m1_3, 1);

  m2_1 = *(m2 + 1);
  mOut_0 = vec_madd(m1_01, m2_1, mOut_0);
  mOut_1 = vec_madd(m1_11, m2_1, mOut_1);
  mOut_2 = vec_madd(m1_21, m2_1, mOut_2);
  mOut_3 = vec_madd(m1_31, m2_1, mOut_3);

  m1_02 = vec_splat(m1_0, 2);
  m1_12 = vec_splat(m1_1, 2);
  m1_22 = vec_splat(m1_2, 2);
  m1_32 = vec_splat(m1_3, 2);

  m2_2 = *(m2 + 2);
  mOut_0 = vec_madd(m1_02, m2_2, mOut_0);
  mOut_1 = vec_madd(m1_12, m2_2, mOut_1);
  mOut_2 = vec_madd(m1_22, m2_2, mOut_2);
  mOut_3 = vec_madd(m1_32, m2_2, mOut_3);

  m1_03 = vec_splat(m1_0, 3);
  m1_13 = vec_splat(m1_1, 3);
  m1_23 = vec_splat(m1_2, 3);
  m1_33 = vec_splat(m1_3, 3);
  
  m2_3 = *(m2 + 3);
  mOut_0 = vec_madd(m1_03, m2_3, mOut_0);
  mOut_1 = vec_madd(m1_13, m2_3, mOut_1);
  mOut_2 = vec_madd(m1_23, m2_3, mOut_2);
  mOut_3 = vec_madd(m1_33, m2_3, mOut_3);

#endif /* __SPU__ */

  *(mOut + 0) = mOut_0;
  *(mOut + 1) = mOut_1;
  *(mOut + 2) = mOut_2;
  *(mOut + 3) = mOut_3;
}

#endif /* _MULT_MATRIX_4X4_H_ */
