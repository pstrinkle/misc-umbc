/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ROT_MATRIX_4X4_TO_QUAT_H_
#define _ROT_MATRIX_4X4_TO_QUAT_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	vector float _rot_matrix4x4_to_quat(vector float *rotMatrix)
 *
 * DESCRIPTION
 *	_rot_matrix4x4_to_quat converts a rotation matrix into a 
 *      unit length quaternion. The rotation matrix is the upper-left 3x3
 *      of the 4x4 matrix pointed to by rotMatrix and is assumed to 
 *      to have a positive trace (i.e., the sum of the diagonal entries,
 *	m[0][0], m[1][1], m[2][2]).
 */

static __inline vector float _rot_matrix4x4_to_quat(vector float *rotMatrix)
{
#ifdef __SPU__
  vector float row0, row1, row2, trace_v, s_v;
  float m00, m11, m22;
  float s, trace;
  float x0, x0_square, x0_quarter;
  vector float mat924t;
  vector float mat681z;
  vector float result;
  vector unsigned char shuffle_24_ = ((vector unsigned char) {
						 0x00, 0x00, 0x00, 0x00,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x10, 0x11, 0x12, 0x13,
						 0x00, 0x00, 0x00, 0x00});
  vector unsigned char shuffle6_1_ = ((vector unsigned char) {
						 0x18, 0x19, 0x1A, 0x1B,
						 0x00, 0x00, 0x00, 0x00,
						 0x04, 0x05, 0x06, 0x07,
						 0x00, 0x00, 0x00, 0x00});
  vector unsigned char shuffle512_ = ((vector unsigned char) {
						 0x14, 0x15, 0x16, 0x17,
						 0x04, 0x05, 0x06, 0x07,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x00, 0x00, 0x00, 0x00});
  vector unsigned char shuffle042z = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x10, 0x11, 0x12, 0x13,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x80, 0x80, 0x80, 0x80});
  vector unsigned char shuffle0124 = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x04, 0x05, 0x06, 0x07,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x10, 0x11, 0x12, 0x13});

  row0 = rotMatrix[0];
  row1 = rotMatrix[1];
  row2 = rotMatrix[2];

  m00 = spu_extract(row0, 0);
  m11 = spu_extract(row1, 1);
  m22 = spu_extract(row2, 2);

  /* Compute the trace of the rotation matrix.
   */
  trace = 1.0f + m00 + m11 + m22;

  /* Since we assume the trace of the matrix is greater than zero, then we
   * can simply generate the quaternion [ x, y, z, w] as follows:
   *     s = 0.5 / sqrt(trace);
   *     x = (row2.f[1] - row1.f[2]) * s;
   *     y = (row0.f[2] - row2.f[0]) * s;
   *     z = (row1.f[0] - row0.f[1]) * s;
   *     w = 0.25 / s = trace * s;
   */
  x0 = spu_extract(spu_rsqrte(spu_promote(trace, 0)), 0);
  x0_square = x0*x0;
  x0_quarter = 0.25f * x0;
  s  = 3.0f - trace*x0_square;
  

  s_v = spu_splats(s * x0_quarter);

  mat924t = spu_shuffle(row0, row1, shuffle_24_);
  mat681z = spu_shuffle(row0, row1, shuffle6_1_);
  mat924t = spu_shuffle(mat924t, row2, shuffle512_);
  mat681z = spu_shuffle(mat681z, row2, shuffle042z);
  trace_v = spu_promote(trace, 0);

  mat924t = spu_shuffle(mat924t, trace_v, shuffle0124);

  result = spu_sub(mat924t, mat681z);
  result = spu_mul(result, s_v);
    
  return (result);
#else /* !__SPU__ */
  vector float row0, row1, row2;
  vector float m00, m11, m22;
  vector float s, trace, trace1, trace2;
  vector float x0, x0_square, x0_quarter;
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});
  vector float mat924t;
  vector float mat681z;
  vector float result;
  vector unsigned char shuffle_350 = ((vector unsigned char) {
						 0x00, 0x00, 0x00, 0x00,
						 0x0C, 0x0D, 0x0E, 0x0F,
						 0x14, 0x15, 0x16, 0x17,
						 0x00, 0x01, 0x02, 0x03});
  vector unsigned char shuffle7_24 = ((vector unsigned char) {
						 0x1C, 0x1D, 0x1E, 0x1F,
						 0x00, 0x00, 0x00, 0x00,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x10, 0x11, 0x12, 0x13});
  vector unsigned char shuffle5123 = ((vector unsigned char) {
						 0x14, 0x15, 0x16, 0x17,
						 0x04, 0x05, 0x06, 0x07,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x0C, 0x0D, 0x0E, 0x0F});
  vector unsigned char shuffle0423 = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x10, 0x11, 0x12, 0x13,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x0C, 0x0D, 0x0E, 0x0F});

  row0 = rotMatrix[0];
  row1 = rotMatrix[1];
  row2 = rotMatrix[2];

  m00 = vec_splat(row0, 0);
  m11 = vec_splat(row1, 1);
  m22 = vec_splat(row2, 2);

  /* Compute the trace of the rotation matrix.
   */
  trace1 = vec_add(m00, ((vector float) {1.0,1.0,1.0,1.0}));
  trace2 = vec_add(m11, m22);
  trace  = vec_add(trace1, trace2);

  /* Since we assume the trace of the matrix is greater than zero, then we
   * can simply generate the quaternion [ x, y, z, w] as follows:
   *     s = 0.5 / sqrt(trace);
   *     x = (row2.f[1] - row1.f[2]) * s;
   *     y = (row0.f[2] - row2.f[0]) * s;
   *     z = (row1.f[0] - row0.f[1]) * s;
   *     w = 0.25 / s = trace * s;
   */
  x0 = vec_rsqrte(trace);
  x0_square = vec_madd(x0, x0, vzero);
  x0_quarter = vec_madd(x0, ((vector float) {0.25f,0.25f,0.25f,0.25f}), vzero);
  s = vec_nmsub(trace, x0_square, ((vector float) {3.0f,3.0f,3.0f,3.0f}));
  s = vec_madd(s, x0_quarter, vzero);

  row0 = vec_sld(trace, row0, 12);	/* row0 = t 0 1 2 */
  row1 = vec_sld(vzero, row1, 12);	/* row1 = z 4 5 6 */

  mat924t = vec_perm(row0, row1, shuffle_350);
  mat681z = vec_perm(row0, row1, shuffle7_24);

  mat924t = vec_perm(mat924t, row2, shuffle5123);
  mat681z = vec_perm(mat681z, row2, shuffle0423);

  result = vec_sub(mat924t, mat681z);
  result = vec_madd(result, s, vzero);
    
  return (result);
#endif /* __SPU__ */
}

#endif /* _ROT_MATRIX_4X4_TO_QUAT_H_ */


