%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Library containing matrix routines for PPE and SPE.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory builds a library (libmatrix) that contains the
	following matrix functions for the PPE and SPE:

	frustum_matrix4x4
		constructs a perspective projection transformation matrix.

	identity_matrix4x4
		constructs a 4x4 identity matrix

	inverse_matrix4x4
		generates the inverse of the input matrix

	mult_matrix4x4
		multiplies input 4x4 matrices

	mult_quat
		multiplies unit length input quaternions

	ortho_matrix4x4
		constructs a orthographic parallel view volume matrix.

	perspective_matrix4x4
		constructs a perspective projection transformation matrix.

	quat_to_rot_matrix4x4
		constructs a quaternion rotation of a matrix

	rot_matrix4x4_to_quat
		converts a rotation matrix into a unit length quaternion

	scale_matrix4x4
		multiplies input 4x4 matrix by scale matrix

	slerp_quat
		generates the Spherical Linear intERPolation along a great
		arc on the 4D sphere

	splat_matrix4x4
		converts a 4x4 floating-point matrix into a vector replicated
		matrix suitable for simultaneously transforming 4 independent
		vectors using SIMD vector operations

	transpose_matrix4x4
		performs a transpose on the 4x4 input matrix
		
	rotate_matrix4x4
		constructs a matrix that performs a rotation of "angle"
		radians about the pre-normalized (unit length) vector


	The following functions are SPE only:

	mult_matrix4x4_d
		multiplies double precision input 4x4 matrices

	cast_matrix4x4_to_dbl
		converts a 4x4 single precision floating-point matrix into a
		double precision matrix.

	cast_matrix4x4_to_flt
		converts a 4x4 double precision floating-point matrix into a
		single precision matrix.

