/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SLERP_QUAT_H_
#define _SLERP_QUAT_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

#include <simdmath/sinf4.h>
#include <simdmath/divf4.h>
#include <simdmath/acosf4.h>

/*
 * FUNCTION
 *      vector float _slerp_qaut(vector float q1, vector float q2, float t)
 * 
 * DESCRIPTION
 *	_slerp_quat generates the Spherical Linear intERPolation along a great
 *	arc on the 4D sphere (which is the shortest way between unit 
 *	quaternions q1 and q2). The interpolation factor, t, varies from 0.0
 *	to 1.0 cooresponding to orientaions q1 and q2 respectively.
 *
 *	The slerp is computed as follows:
 *
 *	slerp_quat(q1, q2, t) = (q1*sin((1-t)*theta) + q2*sin(t*theta)) / sin(theta);
 *
 *	where: cos(theta) = q1 . q2
 *
 *	If the spherical distance bewteen q1 and q2 is very small, then linear interpolation 
 *	is performed.
 */


#define MIN_SPHERICAL_ANGLE	0.0001


static __inline vector float _slerp_quat(vector float q1, vector float q2, float t)
{
  vector float result;
  vector float product, p2, p3, p4, p12, p34, dot;
  vector float one_minus_alpha;
  vector float sines, sine_omega, omega, angle;
  vector float scales, scale0, scale1;
  vector unsigned int sign;

#if __SPU__
  vector float vone = spu_splats((float)1.0);
  vector unsigned int msb = spu_splats((unsigned int)0x80000000);
  vector float alpha;
  vector unsigned int selector;
  vector unsigned char splat0 = ((vector unsigned char) {
					    0, 1, 2, 3, 0, 1, 2, 3,
					    0, 1, 2, 3, 0, 1, 2, 3});
  vector unsigned char splat1, splat2;


  splat1 = spu_or(splat0, 4);
  splat2 = spu_or(splat0, 8);

  alpha = spu_promote(t, 0);
  alpha = spu_shuffle(alpha, alpha, splat0);
  one_minus_alpha = spu_sub(vone, alpha);

  /* Compute the 4-dimensional dot product across the entire SIMD vector. */
  product = spu_mul(q1, q2);

  p2 = spu_rlqwbyte(product, 4);
  p3 = spu_rlqwbyte(product, 8);
  p4 = spu_rlqwbyte(product, 12);

  p12 = spu_add(product, p2);
  p34 = spu_add(p3, p4);

  dot = spu_add(p12, p34);

  sign = spu_and((vector unsigned int)dot, msb);

  /* Adjust sign if necessary */
  q2 = (vector float)spu_xor((vector unsigned int)q2, sign);
  dot = (vector float)spu_andc((vector unsigned int)dot, msb);

  omega = _acosf4(dot);

  angle = spu_sel(alpha, one_minus_alpha, ((vector unsigned int) { 0, -1, 0, 0}));
  angle = spu_sel(angle, vone, ((vector unsigned int) { 0, 0, -1, 0}));

  angle = spu_mul(angle, omega);

  /* angle = t*omega, (1-t)*omega, omega, t*omega */
  sines = _sinf4(angle);

  sine_omega = spu_shuffle(sines, sines, splat2);

  scales = _divf4(sines, sine_omega);
  
  scale0 = spu_shuffle(scales, scales, splat1);
  scale1 = spu_shuffle(scales, scales, splat0);

  /* If the spherical disance between q1 and q2 is small, then linear inrtpolate.
   */
  selector = spu_cmpgt(omega, spu_splats((float)MIN_SPHERICAL_ANGLE));

  scale0 = spu_sel(one_minus_alpha, scale0, selector);
  scale1 = spu_sel(alpha, scale1, selector);
  
  /* Compute interpolation */
  result = spu_mul(q1, scale0);
  result = spu_madd(q2, scale1, result);
  
#else /* !__SPU__ */
  vector float vone = ((vector float) {1.0,1.0,1.0,1.0});
  vector unsigned int msb = ((vector unsigned int) {0x80000000,0x80000000,0x80000000,0x80000000});
  union {
    vector float fv;
    float f[4];
  } alpha;
  vector unsigned int selector;
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});

  alpha.f[0] = t;
  alpha.fv = vec_splat(alpha.fv, 0);
  one_minus_alpha = vec_sub(vone, alpha.fv);

  /* Compute the 4-dimensional dot product across the entire SIMD vector. */
  product = vec_madd(q1, q2, vzero);

  p2 = vec_sld(product, product, 4);
  p3 = vec_sld(product, product, 8);
  p4 = vec_sld(product, product, 12);

  p12 = vec_add(product, p2);
  p34 = vec_add(p3, p4);

  dot = vec_add(p12, p34);

  sign = vec_and((vector unsigned int)dot, msb);

  /* Adjust sign if necessary */
  q2 = (vector float)vec_xor((vector unsigned int)q2, sign);
  dot = (vector float)vec_andc((vector unsigned int)dot, msb);

  omega = _acosf4(dot);

  angle = vec_sel(alpha.fv, one_minus_alpha, ((vector unsigned int) { 0x0, 0xFFFFFFFF, 0x0, 0x0}));
  angle = vec_sel(angle, vone, ((vector unsigned int) { 0x0, 0x0, 0xFFFFFFFF, 0x0}));

  angle = vec_madd(angle, omega, vzero);

  /* angle = t*omega, (1-t)*omega, omega, t*omega */
  sines = _sinf4(angle);

  sine_omega = vec_splat(sines, 2);

  scales = _divf4(sines, sine_omega);
  
  scale0 = vec_splat(scales, 1);
  scale1 = vec_splat(scales, 0);

  /* If the spherical disance between q1 and q2 is small, then linear inrtpolate.
   */
  selector = (vector unsigned int)vec_cmpgt(omega, ((vector float) {MIN_SPHERICAL_ANGLE,MIN_SPHERICAL_ANGLE,MIN_SPHERICAL_ANGLE,MIN_SPHERICAL_ANGLE}));

  scale0 = vec_sel(one_minus_alpha, scale0, selector);
  scale1 = vec_sel(alpha.fv, scale1, selector);
  
  /* Compute interpolation */
  result = vec_madd(q1, scale0, vzero);
  result = vec_madd(q2, scale1, result);
#endif /* __SPU__ */
  
  return (result);
  }

#endif /* _SLERP_QUAT_H_ */
