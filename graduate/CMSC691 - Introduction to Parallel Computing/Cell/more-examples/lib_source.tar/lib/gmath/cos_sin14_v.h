/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _COS_SIN14_V_H_
#define _COS_SIN14_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif


#ifndef M_1_2PI
#define M_1_2PI		0.1591549430919		/* 1/(2*pi) */ 
#endif /* M_1_2PI */

/*
 * FUNCTION
 *	vector float _cos_sin14(vector float angle)
 *
 * DESCRIPTION
 *	_cos_sin14 computes the cosine of a vector of angles 
 * 	(expressed in normalized radians) to an accuracy of 
 *	at least 14 bits for angle of 0.0 to 1.0. Angles outside 
 *	this range are less accurate. Normalized radians mean that
 *	an angle of 1.0 corresponds to 2*PI radians. The cosine is
 *	computed using an 8 segment piecewise, quadratic approximation 
 *	over the interval [0, 0.25) normalized radians.	Symmetry of 
 *	the cosine function is used to produce results over the 
 *	remainder of the interval. The quadratic evaluation is of the 
 *	form 
 *		A*x*x + B*x + C, 
 *	where x is the 1.0 plus the fractional input angle.
 */

/* Precomputed quadratic coefficients */
static vector float cos14_A_v[2] = {
  (vector float) { -19.62842, -18.87403, -17.39576,-15.24641}, 
  (vector float) { -12.51265,  -9.298583, -5.724892,-1.933483}
};
static vector float cos14_B_v[2] = {
  (vector float) { 39.25535,  37.69651, 34.55251,  29.84836}, 
  (vector float) { 23.69532,  16.26119,  7.772535, -1.469602}
};
static vector float cos14_C_v[2] = {
  (vector float) { -18.62693, -17.82171,-16.14998, -13.57606}, 
  (vector float) { -10.11380,  -5.815027,-0.774209,  4.858068}
};

static __inline vector float _cos_sin14_v(vector float angle)
{
  vector unsigned int bit31;
  vector unsigned int idx;
  vector unsigned int quadrant23;
  vector unsigned int quadrant34;
  vector unsigned int mirror;
  vector unsigned int negflag;
  vector float a, b, c;
  vector float work1, work2, frac, result;

  work1 = angle;

#ifdef __SPU__
  bit31 = spu_splats((unsigned int)0x80000000);
  work1 = (vector float)spu_andc((vector unsigned int)(work1), bit31);
  work2 = (vector float)spu_convts(work1, 0);
  work1  = spu_add(work1, spu_splats((float)1.0)); 
  work2  = spu_convtf((vector signed int)work2, 0);
  frac   = spu_sub(work1, work2);

  quadrant23 = spu_sl((vector unsigned int)frac, 10);
  quadrant34 = spu_sl((vector unsigned int)frac, 9);
  frac = (vector float)spu_and((vector unsigned int)frac, spu_splats((unsigned int)0xff9fffff));
  negflag  = spu_xor(quadrant23, quadrant34);
  negflag  = spu_and(negflag, bit31);
  mirror   = spu_rlmaska(quadrant23, -20);
  mirror   = spu_rlmask(mirror, -11);
  frac = (vector float)spu_xor((vector unsigned int)frac, mirror);  		     

  idx      = spu_rlmask((vector unsigned int)frac, -16);
  idx      = spu_shuffle(idx, idx, ((vector unsigned char) { 0x03, 0x03, 0x03, 0x03, 0x07, 0x07, 0x07, 0x07,
  								0x0b, 0x0b, 0x0b, 0x0b, 0x0f, 0x0f, 0x0f, 0x0f}));
  idx      = spu_sel(spu_splats((unsigned int)0x00010203), idx, spu_splats((unsigned int)0x1c1c1c1c));
  
  a = spu_shuffle(cos14_A_v[0], cos14_A_v[1], (vector unsigned char)(idx));
  b = spu_shuffle(cos14_B_v[0], cos14_B_v[1], (vector unsigned char)(idx));
  c = spu_shuffle(cos14_C_v[0], cos14_C_v[1], (vector unsigned char)(idx));

  result = spu_madd(frac, a, b);
  result = spu_madd(frac, result, c);
  result = (vector float)spu_or((vector unsigned int)result, negflag);
#else /* !__SPU__ */
  bit31 = ((vector unsigned int) {0x80000000,0x80000000,0x80000000,0x80000000});
  work1 = (vector float)vec_andc((vector unsigned int)(work1), bit31);
  work2 = (vector float)vec_cts(work1, 0);
  work1  = vec_add(work1, ((vector float) {1.0f,1.0f,1.0f,1.0f})); 
  work2  = vec_ctf((vector signed int)work2, 0);
  frac   = vec_sub(work1, work2);

  quadrant23 = vec_sl((vector unsigned int)frac, ((vector unsigned int) {10,10,10,10}));
  quadrant34 = vec_sl((vector unsigned int)frac, ((vector unsigned int) {9,9,9,9}));
  frac = (vector float)vec_and((vector unsigned int)frac, ((vector unsigned int) {0xff9fffff,0xff9fffff,0xff9fffff,0xff9fffff}));
  negflag  = vec_xor(quadrant23, quadrant34);
  negflag  = vec_and(negflag, bit31);
  mirror   = vec_sra(quadrant23, ((vector unsigned int) {20,20,20,20}));
  mirror   = vec_sr(mirror, ((vector unsigned int) {11,11,11,11}));
  frac = (vector float)vec_xor((vector unsigned int)frac, mirror);  		     

  idx      = vec_sr((vector unsigned int)frac, ((vector unsigned int) {16,16,16,16}));
  idx      = vec_perm(idx, idx, ((vector unsigned char) { 0x03, 0x03, 0x03, 0x03, 0x07, 0x07, 0x07, 0x07,
  								0x0b, 0x0b, 0x0b, 0x0b, 0x0f, 0x0f, 0x0f, 0x0f}));
  idx      = vec_sel(((vector unsigned int) {0x00010203,0x00010203,0x00010203,0x00010203}), idx,
  			((vector unsigned int) {0x1c1c1c1c,0x1c1c1c1c,0x1c1c1c1c,0x1c1c1c1c,}));
  
  a = (vector float)vec_perm((vector unsigned int)(cos14_A_v[0]), (vector unsigned int)(cos14_A_v[1]), (vector unsigned char)(idx));
  b = (vector float)vec_perm((vector unsigned int)(cos14_B_v[0]), (vector unsigned int)(cos14_B_v[1]), (vector unsigned char)(idx));
  c = (vector float)vec_perm((vector unsigned int)(cos14_C_v[0]), (vector unsigned int)(cos14_C_v[1]), (vector unsigned char)(idx));

  result = vec_madd(frac, a, b);
  result = vec_madd(frac, result, c);
  result = (vector float)vec_or((vector unsigned int)result, negflag);
#endif /* __SPU__ */

  return (result);
}

#endif /* _COS_SIN14_V_H_ */
