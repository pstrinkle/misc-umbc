/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _NORMAL16_H_
#define _NORMAL16_H_	1

/* PACK_RANGE can be adjusted to provide increased range of supported packed values. 
 * Values outside this +- range will produces unexpected results due to wrapping of
 * the packed fixed-point cooredinate space. Too large of values will result in a loss
 * of precision.
 */

#define PACK_RANGE			(1.01f)
#define PACK_NORMAL_SCALE		(32768.0f / PACK_RANGE)
#define PACK_NORMAL_BIAS		(12582912.0f)		/* 1.5 * 2^23 */
#define UNPACK_NORMAL_SCALE		(PACK_RANGE)
#if __SPU__
/* SPU bias is compensated for floating point truncation */
#define UNPACK_NORMAL_BIAS		(-2.999985f * UNPACK_NORMAL_SCALE)
#define VECTOR_PACK_NORMAL_SCALE	(spu_splats((float)PACK_NORMAL_SCALE))

#define VECTOR_UNPACK_NORMAL_SCALE	(spu_splats((float)UNPACK_NORMAL_SCALE))

#define VECTOR_PACK_NORMAL_BIAS		(spu_splats((float)PACK_NORMAL_BIAS))

#define VECTOR_UNPACK_NORMAL_BIAS	(spu_splats((float)UNPACK_NORMAL_BIAS))
#else
#define UNPACK_NORMAL_BIAS		(-3.0f      * UNPACK_NORMAL_SCALE)
#define VECTOR_PACK_NORMAL_SCALE	(((vector float) {PACK_NORMAL_SCALE,PACK_NORMAL_SCALE,PACK_NORMAL_SCALE,PACK_NORMAL_SCALE}))

#define VECTOR_UNPACK_NORMAL_SCALE	(((vector float) {UNPACK_NORMAL_SCALE,UNPACK_NORMAL_SCALE,UNPACK_NORMAL_SCALE,UNPACK_NORMAL_SCALE}))

#define VECTOR_PACK_NORMAL_BIAS		(((vector float) {PACK_NORMAL_BIAS,PACK_NORMAL_BIAS,PACK_NORMAL_BIAS,PACK_NORMAL_BIAS}))

#define VECTOR_UNPACK_NORMAL_BIAS	(((vector float) {UNPACK_NORMAL_BIAS,UNPACK_NORMAL_BIAS,UNPACK_NORMAL_BIAS,UNPACK_NORMAL_BIAS}))
#endif

#endif /* _NORMAL16_H_ */






