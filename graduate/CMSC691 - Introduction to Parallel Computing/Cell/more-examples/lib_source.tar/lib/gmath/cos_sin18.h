/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _COS_SIN18_H_
#define _COS_SIN18_H_	1

#ifndef M_16_PI
#define M_16_PI		 5.0929581789407f         /* 16/pi */ 
#endif /* M_16_PI */

/*
 * FUNCTION
 *	float _cos_sin18(float angle)
 *
 * DESCRIPTION
 *	_cos_sin18 computes the cosine of "angle" (expressed in normalized 
 *      radians) to an accuracy of at least 18 bits for angle of 0.0 to 
 *	1.0. Angles outside this range are less accurate. Normalized 
 *	radians mean that an angle of 1.0 corresponds to 2*PI radians. 
 *      The cosine is computed using an 8 segment piecewise, cubic
 *      approximation over the interval [0, 0.25) normalized radians.
 *	Symmetry of the cosine function is used to produce results over
 *	the remainder of the interval. The cubic evaluation is of the form 
 *		((A * x + B) * x + C) * x + D
 *	where x is the fractional input angle within the segments interval.
 */

/* Precomputed quadratic coefficients */
static float cos18_A[8] = {
  0.00012354,0.00036588,0.00059416,0.00079961,
  0.00097433,0.00111160,0.00120616,0.00125436 };

static float cos18_B[8] = {
  -0.01933826,-0.01896574,-0.01786437,-0.01607648,
  -0.01367078,-0.01073973,-0.00739595,-0.00376795 };

static float cos18_C[8] = {
  -0.00000000,-0.03830589,-0.07513972,-0.10908596,
  -0.13884009,-0.16325867,-0.18140332,-0.19257674 };

static float cos18_D[8] = {
  1.00000000,0.98078525,0.92387950,0.83146960,
  0.70710677,0.55557024,0.38268343,0.19509032 };


static __inline float _cos_sin18(float angle)
{
  unsigned int idx;
  union {
    float f;
    unsigned int ui;
  } ang, result;
  float ctmpl, ctmph;
  float fang;
  float ang2;
  unsigned int bit31;
  unsigned int iang;
  unsigned int negflag;
  
  bit31 = (1<<31);
  ang.f = angle;
  /* remove sign since cos(x) == cos(-x) */
  ang.ui &= ~bit31;

  iang = (unsigned int)(ang.f);
  fang  = (float)((unsigned int)iang);

  ang.f = ang.f - fang;
  ang2 = ang.f * ang.f;

  if (iang & 0x8) {
    /* between PI/2 and 3*PI/2 */
    ang.f = 1.0f - ang.f;
    iang ^= 0x17;
  }
  negflag = (iang << 27) & bit31;
  
  idx = iang & 7;
  ang2 = ang.f * ang.f;
  ctmpl = cos18_C[idx] * ang.f + cos18_D[idx];
  ctmph = cos18_A[idx] * ang.f + cos18_B[idx];
  result.f = ctmph * ang2 + ctmpl;
  result.ui |= negflag;

  return (result.f);
}

#endif /* _COS_SIN18_H_ */







