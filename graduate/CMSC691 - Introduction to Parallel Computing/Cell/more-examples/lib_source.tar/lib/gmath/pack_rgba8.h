/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _PACK_RGBA8_H_
#define _PACK_RGBA8_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#include "load_vec_float4.h"
#else /* not __SPU__ */
#include <altivec.h>
#endif
/*
 * FUNCTION
 *	unsigned int _pack_rgba8(float red, float green, float blue, float alpha);
 * 
 * DESCRIPTION
 *	_pack_rgba8 converts a 4 component normalized (0.0 to 1.0) color into 
 *	a packed rgba fixed-point (8 bits per component) color. Values outside
 *	the normalized range are clamped to the range prior to conversion.
 *	Packed color can be unpacked (one component at a time) using the 
 *	function _unpack_rgba8.
 */

static __inline unsigned int _pack_rgba8(float red, float green, float blue, float alpha)
{
  vector float in;

#ifdef __SPU__
  vector unsigned int out;

  in = _load_vec_float4(red, green, blue, alpha);

  out = spu_convtu(in, 32);
  out = spu_shuffle(out, out, ((vector unsigned char) {
					  0, 4, 8, 12, 0, 0, 0, 0, 
					  0, 0, 0,  0, 0, 0, 0, 0}));
  return(spu_extract(out, 0));
#else
  union {
    vector unsigned int iv;
    unsigned int i[4];
  } out;

  /* load_vec_float4 logic was placed into this file instead of
   * inlined like it is done for the SPU becase of the gcc problem
   * inlining functions with both scalar and vector iputs and outputs.
   */
  union {
    vector float fv;
    float f[4];
  } fv1, fv2, fv3, fv4;
  vector float f1f30000, f2f40000;

  fv1.f[0] = red;
  fv3.f[0] = blue;
  fv2.f[0] = green;
  fv4.f[0] = alpha;

  f2f40000 = vec_mergeh(fv2.fv, fv4.fv);
  f1f30000 = vec_mergeh(fv1.fv, fv3.fv);

  in = vec_mergeh(f1f30000, f2f40000);

  in = vec_add(in, in);
  out.iv = vec_ctu(in, 31);
  out.iv = vec_perm(out.iv, out.iv, ((vector unsigned char) { 
						0, 4, 8, 12, 0, 0, 0, 0, 
						0, 0, 0,  0, 0, 0, 0, 0}));
  return(out.i[0]);
#endif

}


#endif /* _PACK_RGBA8_H_ */






