/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SPEC9_H_
#define _SPEC9_H_	1

#include "spec9_types.h"

/*
 * FUNCTION
 *	float _spec9(float base, spec9Exponent *exp)
 *
 * DESCRIPTION
 *	_spec9 computes the power function of the form x^y for the limited 
 *	set of values traditionally used in specular lighting.
 *	_spec9 exploits the shuffle byte instruction to compute
 *	the power function using a 8 segment piecewise quadratic 
 *	approximation. The exponent is an integer within the range 
 *	0-255. The base (x) is a floating point value in the range 0.0
 *	to 1.0. Values below 0.0 produce 0.0 and above produce 1.0.
 *
 *      The coefficients for the quadratic equations are computed 
 *      by the set_spec_exponent9 subroutine and are passed to _spec9
 *	by the exp parameter.
 *
 *	_spec9 is accurate to at least 9 bits.
 */

static __inline float _spec9(float base, spec9Exponent *exp)
{
  unsigned int idx;
  union { 
    unsigned int ui;
    float f;
  } frac;
  float result;

  /* Compute the spec power function using 8 piecewise quadratic
   * equations.
   */
  frac.f = base * *((float *)(&exp->scale)) + *((float *)(&exp->offset));
  if ((frac.ui >> 23) == 0x7f) {
    idx = (frac.ui >> 20) & 0x7;
    result = ((*((float *)(exp->A) + idx) * frac.f + 
	       *((float *)(exp->B) + idx)) * frac.f +
	      *((float *)(exp->C) + idx));
  } else {
    result = (frac.f < 1.0f) ? 0.0f : 1.0f;
  }
  return (result);
}


#endif /* _SPEC9_H_ */







