/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SET_SPEC_EXPONENT9_H_
#define _SET_SPEC_EXPONENT9_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

#include <simdmath/recipf4.h>
#include "spec9_types.h"

/*
 * FUNCTION
 *	void set_spec_exponent9(spec9Exponent *exp, signed int exponent)
 *
 * DESCRIPTION
 *	set_spec_exponent9 generates the coefficients for the 
 *	quadratic equations used by spec9 and spec9_v by 
 *      solving a set of simultaneous set of equations at the 
 *	endpoints and center of each segment. The 8 segments
 *	are uniformily across the interval threshold to 1.0.
 *	All values below threshold evaluate to 0.0.
 *
 *	The coefficients are returned in the structure pointed
 *	to by exp.
 */

/* The threshold table (specThresholds) contains the minimum 
 * base (x) for which we compute specular x^exp using piecewise quadratic
 * equations. Values below this minimum will always evaluate to 0.0.
 * The table is indexed by the 6 msbs of the 8-bit specular exponent 
 * (exp). Its contents are computed so that error is no worse computed 
 * so that threshold**exp < 1/512.
 */
static float specThresholds[64] = { 
  0.000000,0.210224,0.458502,0.594604,0.677128,0.732043,0.771105,0.800277,
  0.822878,0.840896,0.855595,0.867812,0.878126,0.886949,0.894582,0.901250,
  0.907126,0.912342,0.917004,0.921195,0.924984,0.928425,0.931564,0.934440,
  0.937084,0.939523,0.941780,0.943874,0.945823,0.947642,0.949342,0.950935,
  0.952432,0.953839,0.955166,0.956419,0.957603,0.958725,0.959789,0.960800,
  0.961761,0.962676,0.963548,0.964381,0.965176,0.965936,0.966664,0.967362,
  0.968031,0.968673,0.969290,0.969883,0.970453,0.971003,0.971532,0.972042,
  0.972535,0.973010,0.973469,0.973913,0.974342,0.974757,0.975159,0.975549
};

static vector unsigned char shuffle2460 = (vector unsigned char) { 
						      0x08, 0x09, 0x0A, 0x0B, 0x10, 0x11, 0x12, 0x13, 
						      0x18, 0x19, 0x1A, 0x1B, 0x00, 0x01, 0x02, 0x03};
static vector unsigned char shuffle1357 = (vector unsigned char) {
						      0x04, 0x05, 0x06, 0x07, 0x0C, 0x0D, 0x0E, 0x0F, 
						      0x14, 0x15, 0x16, 0x17, 0x1C, 0x1D, 0x1E, 0x1F};
static vector unsigned char shuffle0124 = (vector unsigned char) {
						      0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 
						      0x08, 0x09, 0x0A, 0x0B, 0x10, 0x11, 0x12, 0x13};
static vector unsigned char shuffle0246 = (vector unsigned char) {
						      0x00, 0x01, 0x02, 0x03, 0x08, 0x09, 0x0A, 0x0B, 
						      0x10, 0x11, 0x12, 0x13, 0x18, 0x19, 0x1A, 0x1B};

static vector float m21_0 = (vector float) { 1.128906, 1.410156, 1.722656, 2.066406};
static vector float m21_1 = (vector float) { 2.441406, 2.847656, 3.285156, 3.753906};
static vector float m31_0 = (vector float) { 1.000000, 1.265625, 1.562500, 1.890625};
static vector float m31_1 = (vector float) { 2.250000, 2.640625, 3.062500, 3.515625};
static vector float m32_0 = (vector float) { 0.111111, 0.112500, 0.113636, 0.114583};
static vector float m32_1 = (vector float) { 0.115385, 0.116071, 0.116667, 0.117187};
static vector float m12_0 = (vector float) { 1.125000, 1.250000, 1.375000, 1.500000};
static vector float m12_1 = (vector float) { 1.625000, 1.750000, 1.875000, 2.000000};
static vector float m23_0 = (vector float) { 0.1080247, 0.0975000, 0.0888430, 0.0815972};
static vector float m23_1 = (vector float) { 0.0754438, 0.0701531, 0.0655556, 0.0615234};
static vector float mi11_0 = (vector float) { 0.790123, 0.640000, 0.528926, 0.444444};
static vector float mi11_1 = (vector float) { 0.378698, 0.326531, 0.284444, 0.250000};
static vector float mi22_0 = (vector float) { 16.94118, 16.84210, 16.76189, 16.69565};
static vector float mi22_1 = (vector float) { 16.64001, 16.59258, 16.55173, 16.51613};
static vector float mi33_0 = (vector float) { 153.0004, 189.9992, 230.9980, 276.0001};
static vector float mi33_1 = (vector float) { 325.0043, 377.9959, 435.0032, 495.9991};


static __inline void _set_spec_exponent9(spec9Exponent *exp, signed int exponent)
{
  vector float a0, a1, b0, b1, c0, c1;
  short i;
  vector float threshold;
  vector float incr;
  vector float oneMinusThreshold;
  vector float mulfac0, mulfac1, mulfac2, mulfac3;
  vector float x0, y0, x1, y1, x2, y2, x3, y3;
  vector float y1_0, y2_0, y3_0;
  vector float y1_1, y2_1, y3_1;
  vector float mi11_y1_0, mi11_y1_1;
  vector float mi22_y2_0, mi22_y2_1;

#ifdef __SPU__
/* Simple float values that can be loaded with a single instruction
 * generate better code when "#define" is used instead of a variable
 */
#define fv_one		(spu_splats((float)1.0f))
#define fv_oneEighth	(spu_splats((float)0.125f))

  threshold = spu_splats(specThresholds[exponent>>2]);
   
  oneMinusThreshold = spu_sub(fv_one, threshold);

  exp->scale = _recipf4(oneMinusThreshold);
  exp->offset = spu_nmsub(threshold, exp->scale, fv_one);

  incr = spu_mul(fv_oneEighth, oneMinusThreshold);

  mulfac0 = (vector float) { 0.0, 0.5, 1.0, 1.5};
  mulfac1 = (vector float) { 2.0, 2.5, 3.0, 3.5};
  mulfac2 = (vector float) { 4.0, 4.5, 5.0, 5.5};
  mulfac3 = (vector float) { 6.0, 6.5, 7.0, 7.5};

  x0 = spu_madd(mulfac0, incr, threshold);
  x1 = spu_madd(mulfac1, incr, threshold);
  x2 = spu_madd(mulfac2, incr, threshold);
  x3 = spu_madd(mulfac3, incr, threshold);

  y0 = y1 = y2 = y3 = fv_one;

  for (i=0; i<8; i++) {
    if (exponent & 1) {
      y0 = spu_mul(y0, x0);
      y1 = spu_mul(y1, x1);
      y2 = spu_mul(y2, x2);
      y3 = spu_mul(y3, x3);
    }
    x0 = spu_mul(x0, x0);
    x1 = spu_mul(x1, x1);
    x2 = spu_mul(x2, x2);
    x3 = spu_mul(x3, x3);
    exponent >>= 1;
  }

  /* Compute the 8 quadratic coefficients. 
   * Solve the three simultaneous equations at the endpoints and 
   * center of each segment. We use precomputed constants whenever 
   * possible to reduce computation.
   *
   *       *-----------*----------*
   *      y3          y2         y1
   */
  y1_0 = spu_shuffle(y0, y1, shuffle2460);
  y1_1 = spu_shuffle(y2, y3, shuffle2460);
  y2_0 = spu_shuffle(y0, y1, shuffle1357);
  y2_1 = spu_shuffle(y2, y3, shuffle1357);

  y3_0 = spu_shuffle(y0, y1, shuffle0246);

  y3_1 = spu_shuffle(y2, y3, shuffle0246);
  y1_0 = spu_shuffle(y1_0, y2, shuffle0124);
  y1_1 = spu_shuffle(y1_1, fv_one, shuffle0124);

  mi11_y1_0 = spu_mul(mi11_0, y1_0);
  mi11_y1_1 = spu_mul(mi11_1, y1_1);
  y2_0 = spu_nmsub(m21_0, mi11_y1_0, y2_0);
  y2_1 = spu_nmsub(m21_1, mi11_y1_1, y2_1);
  y3_0 = spu_nmsub(m31_0, mi11_y1_0, y3_0);
  y3_1 = spu_nmsub(m31_1, mi11_y1_1, y3_1);
  mi22_y2_0 = spu_mul(mi22_0, y2_0);
  mi22_y2_1 = spu_mul(mi22_1, y2_1);
  y3_0 = spu_nmsub(m32_0, mi22_y2_0, y3_0);
  y3_1 = spu_nmsub(m32_1, mi22_y2_1, y3_1);

  c0 = spu_mul(y3_0, mi33_0);
  c1 = spu_mul(y3_1, mi33_1);

  b0 = spu_nmsub(c0, m23_0, y2_0);
  b1 = spu_nmsub(c1, m23_1, y2_1);
  b0 = spu_mul(b0, mi22_0);
  b1 = spu_mul(b1, mi22_1);

  a0 = spu_madd(b0, m12_0, c0);
  a1 = spu_madd(b1, m12_1, c1);
  a0 = spu_nmsub(mi11_0, a0, mi11_y1_0);
  a1 = spu_nmsub(mi11_1, a1, mi11_y1_1);

#else /* !__SPU__ */
/* Simple float values that can be loaded with a single instruction
 * generate better code when "#define" is used instead of a variable
 */
#define fv_one		(((vector float) {1.0f,1.0f,1.0f,1.0f}))
#define fv_oneEighth	(((vector float) {0.125f,0.125f,0.125f,0.125f}))

  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});
  /* Work around problem with inlining some functions in PU gcc compiler.
   */
  union {
    vector float fv;
    float f[4];
  } splat;
 
  splat.f[0] = specThresholds[exponent>>2];
  threshold = vec_splat(splat.fv, 0);
   
  oneMinusThreshold = vec_sub(fv_one, threshold);

  exp->scale = _recipf4(oneMinusThreshold);
  exp->offset = vec_nmsub(threshold, exp->scale, fv_one);

  incr = vec_madd(fv_oneEighth, oneMinusThreshold, vzero);

  mulfac0 = (vector float) { 0.0, 0.5, 1.0, 1.5};
  mulfac1 = (vector float) { 2.0, 2.5, 3.0, 3.5};
  mulfac2 = (vector float) { 4.0, 4.5, 5.0, 5.5};
  mulfac3 = (vector float) { 6.0, 6.5, 7.0, 7.5};

  x0 = vec_madd(mulfac0, incr, threshold);
  x1 = vec_madd(mulfac1, incr, threshold);
  x2 = vec_madd(mulfac2, incr, threshold);
  x3 = vec_madd(mulfac3, incr, threshold);

  y0 = y1 = y2 = y3 = fv_one;

  for (i=0; i<8; i++) {
    if (exponent & 1) {
      y0 = vec_madd(y0, x0, vzero);
      y1 = vec_madd(y1, x1, vzero);
      y2 = vec_madd(y2, x2, vzero);
      y3 = vec_madd(y3, x3, vzero);
    }
    x0 = vec_madd(x0, x0, vzero);
    x1 = vec_madd(x1, x1, vzero);
    x2 = vec_madd(x2, x2, vzero);
    x3 = vec_madd(x3, x3, vzero);
    exponent >>= 1;
  }

  /* Compute the 8 quadratic coefficients. 
   * Solve the three simultaneous equations at the endpoints and 
   * center of each segment. We use precomputed constants whenever 
   * possible to reduce computation.
   *
   *       *-----------*----------*
   *      y3          y2         y1
   */
  y1_0 = (vector float)vec_perm((vector unsigned int)(y0), (vector unsigned int)(y1), shuffle2460);
  y1_1 = (vector float)vec_perm((vector unsigned int)(y2), (vector unsigned int)(y3), shuffle2460);
  y2_0 = (vector float)vec_perm((vector unsigned int)(y0), (vector unsigned int)(y1), shuffle1357);
  y2_1 = (vector float)vec_perm((vector unsigned int)(y2), (vector unsigned int)(y3), shuffle1357);
  y3_0 = (vector float)vec_perm((vector unsigned int)(y0), (vector unsigned int)(y1), shuffle0246);

  y3_1 = (vector float)vec_perm((vector unsigned int)(y2), (vector unsigned int)(y3), shuffle0246);
  y1_0 = (vector float)vec_perm((vector unsigned int)(y1_0), (vector unsigned int)(y2), shuffle0124);
  y1_1 = (vector float)vec_perm((vector unsigned int)(y1_1), (vector unsigned int)(fv_one), shuffle0124);

  mi11_y1_0 = vec_madd(mi11_0, y1_0, vzero);
  mi11_y1_1 = vec_madd(mi11_1, y1_1, vzero);
  y2_0 = vec_nmsub(m21_0, mi11_y1_0, y2_0);
  y2_1 = vec_nmsub(m21_1, mi11_y1_1, y2_1);

  y3_0 = vec_nmsub(m31_0, mi11_y1_0, y3_0);
  y3_1 = vec_nmsub(m31_1, mi11_y1_1, y3_1);
  mi22_y2_0 = vec_madd(mi22_0, y2_0, vzero);
  mi22_y2_1 = vec_madd(mi22_1, y2_1, vzero);
  y3_0 = vec_nmsub(m32_0, mi22_y2_0, y3_0);
  y3_1 = vec_nmsub(m32_1, mi22_y2_1, y3_1);

  c0 = vec_madd(y3_0, mi33_0, vzero);
  c1 = vec_madd(y3_1, mi33_1, vzero);

  b0 = vec_nmsub(c0, m23_0, y2_0);
  b1 = vec_nmsub(c1, m23_1, y2_1);
  b0 = vec_madd(b0, mi22_0, vzero);
  b1 = vec_madd(b1, mi22_1, vzero);

  a0 = vec_madd(b0, m12_0, c0);
  a1 = vec_madd(b1, m12_1, c1);
  a0 = vec_nmsub(mi11_0, a0, mi11_y1_0);
  a1 = vec_nmsub(mi11_1, a1, mi11_y1_1);

#endif /* __SPU__ */

  exp->C[0] = c0;
  exp->C[1] = c1;
  exp->B[0] = b0;
  exp->B[1] = b1;
  exp->A[0] = a0;
  exp->A[1] = a1;
}

#endif /* _SET_SPEC_EXPONENT9_H_ */
