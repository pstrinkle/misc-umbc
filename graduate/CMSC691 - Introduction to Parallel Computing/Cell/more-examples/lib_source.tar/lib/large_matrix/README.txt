%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Library containing large matrix routines for the SPE.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory builds a library (spu/lib/liblargematrix) that contains
	the following matrix functions for the SPE:

	index_max_abs_col
		find the index of the maximum absolute value in the specified
		column of matrix m

	index_max_abs_vec
		
	lu2_decomp
		computes the LU factorization of a dense general m by n
		matrix a using partial pivoting with row interchanges.
		This is the right-looking Level 2 BLAS version of the
		algorithm.

	lu3_decomp
		computes the LU factorization of a dense general m by n
		matrix a using partial pivoting with row interchanges.
		This is the right-looking Level 3 BLAS version of the
		algorithm.

	madd_matrix_matrix

	madd_number_vector

	madd_vector_vector
		performs the rank 1 operation  A := x * y' + A

	nmsub_matrix_matrix
		
	nmsub_number_vector

	nmsub_vector_vector
		performs the rank 1 operation  A := alpha * x * y' + A

	scale_matrix_col
		scale a column of a matrix

	scale_vector

	solve_linear_system_1
		computes the solution to a real system of linear equations
		A*X = B where A is a square N X N matrix, and X and B are
		n elements vectors

	solve_unit_lower
		solves the matrix equation  A*X = B  where A is a unit lower
		triangular square matrix of size m, X is an m by n matrix,
		and B is an m by n matrix.

	solve_unit_lower_1
		solves the matrix equation  A*X = B  where A is a unit lower
		triangular square matrix of size m, X is an m by n matrix,
		and B is an m element vector

	solve_upper_1
		solves the matrix equation  A*X = B where A is a upper
		triangular square matrix of size m, X is an m by n matrix,
		and B is an m element vector

	swap_matrix_rows
		performs a series of row interchanges on the matrix
		
	swap_vectors
		interchanges two vectors

	swap_vectors16
		interchanges two vectors as long as both vectors are a
		multiple of 16 in length
		
	transpose_matrix
		transposes a matrix

