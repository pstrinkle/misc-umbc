/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#ifdef PROF
 #include <profile.h>
#endif
#include "liblarge_matrix.h"


/* #define DEBUGGING 1 */

/*
 * Description:
 * -----------
 *    The subroutine solve_linear_system computes the solution to a real
 *    system of linear equations
 *        A*X = B
 *    where A is a square N X N matrix, and X and B are n elements vectors 
 *
 *    The LU decomposition with partial pivoting and row interchanges is used
 *    to factor A as
 *        A = P*L*U
 *    where P is a permutation matrix, L is a unit lower triangular, and U
 *    is a upper triangular.  The factored form of A is then used to solve the
 *    system of equations A*X = B
 *
 * Parameters:
 * ------
 *    n: size of matrix a
 *    a: On entry, n by n coefficient matrix A
 *       On exit, the factors L and U from the LU factorization
 *
 *    lda: stride of matrix a
 *    ipiv: n element vector of integers. On exit, it has the pivot indices
 *          that define the permutation matrix P;  row i of the matrix
 *          was interchanged with row ipiv(i)
 *       
 *    b: On entry the n element vector of right hand side,
 *       On exit, if the return code is 0, this contains the solution X of
 *       the linear system
 *
 * Returns:
 * --------
 *    = 0: successful
 *    < 0: illegal inputs
 *    > 0: U(i, i) is exactly zero.  The factorization has been
 *         completed but the factor U is exactly singular so the
 *         solution could not be computed
 */ 
int solve_linear_system_1 (int n, float* a, int lda, int* ipiv, 
                           float* b)
{
  int rc;
#ifdef DEBUGGING
  int i;
#endif
  rc = lu3_decomp(n, n, a, lda, ipiv);
 
#ifdef PROF
  prof_cp1();
#endif
  
  if (rc == 0)
  {
#ifdef DEBUGGING
    printf ("solve_lu, ipiv vector\n");
    for (i = 0; i < n; i++)
    {
      printf ("%d  ", ipiv[i]);
    }
    printf ("\n\n");
  
#endif

    swap_matrix_rows (1, b, 1, 0, n, ipiv);
  
    solve_unit_lower_1 (n, a, lda, b);
#ifdef DEBUGGING
    printf ("after solve unit lower, vector b\n");
    for (i = 0; i < n; i++)
    {
      printf ("%f  ", b[i]);
    }
    printf ("\n\n");
#endif

    solve_upper_1 (n, a, lda, b);
  }
  return rc;
}
