/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include "liblarge_matrix.h"

void madd_number_vector (int n, float da, float *dx, float *dy)
{

  int i;

  int post_align, pre_align;
  vector float vx0, vx1, vx2, vx3, vx4, vx5, vx6, vx7;
  vector float vy0, vy1, vy2, vy3, vy4, vy5, vy6, vy7;
  vector float vz0;
  vector unsigned int vw0;

  vector float v_da;
  vector float *dxp, *dyp;
  if (n > 4)
  {
    pre_align = (4 - (unsigned int)(((unsigned int)dx & 0xF) >> 2))&0x3;

    vx0 = *((vector float *) (((unsigned int)dx >> 4) << 4));
    vy0 = *((vector float *) (((unsigned int)dy >> 4) << 4));
    v_da = spu_splats (da);
    vw0 = spu_maskw ((1<<pre_align)-1);
    vz0 = spu_madd (v_da, vx0, vy0);
    vz0 = spu_sel (vy0, vz0, vw0);
    *((vector float *) (((unsigned int)dy >> 4) << 4)) = vz0;

    post_align = (int)(((unsigned int)&dy[n] & 0xF)>>2);
    dxp = (vector float *) &dx[pre_align];
    dyp = (vector float *) &dy[pre_align];

    for (i = pre_align; i < n-((n - pre_align)&0x1F); i+=32,dxp+=8,dyp+=8) {
      vx0 = *dxp;
      vy0 = *dyp;
      vx1 = *(dxp+1);
      vy1 = *(dyp+1);
      vx2 = *(dxp+2);
      vy2 = *(dyp+2);
      vx3 = *(dxp+3);
      vy3 = *(dyp+3);
      vx4 = *(dxp+4);
      vy4 = *(dyp+4);
      vx5 = *(dxp+5);
      vy5 = *(dyp+5);
      vx6 = *(dxp+6);
      vy6 = *(dyp+6);
      vx7 = *(dxp+7);
      vy7 = *(dyp+7);
      *dyp = spu_madd (v_da, vx0, vy0);
      *(dyp+1) = spu_madd (v_da, vx1, vy1);
      *(dyp+2) = spu_madd (v_da, vx2, vy2);
      *(dyp+3) = spu_madd (v_da, vx3, vy3);
      *(dyp+4) = spu_madd (v_da, vx4, vy4);
      *(dyp+5) = spu_madd (v_da, vx5, vy5);
      *(dyp+6) = spu_madd (v_da, vx6, vy6);
      *(dyp+7) = spu_madd (v_da, vx7, vy7);
    }

   
    for (i = n-((n-pre_align)&0x1F); i < n-post_align; i+=4, dxp+=1, dyp+=1)
    {
      *dyp = spu_madd (v_da, *dxp, *dyp);
    }

    
    if (post_align == 0)
      return;

    vx0 = *((vector float *) ((unsigned int)(&dx[n-post_align])));
    vy0 = *((vector float *) ((unsigned int)(&dy[n-post_align])));
    v_da = spu_splats (da);
    vw0 = spu_maskw (((1 << post_align)-1) << (4 -post_align));
    vz0 = spu_madd (v_da, vx0, vy0);
    vz0 = spu_sel (vy0, vz0, vw0);
    *((vector float *) ((unsigned int)(&dy[n-post_align]))) = vz0;
  }
  else
  {
    for (i = 0;i < n; i++) {
      dy[i] = dy[i] - da*dx[i];
    }

  }
}

