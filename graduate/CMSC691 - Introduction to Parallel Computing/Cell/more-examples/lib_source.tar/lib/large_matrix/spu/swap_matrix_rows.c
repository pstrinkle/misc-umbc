/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>
#include <stdlib.h>
#include <liblarge_matrix.h>


#ifdef _USE_SCALAR
void swap_matrix_rows (int n, float * a, int lda, int k1, int k2, int* ipiv)
{
  /* assuming that incx = 1 */
  int i,k;
  int ip;
  float temp;
  for (i = k1; i < k2; i++)
  {
    ip = ipiv[i];
    if (ip != i)
    {
      for (k = 0; k < n; k++)
      {
        temp = a[i*lda + k];
        a[i*lda + k] = a[ip*lda + k];
        a[ip*lda + k] = temp;
      }
    }
  }
}
#else
/*
 * Description:
 * ------------
 *  performs a series of row interchanges on the matrix A, 
 *  one row interchange is initiated for each of rows K1 through K2 of A
 *  
 *  interchange row I with row IPIV(I) for each row K1 through K2 
 * 
 * Parameters:
 * -----------
 *  n - num cols of A
 *  A - matrix with n cols 
 *  lda - leading dimension of A
 *  k1 - first element of ipiv for which a row interchange will be done
 *  k2 - last element of ipiv
 *  ipiv - array of ints, size m*abs(incx)
 *  incx;
 * 
 * 
 * Returns:
 * --------
 *  0 if successful, 
 *  -1 otherwise
 *  
 */ 
void swap_matrix_rows (int n, float * a, int lda, int k1, int k2, int* ipiv)
{
  /* assuming that incx = 1 */
  int i, j;
  int ip;
  vector float x0, x1, x2, x3;
  vector float y0, y1, y2, y3;
  vector float* x, *y;
  float temp;
  for (i = k1; i < k2; i++)
  {
    ip = ipiv[i];
    if (ip != i)
    {
      for (j = 0; j < n-(n&0xF); j+=16)
      {
        x = (vector float*)&a[i*lda+j];
        y = (vector float*)&a[ip*lda+j];
  
        x0 = x[0];
        x1 = x[1];
        x2 = x[2]; 
        x3 = x[3];

        y0 = y[0];
        y1 = y[1];
        y2 = y[2];
        y3 = y[3];

        *(x) = y0;
        *(x+1) = y1;
        *(x+2) = y2;
        *(x+3) = y3;

        *(y) = x0;
        *(y+1) = x1;
        *(y+2) = x2;
        *(y+3) = x3;
      }
      for (j = n-(n&0xF); j < n-(n%4); j+=4)
      {
        x = (vector float*)&a[i*lda+j];
        y = (vector float*)&a[ip*lda+j];
        x0 = x[0];
        y0 = y[0];
        *(x) = y0;
        *(y) = x0;
      }
      for (j = n-(n%4); j < n; j++)
      {
        temp = a[i*lda + j];
        a[i*lda + j] = a[ip*lda + j];
        a[ip*lda + j] = temp;
      }
    }
  }
}
#endif

