/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include "liblarge_matrix.h"

/*
 * Description:
 * ------------
 *  interchanges two vectors
 * 
 * Returns:
 *  0 if successful
 *  -1 otherwise
 */ 
void swap_vectors16 (int n, float * sx, float *sy)
{
  int i;
  vector float x0, x1, x2, x3;
  vector float y0, y1, y2, y3;

  for (i = 0; i < n; i+=16)
  {
    x0 = *((vector float*)&sx[i]);
    x1 = *((vector float*)&sx[i+4]);
    x2 = *((vector float*)&sx[i+8]);
    x3 = *((vector float*)&sx[i+12]);
   
    y0 = *((vector float*)&sy[i]);
    y1 = *((vector float*)&sy[i+4]);
    y2 = *((vector float*)&sy[i+8]);
    y3 = *((vector float*)&sy[i+12]);
   
    *((vector float*)&sx[i]) = y0;
    *((vector float*)&sx[i+4]) = y1;
    *((vector float*)&sx[i+8]) = y2;
    *((vector float*)&sx[i+12]) = y3;
    
   
    *((vector float*)&sy[i]) = x0;
    *((vector float*)&sy[i+4]) = x1;
    *((vector float*)&sy[i+8]) = x2;
    *((vector float*)&sy[i+12]) = x3;
  }
}
/*
 * Description:
 * ------------
 *  interchanges two vectors
 * 
 * Returns:
 *  0 if successful
 *  -1 otherwise
 */ 
void swap_vectors (int n, float * sx, float *sy)
{
  int i;
  float temp;
  vector float x0, x1, x2, x3, x4, x5, x6, x7;
  vector float y0, y1, y2, y3, y4, y5, y6, y7;

  for (i = 0; i < n-(n&0x1F); i+=32)
  {
    x0 = *((vector float*)&sx[i]);
    x1 = *((vector float*)&sx[i+4]);
    x2 = *((vector float*)&sx[i+8]);
    x3 = *((vector float*)&sx[i+12]);
    
    x4 = *((vector float*)&sx[i+16]);
    x5 = *((vector float*)&sx[i+20]);
    x6 = *((vector float*)&sx[i+24]);
    x7 = *((vector float*)&sx[i+28]);
    
    y0 = *((vector float*)&sy[i]);
    y1 = *((vector float*)&sy[i+4]);
    y2 = *((vector float*)&sy[i+8]);
    y3 = *((vector float*)&sy[i+12]);
    
    y4 = *((vector float*)&sy[i+16]);
    y5 = *((vector float*)&sy[i+20]);
    y6 = *((vector float*)&sy[i+24]);
    y7 = *((vector float*)&sy[i+28]);   
    
    *((vector float*)&sx[i]) = y0;
    *((vector float*)&sx[i+4]) = y1;
    *((vector float*)&sx[i+8]) = y2;
    *((vector float*)&sx[i+12]) = y3;
    
    *((vector float*)&sx[i+16]) = y4;
    *((vector float*)&sx[i+20]) = y5;
    *((vector float*)&sx[i+24]) = y6;
    *((vector float*)&sx[i+28]) = y7;       
    
    *((vector float*)&sy[i]) = x0;
    *((vector float*)&sy[i+4]) = x1;
    *((vector float*)&sy[i+8]) = x2;
    *((vector float*)&sy[i+12]) = x3;
    
    *((vector float*)&sy[i+16]) = x4;
    *((vector float*)&sy[i+20]) = x5;
    *((vector float*)&sy[i+24]) = x6;
    *((vector float*)&sy[i+28]) = x7;
  }
  for (i = n-(n&0x1F); i < n-(n&0xF); i+=16)
  {
    x0 = *((vector float*)&sx[i]);
    x1 = *((vector float*)&sx[i+4]);
    x2 = *((vector float*)&sx[i+8]);
    x3 = *((vector float*)&sx[i+12]);
   
    y0 = *((vector float*)&sy[i]);
    y1 = *((vector float*)&sy[i+4]);
    y2 = *((vector float*)&sy[i+8]);
    y3 = *((vector float*)&sy[i+12]);
   
    *((vector float*)&sx[i]) = y0;
    *((vector float*)&sx[i+4]) = y1;
    *((vector float*)&sx[i+8]) = y2;
    *((vector float*)&sx[i+12]) = y3;
    
   
    *((vector float*)&sy[i]) = x0;
    *((vector float*)&sy[i+4]) = x1;
    *((vector float*)&sy[i+8]) = x2;
    *((vector float*)&sy[i+12]) = x3;
  }
  for (i = n-(n&0xF); i < n-(n%4); i+=4)
  {
    x0 = *((vector float*)&sx[i]);
    y0 = *((vector float*)&sy[i]);
    *((vector float*)&sx[i]) = y0;
    *((vector float*)&sy[i]) = x0;
  }
  for (i = n-(n%4); i < n; i++)
  {
    temp = sx[i];
    sx[i] = sy[i];
    sy[i] = temp;

  }
}
