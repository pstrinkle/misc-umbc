/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <spu_intrinsics.h>

/*
 * Description:
 *    scale a column of a matrix
 *
 * Parameters:
 *    n: size of a vector
 *    scale factor: scaling factor 
 *    m: matrix
 *    col: index of column to be scaled
 *    stride: stride of matrix m
 *
 * Returns:
 *    m contains the new scaled column 
 */ 
void scale_matrix_col (int n, float scale_factor, float *m, int col, int stride)
{
  int i;
  float* a;
  int col_idx;
  
  vector float v_scale_factor;
  vector float a0, a1, a2, a3, a4, a5, a6, a7; 
  vector float v_one = spu_splats((float)1.0f);
  vector unsigned int pattern;
 
  a = &m[(col >> 2)*4];
  col_idx = col & 0x3;
 
  v_scale_factor = spu_splats (scale_factor);
  pattern = spu_maskw (1 << (3 -col_idx));
  v_scale_factor = spu_sel (v_one, v_scale_factor, pattern); 
  
  
  for (i = 0; i < (n-(n&0x7)); i+=8) {
    a0 = *((vector float*)&a[i*stride]);   
    a1 = *((vector float*)&a[(i+1)*stride]);
    a2 = *((vector float*)&a[(i+2)*stride]);   
    a3 = *((vector float*)&a[(i+3)*stride]);  
    a4 = *((vector float*)&a[(i+4)*stride]);
    a5 = *((vector float*)&a[(i+5)*stride]);    
    a6 = *((vector float*)&a[(i+6)*stride]); 
    a7 = *((vector float*)&a[(i+7)*stride]); 
    
    *((vector float*)&a[i*stride]) = spu_mul (v_scale_factor, a0);
    *((vector float*)&a[(i+1)*stride]) = spu_mul (v_scale_factor, a1);
    *((vector float*)&a[(i+2)*stride]) = spu_mul (v_scale_factor, a2);
    *((vector float*)&a[(i+3)*stride]) = spu_mul (v_scale_factor, a3);
    *((vector float*)&a[(i+4)*stride]) = spu_mul (v_scale_factor, a4);
    *((vector float*)&a[(i+5)*stride]) = spu_mul (v_scale_factor, a5);
    *((vector float*)&a[(i+6)*stride]) = spu_mul (v_scale_factor, a6);
    *((vector float*)&a[(i+7)*stride]) = spu_mul (v_scale_factor, a7);
  }	
  
  for (i = (n-(n&0x7)); i < n; i++) {
    a0 = *((vector float*)&a[i*stride]);   
    *((vector float*)&a[i*stride]) = spu_mul (v_scale_factor, a0);
  }
}

