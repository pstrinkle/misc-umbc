/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include "liblarge_matrix.h"

/*
 * Description:
 * ============
 * performs the rank 1 operation
 *    A := x * y' + A
 * where x is an m element vector, y is an n element vector, 
 * and a is an m by n matrix
 *
 * Parameters:
 * ===========
 * m - number of rows in matrix a
 * n - number of cols in matrix a
 * x - array of dimension at least m 
 * y - array of dimension at least y
 * 
 */ 
void madd_vector_vector (int m, int n, float *col, int c_stride, 
                         float *row, float * a, int a_stride)
{
  int i, j, pre_align, post_align;
  float* pre_a, *post_a;
  float temp;
  vector float t0, t1, t2, t3, t4, t5;
  vector float pre_r, r0, r1, r2, r3, post_r;
  vector float a00, a01, a02, a03;
  vector float a10, a11, a12, a13;
  vector float a20,a21, a22, a23;
  vector float a30, a31, a32, a33;
  vector float a40, a41, a42, a43;
  vector float a50, a51, a52, a53;
  vector float ta0, ta1, ta2, ta3, ta4, ta5;
  vector unsigned int mask, post_mask;
  vector float* ar0, *ar1, *ar2, *ar3, *ar4, *ar5;
 
  
  pre_align = (4 - (unsigned int)(((unsigned int)row & 0xF) >> 2))&0x3;

  pre_r = *((vector float *) (((unsigned int)row >> 4) << 4));
  pre_a = (float*)(((unsigned int)a >> 4) << 4);
  mask = spu_maskw ((1<<pre_align)-1);
  post_align = (int)(((unsigned int)&row[n] & 0xF)>>2);

  post_r = *((vector float*)&row[n-post_align]);
  post_a = (float*)(&a[n-post_align]);
  post_mask = spu_maskw (((1<<post_align)-1) << (4 -post_align)) ;
  
  if (n > 4)
  {
    for (i = 0; i <m-(m%6); i+=6)
    {
      t0 = spu_splats (col[i*c_stride]);
      t1 = spu_splats (col[(i+1)*c_stride]);
      t2 = spu_splats (col[(i+2)*c_stride]);
      t3 = spu_splats (col[(i+3)*c_stride]);
      t4 = spu_splats (col[(i+4)*c_stride]);
      t5 = spu_splats (col[(i+5)*c_stride]);
      
      a00 = *((vector float*)&pre_a[i*a_stride]);
      a10 = *((vector float*)&pre_a[(i+1)*a_stride]);
      a20 = *((vector float*)&pre_a[(i+2)*a_stride]);
      a30 = *((vector float*)&pre_a[(i+3)*a_stride]);
      a40 = *((vector float*)&pre_a[(i+4)*a_stride]);
      a50 = *((vector float*)&pre_a[(i+5)*a_stride]);

      ta0 = spu_madd (t0, pre_r, a00);
      ta1 = spu_madd (t1, pre_r, a10);
      ta2 = spu_madd (t2, pre_r, a20);
      ta3 = spu_madd (t3, pre_r, a30);
      ta4 = spu_madd (t4, pre_r, a40);
      ta5 = spu_madd (t5, pre_r, a50);

      ta0 = spu_sel (a00, ta0, mask);
      ta1 = spu_sel (a10, ta1, mask);
      ta2 = spu_sel (a20, ta2, mask);
      ta3 = spu_sel (a30, ta3, mask);
      ta4 = spu_sel (a40, ta4, mask);
      ta5 = spu_sel (a50, ta5, mask);

      *((vector float*)&pre_a[i*a_stride]) = ta0;
      *((vector float*)&pre_a[(i+1)*a_stride]) = ta1;
      *((vector float*)&pre_a[(i+2)*a_stride]) = ta2;
      *((vector float*)&pre_a[(i+3)*a_stride]) = ta3;
      *((vector float*)&pre_a[(i+4)*a_stride]) = ta4;
      *((vector float*)&pre_a[(i+5)*a_stride]) = ta5;

      for (j = pre_align; j < n-((n - pre_align)&0xF); j+=16)
      {
        r0 = *((vector float*)&row[j]);
        r1 = *((vector float*)&row[j+4]);
        r2 = *((vector float*)&row[j+8]);
        r3 = *((vector float*)&row[j+12]);

        ar0 = ((vector float*)&a[i*a_stride + j]);
        ar1 = ((vector float*)&a[(i+1)*a_stride + j]);
        ar2 = ((vector float*)&a[(i+2)*a_stride + j]);
        ar3 = ((vector float*)&a[(i+3)*a_stride + j]);
        ar4 = ((vector float*)&a[(i+4)*a_stride + j]);
        ar5 = ((vector float*)&a[(i+5)*a_stride + j]);


        a00 = ar0[0];
        a01 = ar0[1];
        a02 = ar0[2];
        a03 = ar0[3];

        a10 = ar1[0];
        a11 = ar1[1];
        a12 = ar1[2];
        a13 = ar1[3];

        a20 = ar2[0];
        a21 = ar2[1];
        a22 = ar2[2];
        a23 = ar2[3];

        a30 = ar3[0];
        a31 = ar3[1];
        a32 = ar3[2];
        a33 = ar3[3];

        a40 = ar4[0];
        a41 = ar4[1];
        a42 = ar4[2];
        a43 = ar4[3];

        a50 = ar5[0];
        a51 = ar5[1];
        a52 = ar5[2];
        a53 = ar5[3];


        *(ar0) = spu_madd (t0, r0, a00);
        *(ar0+1) = spu_madd (t0, r1, a01);
        *(ar0+2) = spu_madd (t0, r2, a02);
        *(ar0+3) = spu_madd (t0, r3, a03);
   
        *(ar1) = spu_madd (t1, r0, a10);
        *(ar1+1) = spu_madd (t1, r1, a11);
        *(ar1+2) = spu_madd (t1, r2, a12);
        *(ar1+3) = spu_madd (t1, r3, a13);
   
        *(ar2) = spu_madd (t2, r0, a20);
        *(ar2+1) = spu_madd (t2, r1, a21);
        *(ar2+2) = spu_madd (t2, r2, a22);
        *(ar2+3) = spu_madd (t2, r3, a23);
       
        *(ar3) = spu_madd (t3, r0, a30);
        *(ar3+1) = spu_madd (t3, r1, a31);
        *(ar3+2) = spu_madd (t3, r2, a32);
        *(ar3+3) = spu_madd (t3, r3, a33);
   
        *(ar4) = spu_madd (t4, r0, a40);
        *(ar4+1) = spu_madd (t4, r1, a41);
        *(ar4+2) = spu_madd (t4, r2, a42);
        *(ar4+3) = spu_madd (t4, r3, a43);

        *(ar5) = spu_madd (t5, r0, a50);
        *(ar5+1) = spu_madd (t5, r1, a51);
        *(ar5+2) = spu_madd (t5, r2, a52);
        *(ar5+3) = spu_madd (t5, r3, a53);
       
      }

      for (j = n-((n-pre_align)&0xF); j < n-post_align; j+=4)
      {
        r0 = *((vector float*)&row[j]);

        ar0 = ((vector float*)&a[i*a_stride+j]);
        ar1 = ((vector float*)&a[(i+1)*a_stride+j]);
        ar2 = ((vector float*)&a[(i+2)*a_stride+j]);
        ar3 = ((vector float*)&a[(i+3)*a_stride+j]);
        ar4 = ((vector float*)&a[(i+4)*a_stride+j]);
        ar5 = ((vector float*)&a[(i+5)*a_stride+j]);

        a00 = ar0[0];
        a10 = ar1[0];
        a20 = ar2[0];
        a30 = ar3[0];
        a40 = ar4[0];
        a50 = ar5[0];
       
        *(ar0) = spu_madd (t0, r0, a00);
        *(ar1) = spu_madd (t1, r0, a10);
        *(ar2) = spu_madd (t2, r0, a20);
        *(ar3) = spu_madd (t3, r0, a30);
        *(ar4) = spu_madd (t4, r0, a40);
        *(ar5) = spu_madd (t5, r0, a50);
     
      }
      
        a00 = *((vector float*)&post_a[i*a_stride]);
        a10 = *((vector float*)&post_a[(i+1)*a_stride]);
        a20 = *((vector float*)&post_a[(i+2)*a_stride]);
        a30 = *((vector float*)&post_a[(i+3)*a_stride]);
        a40 = *((vector float*)&post_a[(i+4)*a_stride]);
        a50 = *((vector float*)&post_a[(i+5)*a_stride]);

        ta0 = spu_madd (t0, post_r, a00);
        ta1 = spu_madd (t1, post_r, a10);
        ta2 = spu_madd (t2, post_r, a20);
        ta3 = spu_madd (t3, post_r, a30);
        ta4 = spu_madd (t4, post_r, a40);
        ta5 = spu_madd (t5, post_r, a50);

        ta0 = spu_sel (a00, ta0, post_mask);
        ta1 = spu_sel (a10, ta1, post_mask);
        ta2 = spu_sel (a20, ta2, post_mask);
        ta3 = spu_sel (a30, ta3, post_mask);
        ta4 = spu_sel (a40, ta4, post_mask);
        ta5 = spu_sel (a50, ta5, post_mask);

        *((vector float*)&post_a[i*a_stride]) = ta0;
        *((vector float*)&post_a[(i+1)*a_stride]) = ta1;
        *((vector float*)&post_a[(i+2)*a_stride]) = ta2;
        *((vector float*)&post_a[(i+3)*a_stride]) = ta3;
        *((vector float*)&post_a[(i+4)*a_stride]) = ta4;
        *((vector float*)&post_a[(i+5)*a_stride]) = ta5;
      
    }

    for (i = m-(m%6); i < m; i++)
    {
      temp = col[i*c_stride];
      madd_number_vector (n, temp, row, &a[i*a_stride]);
    }
  }
  else
  {
    for (i = 0; i < m; i++)
    {
      for (j = 0; j < n; j++)
      {
        a[i*a_stride + j] = a[i*a_stride + j] + col[i*c_stride]*row[j];
      }
    }

  }
}


