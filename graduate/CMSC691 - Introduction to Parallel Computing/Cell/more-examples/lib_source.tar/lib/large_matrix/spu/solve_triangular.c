/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include "liblarge_matrix.h"

/*
 * C Specification
 * ---------------
 * 
 *   #include <solve_triangular.h>
 *   void solve_unit_lower (int m, int n, const float * a, int lda, float* b, int ldb)
 *   
 * Description
 * -----------
 *
 * The subroutine solve_unit_lower solves the matrix equation
 *    
 *    A*X = B
 *   
 * where A is a unit lower triangular square matrix of size m, X is an m by n 
 * matrix, and B is an m by n matrix.
 *
 * A and B must be quad-word aligned. m and n must be multiples of 4
 *
 * Input
 * ------
 * m:	number of rows and columns of matrix a, number of rows of matrix b
 * 
 * n:	number of columns of matrix b
 * 
 * a:	unit lower triangular square matrix of size m
 * 
 * lda:	stride of matrix a
 *
 * b:	general matrix of size m by n
 *
 * ldb: 	stride of matrix b
 *
 * Output
 * ------
 * 
 * b:	solution to matrix equations A*X = B
 * 
 * Dependencies
 * ------------
 *   None
 */
void solve_unit_lower (int m, int n, float * a, int lda, float* b, int ldb)
{
  int i, j, k;
  vector float bk00, bk10, bk20, bk30;
  vector float bk01, bk11, bk21, bk31;
  vector float bk02, bk12, bk22, bk32;
  vector float bk03, bk13, bk23, bk33;
 
  vector float ak10, ak20, ak30, ak21, ak31, ak32;
  vector float a00, a01, a02, a03;
  vector float a10, a11, a12, a13;
  vector float a20, a21, a22, a23;
  vector float a30, a31, a32, a33;

  vector float bi00, bi10, bi20, bi30;
  vector float bi01, bi11, bi21, bi31;
  vector float bi02, bi12, bi22, bi32;
  vector float bi03, bi13, bi23, bi33;

  for (j = 0; j < n-(n&0xF); j+=16)
  {
    for (k = 0; k < m; k+=4)
    {

      bk00 = *((vector float*)&b[k*ldb + j]);
      bk10 = *((vector float*)&b[(k+1)*ldb + j]);
      bk20 = *((vector float*)&b[(k+2)*ldb + j]);
      bk30 = *((vector float*)&b[(k+3)*ldb + j]);

      bk01 = *((vector float*)&b[k*ldb + j+4]);
      bk11 = *((vector float*)&b[(k+1)*ldb + j+4]);
      bk21 = *((vector float*)&b[(k+2)*ldb + j+4]);
      bk31 = *((vector float*)&b[(k+3)*ldb + j+4]);

      bk02 = *((vector float*)&b[k*ldb + j+8]);
      bk12 = *((vector float*)&b[(k+1)*ldb + j+8]);
      bk22 = *((vector float*)&b[(k+2)*ldb + j+8]);
      bk32 = *((vector float*)&b[(k+3)*ldb + j+8]);

      bk03 = *((vector float*)&b[k*ldb + j+12]);
      bk13 = *((vector float*)&b[(k+1)*ldb + j+12]);
      bk23 = *((vector float*)&b[(k+2)*ldb + j+12]);
      bk33 = *((vector float*)&b[(k+3)*ldb + j+12]);


      ak10 = spu_splats (a[(k+1)*lda + k]);
      ak20 = spu_splats (a[(k+2)*lda + k]);
      ak30 = spu_splats (a[(k+3)*lda + k]);
      ak21 = spu_splats (a[(k+2)*lda + k+1]);
      ak31 = spu_splats (a[(k+3)*lda + k+1]);
      ak32 = spu_splats (a[(k+3)*lda + k+2]);
      
      bk10 = spu_nmsub (bk00, ak10, bk10);
      bk20 = spu_nmsub (bk00, ak20, bk20);
      bk30 = spu_nmsub (bk00, ak30, bk30);
      bk20 = spu_nmsub (bk10, ak21, bk20);
      bk30 = spu_nmsub (bk10, ak31, bk30);
      bk30 = spu_nmsub (bk20, ak32, bk30);
 
      bk11 = spu_nmsub (bk01, ak10, bk11);
      bk21 = spu_nmsub (bk01, ak20, bk21);
      bk31 = spu_nmsub (bk01, ak30, bk31);
      bk21 = spu_nmsub (bk11, ak21, bk21);
      bk31 = spu_nmsub (bk11, ak31, bk31);
      bk31 = spu_nmsub (bk21, ak32, bk31);
 
      bk12 = spu_nmsub (bk02, ak10, bk12);
      bk22 = spu_nmsub (bk02, ak20, bk22);
      bk32 = spu_nmsub (bk02, ak30, bk32);
      bk22 = spu_nmsub (bk12, ak21, bk22);
      bk32 = spu_nmsub (bk12, ak31, bk32);
      bk32 = spu_nmsub (bk22, ak32, bk32);
 
      bk13 = spu_nmsub (bk03, ak10, bk13);
      bk23 = spu_nmsub (bk03, ak20, bk23);
      bk33 = spu_nmsub (bk03, ak30, bk33);
      bk23 = spu_nmsub (bk13, ak21, bk23);
      bk33 = spu_nmsub (bk13, ak31, bk33);
      bk33 = spu_nmsub (bk23, ak32, bk33);



      *((vector float*)&b[(k+1)*ldb + j]) = bk10;
      *((vector float*)&b[(k+2)*ldb + j]) = bk20;
      *((vector float*)&b[(k+3)*ldb + j]) = bk30;
 
      *((vector float*)&b[(k+1)*ldb + j+4]) = bk11;
      *((vector float*)&b[(k+2)*ldb + j+4]) = bk21;
      *((vector float*)&b[(k+3)*ldb + j+4]) = bk31;
 
      *((vector float*)&b[(k+1)*ldb + j+8]) = bk12;
      *((vector float*)&b[(k+2)*ldb + j+8]) = bk22;
      *((vector float*)&b[(k+3)*ldb + j+8]) = bk32;
 
      *((vector float*)&b[(k+1)*ldb + j+12]) = bk13;
      *((vector float*)&b[(k+2)*ldb + j+12]) = bk23;
      *((vector float*)&b[(k+3)*ldb + j+12]) = bk33;
 
      /* transpose bk */
      for (i = k+4; i < m; i+=4)
      {
        bi00 = *((vector float*)&b[i*ldb + j]);
        bi10 = *((vector float*)&b[(i+1)*ldb + j]);
        bi20 = *((vector float*)&b[(i+2)*ldb + j]);
        bi30 = *((vector float*)&b[(i+3)*ldb + j]);
 
        bi01 = *((vector float*)&b[i*ldb + j+4]);
        bi11 = *((vector float*)&b[(i+1)*ldb + j+4]);
        bi21 = *((vector float*)&b[(i+2)*ldb + j+4]);
        bi31 = *((vector float*)&b[(i+3)*ldb + j+4]);
 
        bi02 = *((vector float*)&b[i*ldb + j+8]);
        bi12 = *((vector float*)&b[(i+1)*ldb + j+8]);
        bi22 = *((vector float*)&b[(i+2)*ldb + j+8]);
        bi32 = *((vector float*)&b[(i+3)*ldb + j+8]);

        bi03 = *((vector float*)&b[i*ldb + j+12]);
        bi13 = *((vector float*)&b[(i+1)*ldb + j+12]);
        bi23 = *((vector float*)&b[(i+2)*ldb + j+12]);
        bi33 = *((vector float*)&b[(i+3)*ldb + j+12]);


        a00 = spu_splats(a[i*lda + k]);
        a10 = spu_splats(a[(i+1)*lda + k]);
        a20 = spu_splats(a[(i+2)*lda + k]);
        a30 = spu_splats(a[(i+3)*lda + k]);
 
        a01 = spu_splats(a[i*lda + k+1]);
        a11 = spu_splats(a[(i+1)*lda + k+1]);
        a21 = spu_splats(a[(i+2)*lda + k+1]);
        a31 = spu_splats(a[(i+3)*lda + k+1]);
       
        a02 = spu_splats(a[i*lda + k+2]);
        a12 = spu_splats(a[(i+1)*lda + k+2]);
        a22 = spu_splats(a[(i+2)*lda + k+2]);
        a32 = spu_splats(a[(i+3)*lda + k+2]);

        a03 = spu_splats(a[i*lda + k+3]);
        a13 = spu_splats(a[(i+1)*lda + k+3]);
        a23 = spu_splats(a[(i+2)*lda + k+3]);
        a33 = spu_splats(a[(i+3)*lda + k+3]);

        bi00 = spu_nmsub (a00, bk00, bi00);
        bi10 = spu_nmsub (a10, bk00, bi10); 
        bi20 = spu_nmsub (a20, bk00, bi20);
        bi30 = spu_nmsub (a30, bk00, bi30);
 
        bi01 = spu_nmsub (a00, bk01, bi01);
        bi11 = spu_nmsub (a10, bk01, bi11); 
        bi21 = spu_nmsub (a20, bk01, bi21);
        bi31 = spu_nmsub (a30, bk01, bi31);
 
        bi02 = spu_nmsub (a00, bk02, bi02);
        bi12 = spu_nmsub (a10, bk02, bi12); 
        bi22 = spu_nmsub (a20, bk02, bi22);
        bi32 = spu_nmsub (a30, bk02, bi32);

        bi03 = spu_nmsub (a00, bk03, bi03);
        bi13 = spu_nmsub (a10, bk03, bi13); 
        bi23 = spu_nmsub (a20, bk03, bi23);
        bi33 = spu_nmsub (a30, bk03, bi33);

        bi00 = spu_nmsub (a01, bk10, bi00);
        bi10 = spu_nmsub (a11, bk10, bi10); 
        bi20 = spu_nmsub (a21, bk10, bi20);
        bi30 = spu_nmsub (a31, bk10, bi30);
        
        bi01 = spu_nmsub (a01, bk11, bi01);
        bi11 = spu_nmsub (a11, bk11, bi11); 
        bi21 = spu_nmsub (a21, bk11, bi21);
        bi31 = spu_nmsub (a31, bk11, bi31);
 
        bi02 = spu_nmsub (a01, bk12, bi02);
        bi12 = spu_nmsub (a11, bk12, bi12); 
        bi22 = spu_nmsub (a21, bk12, bi22);
        bi32 = spu_nmsub (a31, bk12, bi32);
        
        bi03 = spu_nmsub (a01, bk13, bi03);
        bi13 = spu_nmsub (a11, bk13, bi13); 
        bi23 = spu_nmsub (a21, bk13, bi23);
        bi33 = spu_nmsub (a31, bk13, bi33);
        
        bi00 = spu_nmsub (a02, bk20, bi00);
        bi10 = spu_nmsub (a12, bk20, bi10); 
        bi20 = spu_nmsub (a22, bk20, bi20);
        bi30 = spu_nmsub (a32, bk20, bi30);
          
        bi01 = spu_nmsub (a02, bk21, bi01);
        bi11 = spu_nmsub (a12, bk21, bi11); 
        bi21 = spu_nmsub (a22, bk21, bi21);
        bi31 = spu_nmsub (a32, bk21, bi31);
         
        bi02 = spu_nmsub (a02, bk22, bi02);
        bi12 = spu_nmsub (a12, bk22, bi12); 
        bi22 = spu_nmsub (a22, bk22, bi22);
        bi32 = spu_nmsub (a32, bk22, bi32);
          
        bi03 = spu_nmsub (a02, bk23, bi03);
        bi13 = spu_nmsub (a12, bk23, bi13); 
        bi23 = spu_nmsub (a22, bk23, bi23);
        bi33 = spu_nmsub (a32, bk23, bi33);
        

        
        bi00 = spu_nmsub (a03, bk30, bi00);
        bi10 = spu_nmsub (a13, bk30, bi10); 
        bi20 = spu_nmsub (a23, bk30, bi20);
        bi30 = spu_nmsub (a33, bk30, bi30);
          
        bi01 = spu_nmsub (a03, bk31, bi01);
        bi11 = spu_nmsub (a13, bk31, bi11); 
        bi21 = spu_nmsub (a23, bk31, bi21);
        bi31 = spu_nmsub (a33, bk31, bi31);
        
        bi02 = spu_nmsub (a03, bk32, bi02);
        bi12 = spu_nmsub (a13, bk32, bi12); 
        bi22 = spu_nmsub (a23, bk32, bi22);
        bi32 = spu_nmsub (a33, bk32, bi32);
          
        bi03 = spu_nmsub (a03, bk33, bi03);
        bi13 = spu_nmsub (a13, bk33, bi13); 
        bi23 = spu_nmsub (a23, bk33, bi23);
        bi33 = spu_nmsub (a33, bk33, bi33);
 

        *((vector float*)&b[i*ldb + j]) = bi00;
        *((vector float*)&b[(i+1)*ldb + j]) = bi10;
        *((vector float*)&b[(i+2)*ldb + j]) = bi20;
        *((vector float*)&b[(i+3)*ldb + j]) = bi30;

        *((vector float*)&b[i*ldb + j+4]) = bi01;
        *((vector float*)&b[(i+1)*ldb + j+4]) = bi11;
        *((vector float*)&b[(i+2)*ldb + j+4]) = bi21;
        *((vector float*)&b[(i+3)*ldb + j+4]) = bi31;
 
        *((vector float*)&b[i*ldb + j+8]) = bi02;
        *((vector float*)&b[(i+1)*ldb + j+8]) = bi12;
        *((vector float*)&b[(i+2)*ldb + j+8]) = bi22;
        *((vector float*)&b[(i+3)*ldb + j+8]) = bi32;
  
        *((vector float*)&b[i*ldb + j+12]) = bi03;
        *((vector float*)&b[(i+1)*ldb + j+12]) = bi13;
        *((vector float*)&b[(i+2)*ldb + j+12]) = bi23;
        *((vector float*)&b[(i+3)*ldb + j+12]) = bi33;
     
        //b[i*ldb + j] = b[i*ldb + j] - b[k*ldb + j] * a[i*lda + k];
      }

    }
  }
  for (j = n-(n&0xF); j < n; j+=4)
  {
    for (k = 0; k < m; k+=4)
    {

      bk00 = *((vector float*)&b[k*ldb + j]);
      bk10 = *((vector float*)&b[(k+1)*ldb + j]);
      bk20 = *((vector float*)&b[(k+2)*ldb + j]);
      bk30 = *((vector float*)&b[(k+3)*ldb + j]);

      ak10 = spu_splats (a[(k+1)*lda + k]);
      ak20 = spu_splats (a[(k+2)*lda + k]);
      ak30 = spu_splats (a[(k+3)*lda + k]);
      ak21 = spu_splats (a[(k+2)*lda + k+1]);
      ak31 = spu_splats (a[(k+3)*lda + k+1]);
      ak32 = spu_splats (a[(k+3)*lda + k+2]);
      
      bk10 = spu_nmsub (bk00, ak10, bk10);
      bk20 = spu_nmsub (bk00, ak20, bk20);
      bk30 = spu_nmsub (bk00, ak30, bk30);
      bk20 = spu_nmsub (bk10, ak21, bk20);
      bk30 = spu_nmsub (bk10, ak31, bk30);
      bk30 = spu_nmsub (bk20, ak32, bk30);
 

      *((vector float*)&b[(k+1)*ldb + j]) = bk10;
      *((vector float*)&b[(k+2)*ldb + j]) = bk20;
      *((vector float*)&b[(k+3)*ldb + j]) = bk30;
 
      for (i = k+4; i < m; i+=4)
      {
        bi00 = *((vector float*)&b[i*ldb + j]);
        bi10 = *((vector float*)&b[(i+1)*ldb + j]);
        bi20 = *((vector float*)&b[(i+2)*ldb + j]);
        bi30 = *((vector float*)&b[(i+3)*ldb + j]);
 
        a00 = spu_splats(a[i*lda + k]);
        a10 = spu_splats(a[(i+1)*lda + k]);
        a20 = spu_splats(a[(i+2)*lda + k]);
        a30 = spu_splats(a[(i+3)*lda + k]);
 
        a01 = spu_splats(a[i*lda + k+1]);
        a11 = spu_splats(a[(i+1)*lda + k+1]);
        a21 = spu_splats(a[(i+2)*lda + k+1]);
        a31 = spu_splats(a[(i+3)*lda + k+1]);
       
        a02 = spu_splats(a[i*lda + k+2]);
        a12 = spu_splats(a[(i+1)*lda + k+2]);
        a22 = spu_splats(a[(i+2)*lda + k+2]);
        a32 = spu_splats(a[(i+3)*lda + k+2]);

        a03 = spu_splats(a[i*lda + k+3]);
        a13 = spu_splats(a[(i+1)*lda + k+3]);
        a23 = spu_splats(a[(i+2)*lda + k+3]);
        a33 = spu_splats(a[(i+3)*lda + k+3]);

        bi00 = spu_nmsub (a00, bk00, bi00);
        bi10 = spu_nmsub (a10, bk00, bi10); 
        bi20 = spu_nmsub (a20, bk00, bi20);
        bi30 = spu_nmsub (a30, bk00, bi30);
 
        
        bi00 = spu_nmsub (a01, bk10, bi00);
        bi10 = spu_nmsub (a11, bk10, bi10); 
        bi20 = spu_nmsub (a21, bk10, bi20);
        bi30 = spu_nmsub (a31, bk10, bi30);
        
        bi00 = spu_nmsub (a02, bk20, bi00);
        bi10 = spu_nmsub (a12, bk20, bi10); 
        bi20 = spu_nmsub (a22, bk20, bi20);
        bi30 = spu_nmsub (a32, bk20, bi30);
        
        bi00 = spu_nmsub (a03, bk30, bi00);
        bi10 = spu_nmsub (a13, bk30, bi10); 
        bi20 = spu_nmsub (a23, bk30, bi20);
        bi30 = spu_nmsub (a33, bk30, bi30);
          
        *((vector float*)&b[i*ldb + j]) = bi00;
        *((vector float*)&b[(i+1)*ldb + j]) = bi10;
        *((vector float*)&b[(i+2)*ldb + j]) = bi20;
        *((vector float*)&b[(i+3)*ldb + j]) = bi30;
     
      }

    }
  } 
}

/*
 * C Specification
 * ---------------
 * 
 *   #include <solve_triangular.h>
 *   void solve_unit_lower_1 (int m, const float * a, int lda, float* b)
 *   
 * Description
 * -----------
 *
 * The subroutine solve_unit_lower solves the matrix equation
 *    
 *    A*X = B
 *   
 * where A is a unit lower triangular square matrix of size m, X is an m by n 
 * matrix, and B is an m element vector
 *
 * A and B must be quad-word aligned, m is a multiple of 4
 *
 * Input
 * ------
 * m:	number of rows and columns of matrix a, number of elements of vector b 
 * 
 * a:	unit lower triangular square matrix of size m
 * 
 * lda:	stride of matrix a
 *
 * b: m element vector
 *
 * Output
 * ------
 * 
 * b:	solution to matrix equations A*X = B
 * 
 * Dependencies
 * ------------
 *   None
 */
void solve_unit_lower_1 (int m, float *a, int lda, float *b)
{
  int i, k;
  int off1, off2, off3, off4;
  float *ai;
  vector float a02h, a13h, a02l, a13l;
  vector float a0, a1, a2, a3;
  vector float a_0, a_1, a_2;
  vector float a0t, a1t, a2t, a3t;
  vector float bk, bi, bb;
  vector float *bkv, *biv;
  vector unsigned char shuffle_2637;
  vector unsigned char shuffle_0415 = (vector unsigned char) {
						  0x00, 0x01, 0x02, 0x03, 0x10, 0x11, 0x12, 0x13,
						  0x04, 0x05, 0x06, 0x07, 0x14, 0x15, 0x16, 0x17};
  vector unsigned char shuffle_zzz2 = (vector unsigned char) {
						  0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80,
						  0x80, 0x80, 0x80, 0x80, 0x08, 0x09, 0x0A, 0x0B};
  vector unsigned char shuffle_z000 = (vector unsigned char) {
						  0x80, 0x80, 0x80, 0x80, 0x00, 0x01, 0x02, 0x03,
						  0x00, 0x01, 0x02, 0x03, 0x00, 0x01, 0x02, 0x03};
  vector unsigned char shuffle_z014 = (vector unsigned char) {
						  0x80, 0x80, 0x80, 0x80, 0x00, 0x01, 0x02, 0x03,
						  0x04, 0x05, 0x06, 0x07, 0x10, 0x11, 0x12, 0x13};
  vector unsigned char shuffle_zz15 = (vector unsigned char) {
						  0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80,
						  0x04, 0x05, 0x06, 0x07, 0x14, 0x15, 0x16, 0x17};

  shuffle_2637 = spu_or(shuffle_0415, 8);

  off1 = lda;
  off2 = lda << 1;
  off3 = off2 + lda;
  off4 = lda << 2;

  bkv = (vector float *)(b);

  for (k = 0; k < m; k+=4)
  {
    /* b[k+1] -= a[k+1][k] * b[k]
     * b[k+2] -= a[k+2][k] * b[k] + a[k+2][k+1] * b[k+1];
     * b[k+3] -= a[k+3][k] * b[k] + a[k+3][k+1] * b[k+1] + a[k+3][k+2] * b[k+2]
     */
    bk = *bkv;

    a1 = *(vector float *)(&a[off1]);
    a2 = *(vector float *)(&a[off2]);
    a3 = *(vector float *)(&a[off3]);

    bb  = spu_shuffle(bk, bk, shuffle_z000);
    a_0 = spu_shuffle(a1, a2, shuffle_0415);
    a_0 = spu_shuffle(a_0, a3, shuffle_z014);
    bk  = spu_nmsub(bb, a_0, bk);

    bb  = spu_shuffle(bk, bk, shuffle_zz15);
    a_1 = spu_shuffle(a2, a3, shuffle_zz15);
    bk  = spu_nmsub(bb, a_1, bk);
    
    bb  = spu_shuffle(bk, bk, shuffle_zzz2);
    a_2 = spu_shuffle(a3, a3, shuffle_zzz2);
    bk  = spu_nmsub(bb, a_2, bk);

    *bkv++ = bk;

    biv = bkv;
    a += off4;
    ai = a;
    a += 4;

    for (i = k+4; i<m; i+=4) {
      bi = *biv;

      a0 = *((vector float*)(&ai[0]));
      a1 = *((vector float*)(&ai[off1]));
      a2 = *((vector float*)(&ai[off2]));
      a3 = *((vector float*)(&ai[off3]));

      ai += off4;

      a0 = spu_mul(a0, bk);
      a1 = spu_mul(a1, bk);
      a2 = spu_mul(a2, bk);
      a3 = spu_mul(a3, bk);
   
      /* Transpose the 4x4 contained in a0, a1, a2, a3 
       * into a0t, a1t, a2t, a3t.
       */
      a02h = spu_shuffle(a0, a2, shuffle_0415);
      a02l = spu_shuffle(a0, a2, shuffle_2637);
      a13h = spu_shuffle(a1, a3, shuffle_0415);
      a13l = spu_shuffle(a1, a3, shuffle_2637);

      a0t = spu_shuffle(a02h, a13h, shuffle_0415);
      a1t = spu_shuffle(a02h, a13h, shuffle_2637);
      a2t = spu_shuffle(a02l, a13l, shuffle_0415);
      a3t = spu_shuffle(a02l, a13l, shuffle_2637);

      bi = spu_sub(bi, spu_add(a0t, a1t));
      bi = spu_sub(bi, spu_add(a2t, a3t));
 
      *biv++ = bi;
    }
  }
}

/*
 * C Specification
 * ---------------
 * 
 *   #include <solve_triangular.h>
 *   void solve_upper_1 (int m, int n, const float * a, int lda, float* b, int ldb)
 *   
 * Description
 * -----------
 *
 * The subroutine solve_unit_lower solves the matrix equation
 *    
 *    A*X = B
 *   
 * where A is a upper triangular square matrix of size m, X is an m by n 
 * matrix, and B is an m element vector 
 *
 * Input
 * ------
 * m:	number of rows and columns of matrix a, number of elements of vector b 
 * 
 * a:	upper triangular square matrix of size m
 * 
 * lda:	stride of matrix a
 *
 * b: m element vector
 *
 * Output
 * ------
 * 
 * b:	solution to matrix equations A*X = B
 * 
 * Dependencies
 * ------------
 *   None
 */
void 
solve_upper_1(int m, float * a, int lda, float* b)
{
  int i, k;
  vector float a0, a1, a2, a3;
  vector float bk, bi;
  vector float a02h, a13h, a02l, a13l;
  vector float a0t, a1t, a2t, a3t;

  vector unsigned char shuffle_2637;
  vector unsigned char shuffle_0415 = (vector unsigned char) {
						  0x00, 0x01, 0x02, 0x03, 0x10, 0x11, 0x12, 0x13,
						  0x04, 0x05, 0x06, 0x07, 0x14, 0x15, 0x16, 0x17};

  shuffle_2637 = spu_or(shuffle_0415, 8);

  for (k = m-1; k >= 0; k-=4)
  {
    
    
    b[k] = b[k]/a[k*lda + k];
    b[k-1] = (b[k-1] - b[k]*a[(k-1)*lda +k])/a[(k-1)*lda + (k-1)];
    b[k-2] = (b[k-2] - b[k-1]*a[(k-2)*lda + k-1] - b[k]*a[(k-2)*lda + k])/
              a[(k-2)*lda + (k-2)];
    b[k-3] = (b[k-3] - b[k-2]*a[(k-3)*lda + k-2] -
             b[k-1]*a[(k-3)*lda + (k-1)] - b[k]*a[(k-3)*lda + k])/a[(k-3)*lda + (k-3)];
    
    for (i = 0; i < k-3; i+=4)
    {
      bk = *((vector float*)&b[k-3]);
      bi = *((vector float*)&b[i]);
      a0 = *((vector float*)&a[i*lda + k-3]);
      a1 = *((vector float*)&a[(i+1)*lda + k-3]);
      a2 = *((vector float*)&a[(i+2)*lda + k-3]);
      a3 = *((vector float*)&a[(i+3)*lda + k-3]);
      
      a0 = spu_mul (a0, bk);
      a1 = spu_mul (a1, bk);
      a2 = spu_mul (a2, bk);
      a3 = spu_mul (a3, bk);

      /* Transpose the 4x4 contained in a0, a1, a2, a3 
       * into a0t, a1t, a2t, a3t.
       */
      a02h = spu_shuffle(a0, a2, shuffle_0415);
      a02l = spu_shuffle(a0, a2, shuffle_2637);
      a13h = spu_shuffle(a1, a3, shuffle_0415);
      a13l = spu_shuffle(a1, a3, shuffle_2637);

      a0t = spu_shuffle(a02h, a13h, shuffle_0415);
      a1t = spu_shuffle(a02h, a13h, shuffle_2637);
      a2t = spu_shuffle(a02l, a13l, shuffle_0415);
      a3t = spu_shuffle(a02l, a13l, shuffle_2637);

      bi = spu_sub(bi, spu_add(a0t, a1t));
      bi = spu_sub(bi, spu_add(a2t, a3t));
 
      *((vector float*)&b[i]) = bi;

    }
  }
  
}


