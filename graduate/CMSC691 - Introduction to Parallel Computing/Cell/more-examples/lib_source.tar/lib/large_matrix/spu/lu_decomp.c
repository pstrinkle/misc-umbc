/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#ifdef PROF
 #include <profile.h>
#endif
#include "liblarge_matrix.h"

/*
 * Description:
 * -------------
 *  The lu_decomp_2 subroutine computes the LU factorization of a 
 *  dense general m by n matrix a using partial pivoting with row 
 *  interchanges. The factorization is done in place.
 *
 *  The factorization has the form
 *  	A = P*L*U
 *  where P is a permutation matrix, L is lower triangular with 
 *  unit diagonal elements (lower trapezoidal if m > n) and U 
 *  is upper triangular (upper trapezoidal if m < n).
 *
 * Matrix a and vector ipiv must be quad-word aligned and multiples of 4
 *
 * This is the right-looking Level 2 BLAS version of the algorithm. 
 * This subroutine is suitable for computing the LU Decomposition of 
 * a narrow matrix where the number of rows is much greater than the 
 * number of columns. This subroutine should not be used for general 
 * large square matrix since it is not very efficient. One should use
 * subroutine lu3_decomp instead.
 *
 * Parameters
 * ----------
 *	
 *	int m: 	number of rows of matrix a. m >= 0
 *
 * 	int n: 	number of columns of matrix a. n >= 0
 *
 *   float* a:	on entry, this is the m by n matrix to be factored. 
 *              On exit, the factors L and U from the factorization A = P*L*U; 
 *              the unit diagonal elements of L are not stored.
 *
 *    int lda:	 stride of matrix a
 * 
 *  int* ipiv:	 on entry, this is just an empty array of integers. 
 *               On output, this is an array of integers representing the
 *               pivot indices.
 *
 * Returns:
 * --------
 *  = 0:   on success
 *  < 0:   input parameters are invalid
 *  > 0:   matrix is singular. U(j, j) = 0
 *         The factorization has been completed but the factor U
 *         is exactly singular and division by zero will occur if it is used to
 *         to solve a system of equations
 *
 * Dependencies
 * ------------
 *
 *	index_max_abs
 *	scale_vector
 *	swap_vectors
 *	mult_vector_vector 
 */
int lu2_decomp (int m, int n, float* a, int lda, int* ipiv)
{
  int j, rc, jp;
  if ((m < 0) || (n < 0) || (lda < m)){
    return -1;
  }
  if ((m ==0) || (n == 0))
    return 0;
  rc = 0;
  
  for (j = 0; j < n; j++)
  {
#ifdef PROF
    prof_cp10();
#endif
    jp = j + index_max_abs_col (m-j, &a[j*lda], j, lda);
#ifdef PROF
    prof_cp11();
#endif
    //printf ("lu_decomp: j = %d, pivot index = %d\n", j, jp);
    ipiv[j] = jp;
    //printf ("lu_decomp, ipiv[%d] = %d\n", j, ipiv[j]);
    
    if (a[jp*lda + j] != 0)
    {
      if (jp != j)
      {
#ifdef PROF
        prof_cp12();
#endif
        swap_vectors (n, &a[j*lda], &a[jp*lda]);
#ifdef PROF
        prof_cp13();
#endif
      }
#ifdef PROF
      prof_cp14();
#endif
      scale_matrix_col (m-(j+1), 1.0f/a[j + j*lda], &a[(j+1)*lda], j, lda);
#ifdef PROF
      prof_cp15();
#endif
    }
    else
    {
      rc = j;
    }
    if (j < n)
    {
#ifdef PROF
      prof_cp16();
#endif
      nmsub_vector_vector (m-(j+1), n-(j+1), &a[(j+1)*lda +j], lda, 
                          &a[j*lda + (j+1)], &a[j+1+ (j+1)*lda], lda);
#ifdef PROF
      prof_cp17();
#endif
    }
    
  }
  return rc;
}


static __inline void _update_ipiv (int n, int* ipiv, unsigned int base_idx)
{
  int i;
  
  vector unsigned int v_base;
  vector unsigned int* v_ipiv;
  vector unsigned int i0, i1, i2, i3;
  v_base = spu_splats (base_idx);
  
  v_ipiv = (vector unsigned int*)ipiv; 
  
  for (i = 0; i < n-(n&0xF); i+=16)
  {
    i0 = *((vector unsigned int*)&ipiv[i]);
    i1 = *((vector unsigned int*)&ipiv[i+4]);
    i2 = *((vector unsigned int*)&ipiv[i+8]);
    i3 = *((vector unsigned int*)&ipiv[i+12]);
    
    *((vector unsigned int*)&ipiv[i]) = spu_add (i0, v_base);
    *((vector unsigned int*)&ipiv[i+4]) = spu_add (i1, v_base);
    *((vector unsigned int*)&ipiv[i+8]) = spu_add (i2, v_base);
    *((vector unsigned int*)&ipiv[i+12]) = spu_add (i3, v_base);
  }
  for (i = n-(n&0xF); i < n-(n%4); i+=4)
  {
    i0 = *((vector unsigned int*)&ipiv[i]);
    *((vector unsigned int*)&ipiv[i]) = spu_add (i0, v_base);
  }
  for (i = n-(n%4); i < n; i++)
  {
    ipiv[i] += base_idx;
  }
  
}
/*
 * C Specification
 * ---------------
 *   
 *   #include <lu_decomp.h>
 *   int lu3_decomp(int m, int n, float* a, int lda, int* ipiv)
 *
 * Description
 * ------------ 
 *   The lu3_decomp subroutine computes the LU factorization of a 
 *   dense general m by n matrix a using partial pivoting with row 
 *   interchanges. The factorization is done in place.
 *   
 *   The factorization has the form:  A = P*L*U
 *
 *   where P is a permutation matrix, L is lower triangular with 
 *   unit diagonal elements (lower trapezoidal if m > n) and U is 
 *   upper triangular (upper trapezoidal if m < n).
 *
 *   Matrix a and integer array ipiv must be quad-word aligned. 
 *
 *   This is the right-looking Level 3 BLAS version of the algorithm. 
 *   This version of LU decomposition should be more efficient than the 
 *   subroutine lu2_decomp described above. 
 *
 * Parameters
 * -----------
 * 
 *   int m: 	number of rows of matrix a. m >= 0
 *   
 *   int n: 	number of columns of matrix a. n >= 0
 *   
 *   float* a:	on entry, this is the m by n matrix to be factored. 
 *
 *   On exit, the factors L and U from the factorization A = P*L*U; 
 *   the unit diagonal elements of L are not stored.
 *   
 *   int lda:	 stride of matrix a 
 *   int* ipiv:	 on entry, this is just an empty array of integers. 
 *               On output, this is an array of integers representing 
 *               the pivot indices.
 *
 * Returns:
 * --------
 *  = 0:   on success
 *  < 0:   input parameters are invalid
 *  > 0:   matrix is singular. U(j, j) = 0
 *         The factorization has been completed but the factor U
 *         is exactly singular and division by zero will occur if it is used to 
 *         solve a system of equations

 * Dependencies
 * ------------
 * 
 * lu2_decomp
 * swap_matrix_rows
 * solve_unit_lower
 * nmsub_matrix_matrix
 *
 * Notes
 * -----
 * 
 * LU Decomposition is done according to the blocked algorithm referenced 
 * in Jack Dongarra's paper. (Fill in the name of the paper). The size of 
 * the block is set at compile time as BLOCKSIZE. Default size of BLOCKSIZE 
 * is 32 with 4, 8, 16, 32, 64 as valid BLOCKSIZE.  The size of the matrix 
 * (m, and n) do not have to be multiples of BLOCKSIZE, however, the algorithm
 * works much more efficiently when m and  n are multiples of BLOCKSIZE.
 * Only limited testing has been done for non-square matrix (m is different from n)
 */ 
int lu3_decomp (int m, int n, float* a, int lda, int* ipiv)
{
  int j, rc;
  int nb = BLOCK_SIZE;
  int jb;

  if ((m < 0) || (n < 0) || (lda < m)){
    return -1;
  }
  if ((m ==0) || (n == 0))
    return 0;
  rc = 0;

  for (j = 0; j <n; j+= nb)
  {
    jb = ((n - j) > nb)? nb: n-j;
#ifdef PROF 
    prof_cp2();
#endif
    rc = lu2_decomp (m - j, jb, &a[j + j*lda], lda, &ipiv[j]);
          
#ifdef PROF
    prof_cp3();
#endif
    
    _update_ipiv (jb, &ipiv[j], j); 
    rc = (rc > 0)? rc+j: rc ; 
    if (j > 0)
    {
#ifdef PROF
      prof_cp4();
#endif
      swap_matrix_rows (j, a, lda, j, j+jb, ipiv);
#ifdef PROF
      prof_cp5();
#endif
    }
 
   
    if ((j + jb) < n)
    {
#ifdef PROF
      prof_cp4();
#endif
      swap_matrix_rows (n-j-jb, &a[(j+jb)], lda, j, j+jb, ipiv);
#ifdef PROF
      prof_cp5();
      prof_cp6();
#endif
      solve_unit_lower (jb, n-j-jb, &a[j + j*lda], lda, &a[j*lda + (j+jb)], lda);
#ifdef PROF
      prof_cp7();
      prof_cp8();
#endif
      nmsub_matrix_matrix (m-j-jb, n-j-jb, jb, &a[(j+jb)*lda + j], lda, 
                           &a[j*lda+(j+jb)], lda, &a[j+jb + (j+jb)*lda], lda);
#ifdef PROF
      prof_cp9();
#endif
    }
     
  }
  return rc;
}


