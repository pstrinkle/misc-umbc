/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include "liblarge_matrix.h"

/*
 * Description:
 *    find the index of the maximum absolute value in the specified column
 *    of matrix m
 *
 * Parameters:
 *    n: size of array of floating point numbers dx
 *    m: matrix m
 *    j: index of the column 
 *    stride: stride of matrix m 
 *
 * Return:
 *    index of max absolute value
 *
 */
int index_max_abs_col (int n, float* m, int col, int stride)
{
  int i;
	int index;
	float max;
	float* a;
  int col_idx;
  
  vector float tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
  vector float n0 = spu_splats((float)0.0f);
  vector float n1, n2, n3, n4, n5, n6, n7;
  vector unsigned int cmp0, cmp1, cmp2, cmp3, cmp4, cmp5, cmp6, cmp7;
  vector unsigned int i0, i1, i2, i3, i4, i5, i6, i7;
  vector unsigned int idx0 = spu_splats((unsigned int)0);
  vector unsigned int idx1 = spu_splats((unsigned int)1);
  vector unsigned int idx2 = spu_splats((unsigned int)2);
  vector unsigned int idx3 = spu_splats((unsigned int)3);
  vector unsigned int idx4 = spu_splats((unsigned int)4);
  vector unsigned int idx5 = spu_splats((unsigned int)5);
  vector unsigned int idx6 = spu_splats((unsigned int)6);
  vector unsigned int idx7 = spu_splats((unsigned int)7);

  a = &m[(col >> 2)*4];
  col_idx = col & 0x3;
  
	index = 0;
	max = -1;

  if (n >= 8) {
    n0 = *((vector float*)&a[0]);
    n1 = *((vector float*)&a[stride]);
    n2 = *((vector float*)&a[2*stride]);
    n3 = *((vector float*)&a[3*stride]);
    n4 = *((vector float*)&a[4*stride]);
    n5 = *((vector float*)&a[5*stride]);
    n6 = *((vector float*)&a[6*stride]);
    n7 = *((vector float*)&a[7*stride]);
    i0 = idx0; 
    
    /* going through each row */
    for (i = 8; i < (n - (n&0x7)); i+=8) {
      tmp0 = *((vector float*)&a[i*stride]);
      tmp1 = *((vector float*)&a[(i+1)*stride]);
      tmp2 = *((vector float*)&a[(i+2)*stride]);
      tmp3 = *((vector float*)&a[(i+3)*stride]);
      tmp4 = *((vector float*)&a[(i+4)*stride]);
      tmp5 = *((vector float*)&a[(i+5)*stride]);
      tmp6 = *((vector float*)&a[(i+6)*stride]);
      tmp7 = *((vector float*)&a[(i+7)*stride]);

      i0 = spu_splats ((unsigned int)i);
      i1 = spu_splats ((unsigned int)i+1);
      i2 = spu_splats ((unsigned int)i+2);
      i3 = spu_splats ((unsigned int)i+3);
      i4 = spu_splats ((unsigned int)i+4);
      i5 = spu_splats ((unsigned int)i+5);
      i6 = spu_splats ((unsigned int)i+6);
      i7 = spu_splats ((unsigned int)i+7);
      
      cmp0 = spu_cmpabsgt (tmp0, n0);
      cmp1 = spu_cmpabsgt (tmp1, n1);
      cmp2 = spu_cmpabsgt (tmp2, n2);
      cmp3 = spu_cmpabsgt (tmp3, n3);
      cmp4 = spu_cmpabsgt (tmp4, n4);
      cmp5 = spu_cmpabsgt (tmp5, n5);
      cmp6 = spu_cmpabsgt (tmp6, n6);
      cmp7 = spu_cmpabsgt (tmp7, n7);

      
      idx0 = spu_sel (idx0, i0, cmp0);
      idx1 = spu_sel (idx1, i1, cmp1);
      idx2 = spu_sel (idx2, i2, cmp2);
      idx3 = spu_sel (idx3, i3, cmp3);
      idx4 = spu_sel (idx4, i4, cmp4);
      idx5 = spu_sel (idx5, i5, cmp5);
      idx6 = spu_sel (idx6, i6, cmp6);
      idx7 = spu_sel (idx7, i7, cmp7);

      n0 = spu_sel (n0, tmp0, cmp0);
      n1 = spu_sel (n1, tmp1, cmp1);
      n2 = spu_sel (n2, tmp2, cmp2);
      n3 = spu_sel (n3, tmp3, cmp3);
      n4 = spu_sel (n4, tmp4, cmp4);
      n5 = spu_sel (n5, tmp5, cmp5);
      n6 = spu_sel (n6, tmp6, cmp6);
      n7 = spu_sel (n7, tmp7, cmp7);
    }
    
    /* now find the max and max index of the 8 channels*/
    cmp0 = spu_cmpabsgt (n0, n1);
    cmp2 = spu_cmpabsgt (n2, n3);
    cmp4 = spu_cmpabsgt (n4, n5);
    cmp6 = spu_cmpabsgt (n6, n7);

    idx0 = spu_sel (idx1, idx0, cmp0);
    idx2 = spu_sel (idx3, idx2, cmp2);
    idx4 = spu_sel (idx5, idx4, cmp4);
    idx6 = spu_sel (idx7, idx6, cmp6);

    n0 = spu_sel (n1, n0, cmp0);
    n2 = spu_sel (n3, n2, cmp2);
    n4 = spu_sel (n5, n4, cmp4);
    n6 = spu_sel (n7, n6, cmp6);

    cmp0 = spu_cmpabsgt (n0, n2);
    cmp4 = spu_cmpabsgt (n4, n6);

    idx0 = spu_sel (idx2, idx0, cmp0);
    idx4 = spu_sel (idx6, idx4, cmp4);

    n0 = spu_sel (n2, n0, cmp0);
    n4 = spu_sel (n6, n4, cmp4);

    cmp0 = spu_cmpabsgt (n0, n4);
    idx0 = spu_sel (idx4, idx0, cmp0);
    n0 = spu_sel (n4, n0, cmp0);
   
    /* now go through the remainder */
    for (i = (n - (n&0x7)); i < n; i++)
    {
      i0 = spu_splats ((unsigned int)i);
      tmp0 = *((vector float*)&a[i*stride]);
      cmp0 = spu_cmpabsgt (tmp0, n0);
      idx0 = spu_sel (idx0, i0, cmp0);
      n0 = spu_sel (n0, tmp0, cmp0);
    }
  }
  else
  {
    for (i = 0; i < n; i++)
    {
      i0 = spu_splats ((unsigned int)i);
      tmp0 = *((vector float*)&a[i*stride]);
      cmp0 = spu_cmpabsgt (tmp0, n0);
      idx0 = spu_sel (idx0, i0, cmp0);
      n0 = spu_sel (n0, tmp0, cmp0);
    }
  }
  
  index = spu_extract (idx0, col_idx);
  max = spu_extract (n0, col_idx);
  return index;
}





























