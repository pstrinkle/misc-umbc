/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>
#include <stdlib.h>
#include "liblarge_matrix.h"

//#define SSCAL_SCALAR 1


#ifdef SSCAL_SCALAR 
void scale_vector (int n, float da, float *dx)
{
  int i;
  for (i =0; i < n; i++)
  {
    dx[i] = da * dx[i];
  }
}

#else
void scale_vector (int n, float da, float *dx)
{
  int i;
  int m;
  union 
  {
    unsigned int idx[4];
    vector unsigned int vidx;
  }v_idx1;

  union 
  {
    unsigned int idx[4];
    vector unsigned int vidx;
  }v_idx2;
 
  unsigned int s_32; 
  vector unsigned int v_32;
  vector unsigned int v_s_align;
  vector float vt0, vt1, vt2, vt3, vt4, vt5, vt6, vt7;
	unsigned int pre_aligned_addr, s_align;
  int xalign, palign, n_vops;
  vector float v_tmp_float;
  vector float v_old;
  vector float v_da;
  vector unsigned int pattern;
  /*
  printf ("scale_vector: da = %f input array = \n", da);
  for (i =0; i < n;i++)
  {
    printf ("%f  ", dx[i]);
  } 
  printf ("\n");
  */
  /* pre-align stuff */
  
  palign = (unsigned int)(((unsigned int)dx & 0xF) >> 2);
  s_align = (4 - palign)&0x3;
  v_da = spu_splats (da);
  pre_aligned_addr = ((unsigned int)dx & 0xFFFFFFF0);
  //pattern = ((n < 4))? pre_shuffle_table[n][palign] : pre_shuffle_array[palign]; 
  pattern = spu_maskw ((1 << s_align)-1);

  
  v_old = (*(vector float *)(pre_aligned_addr));
  n_vops = n - s_align; 
  v_tmp_float = spu_mul (v_da, v_old);
  *((vector float*)(pre_aligned_addr)) = spu_sel (v_old, v_tmp_float, pattern);
 
      
  /* align */

  s_32 = 32;
  m = n_vops & 0x1F;
  v_32 = spu_splats (s_32);
  v_s_align = spu_splats (s_align);
  v_idx1.vidx = (vector unsigned int) { 0, 4, 8, 12};
  v_idx2.vidx = (vector unsigned int) { 16, 20, 24, 28};
 
  v_idx1.vidx = spu_add (v_idx1.vidx, v_s_align);
  v_idx2.vidx = spu_add (v_idx2.vidx, v_s_align);

  /*
  print_vec_uint4 ("v_idx1: ", v_idx1.vidx);
  print_vec_uint4 ("v_idx2: ", v_idx2.vidx);
  */
  
  for (i = s_align; i < n-m; i += 32) {
    vt0 = *((vector float *) &dx[v_idx1.idx[0]]); 
    vt1 = *((vector float *) &dx[v_idx1.idx[1]]); 
    vt2 = *((vector float *) &dx[v_idx1.idx[2]]); 
    vt3 = *((vector float *) &dx[v_idx1.idx[3]]); 
    
    vt4 = *((vector float *) &dx[v_idx2.idx[0]]); 
    vt5 = *((vector float *) &dx[v_idx2.idx[1]]); 
    vt6 = *((vector float *) &dx[v_idx2.idx[2]]); 
    vt7 = *((vector float *) &dx[v_idx2.idx[3]]); 
    
    
    *((vector float *) &dx[v_idx1.idx[0]]) = spu_mul (v_da, vt0); 
    *((vector float *) &dx[v_idx2.idx[0]]) = spu_mul (v_da, vt4); 

    *((vector float *) &dx[v_idx1.idx[1]]) = spu_mul (v_da, vt1); 
    *((vector float *) &dx[v_idx2.idx[1]]) = spu_mul (v_da, vt5); 

    *((vector float *) &dx[v_idx1.idx[2]]) = spu_mul (v_da, vt2); 
    *((vector float *) &dx[v_idx2.idx[2]]) = spu_mul (v_da, vt6); 

    *((vector float *) &dx[v_idx1.idx[3]]) = spu_mul (v_da, vt3); 
    *((vector float *) &dx[v_idx2.idx[3]]) = spu_mul (v_da, vt7); 
    
    v_idx1.vidx = spu_add (v_idx1.vidx, v_32);
    v_idx2.vidx = spu_add (v_idx2.vidx, v_32);
  }
  
  xalign = (int)(((unsigned int)&dx[n] & 0xF) >> 2);

  
  for (i = n-m ; i < n-xalign; i+= 4) {
    *((vector float *) &dx[i]) = spu_mul (v_da,*((vector float *) &dx[i])); 
  }
  
  //printf ("i = %d\n", i);


  if (xalign == 0) {
    return;
  }
  
  v_old = (*(vector float *)((unsigned int)(&dx[n-xalign])));
  //pattern = (n < 4)? post_shuffle_table[n][palign] : post_shuffle_array[xalign];
  pattern = spu_maskw (((1 << xalign)-1) << (4-xalign));
  
  v_tmp_float = spu_mul (v_da, v_old);
  (*(vector float*)(&dx[n-xalign])) = spu_sel (v_old, v_tmp_float, pattern);
}
#endif /* _USE_SCALAR */
