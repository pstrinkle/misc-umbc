/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdlib.h>
#include <stdio.h>
#include <max_vec_float4.h>
#include <simdmath/fabsf4.h>
#include "liblarge_matrix.h"


int index_max_abs_vec (int n, float* dx)
{
  int i, itemp;
  vector float t0, t1, t2, t3;
  vector unsigned int cmp0, cmp1, cmp2, cmp3;
  vector float v_max0, v_max1, v_max2, v_max3;
  vector unsigned int mask;
  vector unsigned int idx0, idx1, idx2, idx3;
  vector unsigned int v_i, i0, i1, i2, i3;
  vector unsigned int v0123 = (vector unsigned int) { 0, 1, 2, 3};
  vector unsigned int v4567 = (vector unsigned int) { 4, 5, 6, 7};
  vector unsigned int v8901 = (vector unsigned int) { 8, 9, 10, 11};
  vector unsigned int v2345 = (vector unsigned int) { 12, 13, 14, 15};
  vector float v_tmp_float; 
  vector float zero = spu_splats((float)0.0f);
  float dmax; 
  int pre_align, post_align; 
 
  
  pre_align = 4 - (unsigned int)(((unsigned int)dx & 0xF) >> 2);
  v_max0 = *((vector float *) (((unsigned int)dx >> 4) << 4));

  mask = spu_maskw ((1<<pre_align)-1);

  v_max0 = spu_sel (zero, v_max0, mask);
  idx0 = spu_sub (v0123, (vector unsigned int)spu_splats (4-pre_align));
  
  if (n >= 4)
  {
    v_max1 = zero;
    v_max2 = zero;
    v_max3 = zero;
    idx1 = spu_splats((unsigned int)0);
    idx2 = spu_splats((unsigned int)0);
    idx3 = spu_splats((unsigned int)0);

    for (i = pre_align; i < n - ((n-pre_align)&0xF); i+=16)
    {
      v_i = spu_splats ((unsigned int)i);
      t0 = *((vector float*)&dx[i]);
      t1 = *((vector float*)&dx[i+4]);
      t2 = *((vector float*)&dx[i+8]);
      t3 = *((vector float*)&dx[i+12]);

      i0 = spu_add (v0123, v_i);
      i1 = spu_add (v4567, v_i);
      i2 = spu_add (v8901, v_i);
      i3 = spu_add (v2345, v_i);
     
      cmp0 = spu_cmpabsgt (t0, v_max0);
      cmp1 = spu_cmpabsgt (t1, v_max1);
      cmp2 = spu_cmpabsgt (t2, v_max2);
      cmp3 = spu_cmpabsgt (t3, v_max3);
     
      idx0 = spu_sel (idx0, i0, cmp0);
      idx1 = spu_sel (idx1, i1, cmp1);
      idx2 = spu_sel (idx2, i2, cmp2);
      idx3 = spu_sel (idx3, i3, cmp3);
     
      v_max0 = spu_sel (v_max0, t0, cmp0);
      v_max1 = spu_sel (v_max1, t1, cmp1);
      v_max2 = spu_sel (v_max2, t2, cmp2);
      v_max3 = spu_sel (v_max3, t3, cmp3);
    }
    
    cmp0 = spu_cmpabsgt (v_max0, v_max1);
    cmp2 = spu_cmpabsgt (v_max2, v_max3);

    idx0 = spu_sel (idx1, idx0, cmp0);
    idx2 = spu_sel (idx3, idx2, cmp2);

    v_max0 = spu_sel (v_max1, v_max0, cmp0);
    v_max2 = spu_sel (v_max3, v_max2, cmp2);

    cmp0 = spu_cmpabsgt (v_max0, v_max2);
    idx0 = spu_sel (idx2, idx0, cmp0);
    v_max0 = spu_sel (v_max2, v_max0, cmp0);

    post_align = n-((n-pre_align)%4); 
  
    for (i = (n - ((n-pre_align)&0xF)); i < post_align; i+=4)
    {
      v_i = spu_splats ((unsigned int)i);
      t0 = *((vector float*)&dx[i]);
      i0 = spu_add (v0123, v_i);
      cmp0 = spu_cmpabsgt (t0, v_max0);
      idx0 = spu_sel (idx0, i0, cmp0);
      v_max0 = spu_sel (v_max0, t0, cmp0);
    }
 
    v_i = spu_splats ((unsigned int)post_align);
    
    i0 = spu_add (v0123, v_i);
    /* post_align */
    t0 = *((vector float*)&dx[post_align]);
    mask = spu_maskw ((1<<(4-(n-post_align)))-1);
    t0 = spu_sel (t0, zero, mask);
    cmp0 = spu_cmpabsgt (t0, v_max0);
    idx0 = spu_sel (idx0, i0, cmp0);

    v_max0 = spu_sel (v_max0, t0, cmp0);
  }

  v_max0 = _fabsf4(v_max0);
  /* finding the max of a vector */
  dmax = _max_vec_float4 (v_max0);
  
  v_tmp_float = spu_splats (dmax);
  cmp0 = spu_cmpeq (v_tmp_float, v_max0);

  itemp = spu_extract (spu_cntlz (spu_gather (cmp0)), 0) - 28;
  
  itemp =  (spu_extract (idx0, itemp));
  //printf ("itemp = %d max = %f\n\n", itemp, dmax);
  return itemp;
}
