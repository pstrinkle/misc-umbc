/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdlib.h>
#include <stdio.h>
#include "liblarge_matrix.h"


void nmsub_matrix_matrix (int m, int p, int n, float a[], int lda, float b[], int ldb, float c[], int ldc)
{

  int i, j, k;
  int off_c1, off_c2, off_c3, off_c4;
  int off_a1, off_a2, off_a3, off_a4;
  float* cc, *aa;  
  
  vector float ac0, ac1, ac2, ac3;
  vector float c00, c10, c20, c30;
  vector float c01, c11, c21, c31;
  vector float c02, c12, c22, c32;
  vector float c03, c13, c23, c33;
  
  vector float b00, b10, b20, b30;
  vector float b01, b11, b21, b31;
  vector float b02, b12, b22, b32;
  vector float b03, b13, b23, b33;

  off_c1 = ldc;
  off_c2 = ldc << 1;
  off_c3 = off_c2 + ldc;
  off_c4 = ldc << 2;
  
  off_a1 = lda;
  off_a2 = lda << 1;
  off_a3 = off_a2 + lda;
  off_a4 = lda << 2;

  cc = c;
  aa = a;
  for (i = 0; i < m; i+=4)
  {
    for (j = 0; j < p-(p&0xF); j+=16)
    {
      c00 = *((vector float*)&(cc[j])); 
      c10 = *((vector float*)&(cc[off_c1 + j]));
      c20 = *((vector float*)&(cc[off_c2 + j]));
      c30 = *((vector float*)&(cc[off_c3 + j]));

      c01 = *((vector float*)&(cc[j+4])); 
      c11 = *((vector float*)&(cc[off_c1 + j+4]));
      c21 = *((vector float*)&(cc[off_c2 + j+4]));
      c31 = *((vector float*)&(cc[off_c3 + j+4]));

      c02 = *((vector float*)&(cc[j+8])); 
      c12 = *((vector float*)&(cc[off_c1 + j+8]));
      c22 = *((vector float*)&(cc[off_c2 + j+8]));
      c32 = *((vector float*)&(cc[off_c3 + j+8]));

      c03 = *((vector float*)&(cc[j+12])); 
      c13 = *((vector float*)&(cc[off_c1 + j+12]));
      c23 = *((vector float*)&(cc[off_c2 + j+12]));
      c33 = *((vector float*)&(cc[off_c3 + j+12]));
      
      for (k = 0; k < n; k+=4)
      {
        ac0 = spu_splats (aa[k]);
        ac1 = spu_splats (aa[off_a1+k]);
        ac2 = spu_splats (aa[off_a2+k]);
        ac3 = spu_splats (aa[off_a3+k]);

        
        b00 = *((vector float*)&(b[k*ldb + j])); 
        b10 = *((vector float*)&(b[(k+1)*ldb + j]));
        b20 = *((vector float*)&(b[(k+2)*ldb + j]));
        b30 = *((vector float*)&(b[(k+3)*ldb + j]));

        b01 = *((vector float*)&(b[k*ldb + j+4])); 
        b11 = *((vector float*)&(b[(k+1)*ldb + j+4]));
        b21 = *((vector float*)&(b[(k+2)*ldb + j+4]));
        b31 = *((vector float*)&(b[(k+3)*ldb + j+4]));
        
        b02 = *((vector float*)&(b[k*ldb + j+8])); 
        b12 = *((vector float*)&(b[(k+1)*ldb + j+8]));
        b22 = *((vector float*)&(b[(k+2)*ldb + j+8]));
        b32 = *((vector float*)&(b[(k+3)*ldb + j+8]));

        b03 = *((vector float*)&(b[k*ldb + j+12])); 
        b13 = *((vector float*)&(b[(k+1)*ldb + j+12]));
        b23 = *((vector float*)&(b[(k+2)*ldb + j+12]));
        b33 = *((vector float*)&(b[(k+3)*ldb + j+12]));

        c00 = spu_nmsub (ac0, b00, c00);
        c01 = spu_nmsub (ac0, b01, c01);
        c02 = spu_nmsub (ac0, b02, c02);
        c03 = spu_nmsub (ac0, b03, c03);
        ac0 = spu_splats (aa[k+1]);
 
        
        c10 = spu_nmsub (ac1, b00, c10);
        c11 = spu_nmsub (ac1, b01, c11);
        c12 = spu_nmsub (ac1, b02, c12);
        c13 = spu_nmsub (ac1, b03, c13);
        ac1 = spu_splats (aa[off_a1 + k+1]);

        
        c20 = spu_nmsub (ac2, b00, c20);
        c21 = spu_nmsub (ac2, b01, c21);
        c22 = spu_nmsub (ac2, b02, c22);
        c23 = spu_nmsub (ac2, b03, c23);
        ac2 = spu_splats (aa[off_a2 + k+1]);

  
        c30 = spu_nmsub (ac3, b00, c30);
        c31 = spu_nmsub (ac3, b01, c31);
        c32 = spu_nmsub (ac3, b02, c32);
        c33 = spu_nmsub (ac3, b03, c33);
        ac3 = spu_splats (aa[off_a3 + k+1]);


        /* second column of a */
        
        c00 = spu_nmsub (ac0, b10, c00);
        c01 = spu_nmsub (ac0, b11, c01);
        c02 = spu_nmsub (ac0, b12, c02);
        c03 = spu_nmsub (ac0, b13, c03);
        ac0 = spu_splats (aa[k+2]);

        c10 = spu_nmsub (ac1, b10, c10);
        c11 = spu_nmsub (ac1, b11, c11);
        c12 = spu_nmsub (ac1, b12, c12);
        c13 = spu_nmsub (ac1, b13, c13);
        ac1 = spu_splats (aa[off_a1 + k+2]);

        c20 = spu_nmsub (ac2, b10, c20);
        c21 = spu_nmsub (ac2, b11, c21);
        c22 = spu_nmsub (ac2, b12, c22);
        c23 = spu_nmsub (ac2, b13, c23);
        ac2 = spu_splats (aa[off_a2 + k+2]);

        c30 = spu_nmsub (ac3, b10, c30);
        c31 = spu_nmsub (ac3, b11, c31);
        c32 = spu_nmsub (ac3, b12, c32);
        c33 = spu_nmsub (ac3, b13, c33);
        ac3 = spu_splats (aa[off_a3 + k+2]);


        /* third column of a */
        
        c00 = spu_nmsub (ac0, b20, c00);
        c01 = spu_nmsub (ac0, b21, c01);
        c02 = spu_nmsub (ac0, b22, c02);
        c03 = spu_nmsub (ac0, b23, c03);
        ac0 = spu_splats (aa[k+3]);

        c10 = spu_nmsub (ac1, b20, c10);
        c11 = spu_nmsub (ac1, b21, c11);
        c12 = spu_nmsub (ac1, b22, c12);
        c13 = spu_nmsub (ac1, b23, c13);
        ac1 = spu_splats (aa[off_a1 + k+3]);

        c20 = spu_nmsub (ac2, b20, c20);
        c21 = spu_nmsub (ac2, b21, c21);
        c22 = spu_nmsub (ac2, b22, c22);
        c23 = spu_nmsub (ac2, b23, c23);
        ac2 = spu_splats (aa[off_a2 + k+3]);

        c30 = spu_nmsub (ac3, b20, c30);
        c31 = spu_nmsub (ac3, b21, c31);
        c32 = spu_nmsub (ac3, b22, c32);
        c33 = spu_nmsub (ac3, b23, c33);
        ac3 = spu_splats (aa[off_a3 + k+3]);
     

        /* fourth column of a */
        
        c00 = spu_nmsub (ac0, b30, c00);
        c01 = spu_nmsub (ac0, b31, c01);
        c02 = spu_nmsub (ac0, b32, c02);
        c03 = spu_nmsub (ac0, b33, c03);

        c10 = spu_nmsub (ac1, b30, c10);
        c11 = spu_nmsub (ac1, b31, c11);
        c12 = spu_nmsub (ac1, b32, c12);
        c13 = spu_nmsub (ac1, b33, c13);

        c20 = spu_nmsub (ac2, b30, c20);
        c21 = spu_nmsub (ac2, b31, c21);
        c22 = spu_nmsub (ac2, b32, c22);
        c23 = spu_nmsub (ac2, b33, c23);

        c30 = spu_nmsub (ac3, b30, c30);
        c31 = spu_nmsub (ac3, b31, c31);
        c32 = spu_nmsub (ac3, b32, c32);
        c33 = spu_nmsub (ac3, b33, c33);
      


        //c[i*ldc+j] = c[i*ldc+j] - a[i*lda+k]*b[k*ldb+j];
      }   
      *((vector float*)&(cc[j])) = c00; 
      *((vector float*)&(cc[off_c1 + j])) = c10;
      *((vector float*)&(cc[off_c2 + j])) = c20;
      *((vector float*)&(cc[off_c3 + j])) = c30;

      *((vector float*)&(cc[j+4])) = c01; 
      *((vector float*)&(cc[off_c1 + j+4])) = c11;
      *((vector float*)&(cc[off_c2 + j+4])) = c21;
      *((vector float*)&(cc[off_c3 + j+4])) = c31 ;

      *((vector float*)&(cc[j+8])) = c02; 
      *((vector float*)&(cc[off_c1 + j+8])) = c12;
      *((vector float*)&(cc[off_c2 + j+8])) = c22;
      *((vector float*)&(cc[off_c3 + j+8])) = c32;
 
      *((vector float*)&(cc[j+12])) = c03; 
      *((vector float*)&(cc[off_c1 + j+12])) = c13;
      *((vector float*)&(cc[off_c2 + j+12])) = c23;
      *((vector float*)&(cc[off_c3 + j+12])) = c33;

    }
    for (j = p-(p&0xF); j < p; j+=4)
    {
      c00 = *((vector float*)&(cc[j])); 
      c10 = *((vector float*)&(cc[off_c1 + j]));
      c20 = *((vector float*)&(cc[off_c2 + j]));
      c30 = *((vector float*)&(cc[off_c3 + j]));
      
      for (k = 0; k < n; k+=4)
      {
        ac0 = spu_splats (aa[k]);
        ac1 = spu_splats (aa[off_a1+k]);
        ac2 = spu_splats (aa[off_a2+k]);
        ac3 = spu_splats (aa[off_a3+k]);

        
        b00 = *((vector float*)&(b[k*ldb + j])); 
        b10 = *((vector float*)&(b[(k+1)*ldb + j]));
        b20 = *((vector float*)&(b[(k+2)*ldb + j]));
        b30 = *((vector float*)&(b[(k+3)*ldb + j]));

        c00 = spu_nmsub (ac0, b00, c00);
        ac0 = spu_splats (aa[k+1]);
 
        c10 = spu_nmsub (ac1, b00, c10);
        ac1 = spu_splats (aa[off_a1 + k+1]);
        
        c20 = spu_nmsub (ac2, b00, c20);
        ac2 = spu_splats (aa[off_a2 + k+1]);
  
        c30 = spu_nmsub (ac3, b00, c30);
        ac3 = spu_splats (aa[off_a3 + k+1]);


        /* second column of a */
        
        c00 = spu_nmsub (ac0, b10, c00);
        ac0 = spu_splats (aa[k+2]);

        c10 = spu_nmsub (ac1, b10, c10);
        ac1 = spu_splats (aa[off_a1 + k+2]);

        c20 = spu_nmsub (ac2, b10, c20);
        ac2 = spu_splats (aa[off_a2 + k+2]);

        c30 = spu_nmsub (ac3, b10, c30);
        ac3 = spu_splats (aa[off_a3 + k+2]);


        /* third column of a */
        
        c00 = spu_nmsub (ac0, b20, c00);
        ac0 = spu_splats (aa[k+3]);

        c10 = spu_nmsub (ac1, b20, c10);
        ac1 = spu_splats (aa[off_a1 + k+3]);

        c20 = spu_nmsub (ac2, b20, c20);
        ac2 = spu_splats (aa[off_a2 + k+3]);

        c30 = spu_nmsub (ac3, b20, c30);
        ac3 = spu_splats (aa[off_a3 + k+3]);
     
        /* fourth column of a */
        
        c00 = spu_nmsub (ac0, b30, c00);
        c10 = spu_nmsub (ac1, b30, c10);
        c20 = spu_nmsub (ac2, b30, c20);
        c30 = spu_nmsub (ac3, b30, c30);

      }   
      *((vector float*)&(cc[j])) = c00; 
      *((vector float*)&(cc[off_c1 + j])) = c10;
      *((vector float*)&(cc[off_c2 + j])) = c20;
      *((vector float*)&(cc[off_c3 + j])) = c30;
    }
    cc += off_c4;
    aa += off_a4;
  }

}

