/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SRAND_V_H_
#define _SRAND_V_H_

#include <libmisc.h>

#ifdef __SPU__
  #include <spu_intrinsics.h>
#else /* not __SPU__ */
  #include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void _srand_v(vector unsigned int seed)
 *
 * DESCRIPTION
 *	_srand_v set the random vector seed used by the rand routines -
 *	rand_v, rand_0_to_1_v, rand_minus1_to_1_v. No restrictions are 
 *	placed on the value of the seed, however, values whose least 
 *	significant 31 bits are all zero or all one are coerced to 1 to
 *	0x7FFFFFFE repectively.
 */
static __inline void _srand_v(vector unsigned int seed)
{
  vector unsigned int special;

#ifdef __SPU__
  vector unsigned int mask = spu_splats((unsigned int)0x7FFFFFFF);
  seed = spu_and(seed, mask);
  special = spu_or(spu_cmpeq(seed, 0), spu_cmpeq(seed, mask));
  rand_seed = spu_xor(seed, spu_and(special, 1));
#else
  vector unsigned int mask = ((vector unsigned int) {0x7FFFFFFF,0x7FFFFFFF,0x7FFFFFFF,0x7FFFFFFF});
  seed = vec_and(seed, mask);
  special = vec_or((vector unsigned int)vec_cmpeq(seed, ((vector unsigned int) {0,0,0,0})), 
		   (vector unsigned int)vec_cmpeq(seed, mask));
  rand_seed = vec_xor(seed, vec_and(special, ((vector unsigned int) {1,1,1,1})));
#endif
}

#endif /* _SRAND_V_H_ */
