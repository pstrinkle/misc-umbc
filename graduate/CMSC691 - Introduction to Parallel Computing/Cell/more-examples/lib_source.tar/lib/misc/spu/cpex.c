/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * cpex.c
 */
 
/*
 * These routines provide a simple set of functions that allow a
 * user to copy memory from an SPU local store out to memory or
 * vice-versa..
 * Typical DMA limitations make it more difficult for the end user,
 * so for those who do not care about performance, but would rather
 * have simplicity, we provide these functions.
 *
 * DMA transfers are typically aligned on 16 byte boundries, including
 * the source address, the destination address and the number of bytes
 * to be transferred. If a copy is determined to be aligned, we will
 * use the built in mechanisms to achieve maximum performance. If a
 * copy is determined to fail an address alignment check, then we drop to
 * an inefficient, yet functional, copy algorithm. DMA transfers that
 * are not aligned on 16 byte boundaries, but where the source and target
 * addresses are still aligned will utilize the efficient transfer,
 * function, but will likely suffer a performance penalty in hardware.
 * Transfers with odd sizes but proper alignment will use the efficient
 * functions as well.
 *
 * Aligned transfers can be asynchronous or synchronous, depending on
 * on what the user wants to do. Unaligned transfers must be
 * synchronous, since the data needs to be shifted to a working buffer
 * prior to each DMA, and the transfer needs to complete before reusing
 * the working buffer. The only alternative would be to duplicate the 
 * source buffer with the shifted data, but that seems too costly in
 * SPU resources.
 */

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <cpex.h>

//#define LOCAL_DEBUGGING
#ifdef LOCAL_DEBUGGING
#define PRINTF(...) {          \
  printf(__VA_ARGS__);	       \
}
#else
#define PRINTF(...) {}
#endif

typedef unsigned int 	tagid_t;


/*
 * this is a variable shared by copy_to / from implementation
 * copy_to / from implementation is not thread-safe and do not support re-entrance
 */
static char wb[128] __attribute__ ((aligned(128)));


/* __ls_sync 
 *    internal routine to serialize with 
 *    pending asynchronous copy operations.
 */
static inline void __ls_sync(uint32_t mask)
{
  spu_writech(MFC_WrTagMask, mask);
  spu_writech(MFC_WrTagUpdate, MFC_TAG_UPDATE_ALL);
  spu_readch(MFC_RdTagStat);
}

/* __copy_aligned 
 *    internal routine to perform aligned copies 
 *    to or from LS. This operation is asynchronous.
 */
static inline size_t __copy_aligned(uint32_t ls, uint64_t ea,
					size_t n, tagid_t tagid, uint32_t cmd)
{
  size_t wn = n;
  size_t tn;
  
  union {
    unsigned long long ull;
    unsigned int ui[2];
  } ea64;
  
  ea64.ull = ea;
  /* perform size-aligned transfers until we have less than 16 bytes
   * left to transfer
   */
  while (wn >= 16) {
    tn = (wn > MFC_MAX_DMA_SIZE) ? MFC_MAX_DMA_SIZE : (wn & ~0xF);
    PRINTF("address aligned %s of 0x%x bytes, offsets are 0x%x\n", (cmd==MFC_PUT_CMD)?"put":"get", tn, ls & 0xF);
    spu_mfcdma64((void*)ls, ea64.ui[0], ea64.ui[1], tn, tagid, cmd);
    ea64.ull += (uint64_t)tn;
    ls += tn;
    wn -= tn;
  }
  /* perform partial transfers for the last few bytes */
  while (wn > 0) {
    if ( wn >= 4)
      tn = (wn >= 8) ? 8 : 4;
    else
      tn = (wn >= 2) ? 2 : 1;
    
    PRINTF("address aligned %s of %i byte(s),    %i\n", (cmd==MFC_PUT_CMD)?"put":"get", tn, wn);
    spu_mfcdma64((void*)ls, ea64.ui[0], ea64.ui[1], tn, tagid, cmd);
    ea64.ull += tn;
    ls += tn;
    wn -= tn;
  }
  
  return n;
}

/* __copy_to_ls_unaligned 
 *    internal routine to perform unaligned copies 
 *    in to LS.  This operation is synchronous.
 */
static inline size_t __copy_to_ls_unaligned(uint32_t ls, uint64_t ea,
					    size_t n, tagid_t tagid)
{
  void *dp;
  uint64_t sp, soff;
  int wn, tn;
  uint32_t mask = (1 << tagid);
  union {
    unsigned long long ull;
    unsigned int ui[2];
  } ea64;
  
  sp = ea;
  dp = (void*) ls;
  wn = n;
  
  PRINTF("ls=0x%x\n", ls);
  PRINTF("sp=0x%016llx\n", sp);
  
  /* we need to copy the first part of the data, which may be
   * unaligned. we will copy the entire chunk (16B) of data into
   * the ls working buffer and then copy the partial data to it's 
   * final destination address in local store.
   */
  
  soff = sp & 0xf;
  tn = 16 - (int)soff;
  PRINTF("misaligned get of %i bytes - stage 1\n", tn);
  ea64.ull = sp & ~0xF;
  spu_mfcdma64(wb, ea64.ui[0], ea64.ui[1], 16, tagid, MFC_GET_CMD);
  __ls_sync(mask);
  memcpy(dp, wb+soff, tn);
  sp += tn;
  dp += tn;
  wn -= tn;
  
  /* once our source pointer is 16 byte aligned, we will dma 
   * either 16B or 128B chunks into the working buffer and 
   * copy to the final destination address in local store.
   * Exit this stage if we have 15B or less to go.
   */
  while (wn >= 16) {
    tn = ( wn >= 128 ) ? 128 : 16;
    PRINTF("misaligned get %i bytes - stage 2\n", tn);
    ea64.ull = sp;
    spu_mfcdma64(wb, ea64.ui[0], ea64.ui[1], tn, tagid, MFC_GET_CMD);
    __ls_sync(mask);
    memcpy(dp, wb, tn);
    sp += tn;
    dp += tn;
    wn -= tn;
  }
  
  /* if we have less than 16 bytes left to transfer, dma
   * the whole chunk into the working buffer, but only copy
   * back the needed portion.
   */
  if (wn > 0) {
    PRINTF("misaligned get of %i bytes - stage 3\n", wn);
    ea64.ull = sp;
    spu_mfcdma64(wb, ea64.ui[0], ea64.ui[1], 16, tagid, MFC_GET_CMD);
    __ls_sync(mask);
    memcpy(dp, wb, wn);
  }
  
  return n;
}

/* __copy_from_unaligned 
 *    internal routine to perform unaligned copies 
 *    out from LS.  This operation is synchronous.
 */
static inline size_t __copy_from_ls_unaligned(uint64_t ea, uint32_t ls,
					      size_t n, tagid_t tagid)
{
  void *sp, *wp;
  uint64_t dp, doff;
  size_t wn, tn;
  uint32_t mask = (1 << tagid);
  union {
    unsigned long long ull;
    unsigned int ui[2];
  } ea64;
  
  sp = (void*) ls;
  dp = ea;
  wn = n;
  doff = dp & 0xf;
  
  PRINTF("ls=0x%x\n", ls);
  PRINTF("dp=0x%016llx\n", dp);
  
  /* copy up to the next 16 byte boundary with regard to the destination
   * address, into the working buffer. Then DMA out 1/2/4/8 bytes as
   * per iteration.
   */
  if (doff) {
    wp = wb + doff;
    memcpy(wp, sp, 16-doff);
  }
  
  while (doff && (wn > 0)) {
    ea64.ull = dp;
    
    if (doff & 0x1)
      tn = 1;
    else if (doff & 0x2)
      tn = 2;
    else if (doff & 0x4)
      tn = 4;
    else 
      tn = 8;
    
    PRINTF("misaligned put of %i byte(s) - stage 1\n", tn);
    spu_mfcdma64(wp, ea64.ui[0], ea64.ui[1], tn, tagid, MFC_PUT_CMD);
    sp += tn;
    wp += tn;
    dp += tn;
    wn -= tn;
    doff = dp & 0xf;
    __ls_sync(mask);
  }
  
  /* once our destination address is 16 byte aligned, we will copy 
   * either 16B or 128B chunks into the working buffer and dma the
   * working buffer
   */
  while (wn >= 16) {
    tn = ( wn >= 128 ) ? 128 : 16;
    memcpy(wb, sp, tn);
    ea64.ull = dp;
    PRINTF("misaligned put of %i bytes - stage 2\n", tn);
    spu_mfcdma64(wb, ea64.ui[0], ea64.ui[1], tn, tagid, MFC_PUT_CMD);
    sp += tn;
    dp += tn;
    wn -= tn;
    __ls_sync(mask);
  }
  
  /* we have less than 16 bytes left to transfer. DMA them
   * 8/4/2/1 at a time. Use the working buffer for alignment.
   */
  wp = wb;
  memcpy(wp, sp, wn);
  
  while (wn > 0) {
    
    ea64.ull = dp;
    
    if ( wn >= 4)
      tn = (wn >= 8) ? 8 : 4;
    else
      tn = (wn >= 2) ? 2 : 1;
    
    PRINTF("misaligned put of %i byte - stage 3\n", tn);
    spu_mfcdma64(wp, ea64.ui[0], ea64.ui[1], tn, tagid, MFC_PUT_CMD);
    sp += tn;
    wp += tn;
    dp += tn;
    wn -= tn;
    __ls_sync(mask);
  }
  
  return n;
}


/**
 * ls_sync - Synchronize with pending asynchronous copy operations.
 * @tagid: tag identifier for asynchronous copy operation.
 *
 * Synchronize with pending asynchronous copy operations.
 * This operation effectively waits for completion of any
 * operations with the given @tagid.  If @tagid is greater
 * than %MAX_TAG_ID, then this routine will wait for all
 * pending asynchronous transfers to complete.
 */
void ls_sync(tagid_t tagid)
{
  uint32_t mask = (tagid > 0x1f) ? ~0 : (1 << tagid);
  
  __ls_sync(mask);
}

/**
 * copy_to_ls - Copy of memory to LS.
 * @to: pointer to local storage area buffer (destination).
 * @from: handle to effective address buffer (source).
 * @n: number of bytes to be copied.
 *
 * Copy of memory to to local storage area.
 * This operation is synchronous.
 */
size_t copy_to_ls(uint32_t to, uint64_t from, size_t n)
{
  tagid_t tagid = mfc_tag_reserve();
  uint32_t mask, aligned;
  size_t rtn;
  
  aligned = ARE_ALIGNED(from, to);
  
  if (aligned)
    rtn = __copy_to_ls_aligned(to, from, n, tagid);
  else
    rtn = __copy_to_ls_unaligned(to, from, n, tagid);
  
  /* extra sync only required for successful aligned transfers */
  if (aligned && (rtn == n)) {
    mask = (1 << tagid);
    __ls_sync(mask);
  }
  
  (void)mfc_tag_release(tagid);
  
  return rtn;
}

/**
 * copy_from_ls - Copy of memory from LS.
 * @to: handle to effective address buffer (destination).
 * @from: pointer to local storage area buffer (source).
 * @n: number of bytes to be copied.
 *
 * Copy of memory from local storage area.
 * This operation is synchronous.
 */
size_t copy_from_ls(uint64_t to, uint32_t from, size_t n)
{
  tagid_t tagid = mfc_tag_reserve();
  uint32_t mask, aligned;
  size_t rtn;
  
  aligned = ARE_ALIGNED(to, from);
  PRINTF("aligned returns 0x%x, ea=0x%x, ls=0x%x\n", aligned, ((uint32_t) ((to) & 0xFULL)), ((uint32_t) (from) & 0xF));
  
  if (aligned)
    rtn = __copy_from_ls_aligned(to, from, n, tagid);
  else
    rtn = __copy_from_ls_unaligned(to, from, n, tagid);
  
  /* extra sync only required for successful aligned transfers */
  if (aligned && (rtn == n)) {
    mask = (1 << tagid);
    __ls_sync(mask);
  }
  (void)mfc_tag_release(tagid);
  return rtn;
}

/**
 * copy_from_ls_aligned - Same as copy_from_ls(), but much smaller
 * and more efficient. Assumes caller has checked alignment.
 * @to: handle to effective address buffer (destination).
 * @from: pointer to local storage area buffer (source).
 * @n: number of bytes to be copied.
 *
 * Copy of memory from local storage area.
 * This operation is synchronous.
 */
size_t copy_from_ls_aligned(uint64_t to, uint32_t from, size_t n)
{
  tagid_t tagid = mfc_tag_reserve();
  size_t rtn = __copy_from_ls_aligned(to, from, n, tagid);
  ls_sync(tagid);
  (void)mfc_tag_release(tagid);
  return rtn;
}

/**
 * copy_to_ls_aligned - Same as copy_to_ls(), but much smaller
 * and more efficient. Assumes caller has checked alignment.
 * @to: handle to effective address buffer (destination).
 * @from: pointer to local storage area buffer (source).
 * @n: number of bytes to be copied.
 *
 * Copy of memory to local storage area.
 * This operation is synchronous.
 */
size_t copy_to_ls_aligned(uint32_t to, uint64_t from, size_t n)
{
  tagid_t tagid = mfc_tag_reserve();
  size_t rtn = __copy_to_ls_aligned(to, from, n, tagid);
  ls_sync(tagid);
  (void)mfc_tag_release(tagid);
  return rtn;
}

