%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              

Summary:
	Library containing general routines for PPE and SPE.

Target:
	CBE-Linux SPE (HW or simulator)

Description:
	This directory builds a library (libmisc) that contains the
	following functions for PPE and SPE:

	calloc_align
		allocates and clears a memory buffer aligned to a power of
		2 alignment

	clamp
		clamps the input value to the specified range

	clamp_0_to_1
		clamps the input value to the floating point range 0.0
		to 1.0. Clamping is performed using the HW clamping provided
		by the convert routines.
		
	clamp_0_to_1_v
		clamps a vector of input value to the floating point range 0.0
		to 1.0. Clamping is performed using the HW clamping provided
		by the convert routines.

	clamp_minus1_to_1
		clamps the input value to the floating point range -1.0 to
		1.0. Clamping is performed using the HW clamping provided
		by the convert routines.
		
	clamp_minus1_to_1_v
		clamps a vector of input value to the floating point range
		-1.0 to to 1.0. Clamping is performed using the HW clamping
		provided by the convert routines.

	clamp_v
		clamps the vector input values in to the specified vector range

	free_align
		frees a memory buffer allocate by the malloc_align routine

	load_vec_unaligned
		fetches the quadword beginning at the address specified and
		returns it as an unsigned character vector. This routine
		assumes that the input pointer is not aligned to a quadword
		and therefore fetches the quadword containing the byte pointed
		to by it and the following quadword.

	malloc_align
		allocates a memory buffer aligned to the specified power of
		2 alignment

	max_float_v
		returns a component by component maximum of 2 floating SIMD
		vectors

	max_int_v
		returns a component by component maximum of 2 signed integer
		SIMD vectors

	max_vec_float3
		returns the maximum of 3 of the 4 floating-point components
		of the floating-point vector

	max_vec_float4
		returns the maximum of the 4 floating-point components of the
		floating-point vector

	max_vec_int3
		returns the maximum of 3 of the 4 integer components of the
		integer SIMD vector

	max_vec_int4
		returns the maximum of the 4 integer components of the integer
		SIMD vector

	min_float_v
		returns a component by component minimum of 2 floating SIMD
		vectors

	min_int_v
		returns a component by component minimum of 2 signed integer
		SIMD vectors

	min_vec_float3
		returns the minimum of 3 of the 4 floating-point components of
		the floating-point vector

	min_vec_float4
		returns the minimum of the 4 floating-point components of the
		floating-point vector

	min_vec_int3
		returns the minimum of 3 of the 4 integer components of the
		integer SIMD vector

	min_vec_int4
		returns the minimum of the 4 integer components of the integer
		SIMD vector

	rand_0_to_1
		generates a random floating point value in the half closed
		range [0.0, 1.0)

	rand_0_to_1_v
		generates a vector of random floating-point values in the half
		closed range [0.0, 1.0)

	rand_minus1_to_1
		generates a random floating point value in the half closed
		range [-1.0, 1.0)

	rand_minus1_to_1_v
		generates a vector of random floating-point values in the half
		closed range [-1.0, 1.0)

	rand_v
		generates a random vector word containing 4 31-bit integer
		random values. The seed is implicitly updated such that the
		next call to rand_v returns another random set of values

	realloc_align
		re-allocates a memory buffer to the new size aligned to the
		specified power of 2 alignment

	srand_v
		set the random vector seed used by the rand routines rand_v,
		rand_0_to_1_v, rand_minus1_to_1_v

	store_vec_unaligned
		store a quadword (vector) to memory at the unaligned address
		specified by the parameter ptr. Data surrounding the quadword
		is unaffected


	The following functions are SPE only:

	copy_from_ls
		perform a copy of memory from the local storage area
		
	copy_from_ls_aligned
		perform a copy of memory from the local storage area; assumes
		caller has checked alignment
		
	copy_to_ls
		perform a copy of memory to the local storage area
		
	copy_to_ls_aligned
		perform a copy of memory to the local storage area; assumes
		caller has checked alignment
		
	ls_sync
		synchronize with pending asynchronous copy operations

